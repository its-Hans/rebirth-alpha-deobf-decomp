package org.junit.experimental.results;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;

public class ResultMatchers {
   public static Matcher<PrintableResult> isSuccessful() {
      return failureCountIs(0);
   }

   public static Matcher<PrintableResult> failureCountIs(int var0) {
      return new TypeSafeMatcher<PrintableResult>(var0) {
         final int val$count;

         {
            this.val$count = var1;
         }

         @Override
         public void describeTo(Description var1) {
            var1.appendText("has " + this.val$count + " failures");
         }

         public boolean matchesSafely(PrintableResult var1) {
            return var1.failureCount() == this.val$count;
         }

         @Override
         public boolean matchesSafely(Object var1) {
            return this.matchesSafely((PrintableResult)var1);
         }
      };
   }

   public static Matcher<Object> hasSingleFailureContaining(String var0) {
      return new BaseMatcher<Object>(var0) {
         final String val$string;

         {
            this.val$string = var1;
         }

         @Override
         public boolean matches(Object var1) {
            return var1.toString().contains(this.val$string) && ResultMatchers.failureCountIs(1).matches(var1);
         }

         @Override
         public void describeTo(Description var1) {
            var1.appendText("has single failure containing " + this.val$string);
         }
      };
   }

   public static Matcher<PrintableResult> hasFailureContaining(String var0) {
      return new BaseMatcher<PrintableResult>(var0) {
         final String val$string;

         {
            this.val$string = var1;
         }

         @Override
         public boolean matches(Object var1) {
            return var1.toString().contains(this.val$string);
         }

         @Override
         public void describeTo(Description var1) {
            var1.appendText("has failure containing " + this.val$string);
         }
      };
   }
}
