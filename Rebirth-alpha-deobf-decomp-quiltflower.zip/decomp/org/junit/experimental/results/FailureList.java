package org.junit.experimental.results;

import java.util.List;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

class FailureList {
   private final List<Failure> failures;

   public FailureList(List<Failure> var1) {
      this.failures = var1;
   }

   public Result result() {
      Result var1 = new Result();
      RunListener var2 = var1.createListener();

      for(Failure var4 : this.failures) {
         RunListener var10000 = var2;
         Failure var10001 = var4;

         try {
            var10000.testFailure(var10001);
         } catch (Exception var6) {
            throw new RuntimeException("I can't believe this happened");
         }
      }

      return var1;
   }
}
