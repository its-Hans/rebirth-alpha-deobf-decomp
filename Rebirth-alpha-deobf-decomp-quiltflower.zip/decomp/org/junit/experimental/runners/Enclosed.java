package org.junit.experimental.runners;

import org.junit.runners.Suite;
import org.junit.runners.model.RunnerBuilder;

public class Enclosed extends Suite {
   public Enclosed(Class<?> var1, RunnerBuilder var2) throws Throwable {
      super(var2, var1, var1.getClasses());
   }
}
