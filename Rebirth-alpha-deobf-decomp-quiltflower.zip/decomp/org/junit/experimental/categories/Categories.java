package org.junit.experimental.categories;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.runner.Description;
import org.junit.runner.manipulation.Filter;
import org.junit.runner.manipulation.NoTestsRemainException;
import org.junit.runners.Suite;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.RunnerBuilder;

public class Categories extends Suite {
   public Categories(Class<?> var1, RunnerBuilder var2) throws InitializationError {
      super(var1, var2);
      Categories var10000 = this;
      Categories.CategoryFilter var10001 = new Categories.CategoryFilter;
      Categories.CategoryFilter var10002 = var10001;
      Categories var10003 = this;
      Class var10004 = var1;

      try {
         var10002./* $QF: Unable to resugar constructor */<init>(var10003.getIncludedCategory(var10004), this.getExcludedCategory(var1));
         var10000.filter(var10001);
      } catch (NoTestsRemainException var4) {
         throw new InitializationError(var4);
      }

      this.assertNoCategorizedDescendentsOfUncategorizeableParents(this.getDescription());
   }

   private Class<?> getIncludedCategory(Class<?> var1) {
      Categories.IncludeCategory var2 = var1.getAnnotation(Categories.IncludeCategory.class);
      return var2 == null ? null : var2.value();
   }

   private Class<?> getExcludedCategory(Class<?> var1) {
      Categories.ExcludeCategory var2 = var1.getAnnotation(Categories.ExcludeCategory.class);
      return var2 == null ? null : var2.value();
   }

   private void assertNoCategorizedDescendentsOfUncategorizeableParents(Description var1) throws InitializationError {
      if (!canHaveCategorizedChildren(var1)) {
         this.assertNoDescendantsHaveCategoryAnnotations(var1);
      }

      for(Description var3 : var1.getChildren()) {
         this.assertNoCategorizedDescendentsOfUncategorizeableParents(var3);
      }
   }

   private void assertNoDescendantsHaveCategoryAnnotations(Description var1) throws InitializationError {
      for(Description var3 : var1.getChildren()) {
         if (var3.getAnnotation(Category.class) != null) {
            throw new InitializationError("Category annotations on Parameterized classes are not supported on individual methods.");
         }

         this.assertNoDescendantsHaveCategoryAnnotations(var3);
      }
   }

   private static boolean canHaveCategorizedChildren(Description var0) {
      for(Description var2 : var0.getChildren()) {
         if (var2.getTestClass() == null) {
            return false;
         }
      }

      return true;
   }

   public static class CategoryFilter extends Filter {
      private final Class<?> fIncluded;
      private final Class<?> fExcluded;

      public static Categories.CategoryFilter include(Class<?> var0) {
         return new Categories.CategoryFilter(var0, null);
      }

      public CategoryFilter(Class<?> var1, Class<?> var2) {
         this.fIncluded = var1;
         this.fExcluded = var2;
      }

      @Override
      public String describe() {
         return "category " + this.fIncluded;
      }

      @Override
      public boolean shouldRun(Description var1) {
         if (this.hasCorrectCategoryAnnotation(var1)) {
            return true;
         } else {
            for(Description var3 : var1.getChildren()) {
               if (this.shouldRun(var3)) {
                  return true;
               }
            }

            return false;
         }
      }

      private boolean hasCorrectCategoryAnnotation(Description var1) {
         List var2 = this.categories(var1);
         if (var2.isEmpty()) {
            return this.fIncluded == null;
         } else {
            for(Class var4 : var2) {
               if (this.fExcluded != null && this.fExcluded.isAssignableFrom(var4)) {
                  return false;
               }
            }

            for(Class var6 : var2) {
               if (this.fIncluded == null || this.fIncluded.isAssignableFrom(var6)) {
                  return true;
               }
            }

            return false;
         }
      }

      private List<Class<?>> categories(Description var1) {
         ArrayList var2 = new ArrayList();
         var2.addAll(Arrays.asList(this.directCategories(var1)));
         var2.addAll(Arrays.asList(this.directCategories(this.parentDescription(var1))));
         return var2;
      }

      private Description parentDescription(Description var1) {
         Class var2 = var1.getTestClass();
         return var2 == null ? null : Description.createSuiteDescription(var2);
      }

      private Class<?>[] directCategories(Description var1) {
         if (var1 == null) {
            return new Class[0];
         } else {
            Category var2 = var1.getAnnotation(Category.class);
            return var2 == null ? new Class[0] : var2.value();
         }
      }
   }

   @Retention(RetentionPolicy.RUNTIME)
   public @interface ExcludeCategory {
      Class<?> value();
   }

   @Retention(RetentionPolicy.RUNTIME)
   public @interface IncludeCategory {
      Class<?> value();
   }
}
