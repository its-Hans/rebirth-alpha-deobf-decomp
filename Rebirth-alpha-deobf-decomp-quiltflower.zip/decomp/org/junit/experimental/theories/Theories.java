package org.junit.experimental.theories;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.junit.experimental.theories.internal.Assignments;
import org.junit.experimental.theories.internal.ParameterizedAssertionError;
import org.junit.internal.AssumptionViolatedException;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;
import org.junit.runners.model.TestClass;

public class Theories extends BlockJUnit4ClassRunner {
   public Theories(Class<?> var1) throws InitializationError {
      super(var1);
   }

   @Override
   protected void collectInitializationErrors(List<Throwable> var1) {
      super.collectInitializationErrors(var1);
      this.validateDataPointFields(var1);
   }

   private void validateDataPointFields(List<Throwable> var1) {
      Field[] var2 = this.getTestClass().getJavaClass().getDeclaredFields();

      for(Field var6 : var2) {
         if (var6.getAnnotation(DataPoint.class) != null && !Modifier.isStatic(var6.getModifiers())) {
            var1.add(new Error("DataPoint field " + var6.getName() + " must be static"));
         }
      }
   }

   @Override
   protected void validateConstructor(List<Throwable> var1) {
      this.validateOnlyOneConstructor(var1);
   }

   @Override
   protected void validateTestMethods(List<Throwable> var1) {
      for(FrameworkMethod var3 : this.computeTestMethods()) {
         if (var3.getAnnotation(Theory.class) != null) {
            var3.validatePublicVoid(false, var1);
         } else {
            var3.validatePublicVoidNoArg(false, var1);
         }
      }
   }

   @Override
   protected List<FrameworkMethod> computeTestMethods() {
      List var1 = super.computeTestMethods();
      List var2 = this.getTestClass().getAnnotatedMethods(Theory.class);
      var1.removeAll(var2);
      var1.addAll(var2);
      return var1;
   }

   @Override
   public Statement methodBlock(FrameworkMethod var1) {
      return new Theories.TheoryAnchor(var1, this.getTestClass());
   }

   public static class TheoryAnchor extends Statement {
      private int successes = 0;
      private FrameworkMethod fTestMethod;
      private TestClass fTestClass;
      private List<AssumptionViolatedException> fInvalidParameters = new ArrayList<>();

      public TheoryAnchor(FrameworkMethod var1, TestClass var2) {
         this.fTestMethod = var1;
         this.fTestClass = var2;
      }

      private TestClass getTestClass() {
         return this.fTestClass;
      }

      @Override
      public void evaluate() throws Throwable {
         this.runWithAssignment(Assignments.allUnassigned(this.fTestMethod.getMethod(), this.getTestClass()));
         if (this.successes == 0) {
            Assert.fail("Never found parameters that satisfied method assumptions.  Violated assumptions: " + this.fInvalidParameters);
         }
      }

      protected void runWithAssignment(Assignments var1) throws Throwable {
         if (!var1.isComplete()) {
            this.runWithIncompleteAssignment(var1);
         } else {
            this.runWithCompleteAssignment(var1);
         }
      }

      protected void runWithIncompleteAssignment(Assignments var1) throws InstantiationException, IllegalAccessException, Throwable {
         for(PotentialAssignment var3 : var1.potentialsForNextUnassigned()) {
            this.runWithAssignment(var1.assignNext(var3));
         }
      }

      protected void runWithCompleteAssignment(Assignments var1) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, Throwable {
         (new BlockJUnit4ClassRunner(this, this.getTestClass().getJavaClass(), var1) {
               final Assignments val$complete;
               final Theories.TheoryAnchor this$0;
   
               {
                  this.this$0 = var1;
                  this.val$complete = var3;
               }
   
               @Override
               protected void collectInitializationErrors(List<Throwable> var1) {
               }
   
               @Override
               public Statement methodBlock(FrameworkMethod var1) {
                  Statement var2 = super.methodBlock(var1);
                  return new Statement(this, var2) {
                     final Statement val$statement;
                     final <undefinedtype> this$1;
   
                     {
                        this.this$1 = var1;
                        this.val$statement = var2;
                     }
   
                     // $QF: Could not properly define all variable types!
                     // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
                     @Override
                     public void evaluate() throws Throwable {
                        <undefinedtype> var10000 = this;
   
                        AssumptionViolatedException var1;
                        try {
                           Statement var4 = var10000.val$statement;
   
                           try {
                              var4.evaluate();
                              this.this$1.this$0.handleDataPointSuccess();
                              return;
                           } catch (AssumptionViolatedException var2) {
                              var1 = var2;
                           }
                        } catch (Throwable var3) {
                           this.this$1
                              .this$0
                              .reportParameterizedError(
                                 var3, this.this$1.val$complete.getArgumentStrings(Theories.TheoryAnchor.access$000(this.this$1.this$0))
                              );
                           return;
                        }
   
                        this.this$1.this$0.handleAssumptionViolation(var1);
                     }
                  };
               }
   
               @Override
               protected Statement methodInvoker(FrameworkMethod var1, Object var2) {
                  return Theories.TheoryAnchor.access$100(this.this$0, var1, this.val$complete, var2);
               }
   
               @Override
               public Object createTest() throws Exception {
                  return this.getTestClass()
                     .getOnlyConstructor()
                     .newInstance(this.val$complete.getConstructorArguments(Theories.TheoryAnchor.access$000(this.this$0)));
               }
            })
            .methodBlock(this.fTestMethod)
            .evaluate();
      }

      private Statement methodCompletesWithParameters(FrameworkMethod var1, Assignments var2, Object var3) {
         return new Statement(this, var2, var1, var3) {
            final Assignments val$complete;
            final FrameworkMethod val$method;
            final Object val$freshInstance;
            final Theories.TheoryAnchor this$0;

            {
               this.this$0 = var1;
               this.val$complete = var2;
               this.val$method = var3;
               this.val$freshInstance = var4;
            }

            @Override
            public void evaluate() throws Throwable {
               Assignments var10000 = this.val$complete;
               Theories.TheoryAnchor var10001 = this.this$0;

               try {
                  Object[] var1 = var10000.getMethodArguments(Theories.TheoryAnchor.access$000(var10001));
                  this.val$method.invokeExplosively(this.val$freshInstance, var1);
               } catch (PotentialAssignment.CouldNotGenerateValueException var2) {
               }
            }
         };
      }

      protected void handleAssumptionViolation(AssumptionViolatedException var1) {
         this.fInvalidParameters.add(var1);
      }

      protected void reportParameterizedError(Throwable var1, Object... var2) throws Throwable {
         if (var2.length == 0) {
            throw var1;
         } else {
            throw new ParameterizedAssertionError(var1, this.fTestMethod.getName(), var2);
         }
      }

      private boolean nullsOk() {
         Theory var1 = this.fTestMethod.getMethod().getAnnotation(Theory.class);
         return var1 == null ? false : var1.nullsAccepted();
      }

      protected void handleDataPointSuccess() {
         ++this.successes;
      }

      static boolean access$000(Theories.TheoryAnchor var0) {
         return var0.nullsOk();
      }

      static Statement access$100(Theories.TheoryAnchor var0, FrameworkMethod var1, Assignments var2, Object var3) {
         return var0.methodCompletesWithParameters(var1, var2, var3);
      }
   }
}
