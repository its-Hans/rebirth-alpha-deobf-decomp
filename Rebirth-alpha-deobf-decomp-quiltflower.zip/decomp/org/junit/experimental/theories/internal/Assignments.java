package org.junit.experimental.theories.internal;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.ParametersSuppliedBy;
import org.junit.experimental.theories.PotentialAssignment;
import org.junit.runners.model.TestClass;

public class Assignments {
   private List<PotentialAssignment> fAssigned;
   private final List<ParameterSignature> fUnassigned;
   private final TestClass fClass;

   private Assignments(List<PotentialAssignment> var1, List<ParameterSignature> var2, TestClass var3) {
      this.fUnassigned = var2;
      this.fAssigned = var1;
      this.fClass = var3;
   }

   public static Assignments allUnassigned(Method var0, TestClass var1) throws Exception {
      List var2 = ParameterSignature.signatures(var1.getOnlyConstructor());
      var2.addAll(ParameterSignature.signatures(var0));
      return new Assignments(new ArrayList<>(), var2, var1);
   }

   public boolean isComplete() {
      return this.fUnassigned.size() == 0;
   }

   public ParameterSignature nextUnassigned() {
      return this.fUnassigned.get(0);
   }

   public Assignments assignNext(PotentialAssignment var1) {
      ArrayList var2 = new ArrayList<>(this.fAssigned);
      var2.add(var1);
      return new Assignments(var2, this.fUnassigned.subList(1, this.fUnassigned.size()), this.fClass);
   }

   public Object[] getActualValues(int var1, int var2, boolean var3) throws PotentialAssignment.CouldNotGenerateValueException {
      Object[] var4 = new Object[var2 - var1];

      for(int var5 = var1; var5 < var2; ++var5) {
         Object var6 = this.fAssigned.get(var5).getValue();
         if (var6 == null && !var3) {
            throw new PotentialAssignment.CouldNotGenerateValueException();
         }

         var4[var5 - var1] = var6;
      }

      return var4;
   }

   public List<PotentialAssignment> potentialsForNextUnassigned() throws InstantiationException, IllegalAccessException {
      ParameterSignature var1 = this.nextUnassigned();
      return this.getSupplier(var1).getValueSources(var1);
   }

   public ParameterSupplier getSupplier(ParameterSignature var1) throws InstantiationException, IllegalAccessException {
      ParameterSupplier var2 = this.getAnnotatedSupplier(var1);
      return (ParameterSupplier)(var2 != null ? var2 : new AllMembersSupplier(this.fClass));
   }

   public ParameterSupplier getAnnotatedSupplier(ParameterSignature var1) throws InstantiationException, IllegalAccessException {
      ParametersSuppliedBy var2 = var1.findDeepAnnotation(ParametersSuppliedBy.class);
      return var2 == null ? null : var2.value().newInstance();
   }

   public Object[] getConstructorArguments(boolean var1) throws PotentialAssignment.CouldNotGenerateValueException {
      return this.getActualValues(0, this.getConstructorParameterCount(), var1);
   }

   public Object[] getMethodArguments(boolean var1) throws PotentialAssignment.CouldNotGenerateValueException {
      return this.getActualValues(this.getConstructorParameterCount(), this.fAssigned.size(), var1);
   }

   public Object[] getAllArguments(boolean var1) throws PotentialAssignment.CouldNotGenerateValueException {
      return this.getActualValues(0, this.fAssigned.size(), var1);
   }

   private int getConstructorParameterCount() {
      List var1 = ParameterSignature.signatures(this.fClass.getOnlyConstructor());
      return var1.size();
   }

   public Object[] getArgumentStrings(boolean var1) throws PotentialAssignment.CouldNotGenerateValueException {
      Object[] var2 = new Object[this.fAssigned.size()];

      for(int var3 = 0; var3 < var2.length; ++var3) {
         var2[var3] = this.fAssigned.get(var3).getDescription();
      }

      return var2;
   }
}
