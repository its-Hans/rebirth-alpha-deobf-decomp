package org.junit.experimental.theories.internal;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

public class ParameterizedAssertionError extends RuntimeException {
   private static final long serialVersionUID = 1L;

   public ParameterizedAssertionError(Throwable var1, String var2, Object... var3) {
      super(String.format("%s(%s)", var2, join(", ", var3)), var1);
   }

   @Override
   public boolean equals(Object var1) {
      return this.toString().equals(var1.toString());
   }

   public static String join(String var0, Object... var1) {
      return join(var0, Arrays.asList(var1));
   }

   public static String join(String var0, Collection<Object> var1) {
      StringBuffer var2 = new StringBuffer();
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         Object var4 = var3.next();
         var2.append(stringValueOf(var4));
         if (var3.hasNext()) {
            var2.append(var0);
         }
      }

      return var2.toString();
   }

   private static String stringValueOf(Object var0) {
      Object var10000 = var0;

      try {
         return String.valueOf(var10000);
      } catch (Throwable var2) {
         return "[toString failed]";
      }
   }
}
