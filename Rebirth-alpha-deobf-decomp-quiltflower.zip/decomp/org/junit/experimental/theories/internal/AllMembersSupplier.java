package org.junit.experimental.theories.internal;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.PotentialAssignment;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.TestClass;

public class AllMembersSupplier extends ParameterSupplier {
   private final TestClass fClass;

   public AllMembersSupplier(TestClass var1) {
      this.fClass = var1;
   }

   @Override
   public List<PotentialAssignment> getValueSources(ParameterSignature var1) {
      ArrayList var2 = new ArrayList();
      this.addFields(var1, var2);
      this.addSinglePointMethods(var1, var2);
      this.addMultiPointMethods(var2);
      return var2;
   }

   private void addMultiPointMethods(List<PotentialAssignment> var1) {
      for(FrameworkMethod var3 : this.fClass.getAnnotatedMethods(DataPoints.class)) {
         AllMembersSupplier var10000 = this;
         FrameworkMethod var10001 = var3;

         try {
            var10000.addArrayValues(var10001.getName(), var1, var3.invokeExplosively(null));
         } catch (Throwable var5) {
         }
      }
   }

   private void addSinglePointMethods(ParameterSignature var1, List<PotentialAssignment> var2) {
      for(FrameworkMethod var4 : this.fClass.getAnnotatedMethods(DataPoint.class)) {
         Class var5 = var1.getType();
         if (var4.producesType(var5)) {
            var2.add(new AllMembersSupplier.MethodParameterValue(var4));
         }
      }
   }

   private void addFields(ParameterSignature var1, List<PotentialAssignment> var2) {
      for(Field var6 : this.fClass.getJavaClass().getFields()) {
         if (Modifier.isStatic(var6.getModifiers())) {
            Class var7 = var6.getType();
            if (var1.canAcceptArrayType(var7) && var6.getAnnotation(DataPoints.class) != null) {
               this.addArrayValues(var6.getName(), var2, this.getStaticFieldValue(var6));
            } else if (var1.canAcceptType(var7) && var6.getAnnotation(DataPoint.class) != null) {
               var2.add(PotentialAssignment.forValue(var6.getName(), this.getStaticFieldValue(var6)));
            }
         }
      }
   }

   private void addArrayValues(String var1, List<PotentialAssignment> var2, Object var3) {
      for(int var4 = 0; var4 < Array.getLength(var3); ++var4) {
         var2.add(PotentialAssignment.forValue(var1 + "[" + var4 + "]", Array.get(var3, var4)));
      }
   }

   private Object getStaticFieldValue(Field var1) {
      Field var10000 = var1;
      Object var10001 = null;

      try {
         return var10000.get(var10001);
      } catch (IllegalAccessException | IllegalArgumentException var3) {
         throw new RuntimeException("unexpected: field from getClass doesn't exist on object");
      }
   }

   static class MethodParameterValue extends PotentialAssignment {
      private final FrameworkMethod fMethod;

      private MethodParameterValue(FrameworkMethod var1) {
         this.fMethod = var1;
      }

      @Override
      public Object getValue() throws PotentialAssignment.CouldNotGenerateValueException {
         // $QF: Couldn't be decompiled
         // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
         // java.lang.NullPointerException
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.graphToStatement(DomHelper.java:91)
         //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:207)
         //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:141)
         //
         // Bytecode:
         // 00: aload 0
         // 01: getfield org/junit/experimental/theories/internal/AllMembersSupplier$MethodParameterValue.fMethod Lorg/junit/runners/model/FrameworkMethod;
         // 04: aconst_null
         // 05: bipush 0
         // 06: anewarray 32
         // 09: invokevirtual org/junit/runners/model/FrameworkMethod.invokeExplosively (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
         // 0c: areturn
         // 0d: astore 1
         // 0e: new java/lang/RuntimeException
         // 11: dup
         // 12: ldc "unexpected: argument length is checked"
         // 14: invokespecial java/lang/RuntimeException.<init> (Ljava/lang/String;)V
         // 17: athrow
         // 18: athrow
         // 19: nop
         // 1a: nop
         // 1b: nop
         // 1c: nop
         // 1d: nop
         // 1e: nop
         // 1f: nop
         // 20: nop
         // 21: nop
         // 22: athrow
         // 23: athrow
         // 24: nop
         // 25: nop
         // 26: nop
         // 27: nop
         // 28: nop
         // 29: nop
         // 2a: nop
         // 2b: athrow
      }

      @Override
      public String getDescription() throws PotentialAssignment.CouldNotGenerateValueException {
         return this.fMethod.getName();
      }

      MethodParameterValue(FrameworkMethod var1, Object var2) {
         this(var1);
      }
   }
}
