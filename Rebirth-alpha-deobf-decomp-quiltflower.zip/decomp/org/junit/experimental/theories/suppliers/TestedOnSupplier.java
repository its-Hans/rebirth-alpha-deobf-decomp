package org.junit.experimental.theories.suppliers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.PotentialAssignment;

public class TestedOnSupplier extends ParameterSupplier {
   @Override
   public List<PotentialAssignment> getValueSources(ParameterSignature var1) {
      ArrayList var2 = new ArrayList();
      TestedOn var3 = var1.getAnnotation(TestedOn.class);
      int[] var4 = var3.ints();

      for(int var8 : var4) {
         var2.add(PotentialAssignment.forValue(Arrays.asList(var4).toString(), var8));
      }

      return var2;
   }
}
