package org.junit.experimental.theories;

public abstract class PotentialAssignment {
   public static PotentialAssignment forValue(String var0, Object var1) {
      return new PotentialAssignment(var1, var0) {
         final Object val$value;
         final String val$name;

         {
            this.val$value = var1;
            this.val$name = var2;
         }

         @Override
         public Object getValue() throws PotentialAssignment.CouldNotGenerateValueException {
            return this.val$value;
         }

         @Override
         public String toString() {
            return String.format("[%s]", this.val$value);
         }

         @Override
         public String getDescription() throws PotentialAssignment.CouldNotGenerateValueException {
            return this.val$name;
         }
      };
   }

   public abstract Object getValue() throws PotentialAssignment.CouldNotGenerateValueException;

   public abstract String getDescription() throws PotentialAssignment.CouldNotGenerateValueException;

   public static class CouldNotGenerateValueException extends Exception {
      private static final long serialVersionUID = 1L;
   }
}
