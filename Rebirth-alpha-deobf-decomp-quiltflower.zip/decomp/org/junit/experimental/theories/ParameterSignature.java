package org.junit.experimental.theories;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ParameterSignature {
   private final Class<?> type;
   private final Annotation[] annotations;

   public static ArrayList<ParameterSignature> signatures(Method var0) {
      return signatures(var0.getParameterTypes(), var0.getParameterAnnotations());
   }

   public static List<ParameterSignature> signatures(Constructor<?> var0) {
      return signatures(var0.getParameterTypes(), var0.getParameterAnnotations());
   }

   private static ArrayList<ParameterSignature> signatures(Class<?>[] var0, Annotation[][] var1) {
      ArrayList var2 = new ArrayList();

      for(int var3 = 0; var3 < var0.length; ++var3) {
         var2.add(new ParameterSignature(var0[var3], var1[var3]));
      }

      return var2;
   }

   private ParameterSignature(Class<?> var1, Annotation[] var2) {
      this.type = var1;
      this.annotations = var2;
   }

   public boolean canAcceptType(Class<?> var1) {
      return this.type.isAssignableFrom(var1);
   }

   public Class<?> getType() {
      return this.type;
   }

   public List<Annotation> getAnnotations() {
      return Arrays.asList(this.annotations);
   }

   public boolean canAcceptArrayType(Class<?> var1) {
      return var1.isArray() && this.canAcceptType(var1.getComponentType());
   }

   public boolean hasAnnotation(Class<? extends Annotation> var1) {
      return this.getAnnotation(var1) != null;
   }

   public <T extends Annotation> T findDeepAnnotation(Class<T> var1) {
      Annotation[] var2 = this.annotations;
      return this.findDeepAnnotation(var2, var1, 3);
   }

   private <T extends Annotation> T findDeepAnnotation(Annotation[] var1, Class<T> var2, int var3) {
      if (var3 == 0) {
         return null;
      } else {
         for(Annotation var7 : var1) {
            if (var2.isInstance(var7)) {
               return (T)var2.cast(var7);
            }

            Annotation var8 = this.findDeepAnnotation(var7.annotationType().getAnnotations(), var2, var3 - 1);
            if (var8 != null) {
               return (T)var2.cast(var8);
            }
         }

         return null;
      }
   }

   public <T extends Annotation> T getAnnotation(Class<T> var1) {
      for(Annotation var3 : this.getAnnotations()) {
         if (var1.isInstance(var3)) {
            return (T)var1.cast(var3);
         }
      }

      return null;
   }
}
