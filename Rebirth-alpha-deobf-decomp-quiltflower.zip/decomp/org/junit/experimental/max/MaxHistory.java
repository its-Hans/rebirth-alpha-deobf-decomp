package org.junit.experimental.max;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

public class MaxHistory implements Serializable {
   private static final long serialVersionUID = 1L;
   private final Map<String, Long> fDurations = new HashMap<>();
   private final Map<String, Long> fFailureTimestamps = new HashMap<>();
   private final File fHistoryStore;

   public static MaxHistory forFolder(File var0) {
      if (var0.exists()) {
         File var10000 = var0;

         try {
            return readHistory(var10000);
         } catch (CouldNotReadCoreException var2) {
            var2.printStackTrace();
            var0.delete();
         }
      }

      return new MaxHistory(var0);
   }

   private static MaxHistory readHistory(File param0) throws CouldNotReadCoreException {
      // $QF: Couldn't be decompiled
      // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.NullPointerException
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.graphToStatement(DomHelper.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:207)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:141)
      //
      // Bytecode:
      // 00: new java/io/FileInputStream
      // 03: dup
      // 04: aload 0
      // 05: invokespecial java/io/FileInputStream.<init> (Ljava/io/File;)V
      // 08: astore 1
      // 09: new java/io/ObjectInputStream
      // 0c: dup
      // 0d: aload 1
      // 0e: invokespecial java/io/ObjectInputStream.<init> (Ljava/io/InputStream;)V
      // 11: astore 2
      // 12: aload 2
      // 13: invokevirtual java/io/ObjectInputStream.readObject ()Ljava/lang/Object;
      // 16: checkcast org/junit/experimental/max/MaxHistory
      // 19: astore 3
      // 1a: aload 2
      // 1b: invokevirtual java/io/ObjectInputStream.close ()V
      // 1e: aload 1
      // 1f: invokevirtual java/io/FileInputStream.close ()V
      // 22: aload 3
      // 23: areturn
      // 24: astore 4
      // 26: aload 2
      // 27: invokevirtual java/io/ObjectInputStream.close ()V
      // 2a: aload 4
      // 2c: athrow
      // 2d: astore 5
      // 2f: aload 1
      // 30: invokevirtual java/io/FileInputStream.close ()V
      // 33: aload 5
      // 35: athrow
      // 36: astore 1
      // 37: new org/junit/experimental/max/CouldNotReadCoreException
      // 3a: dup
      // 3b: aload 1
      // 3c: invokespecial org/junit/experimental/max/CouldNotReadCoreException.<init> (Ljava/lang/Throwable;)V
      // 3f: athrow
   }

   private MaxHistory(File var1) {
      this.fHistoryStore = var1;
   }

   private void save() throws IOException {
      ObjectOutputStream var1 = new ObjectOutputStream(new FileOutputStream(this.fHistoryStore));
      var1.writeObject(this);
      var1.close();
   }

   Long getFailureTimestamp(Description var1) {
      return this.fFailureTimestamps.get(var1.toString());
   }

   void putTestFailureTimestamp(Description var1, long var2) {
      this.fFailureTimestamps.put(var1.toString(), var2);
   }

   boolean isNewTest(Description var1) {
      return !this.fDurations.containsKey(var1.toString());
   }

   Long getTestDuration(Description var1) {
      return this.fDurations.get(var1.toString());
   }

   void putTestDuration(Description var1, long var2) {
      this.fDurations.put(var1.toString(), var2);
   }

   public RunListener listener() {
      return new MaxHistory.RememberingListener(this);
   }

   public Comparator<Description> testComparator() {
      return new MaxHistory.TestComparator(this);
   }

   static void access$000(MaxHistory var0) throws IOException {
      var0.save();
   }

   private final class RememberingListener extends RunListener {
      private long overallStart;
      private Map<Description, Long> starts;
      final MaxHistory this$0;

      private RememberingListener(MaxHistory var1) {
         this.this$0 = var1;
         this.overallStart = System.currentTimeMillis();
         this.starts = new HashMap<>();
      }

      @Override
      public void testStarted(Description var1) throws Exception {
         this.starts.put(var1, System.nanoTime());
      }

      @Override
      public void testFinished(Description var1) throws Exception {
         long var2 = System.nanoTime();
         long var4 = this.starts.get(var1);
         this.this$0.putTestDuration(var1, var2 - var4);
      }

      @Override
      public void testFailure(Failure var1) throws Exception {
         this.this$0.putTestFailureTimestamp(var1.getDescription(), this.overallStart);
      }

      @Override
      public void testRunFinished(Result var1) throws Exception {
         MaxHistory.access$000(this.this$0);
      }

      RememberingListener(MaxHistory var1, Object var2) {
         this(var1);
      }
   }

   private class TestComparator implements Comparator<Description> {
      final MaxHistory this$0;

      private TestComparator(MaxHistory var1) {
         this.this$0 = var1;
      }

      public int compare(Description var1, Description var2) {
         if (this.this$0.isNewTest(var1)) {
            return -1;
         } else if (this.this$0.isNewTest(var2)) {
            return 1;
         } else {
            int var3 = this.getFailure(var2).compareTo(this.getFailure(var1));
            return var3 != 0 ? var3 : this.this$0.getTestDuration(var1).compareTo(this.this$0.getTestDuration(var2));
         }
      }

      private Long getFailure(Description var1) {
         Long var2 = this.this$0.getFailureTimestamp(var1);
         return var2 == null ? 0L : var2;
      }

      @Override
      public int compare(Object var1, Object var2) {
         return this.compare((Description)var1, (Description)var2);
      }

      TestComparator(MaxHistory var1, Object var2) {
         this(var1);
      }
   }
}
