package org.junit.experimental.max;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import junit.framework.TestSuite;
import org.junit.internal.requests.SortingRequest;
import org.junit.internal.runners.ErrorReportingRunner;
import org.junit.internal.runners.JUnit38ClassRunner;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
import org.junit.runner.Runner;
import org.junit.runners.Suite;
import org.junit.runners.model.InitializationError;

public class MaxCore {
   private static final String MALFORMED_JUNIT_3_TEST_CLASS_PREFIX = "malformed JUnit 3 test class: ";
   private final MaxHistory fHistory;

   @Deprecated
   public static MaxCore forFolder(String var0) {
      return storedLocally(new File(var0));
   }

   public static MaxCore storedLocally(File var0) {
      return new MaxCore(var0);
   }

   private MaxCore(File var1) {
      this.fHistory = MaxHistory.forFolder(var1);
   }

   public Result run(Class<?> var1) {
      return this.run(Request.aClass(var1));
   }

   public Result run(Request var1) {
      return this.run(var1, new JUnitCore());
   }

   public Result run(Request var1, JUnitCore var2) {
      var2.addListener(this.fHistory.listener());
      return var2.run(this.sortRequest(var1).getRunner());
   }

   public Request sortRequest(Request var1) {
      if (var1 instanceof SortingRequest) {
         return var1;
      } else {
         List var2 = this.findLeaves(var1);
         Collections.sort(var2, this.fHistory.testComparator());
         return this.constructLeafRequest(var2);
      }
   }

   private Request constructLeafRequest(List<Description> var1) {
      ArrayList var2 = new ArrayList();

      for(Description var4 : var1) {
         var2.add(this.buildRunner(var4));
      }

      return new Request(this, var2) {
         final List val$runners;
         final MaxCore this$0;

         {
            this.this$0 = var1;
            this.val$runners = var2;
         }

         // $QF: Could not properly define all variable types!
         // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
         @Override
         public Runner getRunner() {
            Suite var10000 = new Suite() {
               final <undefinedtype> this$1;

               {
                  this.this$1 = var1;
               }
            };
            Suite var10001 = var10000;
            <undefinedtype> var10002 = this;
            Object var10003 = null;
            List var10004 = this.val$runners;

            try {
               var10001./* $QF: Unable to resugar constructor */<init>(var10002, (Class)var10003, var10004);
               return var10000;
            } catch (InitializationError var2) {
               return new ErrorReportingRunner(null, var2);
            }
         }
      };
   }

   private Runner buildRunner(Description var1) {
      if (var1.toString().equals("TestSuite with 0 tests")) {
         return Suite.emptySuite();
      } else if (var1.toString().startsWith("malformed JUnit 3 test class: ")) {
         return new JUnit38ClassRunner(new TestSuite(this.getMalformedTestClass(var1)));
      } else {
         Class var2 = var1.getTestClass();
         if (var2 == null) {
            throw new RuntimeException("Can't build a runner from description [" + var1 + "]");
         } else {
            String var3 = var1.getMethodName();
            return var3 == null ? Request.aClass(var2).getRunner() : Request.method(var2, var3).getRunner();
         }
      }
   }

   private Class<?> getMalformedTestClass(Description var1) {
      Description var10000 = var1;

      try {
         return Class.forName(var10000.toString().replace("malformed JUnit 3 test class: ", ""));
      } catch (ClassNotFoundException var3) {
         return null;
      }
   }

   public List<Description> sortedLeavesForTest(Request var1) {
      return this.findLeaves(this.sortRequest(var1));
   }

   private List<Description> findLeaves(Request var1) {
      ArrayList var2 = new ArrayList();
      this.findLeaves(null, var1.getRunner().getDescription(), var2);
      return var2;
   }

   private void findLeaves(Description var1, Description var2, List<Description> var3) {
      if (var2.getChildren().isEmpty()) {
         if (var2.toString().equals("warning(junit.framework.TestSuite$1)")) {
            var3.add(Description.createSuiteDescription("malformed JUnit 3 test class: " + var1));
         } else {
            var3.add(var2);
         }
      } else {
         for(Description var5 : var2.getChildren()) {
            this.findLeaves(var2, var5, var3);
         }
      }
   }
}
