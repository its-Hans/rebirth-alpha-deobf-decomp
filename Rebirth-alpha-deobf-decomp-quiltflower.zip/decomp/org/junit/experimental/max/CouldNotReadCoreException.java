package org.junit.experimental.max;

public class CouldNotReadCoreException extends Exception {
   private static final long serialVersionUID = 1L;

   public CouldNotReadCoreException(Throwable var1) {
      super(var1);
   }
}
