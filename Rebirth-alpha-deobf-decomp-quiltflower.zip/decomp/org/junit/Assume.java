package org.junit;

import java.util.Arrays;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matcher;
import org.junit.internal.AssumptionViolatedException;
import org.junit.internal.matchers.Each;

public class Assume {
   public static void assumeTrue(boolean var0) {
      assumeThat(var0, CoreMatchers.is(true));
   }

   public static void assumeNotNull(Object... var0) {
      assumeThat(Arrays.asList(var0), Each.each(CoreMatchers.notNullValue()));
   }

   public static <T> void assumeThat(T var0, Matcher<T> var1) {
      if (!var1.matches(var0)) {
         throw new AssumptionViolatedException(var0, var1);
      }
   }

   public static void assumeNoException(Throwable var0) {
      assumeThat(var0, CoreMatchers.nullValue());
   }
}
