package org.junit;

import org.hamcrest.Matcher;
import org.hamcrest.StringDescription;
import org.junit.internal.ArrayComparisonFailure;
import org.junit.internal.ExactComparisonCriteria;
import org.junit.internal.InexactComparisonCriteria;

public class Assert {
   protected Assert() {
   }

   public static void assertTrue(String var0, boolean var1) {
      if (!var1) {
         fail(var0);
      }
   }

   public static void assertTrue(boolean var0) {
      assertTrue(null, var0);
   }

   public static void assertFalse(String var0, boolean var1) {
      assertTrue(var0, !var1);
   }

   public static void assertFalse(boolean var0) {
      assertFalse(null, var0);
   }

   public static void fail(String var0) {
      if (var0 == null) {
         throw new AssertionError();
      } else {
         throw new AssertionError(var0);
      }
   }

   public static void fail() {
      fail(null);
   }

   public static void assertEquals(String var0, Object var1, Object var2) {
      if (var1 != null || var2 != null) {
         if (var1 == null || !isEquals(var1, var2)) {
            if (var1 instanceof String && var2 instanceof String) {
               String var3 = var0 == null ? "" : var0;
               throw new ComparisonFailure(var3, (String)var1, (String)var2);
            } else {
               failNotEquals(var0, var1, var2);
            }
         }
      }
   }

   private static boolean isEquals(Object var0, Object var1) {
      return var0.equals(var1);
   }

   public static void assertEquals(Object var0, Object var1) {
      assertEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, Object[] var1, Object[] var2) throws ArrayComparisonFailure {
      internalArrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(Object[] var0, Object[] var1) {
      assertArrayEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, byte[] var1, byte[] var2) throws ArrayComparisonFailure {
      internalArrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(byte[] var0, byte[] var1) {
      assertArrayEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, char[] var1, char[] var2) throws ArrayComparisonFailure {
      internalArrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(char[] var0, char[] var1) {
      assertArrayEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, short[] var1, short[] var2) throws ArrayComparisonFailure {
      internalArrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(short[] var0, short[] var1) {
      assertArrayEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, int[] var1, int[] var2) throws ArrayComparisonFailure {
      internalArrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(int[] var0, int[] var1) {
      assertArrayEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, long[] var1, long[] var2) throws ArrayComparisonFailure {
      internalArrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(long[] var0, long[] var1) {
      assertArrayEquals(null, var0, var1);
   }

   public static void assertArrayEquals(String var0, double[] var1, double[] var2, double var3) throws ArrayComparisonFailure {
      new InexactComparisonCriteria(var3).arrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(double[] var0, double[] var1, double var2) {
      assertArrayEquals(null, var0, var1, var2);
   }

   public static void assertArrayEquals(String var0, float[] var1, float[] var2, float var3) throws ArrayComparisonFailure {
      new InexactComparisonCriteria((double)var3).arrayEquals(var0, var1, var2);
   }

   public static void assertArrayEquals(float[] var0, float[] var1, float var2) {
      assertArrayEquals(null, var0, var1, var2);
   }

   private static void internalArrayEquals(String var0, Object var1, Object var2) throws ArrayComparisonFailure {
      new ExactComparisonCriteria().arrayEquals(var0, var1, var2);
   }

   public static void assertEquals(String var0, double var1, double var3, double var5) {
      if (Double.compare(var1, var3) != 0) {
         if (!(Math.abs(var1 - var3) <= var5)) {
            failNotEquals(var0, new Double(var1), new Double(var3));
         }
      }
   }

   public static void assertEquals(long var0, long var2) {
      assertEquals(null, var0, var2);
   }

   public static void assertEquals(String var0, long var1, long var3) {
      assertEquals(var0, var1, Long.valueOf(var3));
   }

   @Deprecated
   public static void assertEquals(double var0, double var2) {
      assertEquals(null, var0, var2);
   }

   @Deprecated
   public static void assertEquals(String var0, double var1, double var3) {
      fail("Use assertEquals(expected, actual, delta) to compare floating-point numbers");
   }

   public static void assertEquals(double var0, double var2, double var4) {
      assertEquals(null, var0, var2, var4);
   }

   public static void assertNotNull(String var0, Object var1) {
      assertTrue(var0, var1 != null);
   }

   public static void assertNotNull(Object var0) {
      assertNotNull(null, var0);
   }

   public static void assertNull(String var0, Object var1) {
      assertTrue(var0, var1 == null);
   }

   public static void assertNull(Object var0) {
      assertNull(null, var0);
   }

   public static void assertSame(String var0, Object var1, Object var2) {
      if (var1 != var2) {
         failNotSame(var0, var1, var2);
      }
   }

   public static void assertSame(Object var0, Object var1) {
      assertSame(null, var0, var1);
   }

   public static void assertNotSame(String var0, Object var1, Object var2) {
      if (var1 == var2) {
         failSame(var0);
      }
   }

   public static void assertNotSame(Object var0, Object var1) {
      assertNotSame(null, var0, var1);
   }

   private static void failSame(String var0) {
      String var1 = "";
      if (var0 != null) {
         var1 = var0 + " ";
      }

      fail(var1 + "expected not same");
   }

   private static void failNotSame(String var0, Object var1, Object var2) {
      String var3 = "";
      if (var0 != null) {
         var3 = var0 + " ";
      }

      fail(var3 + "expected same:<" + var1 + "> was not:<" + var2 + ">");
   }

   private static void failNotEquals(String var0, Object var1, Object var2) {
      fail(format(var0, var1, var2));
   }

   static String format(String var0, Object var1, Object var2) {
      String var3 = "";
      if (var0 != null && !var0.equals("")) {
         var3 = var0 + " ";
      }

      String var4 = String.valueOf(var1);
      String var5 = String.valueOf(var2);
      return var4.equals(var5)
         ? var3 + "expected: " + formatClassAndValue(var1, var4) + " but was: " + formatClassAndValue(var2, var5)
         : var3 + "expected:<" + var4 + "> but was:<" + var5 + ">";
   }

   private static String formatClassAndValue(Object var0, String var1) {
      String var2 = var0 == null ? "null" : var0.getClass().getName();
      return var2 + "<" + var1 + ">";
   }

   @Deprecated
   public static void assertEquals(String var0, Object[] var1, Object[] var2) {
      assertArrayEquals(var0, var1, var2);
   }

   @Deprecated
   public static void assertEquals(Object[] var0, Object[] var1) {
      assertArrayEquals(var0, var1);
   }

   public static <T> void assertThat(T var0, Matcher<T> var1) {
      assertThat("", var0, var1);
   }

   public static <T> void assertThat(String var0, T var1, Matcher<T> var2) {
      if (!var2.matches(var1)) {
         StringDescription var3 = new StringDescription();
         var3.appendText(var0);
         var3.appendText("\nExpected: ");
         var3.appendDescriptionOf(var2);
         var3.appendText("\n     got: ");
         var3.appendValue(var1);
         var3.appendText("\n");
         throw new AssertionError(var3.toString());
      }
   }
}
