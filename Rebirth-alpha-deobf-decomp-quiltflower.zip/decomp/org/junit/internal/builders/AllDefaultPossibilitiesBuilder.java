package org.junit.internal.builders;

import java.util.Arrays;
import org.junit.runner.Runner;
import org.junit.runners.model.RunnerBuilder;

public class AllDefaultPossibilitiesBuilder extends RunnerBuilder {
   private final boolean fCanUseSuiteMethod;

   public AllDefaultPossibilitiesBuilder(boolean var1) {
      this.fCanUseSuiteMethod = var1;
   }

   @Override
   public Runner runnerForClass(Class<?> var1) throws Throwable {
      for(RunnerBuilder var4 : Arrays.asList(
         this.ignoredBuilder(), this.annotatedBuilder(), this.suiteMethodBuilder(), this.junit3Builder(), this.junit4Builder()
      )) {
         Runner var5 = var4.safeRunnerForClass(var1);
         if (var5 != null) {
            return var5;
         }
      }

      return null;
   }

   protected JUnit4Builder junit4Builder() {
      return new JUnit4Builder();
   }

   protected JUnit3Builder junit3Builder() {
      return new JUnit3Builder();
   }

   protected AnnotatedBuilder annotatedBuilder() {
      return new AnnotatedBuilder(this);
   }

   protected IgnoredBuilder ignoredBuilder() {
      return new IgnoredBuilder();
   }

   protected RunnerBuilder suiteMethodBuilder() {
      return (RunnerBuilder)(this.fCanUseSuiteMethod ? new SuiteMethodBuilder() : new NullBuilder());
   }
}
