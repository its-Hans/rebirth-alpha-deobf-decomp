package org.junit.internal.builders;

import org.junit.runner.Description;
import org.junit.runner.Runner;
import org.junit.runner.notification.RunNotifier;

public class IgnoredClassRunner extends Runner {
   private final Class<?> fTestClass;

   public IgnoredClassRunner(Class<?> var1) {
      this.fTestClass = var1;
   }

   @Override
   public void run(RunNotifier var1) {
      var1.fireTestIgnored(this.getDescription());
   }

   @Override
   public Description getDescription() {
      return Description.createSuiteDescription(this.fTestClass);
   }
}
