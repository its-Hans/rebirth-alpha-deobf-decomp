package org.junit.internal.builders;

import org.junit.internal.runners.SuiteMethod;
import org.junit.runner.Runner;
import org.junit.runners.model.RunnerBuilder;

public class SuiteMethodBuilder extends RunnerBuilder {
   @Override
   public Runner runnerForClass(Class<?> var1) throws Throwable {
      return this.hasSuiteMethod(var1) ? new SuiteMethod(var1) : null;
   }

   public boolean hasSuiteMethod(Class<?> var1) {
      Class var10000 = var1;
      String var10001 = "suite";
      Class[] var10002 = new Class[0];

      try {
         var10000.getMethod(var10001, var10002);
         return true;
      } catch (NoSuchMethodException var3) {
         return false;
      }
   }
}
