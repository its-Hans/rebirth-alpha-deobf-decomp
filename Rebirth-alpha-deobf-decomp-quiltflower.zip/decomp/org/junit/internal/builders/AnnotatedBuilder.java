package org.junit.internal.builders;

import org.junit.runner.RunWith;
import org.junit.runner.Runner;
import org.junit.runners.model.RunnerBuilder;

public class AnnotatedBuilder extends RunnerBuilder {
   private static final String CONSTRUCTOR_ERROR_FORMAT = "Custom runner class %s should have a public constructor with signature %s(Class testClass)";
   private RunnerBuilder fSuiteBuilder;

   public AnnotatedBuilder(RunnerBuilder var1) {
      this.fSuiteBuilder = var1;
   }

   @Override
   public Runner runnerForClass(Class<?> var1) throws Exception {
      RunWith var2 = var1.getAnnotation(RunWith.class);
      return var2 != null ? this.buildRunner(var2.value(), var1) : null;
   }

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public Runner buildRunner(Class<? extends Runner> var1, Class<?> var2) throws Exception {
      Class var10000 = var1;
      Class[] var10001 = new Class[]{Class.class};

      try {
         return (Runner)var10000.getConstructor(var10001).newInstance(var2);
      } catch (NoSuchMethodException var7) {
         boolean var9 = false;

         while(true) {
            var10000 = var1;
            var10001 = new Class[]{Class.class, RunnerBuilder.class};

            try {
               return (Runner)var10000.getConstructor(var10001).newInstance(var2, this.fSuiteBuilder);
            } catch (NoSuchMethodException var6) {
               boolean var11 = false;
            }
         }
      }
   }
}
