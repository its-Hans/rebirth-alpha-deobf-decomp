package org.junit.internal.builders;

import junit.framework.TestCase;
import org.junit.internal.runners.JUnit38ClassRunner;
import org.junit.runner.Runner;
import org.junit.runners.model.RunnerBuilder;

public class JUnit3Builder extends RunnerBuilder {
   @Override
   public Runner runnerForClass(Class<?> var1) throws Throwable {
      return this.isPre4Test(var1) ? new JUnit38ClassRunner(var1) : null;
   }

   boolean isPre4Test(Class<?> var1) {
      return TestCase.class.isAssignableFrom(var1);
   }
}
