package org.junit.internal;

import org.junit.Assert;

public class InexactComparisonCriteria extends ComparisonCriteria {
   public double fDelta;

   public InexactComparisonCriteria(double var1) {
      this.fDelta = var1;
   }

   @Override
   protected void assertElementsEqual(Object var1, Object var2) {
      if (var1 instanceof Double) {
         Assert.assertEquals((Double)var1, ((Double)var2).doubleValue(), this.fDelta);
      } else {
         Assert.assertEquals((double)((Float)var1).floatValue(), (double)((Float)var2).floatValue(), this.fDelta);
      }
   }
}
