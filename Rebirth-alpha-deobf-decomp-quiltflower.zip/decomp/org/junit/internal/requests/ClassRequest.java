package org.junit.internal.requests;

import org.junit.internal.builders.AllDefaultPossibilitiesBuilder;
import org.junit.runner.Request;
import org.junit.runner.Runner;

public class ClassRequest extends Request {
   private final Class<?> fTestClass;
   private boolean fCanUseSuiteMethod;

   public ClassRequest(Class<?> var1, boolean var2) {
      this.fTestClass = var1;
      this.fCanUseSuiteMethod = var2;
   }

   public ClassRequest(Class<?> var1) {
      this(var1, true);
   }

   @Override
   public Runner getRunner() {
      return new AllDefaultPossibilitiesBuilder(this.fCanUseSuiteMethod).safeRunnerForClass(this.fTestClass);
   }
}
