package org.junit.internal.requests;

import org.junit.internal.runners.ErrorReportingRunner;
import org.junit.runner.Request;
import org.junit.runner.Runner;
import org.junit.runner.manipulation.Filter;
import org.junit.runner.manipulation.NoTestsRemainException;

public final class FilterRequest extends Request {
   private final Request fRequest;
   private final Filter fFilter;

   public FilterRequest(Request var1, Filter var2) {
      this.fRequest = var1;
      this.fFilter = var2;
   }

   @Override
   public Runner getRunner() {
      Request var10000 = this.fRequest;

      try {
         Runner var1 = var10000.getRunner();
         this.fFilter.apply(var1);
         return var1;
      } catch (NoTestsRemainException var2) {
         return new ErrorReportingRunner(
            Filter.class, new Exception(String.format("No tests found matching %s from %s", this.fFilter.describe(), this.fRequest.toString()))
         );
      }
   }
}
