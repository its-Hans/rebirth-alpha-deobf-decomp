package org.junit.internal.requests;

interface package-info {
}
