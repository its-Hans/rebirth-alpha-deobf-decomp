package org.junit.internal.requests;

import java.util.Comparator;
import org.junit.runner.Description;
import org.junit.runner.Request;
import org.junit.runner.Runner;
import org.junit.runner.manipulation.Sorter;

public class SortingRequest extends Request {
   private final Request fRequest;
   private final Comparator<Description> fComparator;

   public SortingRequest(Request var1, Comparator<Description> var2) {
      this.fRequest = var1;
      this.fComparator = var2;
   }

   @Override
   public Runner getRunner() {
      Runner var1 = this.fRequest.getRunner();
      new Sorter(this.fComparator).apply(var1);
      return var1;
   }
}
