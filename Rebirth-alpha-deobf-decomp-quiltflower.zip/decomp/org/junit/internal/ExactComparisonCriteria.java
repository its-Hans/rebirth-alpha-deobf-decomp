package org.junit.internal;

import org.junit.Assert;

public class ExactComparisonCriteria extends ComparisonCriteria {
   @Override
   protected void assertElementsEqual(Object var1, Object var2) {
      Assert.assertEquals(var1, var2);
   }
}
