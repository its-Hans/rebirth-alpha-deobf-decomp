package org.junit.internal;

import java.lang.reflect.Array;
import org.junit.Assert;

public abstract class ComparisonCriteria {
   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public void arrayEquals(String var1, Object var2, Object var3) throws ArrayComparisonFailure {
      if (var2 != var3) {
         String var4 = var1 == null ? "" : var1 + ": ";
         int var5 = this.assertArraysAreSameLength(var2, var3, var4);

         for(int var6 = 0; var6 < var5; ++var6) {
            Object var7 = Array.get(var2, var6);
            Object var8 = Array.get(var3, var6);
            Object var12;
            if (this.isArray(var7) && this.isArray(var8)) {
               var12 = this;
               String var15 = var1;
               Object var17 = var7;
               Object var10003 = var8;

               try {
                  var12.arrayEquals(var15, var17, var10003);
                  continue;
               } catch (ArrayComparisonFailure var10) {
                  var12 = var10;
                  boolean var16 = false;
               }
            } else {
               var12 = this;
               Object var10001 = var7;
               Object var10002 = var8;

               try {
                  var12.assertElementsEqual(var10001, var10002);
                  continue;
               } catch (AssertionError var11) {
                  var12 = var11;
                  boolean var14 = false;
               }
            }

            Object var9 = var12;
            ((ArrayComparisonFailure)var9).addDimension(var6);
            throw var9;
         }
      }
   }

   private boolean isArray(Object var1) {
      return var1 != null && var1.getClass().isArray();
   }

   private int assertArraysAreSameLength(Object var1, Object var2, String var3) {
      if (var1 == null) {
         Assert.fail(var3 + "expected array was null");
      }

      if (var2 == null) {
         Assert.fail(var3 + "actual array was null");
      }

      int var4 = Array.getLength(var2);
      int var5 = Array.getLength(var1);
      if (var4 != var5) {
         Assert.fail(var3 + "array lengths differed, expected.length=" + var5 + " actual.length=" + var4);
      }

      return var5;
   }

   protected abstract void assertElementsEqual(Object var1, Object var2);
}
