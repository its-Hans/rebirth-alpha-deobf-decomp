package org.junit.internal;

import java.util.ArrayList;
import java.util.List;

public class ArrayComparisonFailure extends AssertionError {
   private static final long serialVersionUID = 1L;
   private List<Integer> fIndices = new ArrayList<>();
   private final String fMessage;
   private final AssertionError fCause;

   public ArrayComparisonFailure(String var1, AssertionError var2, int var3) {
      this.fMessage = var1;
      this.fCause = var2;
      this.addDimension(var3);
   }

   public void addDimension(int var1) {
      this.fIndices.add(0, var1);
   }

   @Override
   public String getMessage() {
      StringBuilder var1 = new StringBuilder();
      if (this.fMessage != null) {
         var1.append(this.fMessage);
      }

      var1.append("arrays first differed at element ");

      for(int var3 : this.fIndices) {
         var1.append("[");
         var1.append(var3);
         var1.append("]");
      }

      var1.append("; ");
      var1.append(this.fCause.getMessage());
      return var1.toString();
   }

   @Override
   public String toString() {
      return this.getMessage();
   }
}
