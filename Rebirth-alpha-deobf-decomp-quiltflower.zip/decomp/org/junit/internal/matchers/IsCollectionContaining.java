package org.junit.internal.matchers;

import java.util.ArrayList;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.hamcrest.core.AllOf;
import org.hamcrest.core.IsEqual;

public class IsCollectionContaining<T> extends TypeSafeMatcher<Iterable<T>> {
   private final Matcher<? extends T> elementMatcher;

   public IsCollectionContaining(Matcher<? extends T> var1) {
      this.elementMatcher = var1;
   }

   public boolean matchesSafely(Iterable<T> var1) {
      for(Object var3 : var1) {
         if (this.elementMatcher.matches(var3)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendText("a collection containing ").appendDescriptionOf(this.elementMatcher);
   }

   @Factory
   public static <T> Matcher<Iterable<T>> hasItem(Matcher<? extends T> var0) {
      return new IsCollectionContaining<>(var0);
   }

   @Factory
   public static <T> Matcher<Iterable<T>> hasItem(T var0) {
      return hasItem(IsEqual.equalTo((T)var0));
   }

   @Factory
   public static <T> Matcher<Iterable<T>> hasItems(Matcher<? extends T>... var0) {
      ArrayList var1 = new ArrayList(var0.length);

      for(Matcher var5 : var0) {
         var1.add(hasItem(var5));
      }

      return AllOf.allOf(var1);
   }

   @Factory
   public static <T> Matcher<Iterable<T>> hasItems(T... var0) {
      ArrayList var1 = new ArrayList(var0.length);

      for(Object var5 : var0) {
         var1.add(hasItem(var5));
      }

      return AllOf.allOf(var1);
   }

   @Override
   public boolean matchesSafely(Object var1) {
      return this.matchesSafely((Iterable<T>)var1);
   }
}
