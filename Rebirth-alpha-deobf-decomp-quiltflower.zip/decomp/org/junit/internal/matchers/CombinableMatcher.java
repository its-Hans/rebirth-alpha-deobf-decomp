package org.junit.internal.matchers;

import org.hamcrest.BaseMatcher;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Description;
import org.hamcrest.Matcher;

public class CombinableMatcher<T> extends BaseMatcher<T> {
   private final Matcher<? extends T> fMatcher;

   public CombinableMatcher(Matcher<? extends T> var1) {
      this.fMatcher = var1;
   }

   @Override
   public boolean matches(Object var1) {
      return this.fMatcher.matches(var1);
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendDescriptionOf(this.fMatcher);
   }

   public CombinableMatcher<T> and(Matcher<? extends T> var1) {
      return new CombinableMatcher<>(CoreMatchers.allOf(var1, this.fMatcher));
   }

   public CombinableMatcher<T> or(Matcher<? extends T> var1) {
      return new CombinableMatcher<>(CoreMatchers.anyOf(var1, this.fMatcher));
   }
}
