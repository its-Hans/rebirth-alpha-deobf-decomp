package org.junit.internal.matchers;

import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class StringContains extends SubstringMatcher {
   public StringContains(String var1) {
      super(var1);
   }

   @Override
   protected boolean evalSubstringOf(String var1) {
      return var1.indexOf(this.substring) >= 0;
   }

   @Override
   protected String relationship() {
      return "containing";
   }

   @Factory
   public static Matcher<String> containsString(String var0) {
      return new StringContains(var0);
   }
}
