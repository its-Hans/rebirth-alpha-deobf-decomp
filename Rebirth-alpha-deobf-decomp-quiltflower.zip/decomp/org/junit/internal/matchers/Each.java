package org.junit.internal.matchers;

import org.hamcrest.BaseMatcher;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Description;
import org.hamcrest.Matcher;

public class Each {
   public static <T> Matcher<Iterable<T>> each(Matcher<T> var0) {
      Matcher var1 = CoreMatchers.not(IsCollectionContaining.hasItem(CoreMatchers.not(var0)));
      return new BaseMatcher<Iterable<T>>(var1, var0) {
         final Matcher val$allItemsAre;
         final Matcher val$individual;

         {
            this.val$allItemsAre = var1;
            this.val$individual = var2;
         }

         @Override
         public boolean matches(Object var1) {
            return this.val$allItemsAre.matches(var1);
         }

         @Override
         public void describeTo(Description var1) {
            var1.appendText("each ");
            this.val$individual.describeTo(var1);
         }
      };
   }
}
