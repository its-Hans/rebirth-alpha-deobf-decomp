package org.junit.internal.matchers;

import java.lang.reflect.Method;
import org.hamcrest.BaseMatcher;

public abstract class TypeSafeMatcher<T> extends BaseMatcher<T> {
   private Class<?> expectedType;

   public abstract boolean matchesSafely(T var1);

   protected TypeSafeMatcher() {
      this.expectedType = findExpectedType(this.getClass());
   }

   private static Class<?> findExpectedType(Class<?> var0) {
      for(Class var1 = var0; var1 != Object.class; var1 = var1.getSuperclass()) {
         for(Method var5 : var1.getDeclaredMethods()) {
            if (isMatchesSafelyMethod(var5)) {
               return var5.getParameterTypes()[0];
            }
         }
      }

      throw new Error("Cannot determine correct type for matchesSafely() method.");
   }

   private static boolean isMatchesSafelyMethod(Method var0) {
      return var0.getName().equals("matchesSafely") && var0.getParameterTypes().length == 1 && !var0.isSynthetic();
   }

   protected TypeSafeMatcher(Class<T> var1) {
      this.expectedType = var1;
   }

   @Override
   public final boolean matches(Object var1) {
      return var1 != null && this.expectedType.isInstance(var1) && this.matchesSafely((T)var1);
   }
}
