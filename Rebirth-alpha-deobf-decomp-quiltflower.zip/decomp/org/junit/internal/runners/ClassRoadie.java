package org.junit.internal.runners;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.junit.runner.Description;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunNotifier;

@Deprecated
public class ClassRoadie {
   private RunNotifier fNotifier;
   private TestClass fTestClass;
   private Description fDescription;
   private final Runnable fRunnable;

   public ClassRoadie(RunNotifier var1, TestClass var2, Description var3, Runnable var4) {
      this.fNotifier = var1;
      this.fTestClass = var2;
      this.fDescription = var3;
      this.fRunnable = var4;
   }

   protected void runUnprotected() {
      this.fRunnable.run();
   }

   protected void addFailure(Throwable var1) {
      this.fNotifier.fireTestFailure(new Failure(this.fDescription, var1));
   }

   public void runProtected() {
      ClassRoadie var10000 = this;

      try {
         var10000.runBefores();
         this.runUnprotected();
      } catch (FailedBefore var5) {
      } finally {
         this.runAfters();
      }
   }

   private void runBefores() throws FailedBefore {
      // $QF: Couldn't be decompiled
      // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.NullPointerException
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.graphToStatement(DomHelper.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:207)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:141)
      //
      // Bytecode:
      // 00: aload 0
      // 01: getfield org/junit/internal/runners/ClassRoadie.fTestClass Lorg/junit/internal/runners/TestClass;
      // 04: invokevirtual org/junit/internal/runners/TestClass.getBefores ()Ljava/util/List;
      // 07: astore 1
      // 08: aload 1
      // 09: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 0e: astore 2
      // 0f: aload 2
      // 10: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 15: ifeq 2f
      // 18: aload 2
      // 19: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 1e: checkcast java/lang/reflect/Method
      // 21: astore 3
      // 22: aload 3
      // 23: aconst_null
      // 24: bipush 0
      // 25: anewarray 4
      // 28: invokevirtual java/lang/reflect/Method.invoke (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      // 2b: pop
      // 2c: goto 0f
      // 2f: return
      // 30: astore 1
      // 31: aload 1
      // 32: invokevirtual java/lang/reflect/InvocationTargetException.getTargetException ()Ljava/lang/Throwable;
      // 35: athrow
      // 36: athrow
      // 37: nop
      // 38: nop
      // 39: nop
      // 3a: nop
      // 3b: nop
      // 3c: nop
      // 3d: nop
      // 3e: athrow
      // 3f: athrow
      // 40: nop
      // 41: nop
      // 42: nop
      // 43: nop
      // 44: athrow
      // 45: nop
      // 46: nop
      // 47: nop
      // 48: nop
      // 49: nop
      // 4a: nop
      // 4b: nop
      // 4c: athrow
   }

   private void runAfters() {
      for(Method var3 : this.fTestClass.getAfters()) {
         Method var10000 = var3;
         Object var10001 = null;
         byte var10002 = 0;

         InvocationTargetException var4;
         try {
            Object[] var7 = new Object[var10002];

            try {
               var10000.invoke(var10001, var7);
               continue;
            } catch (InvocationTargetException var5) {
               var4 = var5;
            }
         } catch (Throwable var6) {
            this.addFailure(var6);
            continue;
         }

         this.addFailure(var4.getTargetException());
      }
   }
}
