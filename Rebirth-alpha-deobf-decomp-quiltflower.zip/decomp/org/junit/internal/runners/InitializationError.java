package org.junit.internal.runners;

import java.util.Arrays;
import java.util.List;

@Deprecated
public class InitializationError extends Exception {
   private static final long serialVersionUID = 1L;
   private final List<Throwable> fErrors;

   public InitializationError(List<Throwable> var1) {
      this.fErrors = var1;
   }

   public InitializationError(Throwable... var1) {
      this(Arrays.asList(var1));
   }

   public InitializationError(String var1) {
      this(new Exception(var1));
   }

   public List<Throwable> getCauses() {
      return this.fErrors;
   }
}
