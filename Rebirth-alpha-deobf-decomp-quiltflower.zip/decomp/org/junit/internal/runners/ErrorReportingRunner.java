package org.junit.internal.runners;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;
import org.junit.runner.Description;
import org.junit.runner.Runner;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunNotifier;

public class ErrorReportingRunner extends Runner {
   private final List<Throwable> fCauses;
   private final Class<?> fTestClass;

   public ErrorReportingRunner(Class<?> var1, Throwable var2) {
      this.fTestClass = var1;
      this.fCauses = this.getCauses(var2);
   }

   @Override
   public Description getDescription() {
      Description var1 = Description.createSuiteDescription(this.fTestClass);

      for(Throwable var3 : this.fCauses) {
         var1.addChild(this.describeCause(var3));
      }

      return var1;
   }

   @Override
   public void run(RunNotifier var1) {
      for(Throwable var3 : this.fCauses) {
         this.runCause(var3, var1);
      }
   }

   private List<Throwable> getCauses(Throwable var1) {
      if (var1 instanceof InvocationTargetException) {
         return this.getCauses(var1.getCause());
      } else if (var1 instanceof org.junit.runners.model.InitializationError) {
         return ((org.junit.runners.model.InitializationError)var1).getCauses();
      } else {
         return var1 instanceof InitializationError ? ((InitializationError)var1).getCauses() : Arrays.asList(var1);
      }
   }

   private Description describeCause(Throwable var1) {
      return Description.createTestDescription(this.fTestClass, "initializationError");
   }

   private void runCause(Throwable var1, RunNotifier var2) {
      Description var3 = this.describeCause(var1);
      var2.fireTestStarted(var3);
      var2.fireTestFailure(new Failure(var3, var1));
      var2.fireTestFinished(var3);
   }
}
