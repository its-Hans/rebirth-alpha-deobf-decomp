package org.junit.internal;

import java.io.PrintStream;

public class RealSystem implements JUnitSystem {
   @Override
   public void exit(int var1) {
      System.exit(var1);
   }

   @Override
   public PrintStream out() {
      return System.out;
   }
}
