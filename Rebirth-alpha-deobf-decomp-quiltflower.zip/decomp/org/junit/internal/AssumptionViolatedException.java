package org.junit.internal;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.SelfDescribing;
import org.hamcrest.StringDescription;

public class AssumptionViolatedException extends RuntimeException implements SelfDescribing {
   private static final long serialVersionUID = 1L;
   private final Object fValue;
   private final Matcher<?> fMatcher;

   public AssumptionViolatedException(Object var1, Matcher<?> var2) {
      super(var1 instanceof Throwable ? (Throwable)var1 : null);
      this.fValue = var1;
      this.fMatcher = var2;
   }

   public AssumptionViolatedException(String var1) {
      this(var1, null);
   }

   @Override
   public String getMessage() {
      return StringDescription.asString(this);
   }

   @Override
   public void describeTo(Description var1) {
      if (this.fMatcher != null) {
         var1.appendText("got: ");
         var1.appendValue(this.fValue);
         var1.appendText(", expected: ");
         var1.appendDescriptionOf(this.fMatcher);
      } else {
         var1.appendText("failed assumption: " + this.fValue);
      }
   }
}
