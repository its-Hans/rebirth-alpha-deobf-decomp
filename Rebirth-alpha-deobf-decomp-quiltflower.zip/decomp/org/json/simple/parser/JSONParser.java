package org.json.simple.parser;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JSONParser {
   public static final int S_INIT = 0;
   public static final int S_IN_FINISHED_VALUE = 1;
   public static final int S_IN_OBJECT = 2;
   public static final int S_IN_ARRAY = 3;
   public static final int S_PASSED_PAIR_KEY = 4;
   public static final int S_IN_PAIR_VALUE = 5;
   public static final int S_END = 6;
   public static final int S_IN_ERROR = -1;
   private LinkedList handlerStatusStack;
   private Yylex lexer = new Yylex(null);
   private Yytoken token = null;
   private int status = 0;

   private int peekStatus(LinkedList var1) {
      if (var1.size() == 0) {
         return -1;
      } else {
         Integer var2 = (Integer)var1.getFirst();
         return var2;
      }
   }

   public void reset() {
      this.token = null;
      this.status = 0;
      this.handlerStatusStack = null;
   }

   public void reset(Reader var1) {
      this.lexer.yyreset(var1);
      this.reset();
   }

   public int getPosition() {
      return this.lexer.getPosition();
   }

   public Object parse(String var1) throws ParseException {
      return this.parse(var1, null);
   }

   public Object parse(String var1, ContainerFactory var2) throws ParseException {
      StringReader var3 = new StringReader(var1);
      JSONParser var10000 = this;
      StringReader var10001 = var3;
      ContainerFactory var10002 = var2;

      try {
         return var10000.parse(var10001, var10002);
      } catch (IOException var5) {
         throw new ParseException(-1, 2, var5);
      }
   }

   public Object parse(Reader var1) throws IOException, ParseException {
      return this.parse(var1, null);
   }

   // $QF: Handled exception range with multiple entry points by splitting it
   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public Object parse(Reader var1, ContainerFactory var2) throws IOException, ParseException {
      this.reset(var1);
      LinkedList var3 = new LinkedList();
      LinkedList var4 = new LinkedList();

      while(true) {
         JSONParser var10000 = this;

         label112: {
            label105: {
               label113: {
                  label103: {
                     label102: {
                        label101: {
                           try {
                              var10000.nextToken();
                              switch(this.status) {
                                 case -1:
                                    break label113;
                                 case 0:
                                    switch(this.token.type) {
                                       case 0:
                                          this.status = 1;
                                          var3.addFirst(new Integer(this.status));
                                          var4.addFirst(this.token.value);
                                          break label103;
                                       case 1:
                                          this.status = 2;
                                          var3.addFirst(new Integer(this.status));
                                          var4.addFirst(this.createObjectContainer(var2));
                                          break label103;
                                       case 2:
                                       default:
                                          this.status = -1;
                                          break label103;
                                       case 3:
                                          this.status = 3;
                                          var3.addFirst(new Integer(this.status));
                                          var4.addFirst(this.createArrayContainer(var2));
                                          break label103;
                                    }
                                 case 1:
                                    if (this.token.type != -1) {
                                       break label105;
                                    }

                                    return var4.removeFirst();
                                 case 2:
                                    break label102;
                                 case 3:
                                    break;
                                 case 4:
                                    break label101;
                                 default:
                                    break label103;
                              }
                           } catch (IOException var15) {
                              var27 = var15;
                              boolean var10001 = false;
                              break label112;
                           }

                           try {
                              switch(this.token.type) {
                                 case 0:
                                    List var20 = (List)var4.getFirst();
                                    var20.add(this.token.value);
                                    break label103;
                                 case 1:
                                    List var19 = (List)var4.getFirst();
                                    Map var25 = this.createObjectContainer(var2);
                                    var19.add(var25);
                                    this.status = 2;
                                    var3.addFirst(new Integer(this.status));
                                    var4.addFirst(var25);
                                    break label103;
                                 case 2:
                                 default:
                                    this.status = -1;
                                    break label103;
                                 case 3:
                                    List var18 = (List)var4.getFirst();
                                    List var26 = this.createArrayContainer(var2);
                                    var18.add(var26);
                                    this.status = 3;
                                    var3.addFirst(new Integer(this.status));
                                    var4.addFirst(var26);
                                    break label103;
                                 case 4:
                                    if (var4.size() > 1) {
                                       var3.removeFirst();
                                       var4.removeFirst();
                                       this.status = this.peekStatus(var3);
                                    } else {
                                       this.status = 1;
                                    }
                                 case 5:
                                    break label103;
                              }
                           } catch (IOException var14) {
                              var27 = var14;
                              boolean var30 = false;
                              break label112;
                           }
                        }

                        try {
                           switch(this.token.type) {
                              case 0:
                                 var3.removeFirst();
                                 String var17 = (String)var4.removeFirst();
                                 Map var24 = (Map)var4.getFirst();
                                 var24.put(var17, this.token.value);
                                 this.status = this.peekStatus(var3);
                                 break label103;
                              case 1:
                                 var3.removeFirst();
                                 String var16 = (String)var4.removeFirst();
                                 Map var23 = (Map)var4.getFirst();
                                 Map var8 = this.createObjectContainer(var2);
                                 var23.put(var16, var8);
                                 this.status = 2;
                                 var3.addFirst(new Integer(this.status));
                                 var4.addFirst(var8);
                                 break label103;
                              case 2:
                              case 4:
                              case 5:
                              default:
                                 this.status = -1;
                                 break label103;
                              case 3:
                                 var3.removeFirst();
                                 String var5 = (String)var4.removeFirst();
                                 Map var6 = (Map)var4.getFirst();
                                 List var7 = this.createArrayContainer(var2);
                                 var6.put(var5, var7);
                                 this.status = 3;
                                 var3.addFirst(new Integer(this.status));
                                 var4.addFirst(var7);
                              case 6:
                                 break label103;
                           }
                        } catch (IOException var13) {
                           var27 = var13;
                           boolean var29 = false;
                           break label112;
                        }
                     }

                     try {
                        switch(this.token.type) {
                           case 0:
                              if (this.token.value instanceof String) {
                                 String var21 = (String)this.token.value;
                                 var4.addFirst(var21);
                                 this.status = 4;
                                 var3.addFirst(new Integer(this.status));
                              } else {
                                 this.status = -1;
                              }
                              break;
                           case 2:
                              if (var4.size() > 1) {
                                 var3.removeFirst();
                                 var4.removeFirst();
                                 this.status = this.peekStatus(var3);
                              } else {
                                 this.status = 1;
                              }
                           case 5:
                              break;
                           default:
                              this.status = -1;
                        }
                     } catch (IOException var12) {
                        var27 = var12;
                        boolean var31 = false;
                        break label112;
                     }
                  }

                  try {
                     if (this.status == -1) {
                        throw new ParseException(this.getPosition(), 1, this.token);
                     }

                     if (this.token.type != -1) {
                        continue;
                     }
                  } catch (IOException var11) {
                     var27 = var11;
                     boolean var35 = false;
                     break label112;
                  }

                  throw new ParseException(this.getPosition(), 1, this.token);
               }

               try {
                  throw new ParseException(this.getPosition(), 1, this.token);
               } catch (IOException var10) {
                  var27 = var10;
                  boolean var34 = false;
                  break label112;
               }
            }

            ParseException var28 = new ParseException;
            ParseException var32 = var28;
            JSONParser var10002 = this;

            try {
               var32./* $QF: Unable to resugar constructor */<init>(var10002.getPosition(), 1, this.token);
               throw var28;
            } catch (IOException var9) {
               var27 = var9;
               boolean var33 = false;
            }
         }

         IOException var22 = var27;
         throw var22;
      }
   }

   private void nextToken() throws ParseException, IOException {
      this.token = this.lexer.yylex();
      if (this.token == null) {
         this.token = new Yytoken(-1, null);
      }
   }

   private Map createObjectContainer(ContainerFactory var1) {
      if (var1 == null) {
         return new JSONObject();
      } else {
         Map var2 = var1.createObjectContainer();
         return (Map)(var2 == null ? new JSONObject() : var2);
      }
   }

   private List createArrayContainer(ContainerFactory var1) {
      if (var1 == null) {
         return new JSONArray();
      } else {
         List var2 = var1.creatArrayContainer();
         return (List)(var2 == null ? new JSONArray() : var2);
      }
   }

   public void parse(String var1, ContentHandler var2) throws ParseException {
      this.parse(var1, var2, false);
   }

   public void parse(String var1, ContentHandler var2, boolean var3) throws ParseException {
      StringReader var4 = new StringReader(var1);
      JSONParser var10000 = this;
      StringReader var10001 = var4;
      ContentHandler var10002 = var2;
      boolean var10003 = var3;

      try {
         var10000.parse(var10001, var10002, var10003);
      } catch (IOException var6) {
         throw new ParseException(-1, 2, var6);
      }
   }

   public void parse(Reader var1, ContentHandler var2) throws IOException, ParseException {
      this.parse(var1, var2, false);
   }

   public void parse(Reader param1, ContentHandler param2, boolean param3) throws IOException, ParseException {
      // $QF: Couldn't be decompiled
      // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.NullPointerException
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.graphToStatement(DomHelper.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:207)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:141)
      //
      // Bytecode:
      // 000: iload 3
      // 001: ifne 017
      // 004: aload 0
      // 005: aload 1
      // 006: invokevirtual org/json/simple/parser/JSONParser.reset (Ljava/io/Reader;)V
      // 009: aload 0
      // 00a: new java/util/LinkedList
      // 00d: dup
      // 00e: invokespecial java/util/LinkedList.<init> ()V
      // 011: putfield org/json/simple/parser/JSONParser.handlerStatusStack Ljava/util/LinkedList;
      // 014: goto 030
      // 017: aload 0
      // 018: getfield org/json/simple/parser/JSONParser.handlerStatusStack Ljava/util/LinkedList;
      // 01b: ifnonnull 030
      // 01e: bipush 0
      // 01f: istore 3
      // 020: aload 0
      // 021: aload 1
      // 022: invokevirtual org/json/simple/parser/JSONParser.reset (Ljava/io/Reader;)V
      // 025: aload 0
      // 026: new java/util/LinkedList
      // 029: dup
      // 02a: invokespecial java/util/LinkedList.<init> ()V
      // 02d: putfield org/json/simple/parser/JSONParser.handlerStatusStack Ljava/util/LinkedList;
      // 030: aload 0
      // 031: getfield org/json/simple/parser/JSONParser.handlerStatusStack Ljava/util/LinkedList;
      // 034: astore 4
      // 036: aload 0
      // 037: getfield org/json/simple/parser/JSONParser.status I
      // 03a: tableswitch 853 -1 6 836 46 202 252 654 421 628 835
      // 068: aload 2
      // 069: invokeinterface org/json/simple/parser/ContentHandler.startJSON ()V 1
      // 06e: aload 0
      // 06f: invokespecial org/json/simple/parser/JSONParser.nextToken ()V
      // 072: aload 0
      // 073: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 076: getfield org/json/simple/parser/Yytoken.type I
      // 079: tableswitch 131 0 3 31 69 131 100
      // 098: aload 0
      // 099: bipush 1
      // 09a: putfield org/json/simple/parser/JSONParser.status I
      // 09d: aload 4
      // 09f: new java/lang/Integer
      // 0a2: dup
      // 0a3: aload 0
      // 0a4: getfield org/json/simple/parser/JSONParser.status I
      // 0a7: invokespecial java/lang/Integer.<init> (I)V
      // 0aa: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 0ad: aload 2
      // 0ae: aload 0
      // 0af: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 0b2: getfield org/json/simple/parser/Yytoken.value Ljava/lang/Object;
      // 0b5: invokeinterface org/json/simple/parser/ContentHandler.primitive (Ljava/lang/Object;)Z 2
      // 0ba: ifne 38f
      // 0bd: return
      // 0be: aload 0
      // 0bf: bipush 2
      // 0c0: putfield org/json/simple/parser/JSONParser.status I
      // 0c3: aload 4
      // 0c5: new java/lang/Integer
      // 0c8: dup
      // 0c9: aload 0
      // 0ca: getfield org/json/simple/parser/JSONParser.status I
      // 0cd: invokespecial java/lang/Integer.<init> (I)V
      // 0d0: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 0d3: aload 2
      // 0d4: invokeinterface org/json/simple/parser/ContentHandler.startObject ()Z 1
      // 0d9: ifne 38f
      // 0dc: return
      // 0dd: aload 0
      // 0de: bipush 3
      // 0df: putfield org/json/simple/parser/JSONParser.status I
      // 0e2: aload 4
      // 0e4: new java/lang/Integer
      // 0e7: dup
      // 0e8: aload 0
      // 0e9: getfield org/json/simple/parser/JSONParser.status I
      // 0ec: invokespecial java/lang/Integer.<init> (I)V
      // 0ef: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 0f2: aload 2
      // 0f3: invokeinterface org/json/simple/parser/ContentHandler.startArray ()Z 1
      // 0f8: ifne 38f
      // 0fb: return
      // 0fc: aload 0
      // 0fd: bipush -1
      // 0fe: putfield org/json/simple/parser/JSONParser.status I
      // 101: goto 38f
      // 104: aload 0
      // 105: invokespecial org/json/simple/parser/JSONParser.nextToken ()V
      // 108: aload 0
      // 109: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 10c: getfield org/json/simple/parser/Yytoken.type I
      // 10f: bipush -1
      // 110: if_icmpne 120
      // 113: aload 2
      // 114: invokeinterface org/json/simple/parser/ContentHandler.endJSON ()V 1
      // 119: aload 0
      // 11a: bipush 6
      // 11c: putfield org/json/simple/parser/JSONParser.status I
      // 11f: return
      // 120: aload 0
      // 121: bipush -1
      // 122: putfield org/json/simple/parser/JSONParser.status I
      // 125: new org/json/simple/parser/ParseException
      // 128: dup
      // 129: aload 0
      // 12a: invokevirtual org/json/simple/parser/JSONParser.getPosition ()I
      // 12d: bipush 1
      // 12e: aload 0
      // 12f: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 132: invokespecial org/json/simple/parser/ParseException.<init> (IILjava/lang/Object;)V
      // 135: athrow
      // 136: aload 0
      // 137: invokespecial org/json/simple/parser/JSONParser.nextToken ()V
      // 13a: aload 0
      // 13b: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 13e: getfield org/json/simple/parser/Yytoken.type I
      // 141: lookupswitch 150 3 0 38 2 107 5 35
      // 164: goto 38f
      // 167: aload 0
      // 168: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 16b: getfield org/json/simple/parser/Yytoken.value Ljava/lang/Object;
      // 16e: instanceof java/lang/String
      // 171: ifeq 1a4
      // 174: aload 0
      // 175: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 178: getfield org/json/simple/parser/Yytoken.value Ljava/lang/Object;
      // 17b: checkcast java/lang/String
      // 17e: astore 5
      // 180: aload 0
      // 181: bipush 4
      // 182: putfield org/json/simple/parser/JSONParser.status I
      // 185: aload 4
      // 187: new java/lang/Integer
      // 18a: dup
      // 18b: aload 0
      // 18c: getfield org/json/simple/parser/JSONParser.status I
      // 18f: invokespecial java/lang/Integer.<init> (I)V
      // 192: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 195: aload 2
      // 196: aload 5
      // 198: invokeinterface org/json/simple/parser/ContentHandler.startObjectEntry (Ljava/lang/String;)Z 2
      // 19d: ifne 1a1
      // 1a0: return
      // 1a1: goto 38f
      // 1a4: aload 0
      // 1a5: bipush -1
      // 1a6: putfield org/json/simple/parser/JSONParser.status I
      // 1a9: goto 38f
      // 1ac: aload 4
      // 1ae: invokevirtual java/util/LinkedList.size ()I
      // 1b1: bipush 1
      // 1b2: if_icmple 1c8
      // 1b5: aload 4
      // 1b7: invokevirtual java/util/LinkedList.removeFirst ()Ljava/lang/Object;
      // 1ba: pop
      // 1bb: aload 0
      // 1bc: aload 0
      // 1bd: aload 4
      // 1bf: invokespecial org/json/simple/parser/JSONParser.peekStatus (Ljava/util/LinkedList;)I
      // 1c2: putfield org/json/simple/parser/JSONParser.status I
      // 1c5: goto 1cd
      // 1c8: aload 0
      // 1c9: bipush 1
      // 1ca: putfield org/json/simple/parser/JSONParser.status I
      // 1cd: aload 2
      // 1ce: invokeinterface org/json/simple/parser/ContentHandler.endObject ()Z 1
      // 1d3: ifne 38f
      // 1d6: return
      // 1d7: aload 0
      // 1d8: bipush -1
      // 1d9: putfield org/json/simple/parser/JSONParser.status I
      // 1dc: goto 38f
      // 1df: aload 0
      // 1e0: invokespecial org/json/simple/parser/JSONParser.nextToken ()V
      // 1e3: aload 0
      // 1e4: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 1e7: getfield org/json/simple/parser/Yytoken.type I
      // 1ea: tableswitch 188 0 6 45 138 188 88 188 188 42
      // 214: goto 38f
      // 217: aload 4
      // 219: invokevirtual java/util/LinkedList.removeFirst ()Ljava/lang/Object;
      // 21c: pop
      // 21d: aload 0
      // 21e: aload 0
      // 21f: aload 4
      // 221: invokespecial org/json/simple/parser/JSONParser.peekStatus (Ljava/util/LinkedList;)I
      // 224: putfield org/json/simple/parser/JSONParser.status I
      // 227: aload 2
      // 228: aload 0
      // 229: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 22c: getfield org/json/simple/parser/Yytoken.value Ljava/lang/Object;
      // 22f: invokeinterface org/json/simple/parser/ContentHandler.primitive (Ljava/lang/Object;)Z 2
      // 234: ifne 238
      // 237: return
      // 238: aload 2
      // 239: invokeinterface org/json/simple/parser/ContentHandler.endObjectEntry ()Z 1
      // 23e: ifne 38f
      // 241: return
      // 242: aload 4
      // 244: invokevirtual java/util/LinkedList.removeFirst ()Ljava/lang/Object;
      // 247: pop
      // 248: aload 4
      // 24a: new java/lang/Integer
      // 24d: dup
      // 24e: bipush 5
      // 24f: invokespecial java/lang/Integer.<init> (I)V
      // 252: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 255: aload 0
      // 256: bipush 3
      // 257: putfield org/json/simple/parser/JSONParser.status I
      // 25a: aload 4
      // 25c: new java/lang/Integer
      // 25f: dup
      // 260: aload 0
      // 261: getfield org/json/simple/parser/JSONParser.status I
      // 264: invokespecial java/lang/Integer.<init> (I)V
      // 267: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 26a: aload 2
      // 26b: invokeinterface org/json/simple/parser/ContentHandler.startArray ()Z 1
      // 270: ifne 38f
      // 273: return
      // 274: aload 4
      // 276: invokevirtual java/util/LinkedList.removeFirst ()Ljava/lang/Object;
      // 279: pop
      // 27a: aload 4
      // 27c: new java/lang/Integer
      // 27f: dup
      // 280: bipush 5
      // 281: invokespecial java/lang/Integer.<init> (I)V
      // 284: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 287: aload 0
      // 288: bipush 2
      // 289: putfield org/json/simple/parser/JSONParser.status I
      // 28c: aload 4
      // 28e: new java/lang/Integer
      // 291: dup
      // 292: aload 0
      // 293: getfield org/json/simple/parser/JSONParser.status I
      // 296: invokespecial java/lang/Integer.<init> (I)V
      // 299: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 29c: aload 2
      // 29d: invokeinterface org/json/simple/parser/ContentHandler.startObject ()Z 1
      // 2a2: ifne 38f
      // 2a5: return
      // 2a6: aload 0
      // 2a7: bipush -1
      // 2a8: putfield org/json/simple/parser/JSONParser.status I
      // 2ab: goto 38f
      // 2ae: aload 4
      // 2b0: invokevirtual java/util/LinkedList.removeFirst ()Ljava/lang/Object;
      // 2b3: pop
      // 2b4: aload 0
      // 2b5: aload 0
      // 2b6: aload 4
      // 2b8: invokespecial org/json/simple/parser/JSONParser.peekStatus (Ljava/util/LinkedList;)I
      // 2bb: putfield org/json/simple/parser/JSONParser.status I
      // 2be: aload 2
      // 2bf: invokeinterface org/json/simple/parser/ContentHandler.endObjectEntry ()Z 1
      // 2c4: ifne 38f
      // 2c7: return
      // 2c8: aload 0
      // 2c9: invokespecial org/json/simple/parser/JSONParser.nextToken ()V
      // 2cc: aload 0
      // 2cd: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 2d0: getfield org/json/simple/parser/Yytoken.type I
      // 2d3: tableswitch 162 0 5 40 100 162 131 57 37
      // 2f8: goto 38f
      // 2fb: aload 2
      // 2fc: aload 0
      // 2fd: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 300: getfield org/json/simple/parser/Yytoken.value Ljava/lang/Object;
      // 303: invokeinterface org/json/simple/parser/ContentHandler.primitive (Ljava/lang/Object;)Z 2
      // 308: ifne 38f
      // 30b: return
      // 30c: aload 4
      // 30e: invokevirtual java/util/LinkedList.size ()I
      // 311: bipush 1
      // 312: if_icmple 328
      // 315: aload 4
      // 317: invokevirtual java/util/LinkedList.removeFirst ()Ljava/lang/Object;
      // 31a: pop
      // 31b: aload 0
      // 31c: aload 0
      // 31d: aload 4
      // 31f: invokespecial org/json/simple/parser/JSONParser.peekStatus (Ljava/util/LinkedList;)I
      // 322: putfield org/json/simple/parser/JSONParser.status I
      // 325: goto 32d
      // 328: aload 0
      // 329: bipush 1
      // 32a: putfield org/json/simple/parser/JSONParser.status I
      // 32d: aload 2
      // 32e: invokeinterface org/json/simple/parser/ContentHandler.endArray ()Z 1
      // 333: ifne 38f
      // 336: return
      // 337: aload 0
      // 338: bipush 2
      // 339: putfield org/json/simple/parser/JSONParser.status I
      // 33c: aload 4
      // 33e: new java/lang/Integer
      // 341: dup
      // 342: aload 0
      // 343: getfield org/json/simple/parser/JSONParser.status I
      // 346: invokespecial java/lang/Integer.<init> (I)V
      // 349: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 34c: aload 2
      // 34d: invokeinterface org/json/simple/parser/ContentHandler.startObject ()Z 1
      // 352: ifne 38f
      // 355: return
      // 356: aload 0
      // 357: bipush 3
      // 358: putfield org/json/simple/parser/JSONParser.status I
      // 35b: aload 4
      // 35d: new java/lang/Integer
      // 360: dup
      // 361: aload 0
      // 362: getfield org/json/simple/parser/JSONParser.status I
      // 365: invokespecial java/lang/Integer.<init> (I)V
      // 368: invokevirtual java/util/LinkedList.addFirst (Ljava/lang/Object;)V
      // 36b: aload 2
      // 36c: invokeinterface org/json/simple/parser/ContentHandler.startArray ()Z 1
      // 371: ifne 38f
      // 374: return
      // 375: aload 0
      // 376: bipush -1
      // 377: putfield org/json/simple/parser/JSONParser.status I
      // 37a: goto 38f
      // 37d: return
      // 37e: new org/json/simple/parser/ParseException
      // 381: dup
      // 382: aload 0
      // 383: invokevirtual org/json/simple/parser/JSONParser.getPosition ()I
      // 386: bipush 1
      // 387: aload 0
      // 388: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 38b: invokespecial org/json/simple/parser/ParseException.<init> (IILjava/lang/Object;)V
      // 38e: athrow
      // 38f: aload 0
      // 390: getfield org/json/simple/parser/JSONParser.status I
      // 393: bipush -1
      // 394: if_icmpne 3a8
      // 397: new org/json/simple/parser/ParseException
      // 39a: dup
      // 39b: aload 0
      // 39c: invokevirtual org/json/simple/parser/JSONParser.getPosition ()I
      // 39f: bipush 1
      // 3a0: aload 0
      // 3a1: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 3a4: invokespecial org/json/simple/parser/ParseException.<init> (IILjava/lang/Object;)V
      // 3a7: athrow
      // 3a8: aload 0
      // 3a9: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 3ac: getfield org/json/simple/parser/Yytoken.type I
      // 3af: bipush -1
      // 3b0: if_icmpne 036
      // 3b3: aload 0
      // 3b4: bipush -1
      // 3b5: putfield org/json/simple/parser/JSONParser.status I
      // 3b8: new org/json/simple/parser/ParseException
      // 3bb: dup
      // 3bc: aload 0
      // 3bd: invokevirtual org/json/simple/parser/JSONParser.getPosition ()I
      // 3c0: bipush 1
      // 3c1: aload 0
      // 3c2: getfield org/json/simple/parser/JSONParser.token Lorg/json/simple/parser/Yytoken;
      // 3c5: invokespecial org/json/simple/parser/ParseException.<init> (IILjava/lang/Object;)V
      // 3c8: athrow
      // 3c9: astore 5
      // 3cb: aload 0
      // 3cc: bipush -1
      // 3cd: putfield org/json/simple/parser/JSONParser.status I
      // 3d0: aload 5
      // 3d2: athrow
      // 3d3: astore 5
      // 3d5: aload 0
      // 3d6: bipush -1
      // 3d7: putfield org/json/simple/parser/JSONParser.status I
      // 3da: aload 5
      // 3dc: athrow
      // 3dd: astore 5
      // 3df: aload 0
      // 3e0: bipush -1
      // 3e1: putfield org/json/simple/parser/JSONParser.status I
      // 3e4: aload 5
      // 3e6: athrow
      // 3e7: astore 5
      // 3e9: aload 0
      // 3ea: bipush -1
      // 3eb: putfield org/json/simple/parser/JSONParser.status I
      // 3ee: aload 5
      // 3f0: athrow
   }
}
