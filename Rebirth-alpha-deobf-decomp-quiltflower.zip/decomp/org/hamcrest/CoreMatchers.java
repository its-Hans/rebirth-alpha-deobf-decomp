package org.hamcrest;

import org.hamcrest.core.AllOf;
import org.hamcrest.core.AnyOf;
import org.hamcrest.core.DescribedAs;
import org.hamcrest.core.Is;
import org.hamcrest.core.IsAnything;
import org.hamcrest.core.IsEqual;
import org.hamcrest.core.IsInstanceOf;
import org.hamcrest.core.IsNot;
import org.hamcrest.core.IsNull;
import org.hamcrest.core.IsSame;

public class CoreMatchers {
   public static <T> Matcher<T> is(Matcher<T> var0) {
      return Is.is(var0);
   }

   public static <T> Matcher<T> is(T var0) {
      return Is.is((T)var0);
   }

   public static Matcher<Object> is(Class<?> var0) {
      return Is.is(var0);
   }

   public static <T> Matcher<T> not(Matcher<T> var0) {
      return IsNot.not(var0);
   }

   public static <T> Matcher<T> not(T var0) {
      return IsNot.not((T)var0);
   }

   public static <T> Matcher<T> equalTo(T var0) {
      return IsEqual.equalTo((T)var0);
   }

   public static Matcher<Object> instanceOf(Class<?> var0) {
      return IsInstanceOf.instanceOf(var0);
   }

   public static <T> Matcher<T> allOf(Matcher<? extends T>... var0) {
      return AllOf.allOf(var0);
   }

   public static <T> Matcher<T> allOf(Iterable<Matcher<? extends T>> var0) {
      return AllOf.allOf(var0);
   }

   public static <T> Matcher<T> anyOf(Matcher<? extends T>... var0) {
      return AnyOf.anyOf(var0);
   }

   public static <T> Matcher<T> anyOf(Iterable<Matcher<? extends T>> var0) {
      return AnyOf.anyOf(var0);
   }

   public static <T> Matcher<T> sameInstance(T var0) {
      return IsSame.sameInstance((T)var0);
   }

   public static <T> Matcher<T> anything() {
      return IsAnything.anything();
   }

   public static <T> Matcher<T> anything(String var0) {
      return IsAnything.anything(var0);
   }

   public static <T> Matcher<T> any(Class<T> var0) {
      return IsAnything.any(var0);
   }

   public static <T> Matcher<T> nullValue() {
      return IsNull.nullValue();
   }

   public static <T> Matcher<T> nullValue(Class<T> var0) {
      return IsNull.nullValue(var0);
   }

   public static <T> Matcher<T> notNullValue() {
      return IsNull.notNullValue();
   }

   public static <T> Matcher<T> notNullValue(Class<T> var0) {
      return IsNull.notNullValue(var0);
   }

   public static <T> Matcher<T> describedAs(String var0, Matcher<T> var1, Object... var2) {
      return DescribedAs.describedAs(var0, var1, var2);
   }
}
