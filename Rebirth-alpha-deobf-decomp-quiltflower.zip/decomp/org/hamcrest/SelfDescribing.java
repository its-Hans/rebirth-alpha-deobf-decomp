package org.hamcrest;

public interface SelfDescribing {
   void describeTo(Description var1);
}
