package org.hamcrest.core;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class IsInstanceOf extends BaseMatcher<Object> {
   private final Class<?> theClass;

   public IsInstanceOf(Class<?> var1) {
      this.theClass = var1;
   }

   @Override
   public boolean matches(Object var1) {
      return this.theClass.isInstance(var1);
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendText("an instance of ").appendText(this.theClass.getName());
   }

   @Factory
   public static Matcher<Object> instanceOf(Class<?> var0) {
      return new IsInstanceOf(var0);
   }
}
