package org.hamcrest.core;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class IsSame<T> extends BaseMatcher<T> {
   private final T object;

   public IsSame(T var1) {
      this.object = (T)var1;
   }

   @Override
   public boolean matches(Object var1) {
      return var1 == this.object;
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendText("same(").appendValue(this.object).appendText(")");
   }

   @Factory
   public static <T> Matcher<T> sameInstance(T var0) {
      return new IsSame<>((T)var0);
   }
}
