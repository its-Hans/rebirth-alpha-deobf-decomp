package org.hamcrest.core;

import java.util.Arrays;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class AnyOf<T> extends BaseMatcher<T> {
   private final Iterable<Matcher<? extends T>> matchers;

   public AnyOf(Iterable<Matcher<? extends T>> var1) {
      this.matchers = var1;
   }

   @Override
   public boolean matches(Object var1) {
      for(Matcher var3 : this.matchers) {
         if (var3.matches(var1)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendList("(", " or ", ")", this.matchers);
   }

   @Factory
   public static <T> Matcher<T> anyOf(Matcher<? extends T>... var0) {
      return anyOf(Arrays.asList(var0));
   }

   @Factory
   public static <T> Matcher<T> anyOf(Iterable<Matcher<? extends T>> var0) {
      return new AnyOf<>(var0);
   }
}
