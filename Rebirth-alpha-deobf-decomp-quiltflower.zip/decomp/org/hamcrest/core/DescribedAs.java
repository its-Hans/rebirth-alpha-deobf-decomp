package org.hamcrest.core;

import java.util.regex.Pattern;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class DescribedAs<T> extends BaseMatcher<T> {
   private final String descriptionTemplate;
   private final Matcher<T> matcher;
   private final Object[] values;
   private static final Pattern ARG_PATTERN = Pattern.compile("%([0-9]+)");

   public DescribedAs(String var1, Matcher<T> var2, Object[] var3) {
      this.descriptionTemplate = var1;
      this.matcher = var2;
      this.values = var3.clone();
   }

   @Override
   public boolean matches(Object var1) {
      return this.matcher.matches(var1);
   }

   @Override
   public void describeTo(Description var1) {
      java.util.regex.Matcher var2 = ARG_PATTERN.matcher(this.descriptionTemplate);

      int var3;
      for(var3 = 0; var2.find(); var3 = var2.end()) {
         var1.appendText(this.descriptionTemplate.substring(var3, var2.start()));
         int var4 = Integer.parseInt(var2.group(1));
         var1.appendValue(this.values[var4]);
      }

      if (var3 < this.descriptionTemplate.length()) {
         var1.appendText(this.descriptionTemplate.substring(var3));
      }
   }

   @Factory
   public static <T> Matcher<T> describedAs(String var0, Matcher<T> var1, Object... var2) {
      return new DescribedAs<>(var0, var1, var2);
   }
}
