package org.hamcrest.core;

import java.lang.reflect.Array;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class IsEqual<T> extends BaseMatcher<T> {
   private final Object object;

   public IsEqual(T var1) {
      this.object = var1;
   }

   @Override
   public boolean matches(Object var1) {
      return areEqual(this.object, var1);
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendValue(this.object);
   }

   private static boolean areEqual(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         if (!isArray(var0)) {
            return var0.equals(var1);
         } else {
            return isArray(var1) && areArraysEqual(var0, var1);
         }
      } else {
         return var0 == null && var1 == null;
      }
   }

   private static boolean areArraysEqual(Object var0, Object var1) {
      return areArrayLengthsEqual(var0, var1) && areArrayElementsEqual(var0, var1);
   }

   private static boolean areArrayLengthsEqual(Object var0, Object var1) {
      return Array.getLength(var0) == Array.getLength(var1);
   }

   private static boolean areArrayElementsEqual(Object var0, Object var1) {
      for(int var2 = 0; var2 < Array.getLength(var0); ++var2) {
         if (!areEqual(Array.get(var0, var2), Array.get(var1, var2))) {
            return false;
         }
      }

      return true;
   }

   private static boolean isArray(Object var0) {
      return var0.getClass().isArray();
   }

   @Factory
   public static <T> Matcher<T> equalTo(T var0) {
      return new IsEqual<>((T)var0);
   }
}
