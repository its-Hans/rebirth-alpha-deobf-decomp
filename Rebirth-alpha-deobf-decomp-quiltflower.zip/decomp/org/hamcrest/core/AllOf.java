package org.hamcrest.core;

import java.util.Arrays;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;

public class AllOf<T> extends BaseMatcher<T> {
   private final Iterable<Matcher<? extends T>> matchers;

   public AllOf(Iterable<Matcher<? extends T>> var1) {
      this.matchers = var1;
   }

   @Override
   public boolean matches(Object var1) {
      for(Matcher var3 : this.matchers) {
         if (!var3.matches(var1)) {
            return false;
         }
      }

      return true;
   }

   @Override
   public void describeTo(Description var1) {
      var1.appendList("(", " and ", ")", this.matchers);
   }

   @Factory
   public static <T> Matcher<T> allOf(Matcher<? extends T>... var0) {
      return allOf(Arrays.asList(var0));
   }

   @Factory
   public static <T> Matcher<T> allOf(Iterable<Matcher<? extends T>> var0) {
      return new AllOf<>(var0);
   }
}
