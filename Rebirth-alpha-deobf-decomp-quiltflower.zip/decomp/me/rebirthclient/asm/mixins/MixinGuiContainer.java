package me.rebirthclient.asm.mixins;

import com.google.common.collect.Sets;
import java.awt.Color;
import java.util.Set;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.impl.client.GuiAnimation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.GuiContainerEvent.DrawForeground;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({GuiContainer.class})
public abstract class MixinGuiContainer extends GuiScreen {
   @Shadow
   public Container inventorySlots;
   @Shadow
   protected int guiLeft;
   @Shadow
   protected int guiTop;
   @Shadow
   private Slot hoveredSlot;
   @Shadow
   private boolean isRightMouseClick;
   @Shadow
   private ItemStack draggedStack = ItemStack.EMPTY;
   @Shadow
   private int touchUpX;
   @Shadow
   private int touchUpY;
   @Shadow
   private Slot returningStackDestSlot;
   @Shadow
   private long returningStackTime;
   @Shadow
   private ItemStack returningStack = ItemStack.EMPTY;
   @Final
   @Shadow
   protected final Set<Slot> dragSplittingSlots = Sets.newHashSet();
   @Shadow
   protected boolean dragSplitting;
   @Shadow
   private int dragSplittingRemnant;

   @Overwrite
   public void drawScreen(int var1, int var2, float var3) {
      if (ClickGui.INSTANCE.background.getValue() && this.mc.world != null) {
         RenderUtil.drawVGradientRect(
            0.0F,
            0.0F,
            (float)Managers.TEXT.scaledWidth,
            (float)Managers.TEXT.scaledHeight,
            new Color(0, 0, 0, 0).getRGB(),
            Managers.COLORS.getCurrentWithAlpha(60)
         );
      }

      float var4 = (float)GuiAnimation.inventoryFade.easeOutQuad();
      GlStateManager.pushMatrix();
      GL11.glScaled((double)var4, (double)var4, (double)var4);
      int var5 = this.guiLeft;
      int var6 = this.guiTop;
      this.drawGuiContainerBackgroundLayer(var3, var1, var2);
      GlStateManager.disableRescaleNormal();
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      super.drawScreen(var1, var2, var3);
      RenderHelper.enableGUIStandardItemLighting();
      GlStateManager.pushMatrix();
      GlStateManager.translate((float)var5, (float)var6, 0.0F);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.enableRescaleNormal();
      this.hoveredSlot = null;
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

      for(int var7 = 0; var7 < this.inventorySlots.inventorySlots.size(); ++var7) {
         Slot var8 = (Slot)this.inventorySlots.inventorySlots.get(var7);
         if (var8.isEnabled()) {
            this.drawSlot(var8);
         }

         if (this.isMouseOverSlot(var8, var1, var2) && var8.isEnabled()) {
            this.hoveredSlot = var8;
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            int var9 = var8.xPos;
            int var10 = var8.yPos;
            GlStateManager.colorMask(true, true, true, false);
            this.drawGradientRect(var9, var10, var9 + 16, var10 + 16, -2130706433, -2130706433);
            GlStateManager.colorMask(true, true, true, true);
            GlStateManager.enableLighting();
            GlStateManager.enableDepth();
         }
      }

      RenderHelper.disableStandardItemLighting();
      this.drawGuiContainerForegroundLayer(var1, var2);
      RenderHelper.enableGUIStandardItemLighting();
      MinecraftForge.EVENT_BUS.post(new DrawForeground((GuiContainer)this, var1, var2));
      InventoryPlayer var14 = this.mc.player.inventory;
      ItemStack var15 = this.draggedStack.isEmpty() ? var14.getItemStack() : this.draggedStack;
      if (!var15.isEmpty()) {
         int var16 = this.draggedStack.isEmpty() ? 8 : 16;
         String var18 = null;
         if (!this.draggedStack.isEmpty() && this.isRightMouseClick) {
            var15 = var15.copy();
            var15.setCount(MathHelper.ceil((float)var15.getCount() / 2.0F));
         } else if (this.dragSplitting && this.dragSplittingSlots.size() > 1) {
            var15 = var15.copy();
            var15.setCount(this.dragSplittingRemnant);
            if (var15.isEmpty()) {
               var18 = TextFormatting.YELLOW + "0";
            }
         }

         this.drawItemStack(var15, var1 - var5 - 8, var2 - var6 - var16, var18);
      }

      if (!this.returningStack.isEmpty()) {
         float var17 = (float)(Minecraft.getSystemTime() - this.returningStackTime) / 100.0F;
         if (var17 >= 1.0F) {
            var17 = 1.0F;
            this.returningStack = ItemStack.EMPTY;
         }

         int var19 = this.returningStackDestSlot.xPos - this.touchUpX;
         int var11 = this.returningStackDestSlot.yPos - this.touchUpY;
         int var12 = this.touchUpX + (int)((float)var19 * var17);
         int var13 = this.touchUpY + (int)((float)var11 * var17);
         this.drawItemStack(this.returningStack, var12, var13, null);
      }

      GlStateManager.popMatrix();
      GlStateManager.enableLighting();
      GlStateManager.enableDepth();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.popMatrix();
   }

   @Shadow
   protected abstract void drawGuiContainerBackgroundLayer(float var1, int var2, int var3);

   @Shadow
   private void drawSlot(Slot var1) {
   }

   @Shadow
   protected void drawGuiContainerForegroundLayer(int var1, int var2) {
   }

   @Shadow
   private void drawItemStack(ItemStack var1, int var2, int var3, String var4) {
      GlStateManager.translate(0.0F, 0.0F, 32.0F);
      this.zLevel = 200.0F;
      this.itemRender.zLevel = 200.0F;
      FontRenderer var5 = var1.getItem().getFontRenderer(var1);
      if (var5 == null) {
         var5 = this.fontRenderer;
      }

      this.itemRender.renderItemAndEffectIntoGUI(var1, var2, var3);
      this.itemRender.renderItemOverlayIntoGUI(var5, var1, var2, var3 - (this.draggedStack.isEmpty() ? 0 : 8), var4);
      this.zLevel = 0.0F;
      this.itemRender.zLevel = 0.0F;
   }

   @Shadow
   private boolean isMouseOverSlot(Slot var1, int var2, int var3) {
      return false;
   }
}
