package me.rebirthclient.asm.mixins;

import java.awt.Color;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.impl.render.Chams;
import me.rebirthclient.mod.modules.impl.render.Rotations;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderLivingBase.class})
public abstract class MixinRenderLivingBase<T extends EntityLivingBase> extends Render<T> {
   private float prevRenderYawOffset;
   private float renderYawOffset;
   private float prevRotationYawHead;
   private float rotationYawHead;
   private float prevRotationPitch;
   private float rotationPitch;

   protected MixinRenderLivingBase(RenderManager var1) {
      super(var1);
   }

   @Inject(
      method = {"doRender*"},
      at = {@At("HEAD")}
   )
   public void doRenderHookHead(EntityLivingBase var1, double var2, double var4, double var6, float var8, float var9, CallbackInfo var10) {
      if (var1 instanceof EntityPlayerSP && Rotations.INSTANCE.check()) {
         this.prevRenderYawOffset = var1.prevRenderYawOffset;
         this.renderYawOffset = var1.renderYawOffset;
         this.prevRotationYawHead = var1.prevRotationYawHead;
         this.rotationYawHead = var1.rotationYawHead;
         this.prevRotationPitch = var1.prevRotationPitch;
         this.rotationPitch = var1.rotationPitch;
         var1.prevRenderYawOffset = Rotations.getPrevRenderYawOffset();
         var1.renderYawOffset = Rotations.getRenderYawOffset();
         var1.prevRotationYawHead = Rotations.getPrevRotationYawHead();
         var1.rotationYawHead = Rotations.getRotationYawHead();
         var1.prevRotationPitch = Rotations.getPrevPitch();
         var1.rotationPitch = Rotations.getRenderPitch();
      }
   }

   @Inject(
      method = {"doRender*"},
      at = {@At("RETURN")}
   )
   public void doRenderHookReturn(EntityLivingBase var1, double var2, double var4, double var6, float var8, float var9, CallbackInfo var10) {
      if (var1 instanceof EntityPlayerSP && Rotations.INSTANCE.check()) {
         var1.prevRenderYawOffset = this.prevRenderYawOffset;
         var1.renderYawOffset = this.renderYawOffset;
         var1.prevRotationYawHead = this.prevRotationYawHead;
         var1.rotationYawHead = this.rotationYawHead;
         var1.prevRotationPitch = this.prevRotationPitch;
         var1.rotationPitch = this.rotationPitch;
      }
   }

   @Inject(
      method = {"renderModel"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V",
   shift = At.Shift.BEFORE
)},
      cancellable = true
   )
   private void renderModelHook(T var1, float var2, float var3, float var4, float var5, float var6, float var7, CallbackInfo var8) {
      Chams var9 = Chams.INSTANCE;
      RenderLivingBase var10 = (RenderLivingBase)RenderLivingBase.class.cast(this);
      ModelBase var11 = var10.getMainModel();
      if (var9.isOn() && var1 instanceof EntityPlayer) {
         var8.cancel();
         boolean var12 = Managers.FRIENDS.isFriend(var1.getName());
         float var13 = var9.noInterp.getValue() ? 0.0F : var2;
         float var14 = var9.noInterp.getValue() ? 0.0F : var3;
         if (var9.sneak.getValue()) {
            var1.setSneaking(true);
         }

         if (!var9.self.getValue() && var1 instanceof EntityPlayerSP) {
            var11.render(var1, var2, var3, var4, var5, var6, var7);
            return;
         }

         if (var9.model.getValue() == Chams.Model.VANILLA) {
            var11.render(var1, var13, var14, var4, var5, var6, var7);
         } else if (var9.model.getValue() == Chams.Model.XQZ) {
            GL11.glEnable(32823);
            GlStateManager.enablePolygonOffset();
            GL11.glPolygonOffset(1.0F, -1000000.0F);
            if (var9.modelColor.booleanValue) {
               Color var15 = var12
                  ? Managers.COLORS.getFriendColor(var9.modelColor.getValue().getAlpha())
                  : new Color(
                     var9.modelColor.getValue().getRed(),
                     var9.modelColor.getValue().getGreen(),
                     var9.modelColor.getValue().getBlue(),
                     var9.modelColor.getValue().getAlpha()
                  );
               RenderUtil.glColor(var15);
            }

            var11.render(var1, var13, var14, var4, var5, var6, var7);
            GL11.glDisable(32823);
            GlStateManager.disablePolygonOffset();
            GL11.glPolygonOffset(1.0F, 1000000.0F);
         }

         if (var9.wireframe.getValue()) {
            Color var18 = var12
               ? Managers.COLORS.getFriendColor(var9.lineColor.booleanValue ? var9.lineColor.getValue().getAlpha() : var9.color.getValue().getAlpha())
               : (
                  var9.lineColor.booleanValue
                     ? new Color(
                        var9.lineColor.getValue().getRed(),
                        var9.lineColor.getValue().getGreen(),
                        var9.lineColor.getValue().getBlue(),
                        var9.lineColor.getValue().getAlpha()
                     )
                     : new Color(
                        var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha()
                     )
               );
            GL11.glPushMatrix();
            GL11.glPushAttrib(1048575);
            GL11.glPolygonMode(1032, 6913);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glEnable(2848);
            GL11.glEnable(3042);
            GlStateManager.blendFunc(770, 771);
            RenderUtil.glColor(var18);
            GlStateManager.glLineWidth(var9.lineWidth.getValue());
            var11.render(var1, var13, var14, var4, var5, var6, var7);
            GL11.glPopAttrib();
            GL11.glPopMatrix();
         }

         if (var9.fill.getValue()) {
            Color var19 = var12
               ? Managers.COLORS.getFriendColor(var9.color.getValue().getAlpha())
               : new Color(var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha());
            GL11.glPushAttrib(1048575);
            GL11.glDisable(3008);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glLineWidth(1.5F);
            GL11.glEnable(2960);
            if (var9.xqz.getValue()) {
               GL11.glDisable(2929);
               GL11.glDepthMask(false);
            }

            GL11.glEnable(10754);
            RenderUtil.glColor(var19);
            var11.render(var1, var13, var14, var4, var5, var6, var7);
            if (var9.xqz.getValue()) {
               GL11.glEnable(2929);
               GL11.glDepthMask(true);
            }

            GL11.glEnable(3042);
            GL11.glEnable(2896);
            GL11.glEnable(3553);
            GL11.glEnable(3008);
            GL11.glPopAttrib();
         }

         if (var9.glint.getValue()) {
            Color var20 = var12
               ? Managers.COLORS.getFriendColor(var9.color.getValue().getAlpha())
               : new Color(var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha());
            GL11.glPushMatrix();
            GL11.glPushAttrib(1048575);
            GL11.glPolygonMode(1032, 6914);
            GL11.glDisable(2896);
            GL11.glDepthRange(0.0, 0.1);
            GL11.glEnable(3042);
            RenderUtil.glColor(var20);
            GlStateManager.blendFunc(SourceFactor.SRC_COLOR, DestFactor.ONE);
            float var16 = (float)var1.ticksExisted + Wrapper.mc.getRenderPartialTicks();
            Wrapper.mc.getRenderManager().renderEngine.bindTexture(new ResourceLocation("textures/misc/enchanted_item_glint.png"));

            for(int var17 = 0; var17 < 2; ++var17) {
               GlStateManager.matrixMode(5890);
               GlStateManager.loadIdentity();
               GL11.glScalef(1.0F, 1.0F, 1.0F);
               GlStateManager.rotate(30.0F - (float)var17 * 60.0F, 0.0F, 0.0F, 1.0F);
               GlStateManager.translate(0.0F, var16 * (0.001F + (float)var17 * 0.003F) * 20.0F, 0.0F);
               GlStateManager.matrixMode(5888);
               var11.render(var1, var13, var14, var4, var5, var6, var7);
            }

            GlStateManager.matrixMode(5890);
            GlStateManager.loadIdentity();
            GlStateManager.matrixMode(5888);
            GL11.glDisable(3042);
            GL11.glDepthRange(0.0, 1.0);
            GL11.glEnable(2896);
            GL11.glPopAttrib();
            GL11.glPopMatrix();
         }
      } else {
         var11.render(var1, var2, var3, var4, var5, var6, var7);
      }
   }
}
