package me.rebirthclient.asm.mixins;

import me.rebirthclient.Rebirth;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.impl.client.UnfocusedCPU;
import me.rebirthclient.mod.modules.impl.exploit.MultiTask;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.crash.CrashReport;
import org.lwjgl.opengl.Display;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Minecraft.class})
public abstract class MixinMinecraft {
   @Inject(
      method = {"getLimitFramerate"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getLimitFramerateHook(CallbackInfoReturnable<Integer> var1) {
      UnfocusedCPU var2 = UnfocusedCPU.INSTANCE;
      UnfocusedCPU var10000 = var2;

      try {
         if (var10000.isOn() && !Display.isActive()) {
            var1.setReturnValue(var2.unfocusedFps.getValue());
         }
      } catch (Exception var4) {
      }
   }

   @Inject(
      method = {"shutdownMinecraftApplet"},
      at = {@At("HEAD")}
   )
   private void stopClient(CallbackInfo var1) {
      this.unload();
   }

   @Redirect(
      method = {"run"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"
)
   )
   public void displayCrashReport(Minecraft var1, CrashReport var2) {
      this.unload();
   }

   private void unload() {
      Rebirth.LOGGER.info("Initiated client shutdown.");
      Managers.onUnload();
      Rebirth.LOGGER.info("Finished client shutdown.");
   }

   @Redirect(
      method = {"sendClickBlockToController"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/EntityPlayerSP;isHandActive()Z"
)
   )
   private boolean isHandActiveWrapper(EntityPlayerSP var1) {
      return !MultiTask.INSTANCE.isOn() && var1.isHandActive();
   }

   @Redirect(
      method = {"rightClickMouse"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;getIsHittingBlock()Z",
   ordinal = 0
)
   )
   private boolean isHittingBlockHook(PlayerControllerMP var1) {
      return !MultiTask.INSTANCE.isOn() && var1.getIsHittingBlock();
   }
}
