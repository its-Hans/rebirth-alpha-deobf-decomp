package me.rebirthclient.asm.mixins;

import me.rebirthclient.mod.modules.impl.exploit.LiquidInteract;
import me.rebirthclient.mod.modules.impl.movement.Velocity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({BlockLiquid.class})
public class MixinBlockLiquid extends Block {
   protected MixinBlockLiquid(Material var1) {
      super(var1);
   }

   @Inject(
      method = {"modifyAcceleration"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void modifyAccelerationHook(World var1, BlockPos var2, Entity var3, Vec3d var4, CallbackInfoReturnable<Vec3d> var5) {
      if (Velocity.INSTANCE.isOn()) {
         var5.setReturnValue(var4);
      }
   }

   @Inject(
      method = {"canCollideCheck"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void canCollideCheckHook(IBlockState var1, boolean var2, CallbackInfoReturnable<Boolean> var3) {
      var3.setReturnValue(var2 && var1.getValue(BlockLiquid.LEVEL) == 0 || LiquidInteract.INSTANCE.isOn());
   }
}
