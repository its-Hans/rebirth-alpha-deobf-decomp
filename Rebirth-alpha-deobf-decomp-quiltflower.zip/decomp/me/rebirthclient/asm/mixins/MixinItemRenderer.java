package me.rebirthclient.asm.mixins;

import java.awt.Color;
import me.rebirthclient.api.events.impl.FreecamEntityEvent;
import me.rebirthclient.api.events.impl.FreecamEvent;
import me.rebirthclient.api.events.impl.RenderItemInFirstPersonEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.impl.render.Chams;
import me.rebirthclient.mod.modules.impl.render.ItemModel;
import me.rebirthclient.mod.modules.impl.render.Shader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemRenderer.class})
public abstract class MixinItemRenderer {
   @Shadow
   @Final
   public Minecraft mc;
   private boolean injection = true;

   @Shadow
   public abstract void renderItemInFirstPerson(AbstractClientPlayer var1, float var2, float var3, EnumHand var4, float var5, ItemStack var6, float var7);

   @Redirect(
      method = {"renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/ItemRenderer;renderItemSide(Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemCameraTransforms$TransformType;Z)V"
)
   )
   public void renderItemInFirstPerson(ItemRenderer var1, EntityLivingBase var2, ItemStack var3, TransformType var4, boolean var5) {
      RenderItemInFirstPersonEvent var6 = new RenderItemInFirstPersonEvent(var2, var3, var4, var5, 0);
      MinecraftForge.EVENT_BUS.post(var6);
      if (!var6.isCanceled()) {
         var1.renderItemSide(var2, var6.getStack(), var6.getTransformType(), var5);
      }

      RenderItemInFirstPersonEvent var7 = new RenderItemInFirstPersonEvent(var2, var3, var4, var5, 1);
      MinecraftForge.EVENT_BUS.post(var7);
   }

   @Inject(
      method = {"renderFireInFirstPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderFireInFirstPersonHook(CallbackInfo var1) {
      if (Shader.INSTANCE.isOn()) {
         var1.cancel();
      }
   }

   @Inject(
      method = {"renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderItemInFirstPersonHook(
      AbstractClientPlayer var1, float var2, float var3, EnumHand var4, float var5, ItemStack var6, float var7, CallbackInfo var8
   ) {
      Chams var9 = Chams.INSTANCE;
      if (this.injection) {
         var8.cancel();
         boolean var10 = Managers.FRIENDS.isFriend(var1.getName());
         this.injection = false;
         if (var9.isOn() && var9.self.getValue() && var4 == EnumHand.MAIN_HAND && var6.isEmpty()) {
            if (var9.model.getValue() == Chams.Model.VANILLA) {
               this.renderItemInFirstPerson(var1, var2, var3, var4, var5, var6, var7);
            } else if (var9.model.getValue() == Chams.Model.XQZ) {
               GL11.glEnable(32823);
               GlStateManager.enablePolygonOffset();
               GL11.glPolygonOffset(1.0F, -1000000.0F);
               if (var9.modelColor.booleanValue) {
                  Color var11 = var10
                     ? Managers.COLORS.getFriendColor(var9.modelColor.getValue().getAlpha())
                     : new Color(
                        var9.modelColor.getValue().getRed(),
                        var9.modelColor.getValue().getGreen(),
                        var9.modelColor.getValue().getBlue(),
                        var9.modelColor.getValue().getAlpha()
                     );
                  RenderUtil.glColor(var11);
               }

               this.renderItemInFirstPerson(var1, var2, var3, var4, var5, var6, var7);
               GL11.glDisable(32823);
               GlStateManager.disablePolygonOffset();
               GL11.glPolygonOffset(1.0F, 1000000.0F);
            }

            if (var9.wireframe.getValue()) {
               Color var14 = var10
                  ? Managers.COLORS.getFriendColor(var9.lineColor.booleanValue ? var9.lineColor.getValue().getAlpha() : var9.color.getValue().getAlpha())
                  : (
                     var9.lineColor.booleanValue
                        ? new Color(
                           var9.lineColor.getValue().getRed(),
                           var9.lineColor.getValue().getGreen(),
                           var9.lineColor.getValue().getBlue(),
                           var9.lineColor.getValue().getAlpha()
                        )
                        : new Color(
                           var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha()
                        )
                  );
               GL11.glPushMatrix();
               GL11.glPushAttrib(1048575);
               GL11.glPolygonMode(1032, 6913);
               GL11.glDisable(3553);
               GL11.glDisable(2896);
               GL11.glDisable(2929);
               GL11.glEnable(2848);
               GL11.glEnable(3042);
               GlStateManager.blendFunc(770, 771);
               RenderUtil.glColor(var14);
               GlStateManager.glLineWidth(var9.lineWidth.getValue());
               this.renderItemInFirstPerson(var1, var2, var3, var4, var5, var6, var7);
               GL11.glPopAttrib();
               GL11.glPopMatrix();
            }

            if (var9.fill.getValue()) {
               Color var15 = var10
                  ? Managers.COLORS.getFriendColor(var9.color.getValue().getAlpha())
                  : new Color(
                     var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha()
                  );
               GL11.glPushAttrib(1048575);
               GL11.glDisable(3008);
               GL11.glDisable(3553);
               GL11.glDisable(2896);
               GL11.glEnable(3042);
               GL11.glBlendFunc(770, 771);
               GL11.glLineWidth(1.5F);
               GL11.glEnable(2960);
               if (var9.xqz.getValue()) {
                  GL11.glDisable(2929);
                  GL11.glDepthMask(false);
               }

               GL11.glEnable(10754);
               RenderUtil.glColor(var15);
               this.renderItemInFirstPerson(var1, var2, var3, var4, var5, var6, var7);
               if (var9.xqz.getValue()) {
                  GL11.glEnable(2929);
                  GL11.glDepthMask(true);
               }

               GL11.glEnable(3042);
               GL11.glEnable(2896);
               GL11.glEnable(3553);
               GL11.glEnable(3008);
               GL11.glPopAttrib();
            }

            if (var9.glint.getValue()) {
               Color var16 = var10
                  ? Managers.COLORS.getFriendColor(var9.color.getValue().getAlpha())
                  : new Color(
                     var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha()
                  );
               GL11.glPushMatrix();
               GL11.glPushAttrib(1048575);
               GL11.glPolygonMode(1032, 6914);
               GL11.glDisable(2896);
               GL11.glDepthRange(0.0, 0.1);
               GL11.glEnable(3042);
               RenderUtil.glColor(var16);
               GlStateManager.blendFunc(SourceFactor.SRC_COLOR, DestFactor.ONE);
               float var12 = (float)var1.ticksExisted + this.mc.getRenderPartialTicks();
               this.mc.getRenderManager().renderEngine.bindTexture(new ResourceLocation("textures/misc/enchanted_item_glint.png"));

               for(int var13 = 0; var13 < 2; ++var13) {
                  GlStateManager.matrixMode(5890);
                  GlStateManager.loadIdentity();
                  GL11.glScalef(1.0F, 1.0F, 1.0F);
                  GlStateManager.rotate(30.0F - (float)var13 * 60.0F, 0.0F, 0.0F, 1.0F);
                  GlStateManager.translate(0.0F, var12 * (0.001F + (float)var13 * 0.003F) * 20.0F, 0.0F);
                  GlStateManager.matrixMode(5888);
                  this.renderItemInFirstPerson(var1, var2, var3, var4, var5, var6, var7);
               }

               GlStateManager.matrixMode(5890);
               GlStateManager.loadIdentity();
               GlStateManager.matrixMode(5888);
               GL11.glDisable(3042);
               GL11.glDepthRange(0.0, 1.0);
               GL11.glEnable(2896);
               GL11.glPopAttrib();
               GL11.glPopMatrix();
            }
         } else {
            this.renderItemInFirstPerson(var1, var2, var3, var4, var5, var6, var7);
         }

         this.injection = true;
      }
   }

   @Inject(
      method = {"rotateArm"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void rotateArmHook(float var1, CallbackInfo var2) {
      ItemModel var3 = ItemModel.INSTANCE;
      if (var3.isOn() && var3.noSway.getValue()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"transformSideFirstPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void transformSideFirstPerson(EnumHandSide var1, float var2, CallbackInfo var3) {
      if (ItemModel.INSTANCE.isOn()) {
         boolean var4 = ItemModel.INSTANCE.doBob.getValue();
         int var5 = var1 == EnumHandSide.RIGHT ? 1 : -1;
         GlStateManager.translate((float)var5 * 0.56F, -0.52F + (var4 ? var2 : 0.0F) * -0.6F, -0.72F);
         if (var1 == EnumHandSide.RIGHT) {
            GlStateManager.translate(ItemModel.INSTANCE.mainX.getValue(), ItemModel.INSTANCE.mainY.getValue(), ItemModel.INSTANCE.mainZ.getValue());
         } else {
            GlStateManager.translate(ItemModel.INSTANCE.offX.getValue(), ItemModel.INSTANCE.offY.getValue(), ItemModel.INSTANCE.offZ.getValue());
         }

         var3.cancel();
      }
   }

   @Inject(
      method = {"transformEatFirstPerson"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void transformEatFirstPerson(float var1, EnumHandSide var2, ItemStack var3, CallbackInfo var4) {
      if (ItemModel.INSTANCE.isOn()) {
         if (!ItemModel.INSTANCE.noEatAnimation.getValue()) {
            float var5 = (float)Minecraft.getMinecraft().player.getItemInUseCount() - var1 + 1.0F;
            float var6 = var5 / (float)var3.getMaxItemUseDuration();
            if (var6 < 0.8F) {
               float var7 = MathHelper.abs(MathHelper.cos(var5 / 4.0F * (float) Math.PI) * 0.1F);
               GlStateManager.translate(0.0F, var7, 0.0F);
            }

            float var9 = 1.0F - (float)Math.pow((double)var6, 27.0);
            int var8 = var2 == EnumHandSide.RIGHT ? 1 : -1;
            GlStateManager.translate(
               (double)(var9 * 0.6F * (float)var8) * ItemModel.INSTANCE.eatX.getValue(), (double)(var9 * 0.5F) * -ItemModel.INSTANCE.eatY.getValue(), 0.0
            );
            GlStateManager.rotate((float)var8 * var9 * 90.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(var9 * 10.0F, 1.0F, 0.0F, 0.0F);
            GlStateManager.rotate((float)var8 * var9 * 30.0F, 0.0F, 0.0F, 1.0F);
         }

         var4.cancel();
      }
   }

   @Inject(
      method = {"renderOverlays"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderOverlaysInject(float var1, CallbackInfo var2) {
      FreecamEvent var3 = new FreecamEvent();
      MinecraftForge.EVENT_BUS.post(var3);
      if (var3.isCanceled()) {
         var2.cancel();
      }
   }

   @Redirect(
      method = {"setLightmap"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/Minecraft;player:Lnet/minecraft/client/entity/EntityPlayerSP;"
)
   )
   private EntityPlayerSP redirectLightmapPlayer(Minecraft var1) {
      FreecamEntityEvent var2 = new FreecamEntityEvent(var1.player);
      MinecraftForge.EVENT_BUS.post(var2);
      return (EntityPlayerSP)var2.getEntity();
   }

   @Redirect(
      method = {"rotateArm"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/Minecraft;player:Lnet/minecraft/client/entity/EntityPlayerSP;"
)
   )
   private EntityPlayerSP rotateArmPlayer(Minecraft var1) {
      FreecamEntityEvent var2 = new FreecamEntityEvent(var1.player);
      MinecraftForge.EVENT_BUS.post(var2);
      return (EntityPlayerSP)var2.getEntity();
   }

   @Redirect(
      method = {"renderItemInFirstPerson(F)V"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/Minecraft;player:Lnet/minecraft/client/entity/EntityPlayerSP;"
)
   )
   private EntityPlayerSP redirectPlayer(Minecraft var1) {
      FreecamEntityEvent var2 = new FreecamEntityEvent(var1.player);
      MinecraftForge.EVENT_BUS.post(var2);
      return (EntityPlayerSP)var2.getEntity();
   }

   @Redirect(
      method = {"renderOverlays"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/Minecraft;player:Lnet/minecraft/client/entity/EntityPlayerSP;"
)
   )
   private EntityPlayerSP renderOverlaysPlayer(Minecraft var1) {
      FreecamEntityEvent var2 = new FreecamEntityEvent(var1.player);
      MinecraftForge.EVENT_BUS.post(var2);
      return (EntityPlayerSP)var2.getEntity();
   }
}
