package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.events.impl.RenderEntityEvent;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderManager.class})
public class MixinRenderManager {
   @Inject(
      method = {"renderEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderEntityHook(Entity var1, double var2, double var4, double var6, float var8, float var9, boolean var10, CallbackInfo var11) {
      RenderEntityEvent var12 = new RenderEntityEvent(0, var1, var2, var4, var6, var8, var9);
      MinecraftForge.EVENT_BUS.post(var12);
      if (var12.isCanceled()) {
         var11.cancel();
      }
   }
}
