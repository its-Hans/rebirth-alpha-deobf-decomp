package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.events.impl.BlockEvent;
import me.rebirthclient.api.events.impl.BreakBlockEvent;
import me.rebirthclient.api.events.impl.RightClickBlockEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.impl.player.TpsSync;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerControllerMP.class})
public class MixinPlayerControllerMP {
   @Redirect(
      method = {"onPlayerDamageBlock"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/block/state/IBlockState;getPlayerRelativeBlockHardness(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)F"
)
   )
   public float getPlayerRelativeBlockHardnessHook(IBlockState var1, EntityPlayer var2, World var3, BlockPos var4) {
      return var1.getPlayerRelativeBlockHardness(var2, var3, var4)
         * (TpsSync.INSTANCE.isOn() && TpsSync.INSTANCE.mining.getValue() ? 1.0F / Managers.SERVER.getTpsFactor() : 1.0F);
   }

   @Inject(
      method = {"processRightClickBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void processRightClickBlock(
      EntityPlayerSP var1, WorldClient var2, BlockPos var3, EnumFacing var4, Vec3d var5, EnumHand var6, CallbackInfoReturnable<EnumActionResult> var7
   ) {
      RightClickBlockEvent var8 = new RightClickBlockEvent(var3, var6, Minecraft.instance.player.getHeldItem(var6));
      MinecraftForge.EVENT_BUS.post(var8);
      if (var8.isCanceled()) {
         var7.cancel();
      }
   }

   @Inject(
      method = {"onPlayerDestroyBlock"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/World;playEvent(ILnet/minecraft/util/math/BlockPos;I)V"
)},
      cancellable = true
   )
   private void onPlayerDestroyBlock(BlockPos var1, CallbackInfoReturnable<Boolean> var2) {
      MinecraftForge.EVENT_BUS.post(new BreakBlockEvent(var1));
   }

   @Inject(
      method = {"clickBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void clickBlockHook(BlockPos var1, EnumFacing var2, CallbackInfoReturnable<Boolean> var3) {
      BlockEvent var4 = new BlockEvent(var1, var2);
      MinecraftForge.EVENT_BUS.post(var4);
      if (var4.isCanceled()) {
         var3.setReturnValue(false);
      }
   }

   @Inject(
      method = {"onPlayerDamageBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPlayerDamageBlockHook(BlockPos var1, EnumFacing var2, CallbackInfoReturnable<Boolean> var3) {
      BlockEvent var4 = new BlockEvent(var1, var2);
      MinecraftForge.EVENT_BUS.post(var4);
      if (var4.isCanceled()) {
         var3.setReturnValue(false);
      }
   }
}
