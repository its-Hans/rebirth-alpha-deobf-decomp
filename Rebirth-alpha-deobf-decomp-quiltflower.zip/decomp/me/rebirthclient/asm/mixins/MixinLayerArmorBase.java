package me.rebirthclient.asm.mixins;

import me.rebirthclient.mod.modules.impl.render.Chams;
import me.rebirthclient.mod.modules.impl.render.Models;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LayerArmorBase.class})
public class MixinLayerArmorBase {
   @Shadow
   private void renderArmorLayer(
      EntityLivingBase var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, EntityEquipmentSlot var9
   ) {
   }

   @Inject(
      method = {"doRenderLayer"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/entity/layers/LayerArmorBase;renderArmorLayer(Lnet/minecraft/entity/EntityLivingBase;FFFFFFFLnet/minecraft/inventory/EntityEquipmentSlot;)V",
   shift = At.Shift.BEFORE
)},
      cancellable = true
   )
   public void doRenderLayerHook(EntityLivingBase var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, CallbackInfo var9) {
      Chams var10 = Chams.INSTANCE;
      if (var10.isOn() && var1 instanceof EntityPlayer) {
         var9.cancel();
         float var11 = var10.isOn() && var10.noInterp.getValue() ? 0.0F : var2;
         float var12 = var10.isOn() && var10.noInterp.getValue() ? 0.0F : var3;
         if (!var10.self.getValue() && var1 instanceof EntityPlayerSP) {
            this.renderLayers(var1, var2, var3, var4, var5, var6, var7, var8);
            return;
         }

         this.renderLayers(var1, var11, var12, var4, var5, var6, var7, var8);
      } else {
         this.renderLayers(var1, var2, var3, var4, var5, var6, var7, var8);
      }
   }

   @Inject(
      method = {"doRenderLayer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void doRenderLayer(EntityLivingBase var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, CallbackInfo var9) {
      if (Models.INSTANCE.isOn() && Models.INSTANCE.onlySelf.getValue() && var1 == Minecraft.getMinecraft().player) {
         var9.cancel();
      } else if (Models.INSTANCE.isOn() && !Models.INSTANCE.onlySelf.getValue()) {
         var9.cancel();
      }
   }

   private void renderLayers(EntityLivingBase var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      this.renderArmorLayer(var1, var2, var3, var4, var5, var6, var7, var8, EntityEquipmentSlot.CHEST);
      this.renderArmorLayer(var1, var2, var3, var4, var5, var6, var7, var8, EntityEquipmentSlot.LEGS);
      this.renderArmorLayer(var1, var2, var3, var4, var5, var6, var7, var8, EntityEquipmentSlot.FEET);
      this.renderArmorLayer(var1, var2, var3, var4, var5, var6, var7, var8, EntityEquipmentSlot.HEAD);
   }
}
