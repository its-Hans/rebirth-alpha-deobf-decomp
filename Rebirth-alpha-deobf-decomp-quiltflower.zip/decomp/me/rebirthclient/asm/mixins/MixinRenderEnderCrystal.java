package me.rebirthclient.asm.mixins;

import java.awt.Color;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.impl.render.CrystalChams;
import me.rebirthclient.mod.modules.impl.render.Shader;
import me.rebirthclient.mod.modules.impl.render.Shaders;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({RenderEnderCrystal.class})
public class MixinRenderEnderCrystal {
   @Redirect(
      method = {"doRender(Lnet/minecraft/entity/item/EntityEnderCrystal;DDDFF)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/model/ModelBase;render(Lnet/minecraft/entity/Entity;FFFFFF)V"
)
   )
   public void renderModelBaseHook(ModelBase var1, Entity var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      CrystalChams var9 = CrystalChams.INSTANCE;
      float var10 = var9.changeSpeed.getValue() ? var4 * var9.spinSpeed.getValue() : var4;
      float var11 = var9.changeSpeed.getValue() ? (var9.floatFactor.getValue() == 0.0F ? 0.15F : var5 * var9.floatFactor.getValue()) : var5;
      if (var9.isOn()) {
         GlStateManager.scale(var9.scale.getValue(), var9.scale.getValue(), var9.scale.getValue());
         if (var9.model.getValue() == CrystalChams.Model.VANILLA) {
            var1.render(var2, var3, var10, var11, var6, var7, var8);
         } else if (var9.model.getValue() == CrystalChams.Model.XQZ) {
            GL11.glEnable(32823);
            GlStateManager.enablePolygonOffset();
            GL11.glPolygonOffset(1.0F, -1000000.0F);
            if (var9.modelColor.booleanValue) {
               Color var12 = new Color(
                  var9.modelColor.getValue().getRed(),
                  var9.modelColor.getValue().getGreen(),
                  var9.modelColor.getValue().getBlue(),
                  var9.modelColor.getValue().getAlpha()
               );
               RenderUtil.glColor(var12);
            }

            var1.render(var2, var3, var10, var11, var6, var7, var8);
            GL11.glDisable(32823);
            GlStateManager.disablePolygonOffset();
            GL11.glPolygonOffset(1.0F, 1000000.0F);
         } else if (Shader.INSTANCE.isOn() && Shader.crystalRender) {
            var1.render(var2, var3, var10, var11, var6, var7, var8);
         } else if (Shaders.INSTANCE.isOn() && Shaders.INSTANCE.crystal.getValue() != Shaders.Crystal1.None && !Shaders.INSTANCE.notShader) {
            var1.render(var2, var3, var10, var11, var6, var7, var8);
         }

         if (var9.wireframe.getValue()) {
            Color var15 = var9.lineColor.booleanValue
               ? new Color(
                  var9.lineColor.getValue().getRed(),
                  var9.lineColor.getValue().getGreen(),
                  var9.lineColor.getValue().getBlue(),
                  var9.lineColor.getValue().getAlpha()
               )
               : new Color(var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha());
            GL11.glPushMatrix();
            GL11.glPushAttrib(1048575);
            GL11.glPolygonMode(1032, 6913);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glEnable(2848);
            GL11.glEnable(3042);
            GlStateManager.blendFunc(770, 771);
            RenderUtil.glColor(var15);
            GlStateManager.glLineWidth(var9.lineWidth.getValue());
            var1.render(var2, var3, var10, var11, var6, var7, var8);
            GL11.glPopAttrib();
            GL11.glPopMatrix();
         }

         if (var9.fill.getValue()) {
            Color var16 = new Color(
               var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha()
            );
            GL11.glPushAttrib(1048575);
            GL11.glDisable(3008);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glLineWidth(1.5F);
            GL11.glEnable(2960);
            if (var9.xqz.getValue()) {
               GL11.glDisable(2929);
               GL11.glDepthMask(false);
            }

            GL11.glEnable(10754);
            RenderUtil.glColor(var16);
            var1.render(var2, var3, var10, var11, var6, var7, var8);
            if (var9.xqz.getValue()) {
               GL11.glEnable(2929);
               GL11.glDepthMask(true);
            }

            GL11.glEnable(3042);
            GL11.glEnable(2896);
            GL11.glEnable(3553);
            GL11.glEnable(3008);
            GL11.glPopAttrib();
         }

         if (var9.glint.getValue() && var2 instanceof EntityEnderCrystal) {
            Color var17 = new Color(
               var9.color.getValue().getRed(), var9.color.getValue().getGreen(), var9.color.getValue().getBlue(), var9.color.getValue().getAlpha()
            );
            GL11.glPushMatrix();
            GL11.glPushAttrib(1048575);
            GL11.glPolygonMode(1032, 6914);
            GL11.glDisable(2896);
            GL11.glDepthRange(0.0, 0.1);
            GL11.glEnable(3042);
            RenderUtil.glColor(var17);
            GlStateManager.blendFunc(SourceFactor.SRC_COLOR, DestFactor.ONE);
            float var13 = (float)var2.ticksExisted + Wrapper.mc.getRenderPartialTicks();
            Wrapper.mc.getRenderManager().renderEngine.bindTexture(new ResourceLocation("textures/misc/enchanted_item_glint.png"));

            for(int var14 = 0; var14 < 2; ++var14) {
               GlStateManager.matrixMode(5890);
               GlStateManager.loadIdentity();
               GL11.glScalef(1.0F, 1.0F, 1.0F);
               GlStateManager.rotate(30.0F - (float)var14 * 60.0F, 0.0F, 0.0F, 1.0F);
               GlStateManager.translate(0.0F, var13 * (0.001F + (float)var14 * 0.003F) * 20.0F, 0.0F);
               GlStateManager.matrixMode(5888);
               var1.render(var2, var3, var10, var11, var6, var7, var8);
            }

            GlStateManager.matrixMode(5890);
            GlStateManager.loadIdentity();
            GlStateManager.matrixMode(5888);
            GL11.glDisable(3042);
            GL11.glDepthRange(0.0, 1.0);
            GL11.glEnable(2896);
            GL11.glPopAttrib();
            GL11.glPopMatrix();
         }

         GlStateManager.scale(1.0F / var9.scale.getValue(), 1.0F / var9.scale.getValue(), 1.0F / var9.scale.getValue());
      } else {
         var1.render(var2, var3, var4, var5, var6, var7, var8);
      }
   }
}
