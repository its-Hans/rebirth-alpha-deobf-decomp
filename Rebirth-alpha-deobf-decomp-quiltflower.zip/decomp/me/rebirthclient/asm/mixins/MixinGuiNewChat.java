package me.rebirthclient.asm.mixins;

import java.util.List;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.modules.impl.client.Chat;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.text.ITextComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiNewChat.class})
public abstract class MixinGuiNewChat extends Gui {
   @Shadow
   public boolean isScrolled;
   private float percentComplete;
   private long prevMillis = System.currentTimeMillis();
   private float animationPercent;

   @Redirect(
      method = {"drawChat"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V"
)
   )
   private void drawRectHook(int var1, int var2, int var3, int var4, int var5) {
      Chat var6 = Chat.INSTANCE;
      ClickGui var7 = ClickGui.INSTANCE;
      int var8 = var6.colorRect.getValue()
         ? (
            var7.rainbow.getValue()
               ? ColorUtil.toARGB(
                  ColorUtil.rainbow(var7.rainbowDelay.getValue()).getRed(),
                  ColorUtil.rainbow(var7.rainbowDelay.getValue()).getGreen(),
                  ColorUtil.rainbow(var7.rainbowDelay.getValue()).getBlue(),
                  45
               )
               : ColorUtil.toARGB(var7.color.getValue().getRed(), var7.color.getValue().getGreen(), var7.color.getValue().getBlue(), 45)
         )
         : var5;
      if (var6.isOn()) {
         if (var6.rect.getValue()) {
            Gui.drawRect(var1, var2, var3, var4, var8);
         } else {
            Gui.drawRect(var1, var2, var3, var4, 0);
         }
      } else {
         Gui.drawRect(var1, var2, var3, var4, var5);
      }
   }

   @Redirect(
      method = {"drawChat"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/FontRenderer;drawStringWithShadow(Ljava/lang/String;FFI)I"
)
   )
   private int drawStringWithShadow(FontRenderer var1, String var2, float var3, float var4, int var5) {
      Managers.TEXT.getClass();
      if (var2.contains("§(§)")) {
         Wrapper.mc.fontRenderer.drawStringWithShadow(var2, var3, var4, ColorUtil.injectAlpha(Chat.INSTANCE.color.getValue(), var5 >> 24 & 0xFF).getRGB());
      } else {
         Wrapper.mc.fontRenderer.drawStringWithShadow(var2, var3, var4, var5);
      }

      return 0;
   }

   @Redirect(
      method = {"setChatLine"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/List;size()I",
   ordinal = 0,
   remap = false
)
   )
   public int drawnChatLinesSize(List<ChatLine> var1) {
      return Chat.INSTANCE.isOn() && Chat.INSTANCE.infinite.getValue() ? -2147483647 : var1.size();
   }

   @Redirect(
      method = {"setChatLine"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/List;size()I",
   ordinal = 2,
   remap = false
)
   )
   public int chatLinesSize(List<ChatLine> var1) {
      return Chat.INSTANCE.isOn() && Chat.INSTANCE.infinite.getValue() ? -2147483647 : var1.size();
   }

   @Shadow
   public float getChatScale() {
      return Wrapper.mc.gameSettings.chatScale;
   }

   private void updatePercentage(long var1) {
      if (this.percentComplete < 1.0F) {
         this.percentComplete += 0.004F * (float)var1;
      }

      this.percentComplete = MathUtil.clamp(this.percentComplete, 0.0F, 1.0F);
   }

   @Inject(
      method = {"drawChat"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void modifyChatRendering(CallbackInfo var1) {
      long var2 = System.currentTimeMillis();
      long var4 = var2 - this.prevMillis;
      this.prevMillis = var2;
      this.updatePercentage(var4);
      float var6 = this.percentComplete;
      --var6;
      this.animationPercent = MathUtil.clamp(1.0F - var6 * var6 * var6 * var6, 0.0F, 1.0F);
   }

   @Inject(
      method = {"drawChat"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/GlStateManager;pushMatrix()V",
   ordinal = 0,
   shift = At.Shift.AFTER
)}
   )
   private void translate(CallbackInfo var1) {
      float var2 = 1.0F;
      if (!this.isScrolled && Chat.INSTANCE.isOn() && Chat.INSTANCE.animation.getValue()) {
         var2 += (9.0F - 9.0F * this.animationPercent) * this.getChatScale();
      }

      GlStateManager.translate(0.0F, var2, 0.0F);
   }

   @ModifyArg(
      method = {"drawChat"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/List;get(I)Ljava/lang/Object;",
   ordinal = 0,
   remap = false
),
      index = 0
   )
   private int getLineBeingDrawn(int var1) {
      return var1;
   }

   @Inject(
      method = {"printChatMessageWithOptionalDeletion"},
      at = {@At("HEAD")}
   )
   private void resetPercentage(CallbackInfo var1) {
      this.percentComplete = 0.0F;
   }

   @ModifyVariable(
      method = {"setChatLine"},
      at = @At("STORE"),
      ordinal = 0
   )
   private List<ITextComponent> setNewLines(List<ITextComponent> var1) {
      return var1;
   }
}
