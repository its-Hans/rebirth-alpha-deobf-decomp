package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.events.impl.PushEvent;
import me.rebirthclient.api.events.impl.StepEvent;
import me.rebirthclient.api.events.impl.TurnEvent;
import me.rebirthclient.mod.modules.impl.exploit.GhostHand;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MoverType;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {Entity.class},
   priority = Integer.MAX_VALUE
)
public abstract class MixinEntity {
   @Shadow
   public float stepHeight;

   @Shadow
   @Override
   public abstract boolean equals(Object var1);

   @Shadow
   public abstract AxisAlignedBB getEntityBoundingBox();

   @Shadow
   public abstract boolean isSneaking();

   @Inject(
      method = {"turn"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onTurnHook(float var1, float var2, CallbackInfo var3) {
      TurnEvent var4 = new TurnEvent(var1, var2);
      MinecraftForge.EVENT_BUS.post(var4);
      if (var4.isCanceled()) {
         var3.cancel();
      }
   }

   @Inject(
      method = {"rayTrace"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void rayTrace$Inject$INVOKE$rayTraceBlocks(double var1, float var3, CallbackInfoReturnable<RayTraceResult> var4) {
      if (this == Minecraft.getMinecraft().player) {
         GhostHand.handleRayTrace(var1, var3, var4);
      }
   }

   @Redirect(
      method = {"applyEntityCollision"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;addVelocity(DDD)V"
)
   )
   public void addVelocityHook(Entity var1, double var2, double var4, double var6) {
      PushEvent var8 = new PushEvent(var1, var2, var4, var6, true);
      MinecraftForge.EVENT_BUS.post(var8);
      if (!var8.isCanceled()) {
         var1.motionX += var8.x;
         var1.motionY += var8.y;
         var1.motionZ += var8.z;
         var1.isAirBorne = var8.airbone;
      }
   }

   @Inject(
      method = {"move"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/profiler/Profiler;endSection()V",
   shift = At.Shift.BEFORE,
   ordinal = 0
)}
   )
   public void onMove(MoverType var1, double var2, double var4, double var6, CallbackInfo var8) {
      if (((Entity)this).equals(Minecraft.getMinecraft().player)) {
         StepEvent var9 = new StepEvent(this.getEntityBoundingBox(), this.stepHeight);
         MinecraftForge.EVENT_BUS.post(var9);
         if (var9.isCanceled()) {
            this.stepHeight = var9.getHeight();
         }
      }
   }
}
