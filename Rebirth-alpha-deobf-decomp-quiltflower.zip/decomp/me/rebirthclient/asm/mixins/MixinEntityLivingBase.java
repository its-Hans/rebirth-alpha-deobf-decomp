package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.events.impl.ElytraEvent;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.modules.impl.movement.NoJumpDelay;
import me.rebirthclient.mod.modules.impl.render.ItemModel;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityLivingBase.class})
public class MixinEntityLivingBase implements Wrapper {
   @Shadow
   private int jumpTicks;

   @Inject(
      method = {"onLivingUpdate"},
      at = {@At("HEAD")}
   )
   private void headLiving(CallbackInfo var1) {
      if (NoJumpDelay.INSTANCE.isOn()) {
         this.jumpTicks = 0;
      }
   }

   @Inject(
      method = {"getArmSwingAnimationEnd"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> var1) {
      ItemModel var2 = ItemModel.INSTANCE;
      if (var2.isOn() && var2.customSwing.getValue() && var2.swing.getValue() == ItemModel.Swing.SERVER) {
         var1.setReturnValue(-1);
      } else if (var2.isOn() && var2.slowSwing.getValue()) {
         var1.setReturnValue(var2.swingSpeed.getValue());
      }
   }

   @Inject(
      method = {"travel"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void onTravelPre(float var1, float var2, float var3, CallbackInfo var4) {
      ElytraEvent var5 = new ElytraEvent((EntityLivingBase)this);
      MinecraftForge.EVENT_BUS.post(var5);
      if (var5.isCanceled()) {
         var4.cancel();
      }
   }
}
