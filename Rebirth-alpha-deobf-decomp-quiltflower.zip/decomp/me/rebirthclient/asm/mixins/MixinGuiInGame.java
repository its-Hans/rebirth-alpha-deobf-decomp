package me.rebirthclient.asm.mixins;

import me.rebirthclient.mod.modules.impl.client.HUD;
import me.rebirthclient.mod.modules.impl.render.NoLag;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.scoreboard.ScoreObjective;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiIngame.class})
public abstract class MixinGuiInGame extends Gui {
   @Inject(
      method = {"renderPotionEffects"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void renderPotionEffectsHook(ScaledResolution var1, CallbackInfo var2) {
      HUD var3 = HUD.INSTANCE;
      if (var3.potionIcons.getValue() && var3.isOn()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"renderScoreboard"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void renderScoreboardHook(ScoreObjective var1, ScaledResolution var2, CallbackInfo var3) {
      NoLag var4 = NoLag.INSTANCE;
      if (var4.scoreBoards.getValue() && var4.isOn()) {
         var3.cancel();
      }
   }
}
