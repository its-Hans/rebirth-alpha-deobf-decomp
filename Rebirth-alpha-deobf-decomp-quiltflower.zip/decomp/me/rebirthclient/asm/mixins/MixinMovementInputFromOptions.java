package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.modules.impl.movement.InventoryMove;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.MovementInputFromOptions;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({MovementInputFromOptions.class})
public class MixinMovementInputFromOptions implements Wrapper {
   @Redirect(
      method = {"updatePlayerMoveState"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/settings/KeyBinding;isKeyDown()Z"
)
   )
   public boolean isKeyPressed(KeyBinding var1) {
      int var2 = var1.getKeyCode();
      if (var2 <= 0) {
         return var1.isKeyDown();
      } else if (var2 >= 256) {
         return var1.isKeyDown();
      } else if (!InventoryMove.INSTANCE.isOn()) {
         return var1.isKeyDown();
      } else if (Minecraft.getMinecraft().currentScreen == null) {
         return var1.isKeyDown();
      } else if (Minecraft.getMinecraft().currentScreen instanceof GuiChat) {
         return var1.isKeyDown();
      } else {
         return var2 == 42 && !InventoryMove.INSTANCE.sneak.getValue() ? var1.isKeyDown() : Keyboard.isKeyDown(var2);
      }
   }
}
