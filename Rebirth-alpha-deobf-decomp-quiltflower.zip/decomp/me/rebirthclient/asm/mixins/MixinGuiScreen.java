package me.rebirthclient.asm.mixins;

import java.awt.Color;
import me.rebirthclient.api.events.impl.RenderToolTipEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.impl.misc.ToolTips;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({GuiScreen.class})
public abstract class MixinGuiScreen extends Gui {
   private boolean hoveringShulker;
   private ItemStack shulkerStack;
   private String shulkerName;

   @Inject(
      method = {"renderToolTip"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderToolTipHook(ItemStack var1, int var2, int var3, CallbackInfo var4) {
      RenderToolTipEvent var5 = new RenderToolTipEvent(var1, var2, var3);
      MinecraftForge.EVENT_BUS.post(var5);
      if (var5.isCanceled()) {
         var4.cancel();
      }

      if (var1.getItem() instanceof ItemShulkerBox) {
         this.hoveringShulker = true;
         this.shulkerStack = var1;
         this.shulkerName = var1.getDisplayName();
      } else {
         this.hoveringShulker = false;
      }
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")}
   )
   public void mouseClickedHook(int var1, int var2, int var3, CallbackInfo var4) {
      if (var3 == 2 && this.hoveringShulker && ToolTips.INSTANCE.wheelPeek.getValue() && ToolTips.INSTANCE.isOn()) {
         ToolTips.drawShulkerGui(this.shulkerStack, this.shulkerName);
      }
   }

   @Inject(
      method = {"drawScreen"},
      at = {@At("HEAD")}
   )
   public void drawScreenHook(int var1, int var2, float var3, CallbackInfo var4) {
      if (Wrapper.mc.currentScreen != null
         && !(Wrapper.mc.currentScreen instanceof GuiContainer)
         && ClickGui.INSTANCE.background.getValue()
         && Wrapper.mc.world != null) {
         RenderUtil.drawVGradientRect(
            0.0F,
            0.0F,
            (float)Managers.TEXT.scaledWidth,
            (float)Managers.TEXT.scaledHeight,
            new Color(0, 0, 0, 0).getRGB(),
            Managers.COLORS.getCurrentWithAlpha(60)
         );
      }
   }

   @Inject(
      method = {"drawWorldBackground(I)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void drawWorldBackgroundHook(int var1, CallbackInfo var2) {
      if (Wrapper.mc.world != null && ClickGui.INSTANCE.cleanGui.getValue()) {
         var2.cancel();
      }
   }
}
