package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.modules.impl.client.FontMod;
import me.rebirthclient.mod.modules.impl.client.NameProtect;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({FontRenderer.class})
public abstract class MixinFontRenderer {
   @Shadow
   protected abstract void renderStringAtPos(String var1, boolean var2);

   @Inject(
      method = {"drawString(Ljava/lang/String;FFIZ)I"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderStringHook(String var1, float var2, float var3, int var4, boolean var5, CallbackInfoReturnable<Integer> var6) {
      if (FontMod.INSTANCE == null) {
         FontMod.INSTANCE = new FontMod();
      }

      FontMod var7 = FontMod.INSTANCE;
      if (var7.isOn() && var7.global.getValue() && Managers.TEXT != null) {
         float var8 = Managers.TEXT.drawString(var1, var2, var3, var4, var5);
         var6.setReturnValue((int)var8);
      }
   }

   @Redirect(
      method = {"renderString(Ljava/lang/String;FFIZ)I"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/FontRenderer;renderStringAtPos(Ljava/lang/String;Z)V"
)
   )
   public void renderStringAtPosHook(FontRenderer var1, String var2, boolean var3) {
      if (NameProtect.INSTANCE == null) {
         NameProtect.INSTANCE = new NameProtect();
      }

      NameProtect var4 = NameProtect.INSTANCE;
      var2 = var4.isOn() ? var2.replaceAll(Wrapper.mc.getSession().getUsername(), var4.name.getValue()) : var2;
      this.renderStringAtPos(var2, var3);
   }
}
