package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.events.impl.FreecamEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.impl.render.ESP2D;
import me.rebirthclient.mod.modules.impl.render.Models;
import me.rebirthclient.mod.modules.impl.render.NameTags;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({RenderPlayer.class})
public class MixinRenderPlayer {
   private final ResourceLocation amongUs = new ResourceLocation("textures/rebirth/models/amongus.png");
   private final ResourceLocation rabbit = new ResourceLocation("textures/rebirth/models/rabbit.png");
   private final ResourceLocation freddy = new ResourceLocation("textures/rebirth/models/freddy.png");

   @Inject(
      method = {"renderEntityName*"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderEntityNameHook(AbstractClientPlayer var1, double var2, double var4, double var6, String var8, double var9, CallbackInfo var11) {
      if (NameTags.INSTANCE.isOn() || ESP2D.INSTANCE.isOn()) {
         var11.cancel();
      }
   }

   @Redirect(
      method = {"doRender"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/AbstractClientPlayer;isUser()Z"
)
   )
   private boolean isUserRedirect(AbstractClientPlayer var1) {
      Minecraft var2 = Minecraft.getMinecraft();
      FreecamEvent var3 = new FreecamEvent();
      MinecraftForge.EVENT_BUS.post(var3);
      if (!var3.isCanceled()) {
         return var1.isUser();
      } else {
         return var1.isUser() && var1 == var2.getRenderViewEntity();
      }
   }

   @Inject(
      method = {"getEntityTexture"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getEntityTexture(AbstractClientPlayer var1, CallbackInfoReturnable<ResourceLocation> var2) {
      if (Models.INSTANCE.isOn()
         && (
            !Models.INSTANCE.onlySelf.getValue()
               || var1 == Minecraft.getMinecraft().player
               || Managers.FRIENDS.isFriend(var1.getName()) && Models.INSTANCE.friends.getValue()
         )) {
         if (Models.INSTANCE.Mode.getValue() == Models.mode.AmongUs) {
            var2.setReturnValue(this.amongUs);
         }

         if (Models.INSTANCE.Mode.getValue() == Models.mode.Rabbit) {
            var2.setReturnValue(this.rabbit);
         }

         if (Models.INSTANCE.Mode.getValue() == Models.mode.Freddy) {
            var2.setReturnValue(this.freddy);
         }
      } else {
         GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         var2.setReturnValue(var1.getLocationSkin());
      }
   }
}
