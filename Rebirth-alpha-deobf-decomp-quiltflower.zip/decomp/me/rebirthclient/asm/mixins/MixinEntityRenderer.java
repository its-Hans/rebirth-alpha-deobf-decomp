package me.rebirthclient.asm.mixins;

import com.google.common.base.Predicate;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import me.rebirthclient.api.events.impl.FreecamEvent;
import me.rebirthclient.api.events.impl.PerspectiveEvent;
import me.rebirthclient.api.util.Vector3f;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.modules.impl.exploit.NoHitBox;
import me.rebirthclient.mod.modules.impl.render.Ambience;
import me.rebirthclient.mod.modules.impl.render.CameraClip;
import me.rebirthclient.mod.modules.impl.render.NoRender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.glu.Project;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntityRenderer.class})
public class MixinEntityRenderer {
   final Minecraft mc = Minecraft.getMinecraft();
   @Shadow
   private ItemStack itemActivationItem;
   @Shadow
   @Final
   private int[] lightmapColors;

   @Redirect(
      method = {"getMouseOver"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/multiplayer/WorldClient;getEntitiesInAABBexcluding(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;Lcom/google/common/base/Predicate;)Ljava/util/List;"
)
   )
   public List<Entity> getEntitiesInAABBexcluding(WorldClient var1, Entity var2, AxisAlignedBB var3, Predicate var4) {
      NoHitBox var5 = NoHitBox.INSTANCE;
      return (List<Entity>)(!var5.isOn()
            || (!(this.mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe) || !var5.pickaxe.getValue())
               && (this.mc.player.getHeldItemMainhand().getItem() != Items.END_CRYSTAL || !var5.crystal.getValue())
               && (this.mc.player.getHeldItemMainhand().getItem() != Items.GOLDEN_APPLE || !var5.gapple.getValue())
               && (this.mc.player.getHeldItemMainhand().getItem() != Item.getItemFromBlock(Blocks.OBSIDIAN) || !var5.obby.getValue())
               && this.mc.player.getHeldItemMainhand().getItem() != Items.FLINT_AND_STEEL
               && this.mc.player.getHeldItemMainhand().getItem() != Items.TNT_MINECART
         ? var1.getEntitiesInAABBexcluding(var2, var3, var4)
         : new ArrayList());
   }

   @Inject(
      method = {"hurtCameraEffect"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void hurtCameraEffect(float var1, CallbackInfo var2) {
      if (NoRender.INSTANCE.isOn() && NoRender.INSTANCE.hurtCam.getValue()) {
         var2.cancel();
      }
   }

   @Inject(
      method = {"renderItemActivation"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void renderItemActivationHook(CallbackInfo var1) {
      if (this.itemActivationItem != null
         && NoRender.INSTANCE.isOn()
         && NoRender.INSTANCE.totemPops.getValue()
         && this.itemActivationItem.getItem() == Items.TOTEM_OF_UNDYING) {
         var1.cancel();
      }
   }

   @ModifyVariable(
      method = {"orientCamera"},
      ordinal = 3,
      at = @At(
   value = "STORE",
   ordinal = 0
),
      require = 1
   )
   public double changeCameraDistanceHook(double var1) {
      return CameraClip.INSTANCE.isOn() ? CameraClip.INSTANCE.distance.getValue() : var1;
   }

   @ModifyVariable(
      method = {"orientCamera"},
      ordinal = 7,
      at = @At(
   value = "STORE",
   ordinal = 0
),
      require = 1
   )
   public double orientCameraHook(double var1) {
      return CameraClip.INSTANCE.isOn() ? CameraClip.INSTANCE.distance.getValue() : var1;
   }

   @Redirect(
      method = {"setupCameraTransform"},
      at = @At(
   value = "INVOKE",
   target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"
)
   )
   private void onSetupCameraTransform(float var1, float var2, float var3, float var4) {
      PerspectiveEvent var5 = new PerspectiveEvent((float)this.mc.displayWidth / (float)this.mc.displayHeight);
      MinecraftForge.EVENT_BUS.post(var5);
      Project.gluPerspective(var1, var5.getAngle(), var3, var4);
   }

   @Redirect(
      method = {"renderWorldPass"},
      at = @At(
   value = "INVOKE",
   target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"
)
   )
   private void onRenderWorldPass(float var1, float var2, float var3, float var4) {
      PerspectiveEvent var5 = new PerspectiveEvent((float)this.mc.displayWidth / (float)this.mc.displayHeight);
      MinecraftForge.EVENT_BUS.post(var5);
      Project.gluPerspective(var1, var5.getAngle(), var3, var4);
   }

   @Redirect(
      method = {"renderCloudsCheck"},
      at = @At(
   value = "INVOKE",
   target = "Lorg/lwjgl/util/glu/Project;gluPerspective(FFFF)V"
)
   )
   private void onRenderCloudsCheck(float var1, float var2, float var3, float var4) {
      PerspectiveEvent var5 = new PerspectiveEvent((float)this.mc.displayWidth / (float)this.mc.displayHeight);
      MinecraftForge.EVENT_BUS.post(var5);
      Project.gluPerspective(var1, var5.getAngle(), var3, var4);
   }

   @Inject(
      method = {"updateLightmap"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/texture/DynamicTexture;updateDynamicTexture()V",
   shift = At.Shift.BEFORE
)}
   )
   public void updateTextureHook(float var1, CallbackInfo var2) {
      if (Ambience.INSTANCE.isOn() && Ambience.INSTANCE.lightMap.booleanValue) {
         for(int var3 = 0; var3 < this.lightmapColors.length; ++var3) {
            Color var4 = Ambience.INSTANCE.getColor();
            int var5 = var4.getAlpha();
            float var6 = (float)var5 / 255.0F;
            int var7 = this.lightmapColors[var3];
            int[] var8 = MathUtil.toRGBAArray(var7);
            Vector3f var9 = new Vector3f((float)var8[2] / 255.0F, (float)var8[1] / 255.0F, (float)var8[0] / 255.0F);
            Vector3f var10 = new Vector3f((float)var4.getRed() / 255.0F, (float)var4.getGreen() / 255.0F, (float)var4.getBlue() / 255.0F);
            Vector3f var11 = MathUtil.mix(var9, var10, var6);
            int var12 = (int)(var11.x * 255.0F);
            int var13 = (int)(var11.y * 255.0F);
            int var14 = (int)(var11.z * 255.0F);
            this.lightmapColors[var3] = 0xFF000000 | var12 << 16 | var13 << 8 | var14;
         }
      }
   }

   @Redirect(
      method = {"getMouseOver"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/Minecraft;getRenderViewEntity()Lnet/minecraft/entity/Entity;"
)
   )
   private Entity redirectMouseOver(Minecraft var1) {
      FreecamEvent var2 = new FreecamEvent();
      MinecraftForge.EVENT_BUS.post(var2);
      return (Entity)(var2.isCanceled() && Keyboard.isKeyDown(56) ? var1.player : var1.getRenderViewEntity());
   }

   @Redirect(
      method = {"updateCameraAndRender"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/EntityPlayerSP;turn(FF)V"
)
   )
   private void redirectTurn(EntityPlayerSP var1, float var2, float var3) {
      try {
         Minecraft var4 = Minecraft.getMinecraft();
         FreecamEvent var5 = new FreecamEvent();
         MinecraftForge.EVENT_BUS.post(var5);
         if (var5.isCanceled()) {
            if (Keyboard.isKeyDown(56)) {
               var4.player.turn(var2, var3);
            } else {
               ((Entity)Objects.requireNonNull(var4.getRenderViewEntity(), "Render Entity")).turn(var2, var3);
            }

            return;
         }
      } catch (Exception var6) {
         var6.printStackTrace();
         return;
      }

      var1.turn(var2, var3);
   }

   @Redirect(
      method = {"renderWorldPass"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/EntityPlayerSP;isSpectator()Z"
)
   )
   public boolean redirectIsSpectator(EntityPlayerSP var1) {
      FreecamEvent var2 = new FreecamEvent();
      MinecraftForge.EVENT_BUS.post(var2);
      if (var2.isCanceled()) {
         return true;
      } else {
         return var1 != null ? var1.isSpectator() : false;
      }
   }
}
