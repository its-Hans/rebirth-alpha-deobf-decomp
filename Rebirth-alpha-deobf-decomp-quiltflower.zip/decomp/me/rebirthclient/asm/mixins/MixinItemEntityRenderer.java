package me.rebirthclient.asm.mixins;

import java.util.Random;
import me.rebirthclient.mod.modules.impl.render.ItemPhysics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderEntityItem.class})
public abstract class MixinItemEntityRenderer extends Render<EntityItem> {
   private static final float RAD_TO_DEG = (float) (180.0 / Math.PI);
   @Shadow
   @Final
   private Random random;
   @Shadow
   private RenderItem itemRenderer;

   protected MixinItemEntityRenderer(RenderManager var1) {
      super(var1);
   }

   @Shadow
   public abstract int getModelCount(ItemStack var1);

   @Inject(
      at = {@At("HEAD")},
      method = {"doRender"},
      cancellable = true
   )
   public void render(EntityItem var1, double var2, double var4, double var6, float var8, float var9, CallbackInfo var10) {
      ItemStack var11 = var1.getItem();
      if (ItemPhysics.INSTANCE.isOn() && var11.getItem() != null) {
         int var12 = this.getModelCount(var11);
         Item var13 = var11.getItem();
         int var14 = Item.getIdFromItem(var13) + var11.getItemDamage();
         this.random.setSeed((long)var14);
         float var15 = (((float)var1.getAge() + var9) / 20.0F + var1.height) / 20.0F * ItemPhysics.INSTANCE.rotateSpeed.getValue();
         this.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
         this.getRenderManager().renderEngine.getTexture(TextureMap.LOCATION_BLOCKS_TEXTURE).setBlurMipmap(false, false);
         GlStateManager.enableRescaleNormal();
         GlStateManager.alphaFunc(516, 0.1F);
         GlStateManager.enableBlend();
         RenderHelper.enableStandardItemLighting();
         GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
         GlStateManager.pushMatrix();
         GlStateManager.translate((float)var2, (float)var4, (float)var6);
         if (var1.getItem().item instanceof ItemShulkerBox) {
            GlStateManager.scale(
               ItemPhysics.INSTANCE.Scaling.getValue() + 1.1F + ItemPhysics.INSTANCE.shulkerBox.getValue(),
               ItemPhysics.INSTANCE.Scaling.getValue() + 1.1F + ItemPhysics.INSTANCE.shulkerBox.getValue(),
               ItemPhysics.INSTANCE.Scaling.getValue() + 1.1F + ItemPhysics.INSTANCE.shulkerBox.getValue()
            );
         } else if (var1.getItem().item instanceof ItemBlock) {
            GlStateManager.scale(
               ItemPhysics.INSTANCE.Scaling.getValue() + 1.1F, ItemPhysics.INSTANCE.Scaling.getValue() + 1.1F, ItemPhysics.INSTANCE.Scaling.getValue() + 1.1F
            );
         } else {
            GlStateManager.scale(
               ItemPhysics.INSTANCE.Scaling.getValue() + 0.3F, ItemPhysics.INSTANCE.Scaling.getValue() + 0.3F, ItemPhysics.INSTANCE.Scaling.getValue() + 0.3F
            );
         }

         GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
         GlStateManager.rotate(var1.rotationYaw * (float) (180.0 / Math.PI), 0.0F, 0.0F, 1.0F);
         Minecraft var16 = Minecraft.getMinecraft();
         IBakedModel var17 = var16.getRenderItem().getItemModelMesher().getItemModel(var11);
         this.rotateX(var1, var15);
         if (var17.isGui3d()) {
            GlStateManager.translate(0.0F, -0.2F, -0.08F);
         } else if (var1.getEntityWorld().getBlockState(var1.getPosition()).getBlock() != Blocks.SNOW
            && var1.getEntityWorld().getBlockState(var1.getPosition().down()).getBlock() != Blocks.SOUL_SAND) {
            GlStateManager.translate(0.0F, 0.0F, -0.04F);
         } else {
            GlStateManager.translate(0.0F, 0.0F, -0.14F);
         }

         float var18 = 0.2F;
         if (var17.isGui3d()) {
            GlStateManager.translate(0.0F, var18, 0.0F);
         }

         GlStateManager.rotate(var1.rotationPitch * (float) (180.0 / Math.PI), 0.0F, 1.0F, 0.0F);
         if (var17.isGui3d()) {
            GlStateManager.translate(0.0F, -var18, 0.0F);
         }

         if (!var17.isGui3d()) {
            float var19 = -0.0F * (float)(var12 - 1) * 0.5F;
            float var20 = -0.0F * (float)(var12 - 1) * 0.5F;
            float var21 = -0.09375F * (float)(var12 - 1) * 0.5F;
            GlStateManager.translate(var19, var20, var21);
         }

         for(int var23 = 0; var23 < var12; ++var23) {
            GlStateManager.pushMatrix();
            if (var23 > 0 && var17.isGui3d()) {
               float var24 = (this.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
               float var25 = (this.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
               float var22 = (this.random.nextFloat() * 2.0F - 1.0F) * 0.15F;
               GlStateManager.translate(var24, var25, var22);
            }

            var17.getItemCameraTransforms().applyTransform(TransformType.GROUND);
            this.itemRenderer.renderItem(var11, var17);
            GlStateManager.popMatrix();
            if (!var17.isGui3d()) {
               GlStateManager.translate(0.0F, 0.0F, 0.09375F);
            }
         }

         GlStateManager.popMatrix();
         GlStateManager.disableRescaleNormal();
         GlStateManager.disableBlend();
         this.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
         this.getRenderManager().renderEngine.getTexture(TextureMap.LOCATION_BLOCKS_TEXTURE).restoreLastBlurMipmap();
         var10.cancel();
      }
   }

   private void rotateX(EntityItem var1, float var2) {
      if (!var1.onGround) {
         var1.rotationPitch += var2 * 2.0F;
      }
   }
}
