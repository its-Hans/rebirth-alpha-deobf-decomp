package me.rebirthclient.asm.mixins;

import me.rebirthclient.mod.modules.impl.render.NoRender;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.inventory.EntityEquipmentSlot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LayerBipedArmor.class})
public class MixinLayerBipedArmor {
   @Inject(
      method = {"setModelSlotVisible*"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void setModelSlotVisible(ModelBiped var1, EntityEquipmentSlot var2, CallbackInfo var3) {
      if (!NoRender.INSTANCE.isOff() && NoRender.INSTANCE.armor.getValue()) {
         var3.cancel();
         var1.bipedHead.showModel = false;
         var1.bipedHeadwear.showModel = false;
         var1.bipedRightArm.showModel = false;
         var1.bipedLeftArm.showModel = false;
         var1.bipedBody.showModel = false;
         var1.bipedRightLeg.showModel = false;
         var1.bipedLeftLeg.showModel = false;
      }
   }
}
