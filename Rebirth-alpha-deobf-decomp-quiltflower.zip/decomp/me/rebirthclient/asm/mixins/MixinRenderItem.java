package me.rebirthclient.asm.mixins;

import me.rebirthclient.mod.modules.impl.render.GlintModify;
import me.rebirthclient.mod.modules.impl.render.ItemModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RenderItem.class})
public class MixinRenderItem {
   final Minecraft mc = Minecraft.getMinecraft();

   @ModifyArg(
      method = {"renderEffect"},
      at = @At(
   value = "INVOKE",
   target = "net/minecraft/client/renderer/RenderItem.renderModel(Lnet/minecraft/client/renderer/block/model/IBakedModel;I)V"
),
      index = 1
   )
   private int renderEffect(int var1) {
      return GlintModify.INSTANCE.isOn() ? GlintModify.getColor().getRGB() : var1;
   }

   @Inject(
      method = {"renderItemModel"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/renderer/RenderItem;renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V",
   shift = At.Shift.BEFORE
)}
   )
   private void renderCustom(ItemStack var1, IBakedModel var2, TransformType var3, boolean var4, CallbackInfo var5) {
      ItemModel var6 = ItemModel.INSTANCE;
      float var7 = 1.0F;
      float var8 = 0.0F;
      float var9 = 0.0F;
      if (var6.isOn()) {
         GlStateManager.scale(var7, var7, var7);
         if (this.mc.player.getActiveItemStack() != var1) {
            GlStateManager.translate(var8, var9, 0.0F);
         }
      }
   }

   @Inject(
      method = {"renderItemModel"},
      at = {@At("HEAD")}
   )
   public void renderItem(ItemStack var1, IBakedModel var2, TransformType var3, boolean var4, CallbackInfo var5) {
      ItemModel var6 = ItemModel.INSTANCE;
      if (var3 == TransformType.FIRST_PERSON_LEFT_HAND || var3 == TransformType.FIRST_PERSON_RIGHT_HAND) {
         if (var3 == TransformType.FIRST_PERSON_LEFT_HAND && this.mc.player.isHandActive() && this.mc.player.getActiveHand() == EnumHand.OFF_HAND) {
            return;
         }

         if (var3 == TransformType.FIRST_PERSON_RIGHT_HAND && this.mc.player.isHandActive() && this.mc.player.getActiveHand() == EnumHand.MAIN_HAND) {
            return;
         }
      }

      if (var6.isOn() && (var6.spinX.getValue() || var6.spinY.getValue())) {
         GlStateManager.rotate(var6.angle, var6.spinX.getValue() ? var6.angle : 0.0F, var6.spinY.getValue() ? var6.angle : 0.0F, 0.0F);
      }
   }
}
