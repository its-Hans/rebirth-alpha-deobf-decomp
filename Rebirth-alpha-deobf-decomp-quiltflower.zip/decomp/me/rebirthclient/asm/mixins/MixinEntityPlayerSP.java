package me.rebirthclient.asm.mixins;

import me.rebirthclient.api.events.impl.FreecamEvent;
import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.events.impl.PushEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.mod.modules.impl.exploit.BetterPortal;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.MoverType;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.stats.RecipeBook;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {EntityPlayerSP.class},
   priority = 9998
)
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer {
   @Shadow
   @Final
   public NetHandlerPlayClient connection;
   @Shadow
   protected Minecraft mc;
   @Shadow
   private boolean serverSprintState;
   @Shadow
   private boolean serverSneakState;
   @Shadow
   private double lastReportedPosX;
   @Shadow
   private double lastReportedPosY;
   @Shadow
   private double lastReportedPosZ;
   @Shadow
   private float lastReportedYaw;
   @Shadow
   private float lastReportedPitch;
   @Shadow
   private int positionUpdateTicks;
   @Shadow
   private boolean autoJumpEnabled;
   @Shadow
   private boolean prevOnGround;

   public MixinEntityPlayerSP(Minecraft var1, World var2, NetHandlerPlayClient var3, StatisticsManager var4, RecipeBook var5) {
      super(var2, var3.getGameProfile());
   }

   @Redirect(
      method = {"onLivingUpdate"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/EntityPlayerSP;closeScreen()V"
)
   )
   public void closeScreenHook(EntityPlayerSP var1) {
      if (!BetterPortal.INSTANCE.isOn() || !BetterPortal.INSTANCE.portalChat.getValue()) {
         var1.closeScreen();
      }
   }

   @Redirect(
      method = {"onLivingUpdate"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/Minecraft;displayGuiScreen(Lnet/minecraft/client/gui/GuiScreen;)V"
)
   )
   public void displayGuiScreenHook(Minecraft var1, GuiScreen var2) {
      if (!BetterPortal.INSTANCE.isOn() || !BetterPortal.INSTANCE.portalChat.getValue()) {
         var1.displayGuiScreen(var2);
      }
   }

   @Inject(
      method = {"pushOutOfBlocks"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void pushOutOfBlocksHook(double var1, double var3, double var5, CallbackInfoReturnable<Boolean> var7) {
      PushEvent var8 = new PushEvent(1);
      MinecraftForge.EVENT_BUS.post(var8);
      if (var8.isCanceled()) {
         var7.setReturnValue(false);
      }
   }

   @Redirect(
      method = {"move"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/AbstractClientPlayer;move(Lnet/minecraft/entity/MoverType;DDD)V"
)
   )
   public void move(AbstractClientPlayer var1, MoverType var2, double var3, double var5, double var7) {
      MoveEvent var9 = new MoveEvent(0, var2, var3, var5, var7);
      MinecraftForge.EVENT_BUS.post(var9);
      if (!var9.isCanceled()) {
         super.move(var9.getType(), var9.getX(), var9.getY(), var9.getZ());
      }
   }

   @Inject(
      method = {"onUpdateWalkingPlayer"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void preMotion(CallbackInfo var1) {
      UpdateWalkingPlayerEvent var2 = new UpdateWalkingPlayerEvent(0);
      MinecraftForge.EVENT_BUS.post(var2);
   }

   @Inject(
      method = {"onUpdateWalkingPlayer"},
      at = {@At("RETURN")}
   )
   private void postMotion(CallbackInfo var1) {
      UpdateWalkingPlayerEvent var2 = new UpdateWalkingPlayerEvent(1);
      MinecraftForge.EVENT_BUS.post(var2);
   }

   @Redirect(
      method = {"onUpdateWalkingPlayer"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/EntityPlayerSP;isCurrentViewEntity()Z"
)
   )
   private boolean redirectIsCurrentViewEntity(EntityPlayerSP var1) {
      Minecraft var2 = Minecraft.getMinecraft();
      FreecamEvent var3 = new FreecamEvent();
      MinecraftForge.EVENT_BUS.post(var3);
      if (var3.isCanceled()) {
         return var1 == var2.player;
      } else {
         return var2.getRenderViewEntity() == var1;
      }
   }

   @Redirect(
      method = {"updateEntityActionState"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/entity/EntityPlayerSP;isCurrentViewEntity()Z"
)
   )
   private boolean redirectIsCurrentViewEntity2(EntityPlayerSP var1) {
      Minecraft var2 = Minecraft.getMinecraft();
      FreecamEvent var3 = new FreecamEvent();
      MinecraftForge.EVENT_BUS.post(var3);
      if (var3.isCanceled()) {
         return var1 == var2.player;
      } else {
         return var2.getRenderViewEntity() == var1;
      }
   }

   @Shadow
   protected boolean isCurrentViewEntity() {
      return false;
   }

   @Overwrite
   private void onUpdateWalkingPlayer() {
      boolean var1 = this.isSprinting();
      MotionEvent var2 = new MotionEvent(0, this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch, this.onGround);
      MinecraftForge.EVENT_BUS.post(var2);
      if (var2.isCanceled()) {
         MotionEvent var17 = new MotionEvent(1, var2.getX(), var2.getY(), var2.getZ(), var2.getYaw(), var2.getPitch(), var2.isOnGround());
         MinecraftForge.EVENT_BUS.post(var17);
      } else {
         if (var1 != this.serverSprintState) {
            if (var1) {
               this.connection.sendPacket(new CPacketEntityAction(Minecraft.getMinecraft().player, Action.START_SPRINTING));
            } else {
               this.connection.sendPacket(new CPacketEntityAction(Minecraft.getMinecraft().player, Action.STOP_SPRINTING));
            }

            this.serverSprintState = var1;
         }

         boolean var3 = this.isSneaking();
         if (var3 != this.serverSneakState) {
            if (var3) {
               this.connection.sendPacket(new CPacketEntityAction(Minecraft.getMinecraft().player, Action.START_SNEAKING));
            } else {
               this.connection.sendPacket(new CPacketEntityAction(Minecraft.getMinecraft().player, Action.STOP_SNEAKING));
            }

            this.serverSneakState = var3;
         }

         if (this.isCurrentViewEntity()) {
            double var4 = this.posX - this.lastReportedPosX;
            double var6 = this.getEntityBoundingBox().minY - this.lastReportedPosY;
            double var8 = this.posZ - this.lastReportedPosZ;
            double var10 = (double)(var2.getYaw() - this.lastReportedYaw);
            double var12 = (double)(var2.getPitch() - this.lastReportedPitch);
            boolean var14 = var4 * var4 + var6 * var6 + var8 * var8 > 9.0E-4 || this.positionUpdateTicks >= 20;
            boolean var15 = var10 != 0.0 || var12 != 0.0;
            if (this.ridingEntity == null) {
               if (var14 && var15) {
                  this.connection.sendPacket(new PositionRotation(var2.getX(), var2.getY(), var2.getZ(), var2.getYaw(), var2.getPitch(), var2.isOnGround()));
               } else if (var14) {
                  this.connection.sendPacket(new Position(var2.getX(), var2.getY(), var2.getZ(), var2.isOnGround()));
               } else if (var15) {
                  this.connection.sendPacket(new Rotation(var2.getYaw(), var2.getPitch(), var2.isOnGround()));
               } else {
                  this.connection.sendPacket(new CPacketPlayer(var2.isOnGround()));
               }
            } else {
               this.connection.sendPacket(new PositionRotation(this.motionX, -999.0, this.motionZ, var2.getYaw(), var2.getPitch(), var2.isOnGround()));
               var14 = false;
            }

            ++this.positionUpdateTicks;
            if (var14) {
               this.lastReportedPosX = var2.getX();
               this.lastReportedPosY = var2.getY();
               this.lastReportedPosZ = var2.getZ();
               this.positionUpdateTicks = 0;
            }

            if (var15) {
               this.lastReportedYaw = var2.getYaw();
               this.lastReportedPitch = var2.getPitch();
            }

            this.prevOnGround = this.onGround;
            this.autoJumpEnabled = this.mc.gameSettings.autoJump;
            MotionEvent var16 = new MotionEvent(1, var2.getX(), var2.getY(), var2.getZ(), var2.getYaw(), var2.getPitch(), var2.isOnGround());
            MinecraftForge.EVENT_BUS.post(var16);
         }
      }
   }
}
