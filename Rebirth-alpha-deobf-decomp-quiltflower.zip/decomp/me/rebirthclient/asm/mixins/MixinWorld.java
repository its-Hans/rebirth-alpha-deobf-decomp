package me.rebirthclient.asm.mixins;

import com.google.common.base.Predicate;
import java.util.List;
import me.rebirthclient.api.events.impl.PushEvent;
import me.rebirthclient.api.events.impl.RenderSkyEvent;
import me.rebirthclient.mod.modules.impl.render.NoRender;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({World.class})
public class MixinWorld {
   @Inject(
      method = {"checkLightFor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void updateLightmapHook(EnumSkyBlock var1, BlockPos var2, CallbackInfoReturnable<Boolean> var3) {
      NoRender var4 = NoRender.INSTANCE;
      if (var1 == EnumSkyBlock.SKY && var4.isOn() && var4.skyLight.getValue() && !Minecraft.getMinecraft().isSingleplayer()) {
         var3.setReturnValue(false);
      }
   }

   @Redirect(
      method = {"getEntitiesWithinAABB(Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;Lcom/google/common/base/Predicate;)Ljava/util/List;"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/chunk/Chunk;getEntitiesOfTypeWithinAABB(Ljava/lang/Class;Lnet/minecraft/util/math/AxisAlignedBB;Ljava/util/List;Lcom/google/common/base/Predicate;)V"
)
   )
   public <T extends Entity> void getEntitiesOfTypeWithinAABBHook(
      Chunk var1, Class<? extends T> var2, AxisAlignedBB var3, List<T> var4, Predicate<? super T> var5
   ) {
      Chunk var10000 = var1;
      Class var10001 = var2;
      AxisAlignedBB var10002 = var3;
      List var10003 = var4;
      Predicate var10004 = var5;

      try {
         var10000.getEntitiesOfTypeWithinAABB(var10001, var10002, var10003, var10004);
      } catch (Exception var7) {
      }
   }

   @Redirect(
      method = {"handleMaterialAcceleration"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;isPushedByWater()Z"
)
   )
   public boolean isPushedbyWaterHook(Entity var1) {
      PushEvent var2 = new PushEvent(2, var1);
      MinecraftForge.EVENT_BUS.post(var2);
      if (!var1.isPushedByWater()) {
         return false;
      } else {
         return !var2.isCanceled();
      }
   }

   @Inject(
      method = {"onEntityAdded"},
      at = {@At("HEAD")}
   )
   private void onEntityAdded(Entity var1, CallbackInfo var2) {
   }

   @Inject(
      method = {"getSkyColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getSkyColorHook(Entity var1, float var2, CallbackInfoReturnable<Vec3d> var3) {
      RenderSkyEvent var4 = new RenderSkyEvent();
      MinecraftForge.EVENT_BUS.post(var4);
      if (var4.isCanceled()) {
         var3.cancel();
         var3.setReturnValue(
            new Vec3d((double)var4.getColor().getRed() / 255.0, (double)var4.getColor().getGreen() / 255.0, (double)var4.getColor().getBlue() / 255.0)
         );
      }
   }
}
