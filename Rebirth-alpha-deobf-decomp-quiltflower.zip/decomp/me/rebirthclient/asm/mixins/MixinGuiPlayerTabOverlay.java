package me.rebirthclient.asm.mixins;

import java.util.List;
import me.rebirthclient.mod.modules.impl.misc.ExtraTab;
import me.rebirthclient.mod.modules.impl.misc.TabFriends;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetworkPlayerInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({GuiPlayerTabOverlay.class})
public class MixinGuiPlayerTabOverlay extends Gui {
   @Redirect(
      method = {"renderPlayerlist"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/List;subList(II)Ljava/util/List;"
)
   )
   public List<NetworkPlayerInfo> subListHook(List<NetworkPlayerInfo> var1, int var2, int var3) {
      return var1.subList(var2, ExtraTab.INSTANCE.isOn() ? Math.min(ExtraTab.INSTANCE.size.getValue(), var1.size()) : var3);
   }

   @Inject(
      method = {"getPlayerName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getPlayerNameHook(NetworkPlayerInfo var1, CallbackInfoReturnable<String> var2) {
      if (TabFriends.INSTANCE.isOn()) {
         var2.setReturnValue(TabFriends.getPlayerName(var1));
      }
   }
}
