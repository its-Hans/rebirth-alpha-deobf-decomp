package me.rebirthclient.api.managers.impl;

import com.google.common.base.Strings;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import me.rebirthclient.api.events.impl.ConnectionEvent;
import me.rebirthclient.api.events.impl.DamageBlockEvent;
import me.rebirthclient.api.events.impl.DeathEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.events.impl.RenderFogColorEvent;
import me.rebirthclient.api.events.impl.TotemPopEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.gui.click.items.other.Particle;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.impl.client.Title;
import me.rebirthclient.mod.modules.impl.combat.CombatSetting;
import me.rebirthclient.mod.modules.impl.combat.Surround;
import me.rebirthclient.mod.modules.impl.render.RenderSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraft.network.play.server.SPacketPlayerListItem.Action;
import net.minecraft.network.play.server.SPacketPlayerListItem.AddPlayerData;
import net.minecraftforge.client.event.ClientChatEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogColors;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientConnectedToServerEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import org.lwjgl.input.Keyboard;

public class EventManager extends Mod {
   private final Timer logoutTimer = new Timer();
   private final AtomicBoolean tickOngoing;
   private final Particle.Util particles = new Particle.Util(300);

   @SubscribeEvent
   public void BlockBreak(DamageBlockEvent var1) {
      if (var1.getPosition().getY() != -1) {
         EntityPlayer var2 = (EntityPlayer)mc.world.getEntityByID(var1.getBreakerId());
         if (var2 != null
            && !(var2.getDistance((double)var1.getPosition().getX() + 0.5, (double)var1.getPosition().getY(), (double)var1.getPosition().getZ() + 0.5) > 7.0)) {
            BreakManager.MineMap.put(var2, var1.getPosition());
            boolean var10000 = false;
         }
      }
   }

   @SubscribeEvent
   public void onTick(ClientTickEvent var1) {
      Title.updateTitle();
      Managers.COLORS.rainbowProgress += ClickGui.INSTANCE.rainbowSpeed.getValue();
      if (!fullNullCheck()) {
         Managers.MODULES.onTick();

         for(EntityPlayer var3 : mc.world.playerEntities) {
            if (var3 != null) {
               if (var3.getHealth() > 0.0F) {
                  boolean var10000 = false;
               } else {
                  MinecraftForge.EVENT_BUS.post(new DeathEvent(var3));
                  boolean var4 = false;
                  Managers.MODULES.onDeath(var3);
                  var4 = false;
               }
            }
         }

         if (CombatUtil.isHole(EntityUtil.getPlayerPos(), false, 4, true)
            && Surround.INSTANCE.isOff()
            && Surround.INSTANCE.enableInHole.getValue()
            && mc.player.onGround
            && !MovementUtil.isJumping()) {
            Surround.INSTANCE.enable();
         }

         if (CombatSetting.INSTANCE.isOff()) {
            CombatSetting.INSTANCE.enable();
         }

         if (RenderSetting.INSTANCE.isOff()) {
            RenderSetting.INSTANCE.enable();
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onChatSent(ClientChatEvent var1) {
      if (var1.getMessage().startsWith(Command.getCommandPrefix())) {
         var1.setCanceled(true);
         Minecraft var10000 = mc;

         try {
            var10000.ingameGUI.getChatGUI().addToSentMessages(var1.getMessage());
            if (var1.getMessage().length() > 1) {
               Managers.COMMANDS.executeCommand(var1.getMessage().substring(Command.getCommandPrefix().length() - 1));
               boolean var4 = false;
            } else {
               Command.sendMessage("Please enter a command.");
            }
         } catch (Exception var3) {
            var3.printStackTrace();
            Command.sendMessage(
               String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("An error occurred while running this command. Check the log!"))
            );
            return;
         }

         boolean var5 = false;
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOW
   )
   public void onRenderGameOverlayEvent(Text var1) {
      if (var1.getType() == ElementType.TEXT) {
         ScaledResolution var2 = new ScaledResolution(mc);
         Render2DEvent var3 = new Render2DEvent(var1.getPartialTicks(), var2);
         Managers.MODULES.onRender2D(var3);
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   @SubscribeEvent
   public void onFogColor(FogColors var1) {
      RenderFogColorEvent var2 = new RenderFogColorEvent();
      MinecraftForge.EVENT_BUS.post(var2);
      boolean var10000 = false;
      if (var2.isCanceled()) {
         var1.setRed((float)var2.getColor().getRed() / 255.0F);
         var1.setGreen((float)var2.getColor().getGreen() / 255.0F);
         var1.setBlue((float)var2.getColor().getBlue() / 255.0F);
      }
   }

   public void init() {
      MinecraftForge.EVENT_BUS.register(this);
   }

   public boolean ticksOngoing() {
      return this.tickOngoing.get();
   }

   @SubscribeEvent
   public void onWorldRender(RenderWorldLastEvent var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            Managers.FPS.update();
            mc.profiler.startSection("Rebirth");
            GlStateManager.disableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.disableAlpha();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.shadeModel(7425);
            GlStateManager.disableDepth();
            GlStateManager.glLineWidth(1.0F);
            Render3DEvent var2 = new Render3DEvent(var1.getPartialTicks());
            Managers.MODULES.onRender3D(var2);
            GlStateManager.glLineWidth(1.0F);
            GlStateManager.shadeModel(7424);
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.enableTexture2D();
            GlStateManager.enableDepth();
            GlStateManager.enableCull();
            GlStateManager.enableCull();
            GlStateManager.depthMask(true);
            GlStateManager.enableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.enableDepth();
            mc.profiler.endSection();
         }
      }
   }

   public void onUnload() {
      MinecraftForge.EVENT_BUS.unregister(this);
   }

   private static void lambda$onPacketReceive$1(SPacketPlayerListItem var0, AddPlayerData var1) {
      UUID var4 = var1.getProfile().getId();
      switch(null.$SwitchMap$net$minecraft$network$play$server$SPacketPlayerListItem$Action[var0.getAction().ordinal()]) {
         case 1:
            String var2 = var1.getProfile().getName();
            MinecraftForge.EVENT_BUS.post(new ConnectionEvent(0, var4, var2));
            boolean var8 = false;
            var8 = false;
            break;
         case 2:
            EntityPlayer var3 = mc.world.getPlayerEntityByUUID(var4);
            if (var3 != null) {
               String var5 = var3.getName();
               MinecraftForge.EVENT_BUS.post(new ConnectionEvent(1, var3, var4, var5));
               boolean var10000 = false;
               var10000 = false;
            } else {
               MinecraftForge.EVENT_BUS.post(new ConnectionEvent(2, var4, null));
               boolean var7 = false;
            }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (var1.getStage() == 0) {
            Managers.SERVER.onPacketReceived();
            if (var1.getPacket() instanceof SPacketEntityStatus) {
               SPacketEntityStatus var2 = var1.getPacket();
               if (var2.getOpCode() == 35 && var2.getEntity(mc.world) instanceof EntityPlayer) {
                  EntityPlayer var3 = (EntityPlayer)var2.getEntity(mc.world);
                  MinecraftForge.EVENT_BUS.post(new TotemPopEvent(var3));
                  boolean var10000 = false;
                  Managers.MODULES.onTotemPop(var3);
               }
            }

            if (var1.getPacket() instanceof SPacketPlayerListItem && !fullNullCheck() && this.logoutTimer.passedS(1.0)) {
               SPacketPlayerListItem var4 = var1.getPacket();
               if (Action.ADD_PLAYER != var4.getAction() && Action.REMOVE_PLAYER != var4.getAction()) {
                  return;
               }

               var4.getEntries()
                  .stream()
                  .filter(Objects::nonNull)
                  .filter(EventManager::lambda$onPacketReceive$0)
                  .forEach(EventManager::lambda$onPacketReceive$1);
            }

            if (var1.getPacket() instanceof SPacketTimeUpdate) {
               Managers.SERVER.update();
            }
         }
      }
   }

   private static boolean lambda$onPacketReceive$0(AddPlayerData var0) {
      boolean var10000;
      if (Strings.isNullOrEmpty(var0.getProfile().getName()) && var0.getProfile().getId() == null) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void renderHUD(Post var1) {
      if (var1.getType() == ElementType.HOTBAR) {
         Managers.TEXT.updateResolution();
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getStage() == 0) {
            Managers.SPEED.updateValues();
            Managers.ROTATIONS.updateRotations();
            Managers.POSITION.updatePosition();
         }

         if (var1.getStage() == 1) {
            if (CombatSetting.INSTANCE.resetRotation.getValue()) {
               Managers.ROTATIONS.resetRotations();
            }

            if (CombatSetting.INSTANCE.resetPosition.getValue()) {
               Managers.POSITION.restorePosition();
            }
         }
      }
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectionFromServerEvent var1) {
      Managers.CONFIGS.saveConfig(Managers.CONFIGS.config.replaceFirst("Rebirth/", ""));
      Managers.MODULES.onLogout();
   }

   @SubscribeEvent
   public void onUpdate(LivingUpdateEvent var1) {
      if (!fullNullCheck() && var1.getEntity().getEntityWorld().isRemote && var1.getEntityLiving().equals(mc.player)) {
         Managers.MODULES.onUpdate();
         Managers.MODULES.sortModules();
      }
   }

   @SubscribeEvent
   public void onTick(RenderTickEvent var1) {
      GuiScreen var2 = Minecraft.getMinecraft().currentScreen;
      if (var2 != null) {
         if (ClickGui.INSTANCE.particles.getValue()) {
            this.particles.drawParticles();
         }

         if (Minecraft.getMinecraft().world == null) {
            Managers.TEXT
               .drawString(
                  String.valueOf(new StringBuilder().append("Rebirth ").append(ChatFormatting.WHITE).append("alpha")),
                  1.0F,
                  (float)(var2.height - Managers.TEXT.getFontHeight2()),
                  Managers.COLORS.getNormalCurrent().getRGB(),
                  true
               );
            boolean var10000 = false;
            Managers.TEXT.drawRollingRainbowString("powered by iMadCat", 1.0F, (float)(var2.height - Managers.TEXT.getFontHeight2() * 2), true);
            var10000 = false;
         } else {
            Managers.TEXT
               .drawString(
                  String.valueOf(new StringBuilder().append("Rebirth ").append(ChatFormatting.WHITE).append("alpha")),
                  (float)var2.width - 1.0F - (float)Managers.TEXT.getStringWidth("Rebirth alpha"),
                  (float)(var2.height - Managers.TEXT.getFontHeight2()),
                  Managers.COLORS.getNormalCurrent().getRGB(),
                  true
               );
            boolean var4 = false;
            Managers.TEXT
               .drawRollingRainbowString(
                  "powered by iMadCat",
                  (float)var2.width - 1.0F - (float)Managers.TEXT.getStringWidth("powered by iMadCat"),
                  (float)(var2.height - Managers.TEXT.getFontHeight2() * 2),
                  true
               );
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.NORMAL,
      receiveCanceled = true
   )
   public void onKeyInput(KeyInputEvent var1) {
      if (Keyboard.getEventKeyState()) {
         Managers.MODULES.onKeyInput(Keyboard.getEventKey());
      }
   }

   public EventManager() {
      this.tickOngoing = new AtomicBoolean(false);
   }

   @SubscribeEvent
   public void onClientConnect(ClientConnectedToServerEvent var1) {
      this.logoutTimer.reset();
      boolean var10000 = false;
      Managers.MODULES.onLogin();
   }
}
