package me.rebirthclient.api.managers.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.LinkedList;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.commands.impl.BindCommand;
import me.rebirthclient.mod.commands.impl.ConfigCommand;
import me.rebirthclient.mod.commands.impl.CoordsCommand;
import me.rebirthclient.mod.commands.impl.FriendCommand;
import me.rebirthclient.mod.commands.impl.HelpCommand;
import me.rebirthclient.mod.commands.impl.ModuleCommand;
import me.rebirthclient.mod.commands.impl.PrefixCommand;
import me.rebirthclient.mod.commands.impl.ReloadSoundCommand;
import me.rebirthclient.mod.commands.impl.ShrugCommand;
import me.rebirthclient.mod.commands.impl.UnloadCommand;
import me.rebirthclient.mod.commands.impl.WatermarkCommand;

public class CommandManager extends Mod {
   private String prefix;
   private String clientMessage;
   private final ArrayList<Command> commands = new ArrayList<>();

   public String getClientMessage() {
      return this.clientMessage;
   }

   public CommandManager() {
      super("Command");
      this.clientMessage = "[Rebirth]";
      this.prefix = ";";
      this.commands.add(new BindCommand());
      boolean var10000 = false;
      this.commands.add(new ModuleCommand());
      var10000 = false;
      this.commands.add(new PrefixCommand());
      var10000 = false;
      this.commands.add(new ConfigCommand());
      var10000 = false;
      this.commands.add(new FriendCommand());
      var10000 = false;
      this.commands.add(new HelpCommand());
      var10000 = false;
      this.commands.add(new UnloadCommand());
      var10000 = false;
      this.commands.add(new ReloadSoundCommand());
      var10000 = false;
      this.commands.add(new CoordsCommand());
      var10000 = false;
      this.commands.add(new ShrugCommand());
      var10000 = false;
      this.commands.add(new WatermarkCommand());
      var10000 = false;
   }

   public void setClientMessage(String var1) {
      this.clientMessage = var1;
   }

   public void executeCommand(String var1) {
      String[] var2 = var1.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
      String var3 = var2[0].substring(1);
      String[] var4 = removeElement(var2, 0);

      for(int var5 = 0; var5 < var4.length; ++var5) {
         if (var4[var5] == null) {
            boolean var10000 = false;
         } else {
            var4[var5] = strip(var4[var5]);
         }

         boolean var8 = false;
      }

      for(Command var6 : this.commands) {
         if (Integer.valueOf(var3.toUpperCase().hashCode()).equals(var6.getName().toUpperCase().hashCode())) {
            var6.execute(var2);
            return;
         }

         boolean var9 = false;
      }

      Command.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append("Command not found, type 'help' for the commands list.")));
   }

   public String getCommandPrefix() {
      return this.prefix;
   }

   public ArrayList<Command> getCommands() {
      return this.commands;
   }

   public static String[] removeElement(String[] var0, int var1) {
      LinkedList var2 = new LinkedList();

      for(int var3 = 0; var3 < var0.length; ++var3) {
         if (var3 == var1) {
            boolean var10000 = false;
         } else {
            var2.add(var0[var3]);
            boolean var4 = false;
         }

         boolean var5 = false;
      }

      return var2.toArray(var0);
   }

   private static String strip(String var0) {
      return var0.startsWith("\"") && var0.endsWith("\"") ? var0.substring("\"".length(), var0.length() - "\"".length()) : var0;
   }

   public Command getCommandByName(String var1) {
      for(Command var3 : this.commands) {
         if (Integer.valueOf(var1.hashCode()).equals(var3.getName().hashCode())) {
            return var3;
         }

         boolean var10000 = false;
      }

      return null;
   }

   public void setPrefix(String var1) {
      this.prefix = var1;
   }
}
