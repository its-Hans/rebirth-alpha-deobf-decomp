package me.rebirthclient.api.managers.impl;

import java.util.HashMap;
import me.rebirthclient.mod.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;

public class SpeedManager extends Mod {
   public boolean wasFirstJump;
   public double speedometerCurrentSpeed;
   public boolean didJumpLastTick;
   public static boolean isJumping;
   public final HashMap<EntityPlayer, Double> playerSpeeds = new HashMap<>();
   public double percentJumpSpeedChanged;
   public long jumpInfoStartTime;
   public double lastJumpSpeed;
   public static final Minecraft mc = Minecraft.getMinecraft();
   private final int distancer = 20;
   public double firstJumpSpeed;
   public static final double LAST_JUMP_INFO_DURATION_DEFAULT = 3.0;
   public double jumpSpeedChanged;
   public static boolean didJumpThisTick;

   public double getSpeedMpS() {
      double var1 = this.turnIntoKpH(this.speedometerCurrentSpeed) / 3.6;
      return (double)Math.round(10.0 * var1) / 10.0;
   }

   public void updatePlayers() {
      for(EntityPlayer var2 : mc.world.playerEntities) {
         if (!(mc.player.getDistanceSq(var2) < 400.0)) {
            boolean var10000 = false;
         } else {
            double var3 = var2.posX - var2.prevPosX;
            double var5 = var2.posZ - var2.prevPosZ;
            double var7 = var3 * var3 + var5 * var5;
            this.playerSpeeds.put(var2, var7);
            boolean var9 = false;
            var9 = false;
         }
      }
   }

   public float lastJumpInfoTimeRemaining() {
      return (float)(Minecraft.getSystemTime() - this.jumpInfoStartTime) / 1000.0F;
   }

   public void updateValues() {
      double var1 = mc.player.posX - mc.player.prevPosX;
      double var3 = mc.player.posZ - mc.player.prevPosZ;
      this.speedometerCurrentSpeed = var1 * var1 + var3 * var3;
      if (didJumpThisTick && (!mc.player.onGround || isJumping)) {
         if (didJumpThisTick && !this.didJumpLastTick) {
            boolean var10001;
            if (this.lastJumpSpeed == 0.0) {
               var10001 = true;
               boolean var10002 = false;
            } else {
               var10001 = false;
            }

            this.wasFirstJump = var10001;
            double var5;
            if (this.speedometerCurrentSpeed != 0.0) {
               var5 = this.speedometerCurrentSpeed / this.lastJumpSpeed - 1.0;
               boolean var7 = false;
            } else {
               var5 = -1.0;
            }

            this.percentJumpSpeedChanged = var5;
            this.jumpSpeedChanged = this.speedometerCurrentSpeed - this.lastJumpSpeed;
            this.jumpInfoStartTime = Minecraft.getSystemTime();
            this.lastJumpSpeed = this.speedometerCurrentSpeed;
            double var6;
            if (this.wasFirstJump) {
               var6 = this.lastJumpSpeed;
               boolean var8 = false;
            } else {
               var6 = 0.0;
            }

            this.firstJumpSpeed = var6;
         }

         this.didJumpLastTick = didJumpThisTick;
         boolean var10000 = false;
      } else {
         this.didJumpLastTick = false;
         this.lastJumpSpeed = 0.0;
      }

      this.updatePlayers();
   }

   public double getPlayerSpeed(EntityPlayer var1) {
      return this.playerSpeeds.get(var1) == null ? 0.0 : this.turnIntoKpH(this.playerSpeeds.get(var1));
   }

   public SpeedManager() {
      this.wasFirstJump = true;
   }

   public static void setIsJumping(boolean var0) {
      isJumping = var0;
   }

   public double turnIntoKpH(double var1) {
      return (double)MathHelper.sqrt(var1) * 71.2729367892;
   }

   public double getSpeedKpH() {
      double var1 = this.turnIntoKpH(this.speedometerCurrentSpeed);
      return (double)Math.round(10.0 * var1) / 10.0;
   }

   public static void setDidJumpThisTick(boolean var0) {
      didJumpThisTick = var0;
   }
}
