package me.rebirthclient.api.managers.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.Rebirth;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.commands.Command;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ReloadManager extends Mod {
   public String prefix;

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (var1.getPacket() instanceof CPacketChatMessage) {
         CPacketChatMessage var2 = var1.getPacket();
         if (var2.getMessage().startsWith(this.prefix) && var2.getMessage().contains("reload")) {
            Rebirth.load();
            var1.setCanceled(true);
         }
      }
   }

   public void unload() {
      MinecraftForge.EVENT_BUS.unregister(this);
   }

   public void init(String var1) {
      this.prefix = var1;
      MinecraftForge.EVENT_BUS.register(this);
      if (!fullNullCheck()) {
         Command.sendMessage(
            String.valueOf(
               new StringBuilder().append(ChatFormatting.RED).append("Rebirth").append(" has been unloaded. Type ").append(var1).append("reload to reload.")
            )
         );
      }
   }
}
