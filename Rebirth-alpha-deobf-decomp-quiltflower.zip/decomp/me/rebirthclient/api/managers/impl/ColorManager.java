package me.rebirthclient.api.managers.impl;

import java.awt.Color;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.modules.impl.client.ClickGui;

public class ColorManager {
   public int rainbowProgress = 1;
   private Color current = new Color(-1);

   public Color getRainbow() {
      return ColorUtil.rainbow(ClickGui.INSTANCE.rainbowDelay.getValue());
   }

   public boolean isRainbow() {
      return ClickGui.INSTANCE.rainbow.getValue();
   }

   public Color getCurrent() {
      return this.isRainbow() ? this.getRainbow() : this.current;
   }

   public int getCurrentGui(int var1) {
      return this.isRainbow()
         ? ColorUtil.rainbow(Component.counter1[0] * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB()
         : ColorUtil.toRGBA(ColorUtil.injectAlpha(this.current, var1));
   }

   public Color getFriendColor(int var1) {
      return new Color(0, 191, 255, var1);
   }

   public int getCurrentWithAlpha(int var1) {
      return this.isRainbow() ? ColorUtil.toRGBA(ColorUtil.injectAlpha(this.getRainbow(), var1)) : ColorUtil.toRGBA(ColorUtil.injectAlpha(this.current, var1));
   }

   public void setCurrent(Color var1) {
      this.current = var1;
   }

   public Color getNormalCurrent() {
      return this.current;
   }
}
