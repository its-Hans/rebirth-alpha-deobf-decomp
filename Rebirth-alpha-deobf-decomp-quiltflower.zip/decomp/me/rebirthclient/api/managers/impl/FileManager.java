package me.rebirthclient.api.managers.impl;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.modules.Category;

public class FileManager extends Mod {
   private final Path config;
   private final Path base = this.getMkDirectory(this.getRoot(), "Rebirth");

   public Path getMkBaseResolve(String... var1) {
      Path var2 = this.getBaseResolve(var1);
      this.createDirectory(var2.getParent());
      return var2;
   }

   public Path getBasePath() {
      return this.base;
   }

   public Path getBaseResolve(String... var1) {
      String[] var2 = this.expandPaths(var1).toArray(FileManager::lambda$getBaseResolve$0);
      if (var2.length < 1) {
         throw new IllegalArgumentException("missing path");
      } else {
         return this.lookupPath(this.getBasePath(), var2);
      }
   }

   private Path getRoot() {
      return Paths.get("");
   }

   public FileManager() {
      this.config = this.getMkDirectory(this.base, "config");
      this.getMkDirectory(this.base, "pvp");
      boolean var10000 = false;

      for(Category var2 : Managers.MODULES.getCategories()) {
         this.getMkDirectory(this.config, var2.getName());
         var10000 = false;
         var10000 = false;
      }
   }

   public static void appendTextFile(String var0, String var1) {
      String var10000 = var1;
      String[] var10001 = new String[0];

      try {
         Path var2 = Paths.get(var10000, var10001);
         List var6 = Collections.singletonList(var0);
         Charset var10002 = StandardCharsets.UTF_8;
         OpenOption[] var10003 = new OpenOption[1];
         StandardOpenOption var10006;
         if (Files.exists(var2)) {
            var10006 = StandardOpenOption.APPEND;
            boolean var10007 = false;
         } else {
            var10006 = StandardOpenOption.CREATE;
         }

         var10003[0] = var10006;
         Files.write(var2, var6, var10002, var10003);
         boolean var4 = false;
      } catch (IOException var3) {
         System.out.println(String.valueOf(new StringBuilder().append("WARNING: Unable to write file: ").append(var1)));
         return;
      }

      boolean var5 = false;
   }

   public Path getMkBaseDirectory(String... var1) {
      return this.getMkDirectory(this.getBasePath(), this.expandPaths(var1).collect(Collectors.joining(File.separator)));
   }

   private String[] expandPath(String var1) {
      return var1.split(":?\\\\\\\\|\\/");
   }

   private Stream<String> expandPaths(String... var1) {
      return Arrays.stream(var1).map(this::expandPath).flatMap(Arrays::stream);
   }

   public Path getCache() {
      return this.getBasePath().resolve("cache");
   }

   private Path getMkDirectory(Path var1, String... var2) {
      if (var2.length < 1) {
         return var1;
      } else {
         Path var3 = this.lookupPath(var1, var2);
         this.createDirectory(var3);
         return var3;
      }
   }

   private static String[] lambda$getBaseResolve$0(int var0) {
      return new String[var0];
   }

   public static List<String> readTextFileAllLines(String var0) {
      String var10000 = var0;
      String[] var10001 = new String[0];

      try {
         Path var1 = Paths.get(var10000, var10001);
         return Files.readAllLines(var1, StandardCharsets.UTF_8);
      } catch (IOException var2) {
         System.out.println(String.valueOf(new StringBuilder().append("WARNING: Unable to read file, creating new file: ").append(var0)));
         appendTextFile("", var0);
         return Collections.emptyList();
      }
   }

   private Path lookupPath(Path var1, String... var2) {
      return Paths.get(var1.toString(), var2);
   }

   public Path getConfig() {
      return this.getBasePath().resolve("config");
   }

   public Path getMkConfigDirectory(String... var1) {
      return this.getMkDirectory(this.getConfig(), this.expandPaths(var1).collect(Collectors.joining(File.separator)));
   }

   private void createDirectory(Path var1) {
      Path var10000 = var1;
      LinkOption[] var10001 = new LinkOption[0];

      try {
         if (!Files.isDirectory(var10000, var10001)) {
            if (Files.exists(var1)) {
               Files.delete(var1);
            }

            Files.createDirectories(var1);
            boolean var4 = false;
         }
      } catch (IOException var3) {
         var3.printStackTrace();
         return;
      }

      boolean var5 = false;
   }
}
