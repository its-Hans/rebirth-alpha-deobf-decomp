package me.rebirthclient.api.managers.impl;

import java.util.Optional;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.modules.impl.render.PlaceRender;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockAnvil;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockButton;
import net.minecraft.block.BlockCake;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockRedstoneDiode;
import net.minecraft.block.BlockTrapDoor;
import net.minecraft.block.BlockWorkbench;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class InteractionManager extends Mod {
   private final Timer attackTimer = new Timer();

   public Optional<InteractionManager.ClickLocation> getClickLocation(BlockPos var1, boolean var2, boolean var3, boolean var4) {
      Block var5 = mc.world.getBlockState(var1).getBlock();
      if (!(var5 instanceof BlockAir) && !(var5 instanceof BlockLiquid)) {
         return Optional.empty();
      } else {
         if (!var2) {
            for(Entity var7 : mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(var1))) {
               if (var4 && var7 instanceof EntityEnderCrystal) {
                  boolean var17 = false;
               } else {
                  if (!(var7 instanceof EntityItem) && !(var7 instanceof EntityXPOrb) && !(var7 instanceof EntityArrow)) {
                     return Optional.empty();
                  }

                  boolean var10000 = false;
               }
            }
         }

         EnumFacing var13 = null;

         for(EnumFacing var10 : EnumFacing.values()) {
            BlockPos var11 = var1.offset(var10);
            if (var3 && mc.world.getBlockState(var11).getBlock() == Blocks.PISTON) {
               boolean var20 = false;
            } else if (!mc.world.getBlockState(var11).getBlock().canCollideCheck(mc.world.getBlockState(var11), false)) {
               boolean var18 = false;
            } else {
               IBlockState var12 = mc.world.getBlockState(var11);
               if (!var12.getMaterial().isReplaceable()) {
                  var13 = var10;
                  boolean var19 = false;
                  break;
               }
            }

            boolean var21 = false;
         }

         if (var13 == null) {
            return Optional.empty();
         } else {
            BlockPos var15 = var1.offset(var13);
            EnumFacing var16 = var13.getOpposite();
            return !mc.world.getBlockState(var15).getBlock().canCollideCheck(mc.world.getBlockState(var15), false)
               ? Optional.empty()
               : Optional.of(new InteractionManager.ClickLocation(var15, var16));
         }
      }
   }

   public void attackCrystals(BlockPos var1, boolean var2) {
      boolean var3 = mc.player.isSprinting();
      int var4 = Managers.SERVER.getPing();

      for(EntityEnderCrystal var6 : mc.world.getEntitiesWithinAABB(EntityEnderCrystal.class, new AxisAlignedBB(var1))) {
         Timer var10000 = this.attackTimer;
         long var10001;
         if (var4 <= 50) {
            var10001 = 75L;
            boolean var10002 = false;
         } else {
            var10001 = 100L;
         }

         if (var10000.passedMs(var10001)) {
            if (var2) {
               Managers.ROTATIONS.lookAtVec3dPacket(var6.getPositionVector(), true);
            }

            if (var3) {
               mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SPRINTING));
            }

            mc.player.connection.sendPacket(new CPacketUseEntity(var6));
            mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
            if (var3) {
               mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SPRINTING));
            }

            this.attackTimer.reset();
            boolean var8 = false;
            boolean var9 = false;
            break;
         }

         boolean var7 = false;
      }
   }

   public void placeBlock(BlockPos var1, boolean var2, boolean var3, boolean var4, boolean var5) {
      if (!fullNullCheck()) {
         if (BlockUtil.canReplace(var1)) {
            if (var4) {
               this.attackCrystals(var1, var2);
            }

            Optional var6 = this.getClickLocation(var1, var5, false, var4);
            if (var6.isPresent()) {
               BlockPos var7 = ((InteractionManager.ClickLocation)var6.get()).neighbour;
               EnumFacing var8 = ((InteractionManager.ClickLocation)var6.get()).opposite;
               boolean var9 = this.shouldShiftClick(var7);
               if (var9) {
                  mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
               }

               Vec3d var10 = new Vec3d(var7).add(0.5, 0.5, 0.5).add(new Vec3d(var8.getDirectionVec()).scale(0.5));
               if (var2) {
                  Managers.ROTATIONS.lookAtVec3dPacket(var10, true);
               }

               if (var3) {
                  Vec3d var11 = new Vec3d(var7).add(0.5, 0.5, 0.5);
                  float var12 = (float)(var11.x - (double)var7.getX());
                  float var13 = (float)(var11.y - (double)var7.getY());
                  float var14 = (float)(var11.z - (double)var7.getZ());
                  mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(var7, var8, EnumHand.MAIN_HAND, var12, var13, var14));
                  boolean var10000 = false;
               } else {
                  mc.playerController.processRightClickBlock(mc.player, mc.world, var7, var8, var10, EnumHand.MAIN_HAND);
                  boolean var15 = false;
               }

               PlaceRender.PlaceMap.put(var1, new PlaceRender.placePosition(var1));
               boolean var16 = false;
               mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
               if (var9) {
                  mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
               }
            }
         }
      }
   }

   public void placeBlock(BlockPos var1, boolean var2, boolean var3, boolean var4) {
      this.placeBlock(var1, var2, var3, var4, false);
   }

   public void attackEntity(Entity var1, boolean var2, boolean var3) {
      if (var2) {
         mc.player.connection.sendPacket(new CPacketUseEntity(var1));
         boolean var10000 = false;
      } else {
         mc.playerController.attackEntity(mc.player, var1);
      }

      if (var3) {
         mc.player.swingArm(EnumHand.MAIN_HAND);
      }
   }

   public boolean shouldShiftClick(BlockPos var1) {
      Block var2 = mc.world.getBlockState(var1).getBlock();
      TileEntity var3 = null;

      for(TileEntity var5 : mc.world.loadedTileEntityList) {
         if (var5.getPos().equals(var1)) {
            var3 = var5;
            boolean var6 = false;
            break;
         }

         boolean var10000 = false;
      }

      boolean var7;
      if (var3 == null
         && !(var2 instanceof BlockBed)
         && !(var2 instanceof BlockContainer)
         && !(var2 instanceof BlockDoor)
         && !(var2 instanceof BlockTrapDoor)
         && !(var2 instanceof BlockFenceGate)
         && !(var2 instanceof BlockButton)
         && !(var2 instanceof BlockAnvil)
         && !(var2 instanceof BlockWorkbench)
         && !(var2 instanceof BlockCake)
         && !(var2 instanceof BlockRedstoneDiode)) {
         var7 = false;
      } else {
         var7 = true;
         boolean var10001 = false;
      }

      return var7;
   }

   public static class ClickLocation {
      public final BlockPos neighbour;
      public final EnumFacing opposite;

      public ClickLocation(BlockPos var1, EnumFacing var2) {
         this.neighbour = var1;
         this.opposite = var2;
      }
   }
}
