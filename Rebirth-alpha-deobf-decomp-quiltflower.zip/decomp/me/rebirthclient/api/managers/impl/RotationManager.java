package me.rebirthclient.api.managers.impl;

import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.asm.accessors.IEntityPlayerSP;
import me.rebirthclient.mod.Mod;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationManager extends Mod {
   private float pitch;
   private float yaw;

   public void lookAtPos(BlockPos var1) {
      float[] var2 = MathUtil.calcAngle(
         mc.player.getPositionEyes(Wrapper.mc.getRenderPartialTicks()),
         new Vec3d((double)((float)var1.getX() + 0.5F), (double)((float)var1.getY() - 0.5F), (double)((float)var1.getZ() + 0.5F))
      );
      this.setRotations(var2[0], var2[1]);
   }

   public void setRotations(float var1, float var2) {
      mc.player.rotationYaw = var1;
      mc.player.rotationYawHead = var1;
      mc.player.rotationPitch = var2;
   }

   public float[] injectYawStep(float[] var1, float var2) {
      if (var2 < 0.1F) {
         var2 = 0.1F;
      }

      if (var2 > 1.0F) {
         var2 = 1.0F;
      }

      if (var2 < 1.0F && var1 != null) {
         float var3 = ((IEntityPlayerSP)mc.player).getLastReportedYaw();
         float var4 = MathHelper.wrapDegrees(var1[0] - var3);
         if (Math.abs(var4) > 180.0F * var2) {
            var1[0] = var3 + var4 * (180.0F * var2 / Math.abs(var4));
         }
      }

      return new float[]{var1[0], var1[1]};
   }

   public void resetRotationsPacket() {
      float[] var1 = new float[]{mc.player.rotationYaw, mc.player.rotationPitch};
      mc.player.connection.sendPacket(new Rotation(var1[0], var1[1], mc.player.onGround));
   }

   public float getPitch() {
      return this.pitch;
   }

   public boolean isInFov(BlockPos var1) {
      int var2 = this.getYaw4D();
      if (var2 == 0 && (double)var1.getZ() - mc.player.getPositionVector().z < 0.0) {
         return false;
      } else if (var2 == 1 && (double)var1.getX() - mc.player.getPositionVector().x > 0.0) {
         return false;
      } else if (var2 == 2 && (double)var1.getZ() - mc.player.getPositionVector().z > 0.0) {
         return false;
      } else {
         boolean var10000;
         if (var2 == 3 && !((double)var1.getX() - mc.player.getPositionVector().x >= 0.0)) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var10001 = false;
         }

         return var10000;
      }
   }

   public float getYaw() {
      return this.yaw;
   }

   public static float[] calculateAngle(Vec3d var0, Vec3d var1) {
      double var2 = var1.x - var0.x;
      double var4 = (var1.y - var0.y) * -1.0;
      double var6 = var1.z - var0.z;
      double var8 = (double)MathHelper.sqrt(var2 * var2 + var6 * var6);
      float var10 = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(var6, var2)) - 90.0);
      float var11 = (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(var4, var8)));
      if (var11 > 90.0F) {
         var11 = 90.0F;
         boolean var10000 = false;
      } else if (var11 < -90.0F) {
         var11 = -90.0F;
      }

      return new float[]{var10, var11};
   }

   public float[] getAngle(Vec3d var1) {
      Vec3d var2 = new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ);
      double var3 = var1.x - var2.x;
      double var5 = var1.y - var2.y;
      double var7 = var1.z - var2.z;
      double var9 = Math.sqrt(var3 * var3 + var7 * var7);
      float var11 = (float)Math.toDegrees(Math.atan2(var7, var3)) - 90.0F;
      float var12 = (float)(-Math.toDegrees(Math.atan2(var5, var9)));
      return new float[]{
         mc.player.rotationYaw + MathHelper.wrapDegrees(var11 - mc.player.rotationYaw),
         mc.player.rotationPitch + MathHelper.wrapDegrees(var12 - mc.player.rotationPitch)
      };
   }

   public void resetRotations() {
      mc.player.rotationYaw = this.yaw;
      mc.player.rotationYawHead = this.yaw;
      mc.player.rotationPitch = this.pitch;
   }

   public void updateRotations() {
      this.yaw = mc.player.rotationYaw;
      this.pitch = mc.player.rotationPitch;
   }

   public int getYaw4D() {
      return MathHelper.floor((double)(mc.player.rotationYaw * 4.0F / 360.0F) + 0.5) & 3;
   }

   public void setPlayerRotations(float var1, float var2) {
      mc.player.rotationYaw = var1;
      mc.player.rotationYawHead = var1;
      mc.player.rotationPitch = var2;
   }

   public void lookAtVec3dPacket(Vec3d var1, boolean var2) {
      float[] var3 = this.getAngle(var1);
      mc.player.connection.sendPacket(new Rotation(var3[0], var3[1], mc.player.onGround));
      if (var2) {
         ((IEntityPlayerSP)mc.player).setLastReportedYaw(var3[0]);
         ((IEntityPlayerSP)mc.player).setLastReportedPitch(var3[1]);
      }
   }

   public void lookAtVec3d(Vec3d var1) {
      float[] var2 = MathUtil.calcAngle(mc.player.getPositionEyes(Wrapper.mc.getRenderPartialTicks()), new Vec3d(var1.x, var1.y, var1.z));
      this.setRotations(var2[0], var2[1]);
   }

   public String getDirection4D(boolean var1) {
      int var2 = this.getYaw4D();
      if (var2 == 0) {
         return "South (+Z)";
      } else if (var2 == 1) {
         return "West (-X)";
      } else if (var2 == 2) {
         StringBuilder var10000 = new StringBuilder();
         String var10001;
         if (var1) {
            var10001 = "Â§c";
            boolean var10002 = false;
         } else {
            var10001 = "";
         }

         return String.valueOf(var10000.append(var10001).append("North (-Z)"));
      } else {
         return var2 == 3 ? "East (+X)" : "Loading...";
      }
   }

   public void lookAtVec3dPacket(Vec3d var1) {
      float[] var2 = this.getAngle(var1);
      mc.player.connection.sendPacket(new Rotation(var2[0], var2[1], mc.player.onGround));
   }
}
