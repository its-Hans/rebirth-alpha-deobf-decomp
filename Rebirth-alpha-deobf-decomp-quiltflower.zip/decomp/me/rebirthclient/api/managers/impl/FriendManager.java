package me.rebirthclient.api.managers.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import me.rebirthclient.api.util.ProfileUtil;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;

public class FriendManager extends Mod {
   private List<FriendManager.Friend> friends = new ArrayList<>();

   private static boolean lambda$isFriend$0(String var0, FriendManager.Friend var1) {
      return Integer.valueOf(var0.toUpperCase().hashCode()).equals(FriendManager.Friend.access$000(var1).toUpperCase().hashCode());
   }

   public FriendManager() {
      super("Friends");
   }

   public void addFriend(FriendManager.Friend var1) {
      this.friends.add(var1);
      boolean var10000 = false;
   }

   private static boolean lambda$cleanFriends$1(FriendManager.Friend var0) {
      boolean var10000;
      if (var0.getUsername() != null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public FriendManager.Friend getFriendByName(String var1) {
      UUID var2 = ProfileUtil.getUUIDFromName(var1);
      return var2 != null ? new FriendManager.Friend(var1, var2) : null;
   }

   public void saveFriends() {
      this.resetSettings();
      this.cleanFriends();

      for(FriendManager.Friend var2 : this.friends) {
         this.add(new Setting<>(var2.getUuid().toString(), var2.getUsername()));
         boolean var10000 = false;
         var10000 = false;
      }
   }

   public boolean isCool(String var1) {
      List var2 = Arrays.asList("iMadCat");
      return var2.contains(var1);
   }

   public void addFriend(String var1) {
      FriendManager.Friend var2 = this.getFriendByName(var1);
      if (var2 != null) {
         this.friends.add(var2);
         boolean var10000 = false;
      }

      this.cleanFriends();
   }

   public List<FriendManager.Friend> getFriends() {
      this.cleanFriends();
      return this.friends;
   }

   public boolean isFriend(EntityPlayer var1) {
      return this.isFriend(var1.getName());
   }

   public void onLoad() {
      this.friends = new ArrayList<>();
      this.resetSettings();
   }

   public void cleanFriends() {
      this.friends.stream().filter(Objects::nonNull).filter(FriendManager::lambda$cleanFriends$1);
      boolean var10000 = false;
   }

   public boolean isFriend(String var1) {
      if (Integer.valueOf("§aYou".hashCode()).equals(var1.hashCode())) {
         return true;
      } else {
         this.cleanFriends();
         return this.friends.stream().anyMatch(FriendManager::lambda$isFriend$0);
      }
   }

   public void removeFriend(String var1) {
      this.cleanFriends();

      for(FriendManager.Friend var3 : this.friends) {
         if (Integer.valueOf(var1.toUpperCase().hashCode()).equals(var3.getUsername().toUpperCase().hashCode())) {
            this.friends.remove(var3);
            boolean var4 = false;
            var4 = false;
            break;
         }

         boolean var10000 = false;
      }
   }

   public static class Friend {
      private final UUID uuid;
      private final String username;

      public String getUsername() {
         return this.username;
      }

      public Friend(String var1, UUID var2) {
         this.username = var1;
         this.uuid = var2;
      }

      static String access$000(FriendManager.Friend var0) {
         return var0.username;
      }

      public UUID getUuid() {
         return this.uuid;
      }
   }
}
