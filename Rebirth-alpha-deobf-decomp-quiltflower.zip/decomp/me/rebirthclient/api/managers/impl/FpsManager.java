package me.rebirthclient.api.managers.impl;

import java.util.LinkedList;
import net.minecraft.client.Minecraft;

public final class FpsManager {
   private final LinkedList<Long> frames = new LinkedList<>();
   private int fps;

   public int getMcFPS() {
      return Minecraft.getDebugFPS();
   }

   public void update() {
      long var1 = System.nanoTime();
      this.frames.add(var1);
      boolean var10000 = false;

      while(true) {
         long var3 = this.frames.getFirst();
         long var5 = 1000000000L;
         if (var1 - var3 <= 1000000000L) {
            this.fps = this.frames.size();
            return;
         }

         this.frames.remove();
         var10000 = false;
         var10000 = false;
      }
   }

   public int getFPS() {
      return this.fps;
   }

   public float getFrametime() {
      return 0.004166667F;
   }
}
