package me.rebirthclient.api.managers.impl;

import java.util.HashMap;
import me.rebirthclient.api.util.Wrapper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

public class BreakManager implements Wrapper {
   public static final HashMap<EntityPlayer, BlockPos> MineMap = new HashMap();

   public static boolean isMine(BlockPos var0) {
      for(EntityPlayer var2 : MineMap.keySet()) {
         if (var2 == null) {
            boolean var10000 = false;
         } else {
            BlockPos var3 = (BlockPos)MineMap.get(var2);
            if (var3 == null) {
               boolean var4 = false;
            } else {
               if (new BlockPos(var3).equals(new BlockPos(var0))) {
                  return true;
               }

               boolean var5 = false;
            }
         }
      }

      return false;
   }
}
