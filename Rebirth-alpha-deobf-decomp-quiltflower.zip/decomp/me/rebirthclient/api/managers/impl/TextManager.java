package me.rebirthclient.api.managers.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Font;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.gui.font.CFont;
import me.rebirthclient.mod.gui.font.CustomFont;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.impl.client.FontMod;
import me.rebirthclient.mod.modules.impl.client.NameProtect;
import net.minecraft.util.math.MathHelper;

public class TextManager extends Mod {
   public int scaledWidth;
   public int scaleFactor;
   public final String syncCode = "§(§)";
   public int scaledHeight;
   private CustomFont customFont;
   private final CustomFont iconFont;
   private final Timer idleTimer = new Timer();
   private boolean idling;

   public int getMCStringWidth(String var1) {
      NameProtect var2 = NameProtect.INSTANCE;
      String var10000;
      if (var2.isOn()) {
         var10000 = var1.replaceAll(mc.getSession().getUsername(), var2.name.getValue());
         boolean var10001 = false;
      } else {
         var10000 = var1;
      }

      var1 = var10000;
      return mc.fontRenderer.getStringWidth(var1);
   }

   public int getFontHeight() {
      return FontMod.INSTANCE.isOn() ? this.customFont.getStringHeight("A") : mc.fontRenderer.FONT_HEIGHT;
   }

   public String capitalSpace(String var1) {
      var1 = var1.replace("A", " A");
      var1 = var1.replace("B", " B");
      var1 = var1.replace("C", " C");
      var1 = var1.replace("D", " D");
      var1 = var1.replace("E", " E");
      var1 = var1.replace("F", " F");
      var1 = var1.replace("G", " G");
      var1 = var1.replace("H", " H");
      var1 = var1.replace("I", " I");
      var1 = var1.replace("J", " J");
      var1 = var1.replace("K", " K");
      var1 = var1.replace("L", " L");
      var1 = var1.replace("M", " M");
      var1 = var1.replace("N", " N");
      var1 = var1.replace("O", " O");
      var1 = var1.replace("P", " P");
      var1 = var1.replace("Q", " Q");
      var1 = var1.replace("R", " R");
      var1 = var1.replace("S", " S");
      var1 = var1.replace("T", " T");
      var1 = var1.replace("U", " U");
      var1 = var1.replace("V", " V");
      var1 = var1.replace("W", " W");
      var1 = var1.replace("X", " X");
      var1 = var1.replace("Y", " Y");
      var1 = var1.replace("Z", " Z");
      var1 = var1.replace("T P", "TP");
      var1 = var1.replace("T N T", "TNT");
      var1 = var1.replace("D M G", "DMG");
      var1 = var1.replace("H U D", "HUD");
      var1 = var1.replace("E S P", "ESP");
      var1 = var1.replace("F P S", "FPS");
      var1 = var1.replace("M C F", "MCF");
      var1 = var1.replace("2 D", "2D");
      if (var1.startsWith(" ")) {
         var1 = var1.replaceFirst(" ", "");
      }

      return var1;
   }

   public void drawStringWithShadow(String var1, float var2, float var3, int var4) {
      this.drawString(var1, var2, var3, var4, true);
      boolean var10000 = false;
   }

   public void drawMCString(String var1, float var2, float var3, int var4, boolean var5) {
      NameProtect var6 = NameProtect.INSTANCE;
      String var10000;
      if (var6.isOn()) {
         var10000 = var1.replaceAll(mc.getSession().getUsername(), var6.name.getValue());
         boolean var10001 = false;
      } else {
         var10000 = var1;
      }

      var1 = var10000;
      mc.fontRenderer.drawString(var1, var2, var3, var4, var5);
      boolean var8 = false;
   }

   public void updateResolution() {
      this.scaledWidth = mc.displayWidth;
      this.scaledHeight = mc.displayHeight;
      this.scaleFactor = 1;
      boolean var1 = mc.isUnicode();
      int var2 = mc.gameSettings.guiScale;
      if (var2 == 0) {
         var2 = 1000;
      }

      while(this.scaleFactor < var2 && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
         ++this.scaleFactor;
         boolean var10000 = false;
      }

      if (var1 && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
         --this.scaleFactor;
      }

      double var3 = (double)this.scaledWidth / (double)this.scaleFactor;
      double var5 = (double)this.scaledHeight / (double)this.scaleFactor;
      this.scaledWidth = MathHelper.ceil(var3);
      this.scaledHeight = MathHelper.ceil(var5);
   }

   public String normalizeCases(Object var1) {
      return String.valueOf(new StringBuilder().append(Character.toUpperCase(var1.toString().charAt(0))).append(var1.toString().toLowerCase().substring(1)));
   }

   public int getStringWidth(String var1) {
      NameProtect var2 = NameProtect.INSTANCE;
      String var10000;
      if (var2.isOn()) {
         var10000 = var1.replaceAll(mc.getSession().getUsername(), var2.name.getValue());
         boolean var10001 = false;
      } else {
         var10000 = var1;
      }

      var1 = var10000;
      return FontMod.INSTANCE.isOn() ? this.customFont.getStringWidth(var1) : mc.fontRenderer.getStringWidth(var1);
   }

   public String getPrefix() {
      return String.valueOf(new StringBuilder().append("§(§)§f[§rRebirth§f] ").append(ChatFormatting.RESET));
   }

   public void drawStringIcon(String var1, float var2, float var3, int var4) {
      NameProtect var5 = NameProtect.INSTANCE;
      String var10000;
      if (var5.isOn()) {
         var10000 = var1.replaceAll(mc.getSession().getUsername(), var5.name.getValue());
         boolean var10001 = false;
      } else {
         var10000 = var1;
      }

      var1 = var10000;
      this.iconFont.drawStringWithShadow(var1, (double)var2, (double)var3, var4);
      boolean var7 = false;
   }

   public void init() {
      if (FontMod.INSTANCE == null) {
         FontMod.INSTANCE = new FontMod();
      }

      FontMod var1 = FontMod.INSTANCE;
      TextManager var10000 = this;
      Font var10001 = new Font;
      Font var10002 = var10001;
      FontMod var10003 = var1;

      try {
         var10002./* $QF: Unable to resugar constructor */<init>(var10003.font.getValue(), var1.getFont(), var1.size.getValue());
         var10000.setFontRenderer(var10001, var1.antiAlias.getValue(), var1.metrics.getValue());
      } catch (Exception var3) {
         return;
      }

      boolean var4 = false;
   }

   public void setFontRenderer(Font var1, boolean var2, boolean var3) {
      this.customFont = new CustomFont(var1, var2, var3);
   }

   public Font getCurrentFont() {
      return this.customFont.getFont();
   }

   public void drawRollingRainbowString(String var1, float var2, float var3, boolean var4) {
      int[] var5 = new int[]{1};
      char[] var6 = var1.toCharArray();
      float var7 = 0.0F + var2;

      for(char var11 : var6) {
         this.drawString(String.valueOf(var11), var7, var3, ColorUtil.rainbow(var5[0] * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB(), var4);
         boolean var10000 = false;
         var7 += (float)this.getStringWidth(String.valueOf(var11));
         var5[0]++;
         var10000 = false;
      }
   }

   public int getFontHeight2() {
      return FontMod.INSTANCE.isOn() ? this.customFont.getStringHeight("A") + 3 : mc.fontRenderer.FONT_HEIGHT;
   }

   public String getIdleSign() {
      if (this.idleTimer.passedMs(500L)) {
         boolean var10001;
         if (!this.idling) {
            var10001 = true;
            boolean var10002 = false;
         } else {
            var10001 = false;
         }

         this.idling = var10001;
         this.idleTimer.reset();
         boolean var10000 = false;
      }

      return this.idling ? "_" : "";
   }

   public TextManager() {
      this.iconFont = new CustomFont(new CFont.CustomFont("/assets/minecraft/textures/rebirth/fonts/IconFont.ttf", 19.0F, 0), true, false);
      this.customFont = new CustomFont(new Font("Verdana", 0, 17), true, true);
      this.updateResolution();
   }

   public float drawString(String var1, float var2, float var3, int var4, boolean var5) {
      NameProtect var6 = NameProtect.INSTANCE;
      String var10000;
      if (var6.isOn()) {
         var10000 = var1.replaceAll(mc.getSession().getUsername(), var6.name.getValue());
         boolean var10001 = false;
      } else {
         var10000 = var1;
      }

      var1 = var10000;
      if (FontMod.INSTANCE.isOn()) {
         if (var5) {
            this.customFont.drawStringWithShadow(var1, (double)var2, (double)var3, var4);
            boolean var9 = false;
            boolean var10 = false;
         } else {
            this.customFont.drawString(var1, var2, var3, var4);
            boolean var11 = false;
         }

         return var2;
      } else {
         mc.fontRenderer.drawString(var1, var2, var3, var4, var5);
         boolean var8 = false;
         return var2;
      }
   }
}
