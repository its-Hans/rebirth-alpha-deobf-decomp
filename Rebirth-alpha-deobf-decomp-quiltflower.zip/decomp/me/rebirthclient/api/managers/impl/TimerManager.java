package me.rebirthclient.api.managers.impl;

import me.rebirthclient.mod.Mod;

public class TimerManager extends Mod {
   public float timer = 1.0F;

   public void reset() {
      this.timer = 1.0F;
   }

   public float get() {
      return this.timer;
   }

   public void set(float var1) {
      if (var1 < 0.1F) {
         var1 = 0.1F;
      }

      this.timer = var1;
   }
}
