package me.rebirthclient.api.managers.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.client.Appearance;
import me.rebirthclient.mod.modules.impl.client.Chat;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.impl.client.Desktop;
import me.rebirthclient.mod.modules.impl.client.FakeFPS;
import me.rebirthclient.mod.modules.impl.client.FontMod;
import me.rebirthclient.mod.modules.impl.client.FovMod;
import me.rebirthclient.mod.modules.impl.client.GuiAnimation;
import me.rebirthclient.mod.modules.impl.client.HUD;
import me.rebirthclient.mod.modules.impl.client.NameProtect;
import me.rebirthclient.mod.modules.impl.client.Title;
import me.rebirthclient.mod.modules.impl.client.UnfocusedCPU;
import me.rebirthclient.mod.modules.impl.combat.AntiBurrow;
import me.rebirthclient.mod.modules.impl.combat.AntiCity;
import me.rebirthclient.mod.modules.impl.combat.AntiPiston;
import me.rebirthclient.mod.modules.impl.combat.AntiRegear;
import me.rebirthclient.mod.modules.impl.combat.AntiWeak;
import me.rebirthclient.mod.modules.impl.combat.AnvilAura;
import me.rebirthclient.mod.modules.impl.combat.Aura;
import me.rebirthclient.mod.modules.impl.combat.AutoArmor;
import me.rebirthclient.mod.modules.impl.combat.AutoCity;
import me.rebirthclient.mod.modules.impl.combat.AutoPush;
import me.rebirthclient.mod.modules.impl.combat.AutoReplenish;
import me.rebirthclient.mod.modules.impl.combat.AutoTotem;
import me.rebirthclient.mod.modules.impl.combat.AutoTrap;
import me.rebirthclient.mod.modules.impl.combat.AutoWeb;
import me.rebirthclient.mod.modules.impl.combat.AutoWire;
import me.rebirthclient.mod.modules.impl.combat.Burrow;
import me.rebirthclient.mod.modules.impl.combat.CatCrystal;
import me.rebirthclient.mod.modules.impl.combat.CityRecode;
import me.rebirthclient.mod.modules.impl.combat.CombatSetting;
import me.rebirthclient.mod.modules.impl.combat.Criticals;
import me.rebirthclient.mod.modules.impl.combat.CrystalBot;
import me.rebirthclient.mod.modules.impl.combat.Filler;
import me.rebirthclient.mod.modules.impl.combat.HoleFiller;
import me.rebirthclient.mod.modules.impl.combat.ObiPlacer;
import me.rebirthclient.mod.modules.impl.combat.PacketExp;
import me.rebirthclient.mod.modules.impl.combat.PacketMine;
import me.rebirthclient.mod.modules.impl.combat.PistonCrystal;
import me.rebirthclient.mod.modules.impl.combat.PullCrystal;
import me.rebirthclient.mod.modules.impl.combat.SelfWeb;
import me.rebirthclient.mod.modules.impl.combat.Surround;
import me.rebirthclient.mod.modules.impl.combat.TestPush;
import me.rebirthclient.mod.modules.impl.combat.TrapSelf;
import me.rebirthclient.mod.modules.impl.combat.WebTrap;
import me.rebirthclient.mod.modules.impl.exploit.BetterPortal;
import me.rebirthclient.mod.modules.impl.exploit.Blink;
import me.rebirthclient.mod.modules.impl.exploit.Clip;
import me.rebirthclient.mod.modules.impl.exploit.Crasher;
import me.rebirthclient.mod.modules.impl.exploit.FakePearl;
import me.rebirthclient.mod.modules.impl.exploit.GhostHand;
import me.rebirthclient.mod.modules.impl.exploit.GodMode;
import me.rebirthclient.mod.modules.impl.exploit.LiquidInteract;
import me.rebirthclient.mod.modules.impl.exploit.MultiTask;
import me.rebirthclient.mod.modules.impl.exploit.NoHitBox;
import me.rebirthclient.mod.modules.impl.exploit.NoInteract;
import me.rebirthclient.mod.modules.impl.exploit.PacketFly;
import me.rebirthclient.mod.modules.impl.exploit.PearlSpoof;
import me.rebirthclient.mod.modules.impl.exploit.Phase;
import me.rebirthclient.mod.modules.impl.exploit.Stresser;
import me.rebirthclient.mod.modules.impl.exploit.SuperBow;
import me.rebirthclient.mod.modules.impl.exploit.SuperThrow;
import me.rebirthclient.mod.modules.impl.exploit.TPCoordLog;
import me.rebirthclient.mod.modules.impl.exploit.XCarry;
import me.rebirthclient.mod.modules.impl.hud.BindList;
import me.rebirthclient.mod.modules.impl.hud.InventoryPreview;
import me.rebirthclient.mod.modules.impl.hud.Notifications;
import me.rebirthclient.mod.modules.impl.hud.TargetHUD;
import me.rebirthclient.mod.modules.impl.misc.AntiNullPointer;
import me.rebirthclient.mod.modules.impl.misc.AntiSpam;
import me.rebirthclient.mod.modules.impl.misc.AutoEZ;
import me.rebirthclient.mod.modules.impl.misc.AutoKit;
import me.rebirthclient.mod.modules.impl.misc.AutoLogin;
import me.rebirthclient.mod.modules.impl.misc.AutoReconnect;
import me.rebirthclient.mod.modules.impl.misc.AutoTNT;
import me.rebirthclient.mod.modules.impl.misc.Coords;
import me.rebirthclient.mod.modules.impl.misc.Debug;
import me.rebirthclient.mod.modules.impl.misc.ExtraTab;
import me.rebirthclient.mod.modules.impl.misc.FakePlayer;
import me.rebirthclient.mod.modules.impl.misc.GhastNotifier;
import me.rebirthclient.mod.modules.impl.misc.KillEffects;
import me.rebirthclient.mod.modules.impl.misc.LightningDetect;
import me.rebirthclient.mod.modules.impl.misc.MCF;
import me.rebirthclient.mod.modules.impl.misc.Message;
import me.rebirthclient.mod.modules.impl.misc.PearlNotify;
import me.rebirthclient.mod.modules.impl.misc.Peek;
import me.rebirthclient.mod.modules.impl.misc.PopCounter;
import me.rebirthclient.mod.modules.impl.misc.SilentDisconnect;
import me.rebirthclient.mod.modules.impl.misc.TNTTime;
import me.rebirthclient.mod.modules.impl.misc.TabFriends;
import me.rebirthclient.mod.modules.impl.misc.ToolTips;
import me.rebirthclient.mod.modules.impl.movement.AntiGlide;
import me.rebirthclient.mod.modules.impl.movement.AntiVoid;
import me.rebirthclient.mod.modules.impl.movement.AntiWeb;
import me.rebirthclient.mod.modules.impl.movement.AutoCenter;
import me.rebirthclient.mod.modules.impl.movement.AutoWalk;
import me.rebirthclient.mod.modules.impl.movement.ElytraFly;
import me.rebirthclient.mod.modules.impl.movement.FastFall;
import me.rebirthclient.mod.modules.impl.movement.FastSwim;
import me.rebirthclient.mod.modules.impl.movement.FastWeb;
import me.rebirthclient.mod.modules.impl.movement.Flight;
import me.rebirthclient.mod.modules.impl.movement.HoleSnap;
import me.rebirthclient.mod.modules.impl.movement.InventoryMove;
import me.rebirthclient.mod.modules.impl.movement.LongJump;
import me.rebirthclient.mod.modules.impl.movement.NewStep;
import me.rebirthclient.mod.modules.impl.movement.NoJumpDelay;
import me.rebirthclient.mod.modules.impl.movement.NoSlowDown;
import me.rebirthclient.mod.modules.impl.movement.SafeWalk;
import me.rebirthclient.mod.modules.impl.movement.Scaffold;
import me.rebirthclient.mod.modules.impl.movement.Speed;
import me.rebirthclient.mod.modules.impl.movement.Sprint;
import me.rebirthclient.mod.modules.impl.movement.Step;
import me.rebirthclient.mod.modules.impl.movement.Strafe;
import me.rebirthclient.mod.modules.impl.movement.TargetStrafe;
import me.rebirthclient.mod.modules.impl.movement.Velocity;
import me.rebirthclient.mod.modules.impl.player.Announcer;
import me.rebirthclient.mod.modules.impl.player.AntiAim;
import me.rebirthclient.mod.modules.impl.player.AntiOpen;
import me.rebirthclient.mod.modules.impl.player.ArmorWarner;
import me.rebirthclient.mod.modules.impl.player.AutoFish;
import me.rebirthclient.mod.modules.impl.player.AutoFuck;
import me.rebirthclient.mod.modules.impl.player.AutoRespawn;
import me.rebirthclient.mod.modules.impl.player.BlockTweaks;
import me.rebirthclient.mod.modules.impl.player.FastPlace;
import me.rebirthclient.mod.modules.impl.player.FlagDetect;
import me.rebirthclient.mod.modules.impl.player.FreeLook;
import me.rebirthclient.mod.modules.impl.player.Freecam;
import me.rebirthclient.mod.modules.impl.player.KeyPearl;
import me.rebirthclient.mod.modules.impl.player.NoFall;
import me.rebirthclient.mod.modules.impl.player.NoRotate;
import me.rebirthclient.mod.modules.impl.player.PacketEat;
import me.rebirthclient.mod.modules.impl.player.Replenish;
import me.rebirthclient.mod.modules.impl.player.SpeedMine;
import me.rebirthclient.mod.modules.impl.player.TimerModule;
import me.rebirthclient.mod.modules.impl.player.TpsSync;
import me.rebirthclient.mod.modules.impl.render.Ambience;
import me.rebirthclient.mod.modules.impl.render.AutoEsu;
import me.rebirthclient.mod.modules.impl.render.BreadCrumbs;
import me.rebirthclient.mod.modules.impl.render.BreakESP;
import me.rebirthclient.mod.modules.impl.render.CameraClip;
import me.rebirthclient.mod.modules.impl.render.Chams;
import me.rebirthclient.mod.modules.impl.render.ChinaHat;
import me.rebirthclient.mod.modules.impl.render.CityESP;
import me.rebirthclient.mod.modules.impl.render.CrystalChams;
import me.rebirthclient.mod.modules.impl.render.DMGParticles;
import me.rebirthclient.mod.modules.impl.render.ESP;
import me.rebirthclient.mod.modules.impl.render.ESP2D;
import me.rebirthclient.mod.modules.impl.render.EarthPopChams;
import me.rebirthclient.mod.modules.impl.render.ExplosionSpawn;
import me.rebirthclient.mod.modules.impl.render.GlintModify;
import me.rebirthclient.mod.modules.impl.render.Highlight;
import me.rebirthclient.mod.modules.impl.render.HoleESP;
import me.rebirthclient.mod.modules.impl.render.ItemModel;
import me.rebirthclient.mod.modules.impl.render.ItemPhysics;
import me.rebirthclient.mod.modules.impl.render.LogOutSpots;
import me.rebirthclient.mod.modules.impl.render.Models;
import me.rebirthclient.mod.modules.impl.render.NameTags;
import me.rebirthclient.mod.modules.impl.render.NoLag;
import me.rebirthclient.mod.modules.impl.render.NoRender;
import me.rebirthclient.mod.modules.impl.render.PlaceRender;
import me.rebirthclient.mod.modules.impl.render.PopChams;
import me.rebirthclient.mod.modules.impl.render.PortalESP;
import me.rebirthclient.mod.modules.impl.render.RenderSetting;
import me.rebirthclient.mod.modules.impl.render.Rotations;
import me.rebirthclient.mod.modules.impl.render.Search;
import me.rebirthclient.mod.modules.impl.render.Shader;
import me.rebirthclient.mod.modules.impl.render.ShaderChams;
import me.rebirthclient.mod.modules.impl.render.Shaders;
import me.rebirthclient.mod.modules.impl.render.TileESP;
import me.rebirthclient.mod.modules.impl.render.Tracers;
import me.rebirthclient.mod.modules.impl.render.Trajectories;
import me.rebirthclient.mod.modules.impl.render.VoidESP;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;

public class ModuleManager extends Mod {
   public final ArrayList<Module> modules = new ArrayList<>();
   public List<Module> sortedLength = new ArrayList<>();
   public static final Minecraft mc = Minecraft.getMinecraft();
   public List<String> sortedAbc = new ArrayList<>();

   private static void lambda$onRender2D$3(Render2DEvent var0, Module var1) {
      var1.onRender2D(var0);
   }

   public void onTotemPop(EntityPlayer var1) {
      this.modules.stream().filter(Module::isOn).forEach(ModuleManager::lambda$onTotemPop$5);
   }

   public void onUnloadPre() {
      boolean var10002 = false;
      this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
      this.modules.forEach(Module::onUnload);
   }

   public void onRender3D(Render3DEvent var1) {
      this.modules.stream().filter(Module::isOn).forEach(ModuleManager::lambda$onRender3D$4);
   }

   public ArrayList<Module> getModulesByCategory(Category var1) {
      ArrayList var2 = new ArrayList();
      this.modules.forEach(ModuleManager::lambda$getModulesByCategory$1);
      return var2;
   }

   public void onUnloadPost() {
      for(Module var2 : this.modules) {
         var2.enabled.setValue(false);
         boolean var10000 = false;
      }
   }

   public void onLoad() {
      Stream var10000 = this.modules.stream().filter(Module::isListening);
      boolean var10002 = false;
      var10000.forEach(MinecraftForge.EVENT_BUS::register);
      this.modules.forEach(Module::onLoad);
   }

   public void onUpdate() {
      this.modules.stream().filter(Module::isOn).forEach(Module::onUpdate);
   }

   private static void lambda$getModulesByCategory$1(Category var0, ArrayList var1, Module var2) {
      if (var2.getCategory() == var0) {
         var1.add(var2);
         boolean var10000 = false;
      }
   }

   private static void lambda$onRender3D$4(Render3DEvent var0, Module var1) {
      var1.onRender3D(var0);
   }

   public Module getModuleByName(String var1) {
      for(Module var3 : this.modules) {
         if (Integer.valueOf(var1.toUpperCase().hashCode()).equals(var3.getName().toUpperCase().hashCode())) {
            return var3;
         }

         boolean var10000 = false;
      }

      return null;
   }

   private static void lambda$onTotemPop$5(EntityPlayer var0, Module var1) {
      var1.onTotemPop(var0);
   }

   public void sortModules() {
      this.sortedLength = this.getEnabledModules()
         .stream()
         .filter(Module::isDrawn)
         .sorted(Comparator.comparing(ModuleManager::lambda$sortModules$0))
         .collect(Collectors.toList());
      this.sortedAbc = new ArrayList<>(this.getEnabledModulesString());
      this.sortedAbc.sort(String.CASE_INSENSITIVE_ORDER);
   }

   public ArrayList<String> getEnabledModulesString() {
      ArrayList var1 = new ArrayList();

      for(Module var3 : this.modules) {
         if (var3.isOn() && var3.isDrawn()) {
            if (HUD.INSTANCE.onlyBind.getValue() && var3.bind.getValue().getKey() == -1) {
               boolean var5 = false;
            } else {
               var1.add(var3.getArrayListInfo());
               boolean var10000 = false;
               var10000 = false;
            }
         }
      }

      return var1;
   }

   public void init() {
      this.registerModules();
   }

   private void registerModules() {
      this.modules.add(new Chat());
      boolean var10000 = false;
      this.modules.add(new me.rebirthclient.mod.modules.impl.client.ArrayList());
      var10000 = false;
      this.modules.add(new FakeFPS());
      var10000 = false;
      this.modules.add(new GuiAnimation());
      var10000 = false;
      this.modules.add(new UnfocusedCPU());
      var10000 = false;
      this.modules.add(new NameProtect());
      var10000 = false;
      this.modules.add(new ClickGui());
      var10000 = false;
      this.modules.add(new FontMod());
      var10000 = false;
      this.modules.add(new HUD());
      var10000 = false;
      this.modules.add(new FovMod());
      var10000 = false;
      this.modules.add(new Title());
      var10000 = false;
      this.modules.add(new Desktop());
      var10000 = false;
      this.modules.add(new Appearance());
      var10000 = false;
      this.modules.add(new BindList());
      var10000 = false;
      this.modules.add(new Notifications());
      var10000 = false;
      this.modules.add(new InventoryPreview());
      var10000 = false;
      this.modules.add(new TargetHUD());
      var10000 = false;
      this.modules.add(new AutoEsu());
      var10000 = false;
      this.modules.add(new RenderSetting());
      var10000 = false;
      this.modules.add(new PlaceRender());
      var10000 = false;
      this.modules.add(new Highlight());
      var10000 = false;
      this.modules.add(new ExplosionSpawn());
      var10000 = false;
      this.modules.add(new EarthPopChams());
      var10000 = false;
      this.modules.add(new PopChams());
      var10000 = false;
      this.modules.add(new Rotations());
      var10000 = false;
      this.modules.add(new CameraClip());
      var10000 = false;
      this.modules.add(new PortalESP());
      var10000 = false;
      this.modules.add(new Search());
      var10000 = false;
      this.modules.add(new ChinaHat());
      var10000 = false;
      this.modules.add(new CityESP());
      var10000 = false;
      this.modules.add(new GlintModify());
      var10000 = false;
      this.modules.add(new NoRender());
      var10000 = false;
      this.modules.add(new Trajectories());
      var10000 = false;
      this.modules.add(new ShaderChams());
      var10000 = false;
      this.modules.add(new HoleESP());
      var10000 = false;
      this.modules.add(new ItemModel());
      var10000 = false;
      this.modules.add(new Tracers());
      var10000 = false;
      this.modules.add(new CrystalChams());
      var10000 = false;
      this.modules.add(new Chams());
      var10000 = false;
      this.modules.add(new DMGParticles());
      var10000 = false;
      this.modules.add(new ItemPhysics());
      var10000 = false;
      this.modules.add(new BreakESP());
      var10000 = false;
      this.modules.add(new Models());
      var10000 = false;
      this.modules.add(new NameTags());
      var10000 = false;
      this.modules.add(new ESP2D());
      var10000 = false;
      this.modules.add(new Ambience());
      var10000 = false;
      this.modules.add(new ESP());
      var10000 = false;
      this.modules.add(new BreadCrumbs());
      var10000 = false;
      this.modules.add(new VoidESP());
      var10000 = false;
      this.modules.add(new NoLag());
      var10000 = false;
      this.modules.add(new TileESP());
      var10000 = false;
      this.modules.add(new Shader());
      var10000 = false;
      this.modules.add(new Shaders());
      var10000 = false;
      this.modules.add(new LogOutSpots());
      var10000 = false;
      this.modules.add(new CatCrystal());
      var10000 = false;
      this.modules.add(new PistonCrystal());
      var10000 = false;
      this.modules.add(new PullCrystal());
      var10000 = false;
      this.modules.add(new CrystalBot());
      var10000 = false;
      this.modules.add(new AutoTotem());
      var10000 = false;
      this.modules.add(new Burrow());
      var10000 = false;
      this.modules.add(new AutoWire());
      var10000 = false;
      this.modules.add(new Filler());
      var10000 = false;
      this.modules.add(new WebTrap());
      var10000 = false;
      this.modules.add(new AutoCity());
      var10000 = false;
      this.modules.add(new CityRecode());
      var10000 = false;
      this.modules.add(new PacketMine());
      var10000 = false;
      this.modules.add(new Surround());
      var10000 = false;
      this.modules.add(new TrapSelf());
      var10000 = false;
      this.modules.add(new AntiWeak());
      var10000 = false;
      this.modules.add(new AntiCity());
      var10000 = false;
      this.modules.add(new AntiPiston());
      var10000 = false;
      this.modules.add(new CombatSetting());
      var10000 = false;
      this.modules.add(new AntiBurrow());
      var10000 = false;
      this.modules.add(new ObiPlacer());
      var10000 = false;
      this.modules.add(new Aura());
      var10000 = false;
      this.modules.add(new AntiRegear());
      var10000 = false;
      this.modules.add(new AutoArmor());
      var10000 = false;
      this.modules.add(new Criticals());
      var10000 = false;
      this.modules.add(new SelfWeb());
      var10000 = false;
      this.modules.add(new AutoTrap());
      var10000 = false;
      this.modules.add(new PacketExp());
      var10000 = false;
      this.modules.add(new AutoPush());
      var10000 = false;
      this.modules.add(new AutoWeb());
      var10000 = false;
      this.modules.add(new TestPush());
      var10000 = false;
      this.modules.add(new HoleFiller());
      var10000 = false;
      this.modules.add(new AnvilAura());
      var10000 = false;
      this.modules.add(new AutoReplenish());
      var10000 = false;
      this.modules.add(new AntiAim());
      var10000 = false;
      this.modules.add(new SpeedMine());
      var10000 = false;
      this.modules.add(new AutoFish());
      var10000 = false;
      this.modules.add(new AutoFuck());
      var10000 = false;
      this.modules.add(new KeyPearl());
      var10000 = false;
      this.modules.add(new BlockTweaks());
      var10000 = false;
      this.modules.add(new Freecam());
      var10000 = false;
      this.modules.add(new NoFall());
      var10000 = false;
      this.modules.add(new AntiOpen());
      var10000 = false;
      this.modules.add(new TpsSync());
      var10000 = false;
      this.modules.add(new PacketEat());
      var10000 = false;
      this.modules.add(new AutoRespawn());
      var10000 = false;
      this.modules.add(new TimerModule());
      var10000 = false;
      this.modules.add(new NoRotate());
      var10000 = false;
      this.modules.add(new FastPlace());
      var10000 = false;
      this.modules.add(new Replenish());
      var10000 = false;
      this.modules.add(new ArmorWarner());
      var10000 = false;
      this.modules.add(new Announcer());
      var10000 = false;
      this.modules.add(new FlagDetect());
      var10000 = false;
      this.modules.add(new FreeLook());
      var10000 = false;
      this.modules.add(new Debug());
      var10000 = false;
      this.modules.add(new AntiSpam());
      var10000 = false;
      this.modules.add(new SilentDisconnect());
      var10000 = false;
      this.modules.add(new TabFriends());
      var10000 = false;
      this.modules.add(new ExtraTab());
      var10000 = false;
      this.modules.add(new AntiNullPointer());
      var10000 = false;
      this.modules.add(new AutoEZ());
      var10000 = false;
      this.modules.add(new PopCounter());
      var10000 = false;
      this.modules.add(new LightningDetect());
      var10000 = false;
      this.modules.add(new Message());
      var10000 = false;
      this.modules.add(new TNTTime());
      var10000 = false;
      this.modules.add(new AutoTNT());
      var10000 = false;
      this.modules.add(new AutoKit());
      var10000 = false;
      this.modules.add(new AutoLogin());
      var10000 = false;
      this.modules.add(new FakePlayer());
      var10000 = false;
      this.modules.add(new AutoReconnect());
      var10000 = false;
      this.modules.add(new KillEffects());
      var10000 = false;
      this.modules.add(new Coords());
      var10000 = false;
      this.modules.add(new PearlNotify());
      var10000 = false;
      this.modules.add(new Peek());
      var10000 = false;
      this.modules.add(new GhastNotifier());
      var10000 = false;
      this.modules.add(new ToolTips());
      var10000 = false;
      this.modules.add(new MCF());
      var10000 = false;
      this.modules.add(new TargetStrafe());
      var10000 = false;
      this.modules.add(new FastSwim());
      var10000 = false;
      this.modules.add(new ElytraFly());
      var10000 = false;
      this.modules.add(new AntiWeb());
      var10000 = false;
      this.modules.add(new NoJumpDelay());
      var10000 = false;
      this.modules.add(new AutoCenter());
      var10000 = false;
      this.modules.add(new Step());
      var10000 = false;
      this.modules.add(new NewStep());
      var10000 = false;
      this.modules.add(new Flight());
      var10000 = false;
      this.modules.add(new Speed());
      var10000 = false;
      this.modules.add(new Strafe());
      var10000 = false;
      this.modules.add(new LongJump());
      var10000 = false;
      this.modules.add(new SafeWalk());
      var10000 = false;
      this.modules.add(new NoSlowDown());
      var10000 = false;
      this.modules.add(new InventoryMove());
      var10000 = false;
      this.modules.add(new Scaffold());
      var10000 = false;
      this.modules.add(new FastWeb());
      var10000 = false;
      this.modules.add(new AutoWalk());
      var10000 = false;
      this.modules.add(new FastFall());
      var10000 = false;
      this.modules.add(new Sprint());
      var10000 = false;
      this.modules.add(new AntiVoid());
      var10000 = false;
      this.modules.add(new AntiGlide());
      var10000 = false;
      this.modules.add(new Velocity());
      var10000 = false;
      this.modules.add(new HoleSnap());
      var10000 = false;
      this.modules.add(new Blink());
      var10000 = false;
      this.modules.add(new PacketFly());
      var10000 = false;
      this.modules.add(new BetterPortal());
      var10000 = false;
      this.modules.add(new SuperThrow());
      var10000 = false;
      this.modules.add(new SuperBow());
      var10000 = false;
      this.modules.add(new Phase());
      var10000 = false;
      this.modules.add(new TPCoordLog());
      var10000 = false;
      this.modules.add(new GodMode());
      var10000 = false;
      this.modules.add(new MultiTask());
      var10000 = false;
      this.modules.add(new LiquidInteract());
      var10000 = false;
      this.modules.add(new NoHitBox());
      var10000 = false;
      this.modules.add(new Stresser());
      var10000 = false;
      this.modules.add(new GhostHand());
      var10000 = false;
      this.modules.add(new Crasher());
      var10000 = false;
      this.modules.add(new XCarry());
      var10000 = false;
      this.modules.add(new FakePearl());
      var10000 = false;
      this.modules.add(new PearlSpoof());
      var10000 = false;
      this.modules.add(new Clip());
      var10000 = false;
      this.modules.add(new NoInteract());
      var10000 = false;
   }

   public void onDeath(EntityPlayer var1) {
      this.modules.stream().filter(Module::isOn).forEach(ModuleManager::lambda$onDeath$6);
   }

   public ArrayList<Module> getEnabledModules() {
      ArrayList var1 = new ArrayList();

      for(Module var3 : this.modules) {
         if (!var3.isOn()) {
            boolean var6 = false;
         } else if (HUD.INSTANCE.onlyBind.getValue() && var3.bind.getValue().getKey() == -1) {
            boolean var5 = false;
         } else {
            var1.add(var3);
            boolean var10000 = false;
            var10000 = false;
         }
      }

      return var1;
   }

   public void onLogout() {
      this.modules.forEach(Module::onLogout);
   }

   public void onRender2D(Render2DEvent var1) {
      this.modules.stream().filter(Module::isOn).forEach(ModuleManager::lambda$onRender2D$3);
   }

   public List<Category> getCategories() {
      return Arrays.asList(Category.values());
   }

   private static void lambda$onKeyInput$2(int var0, Module var1) {
      if (var1.getBind().getKey() == var0) {
         var1.toggle();
      }
   }

   public void onTick() {
      this.modules.stream().filter(Module::isOn).forEach(Module::onTick);
   }

   private static Integer lambda$sortModules$0(Module var0) {
      TextManager var10000 = Managers.TEXT;
      String var10001;
      if (HUD.INSTANCE.lowerCase.getValue()) {
         var10001 = var0.getArrayListInfo().toLowerCase();
         boolean var10002 = false;
      } else {
         var10001 = var0.getArrayListInfo();
      }

      return var10000.getStringWidth(var10001) * -1;
   }

   public void onKeyInput(int var1) {
      if (var1 != 0 && Keyboard.getEventKeyState() && !(mc.currentScreen instanceof Gui)) {
         this.modules.forEach(ModuleManager::lambda$onKeyInput$2);
      }
   }

   public void onLogin() {
      this.modules.forEach(Module::onLogin);
   }

   private static void lambda$onDeath$6(EntityPlayer var0, Module var1) {
      var1.onDeath(var0);
   }

   public ArrayList<Module> getModules() {
      return this.modules;
   }

   public static enum Ordering {
      ABC,
      LENGTH;

      private static final ModuleManager.Ordering[] $VALUES = new ModuleManager.Ordering[]{ABC, LENGTH};
   }
}
