package me.rebirthclient.api.managers.impl;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Objects;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.modules.impl.client.HUD;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;

public class ServerManager extends Mod {
   private String serverBrand;
   private final Timer timer;
   private final float[] tpsCounts = new float[10];
   private long lastUpdate;
   private float TPS;
   private final DecimalFormat format = new DecimalFormat("##.00#");

   public boolean isServerNotResponding() {
      return this.timer.passedMs((long)HUD.INSTANCE.lagTime.getValue().intValue());
   }

   public void setServerBrand(String var1) {
      this.serverBrand = var1;
   }

   public void reset() {
      Arrays.fill(this.tpsCounts, 20.0F);
      this.TPS = 20.0F;
   }

   public long serverRespondingTime() {
      return this.timer.getPassedTimeMs();
   }

   public ServerManager() {
      this.timer = new Timer();
      this.TPS = 20.0F;
      this.lastUpdate = -1L;
      this.serverBrand = "";
   }

   public int getPing() {
      if (fullNullCheck()) {
         return 0;
      } else {
         Minecraft var10000 = mc;

         try {
            return ((NetHandlerPlayClient)Objects.requireNonNull(var10000.getConnection()))
               .getPlayerInfo(Wrapper.mc.getConnection().getGameProfile().getId())
               .getResponseTime();
         } catch (Exception var2) {
            return 0;
         }
      }
   }

   public void onPacketReceived() {
      this.timer.reset();
      boolean var10000 = false;
   }

   public float getTpsFactor() {
      return 20.0F / this.TPS;
   }

   public String getServerBrand() {
      return this.serverBrand;
   }

   public void update() {
      long var2 = System.currentTimeMillis();
      if (this.lastUpdate == -1L) {
         this.lastUpdate = var2;
      } else {
         long var4 = var2 - this.lastUpdate;
         float var6 = (float)var4 / 20.0F;
         if (var6 == 0.0F) {
            var6 = 50.0F;
         }

         float var1 = 1000.0F / var6;
         if (var1 > 20.0F) {
            var1 = 20.0F;
         }

         System.arraycopy(this.tpsCounts, 0, this.tpsCounts, 1, this.tpsCounts.length - 1);
         this.tpsCounts[0] = var1;
         double var7 = 0.0;

         for(float var12 : this.tpsCounts) {
            var7 += (double)var12;
            boolean var10000 = false;
         }

         var7 /= (double)this.tpsCounts.length;
         if (var7 > 20.0) {
            var7 = 20.0;
         }

         this.TPS = Float.parseFloat(this.format.format(var7));
         this.lastUpdate = var2;
      }
   }

   public float getTPS() {
      return this.TPS;
   }
}
