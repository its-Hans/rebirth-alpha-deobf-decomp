package me.rebirthclient.api.managers.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.Color;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import me.rebirthclient.Rebirth;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.EnumConverter;
import me.rebirthclient.mod.modules.settings.Setting;

public class ConfigManager implements Wrapper {
   public String config;
   public final ArrayList<Mod> mods = new ArrayList<>();

   public void init() {
      this.mods.addAll(Managers.MODULES.modules);
      boolean var10000 = false;
      this.mods.add(Managers.FRIENDS);
      var10000 = false;
      String var1 = this.loadCurrentConfig();
      this.loadConfig(var1);
      Rebirth.LOGGER.info("Config loaded.");
   }

   public ConfigManager() {
      this.config = "Rebirth/config/";
   }

   public String getDirectory(Mod var1) {
      String var2 = "";
      if (var1 instanceof Module) {
         var2 = String.valueOf(new StringBuilder().append(var2).append(((Module)var1).getCategory().getName()).append("/"));
      }

      return var2;
   }

   public void saveCurrentConfig() {
      File var1 = new File("Rebirth/currentconfig.txt");
      File var10000 = var1;

      try {
         if (var10000.exists()) {
            FileWriter var2 = new FileWriter(var1);
            String var3 = this.config.replaceAll("/", "");
            var2.write(var3.replaceAll("Rebirth", ""));
            var2.close();
            boolean var7 = false;
         } else {
            var1.createNewFile();
            boolean var8 = false;
            FileWriter var5 = new FileWriter(var1);
            String var6 = this.config.replaceAll("/", "");
            var5.write(var6.replaceAll("Rebirth", ""));
            var5.close();
         }
      } catch (Exception var4) {
         var4.printStackTrace();
         return;
      }

      boolean var9 = false;
   }

   private void loadSettings(Mod var1) throws IOException {
      String var2 = String.valueOf(new StringBuilder().append(this.config).append(this.getDirectory(var1)).append(var1.getName()).append(".json"));
      Path var3 = Paths.get(var2);
      if (Files.exists(var3)) {
         this.loadPath(var3, var1);
      }
   }

   public void saveSettings(Mod var1) throws IOException {
      new JsonObject();
      boolean var10000 = false;
      File var2 = new File(String.valueOf(new StringBuilder().append(this.config).append(this.getDirectory(var1))));
      if (!var2.exists()) {
         var2.mkdir();
         var10000 = false;
      }

      String var3 = String.valueOf(new StringBuilder().append(this.config).append(this.getDirectory(var1)).append(var1.getName()).append(".json"));
      Path var4 = Paths.get(var3);
      if (!Files.exists(var4)) {
         Files.createFile(var4);
         var10000 = false;
      }

      Gson var5 = new GsonBuilder().setPrettyPrinting().create();
      String var6 = var5.toJson(this.writeSettings(var1));
      BufferedWriter var7 = new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(var4)));
      var7.write(var6);
      var7.close();
   }

   public void saveConfig(String var1) {
      this.config = String.valueOf(new StringBuilder().append("Rebirth/").append(var1).append("/"));
      File var2 = new File(this.config);
      if (!var2.exists()) {
         var2.mkdir();
         boolean var10000 = false;
      }

      Managers.FRIENDS.saveFriends();

      for(Mod var4 : this.mods) {
         ConfigManager var7 = this;
         Mod var10001 = var4;

         label23: {
            try {
               var7.saveSettings(var10001);
            } catch (IOException var6) {
               var6.printStackTrace();
               break label23;
            }

            boolean var8 = false;
         }

         boolean var9 = false;
      }

      this.saveCurrentConfig();
   }

   private static void loadFile(JsonObject var0, Mod var1) {
      for(Entry var3 : var0.entrySet()) {
         String var4 = (String)var3.getKey();
         JsonElement var5 = (JsonElement)var3.getValue();
         if (var1 instanceof FriendManager) {
            FriendManager var17 = Managers.FRIENDS;
            FriendManager.Friend var21 = new FriendManager.Friend;
            FriendManager.Friend var23 = var21;
            JsonElement var10003 = var5;

            try {
               var23./* $QF: Unable to resugar constructor */<init>(var10003.getAsString(), UUID.fromString(var4));
               var17.addFriend(var21);
            } catch (Exception var11) {
               var11.printStackTrace();
               boolean var18 = false;
               continue;
            }

            boolean var19 = false;
         } else {
            for(Setting var7 : var1.getSettings()) {
               label48:
               if (Integer.valueOf(var7.getName().hashCode()).equals(var4.hashCode())) {
                  Mod var10000 = var1;
                  Setting var10001 = var7;
                  JsonElement var10002 = var5;

                  try {
                     setValueFromJson(var10000, var10001, var10002);
                  } catch (Exception var9) {
                     var9.printStackTrace();
                     break label48;
                  }

                  boolean var12 = false;
               }

               label55:
               if (Integer.valueOf(String.valueOf(new StringBuilder().append("should").append(var7.getName())).hashCode()).equals(var4.hashCode())) {
                  Mod var13 = var1;
                  Setting var20 = var7;
                  JsonElement var22 = var5;

                  try {
                     setValueFromJson(var13, var20, var22);
                  } catch (Exception var10) {
                     break label55;
                  }

                  boolean var14 = false;
               }

               if (Integer.valueOf(String.valueOf(new StringBuilder().append("Rainbow").append(var7.getName())).hashCode()).equals(var4.hashCode())) {
                  if (!Mod.fullNullCheck()) {
                     Command.sendMessage(String.valueOf(new StringBuilder().append("rainbow test").append(var5.getAsBoolean())));
                  }

                  var7.isRainbow = var5.getAsBoolean();
               }

               boolean var15 = false;
            }

            boolean var16 = false;
         }
      }
   }

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public static void setValueFromJson(Mod var0, Setting var1, JsonElement var2) {
      String var4 = var1.getType();
      byte var5 = -1;
      switch(var4.hashCode()) {
         case -1808118735:
            if (Integer.valueOf("String".hashCode()).equals(var4.hashCode())) {
               var5 = 4;
               boolean var18 = false;
            }
            break;
         case -672261858:
            if (Integer.valueOf("Integer".hashCode()).equals(var4.hashCode())) {
               var5 = 3;
               boolean var17 = false;
            }
            break;
         case 2070621:
            if (Integer.valueOf("Bind".hashCode()).equals(var4.hashCode())) {
               var5 = 5;
               boolean var16 = false;
            }
            break;
         case 2165025:
            if (Integer.valueOf("Enum".hashCode()).equals(var4.hashCode())) {
               var5 = 6;
               boolean var15 = false;
            }
            break;
         case 65290051:
            if (Integer.valueOf("Color".hashCode()).equals(var4.hashCode())) {
               var5 = 7;
            }
            break;
         case 67973692:
            if (Integer.valueOf("Float".hashCode()).equals(var4.hashCode())) {
               var5 = 2;
               boolean var14 = false;
            }
            break;
         case 1729365000:
            if (Integer.valueOf("Boolean".hashCode()).equals(var4.hashCode())) {
               var5 = 0;
               boolean var13 = false;
            }
            break;
         case 2052876273:
            if (Integer.valueOf("Double".hashCode()).equals(var4.hashCode())) {
               var5 = 1;
               boolean var10000 = false;
            }
      }

      switch(var5) {
         case 0:
            var1.setValue(var2.getAsBoolean());
            return;
         case 1:
            var1.setValue(var2.getAsDouble());
            return;
         case 2:
            var1.setValue(var2.getAsFloat());
            return;
         case 3:
            var1.setValue(var2.getAsInt());
            return;
         case 4:
            JsonElement var28 = var2;

            try {
               String var3 = var28.getAsString();
               var1.setValue(var3.replace("_", " "));
            } catch (Exception var12) {
               boolean var36 = false;
               break;
            }

            boolean var29 = false;
            break;
         case 5:
            Setting var26 = var1;
            Bind.BindConverter var34 = new Bind.BindConverter;
            Bind.BindConverter var39 = var34;

            try {
               var39./* $QF: Unable to resugar constructor */<init>();
               var26.setValue(var34.doBackward(var2));
            } catch (Exception var10) {
               boolean var35 = false;
               break;
            }

            boolean var27 = false;
            return;
         case 6:
            EnumConverter var24 = new EnumConverter;
            EnumConverter var31 = var24;
            Setting var37 = var1;

            try {
               var31./* $QF: Unable to resugar constructor */<init>(((Enum)var37.getValue()).getClass());
               EnumConverter var6 = var24;
               Enum var7 = var6.doBackward(var2);
               Object var33;
               if (var7 == null) {
                  var33 = var1.getDefaultValue();
                  boolean var38 = false;
               } else {
                  var33 = var7;
               }

               var1.setValue(var33);
            } catch (Exception var9) {
               boolean var32 = false;
               break;
            }

            boolean var25 = false;
            return;
         case 7:
            Setting var19 = var1;

            try {
               label128: {
                  if (var19.hasBoolean) {
                     var1.injectBoolean(var2.getAsBoolean());
                     boolean var20 = false;
                  }

                  var19 = var1;
                  Color var30 = new Color;
                  Color var10002 = var30;
                  JsonElement var10003 = var2;

                  try {
                     var10002./* $QF: Unable to resugar constructor */<init>(var10003.getAsInt(), true);
                     var19.setValue(var30);
                  } catch (Exception var8) {
                     break label128;
                  }

                  boolean var22 = false;
               }
            } catch (Exception var11) {
               boolean var10001 = false;
               return;
            }

            boolean var23 = false;
            return;
      }
   }

   public boolean configExists(String var1) {
      List var2 = Arrays.stream(Objects.requireNonNull(new File("Rebirth").listFiles())).filter(File::isDirectory).collect(Collectors.toList());
      return var2.contains(new File(String.valueOf(new StringBuilder().append("Rebirth/").append(var1).append("/"))));
   }

   private void loadPath(Path var1, Mod var2) throws IOException {
      InputStream var3 = Files.newInputStream(var1);
      JsonParser var10000 = new JsonParser;
      JsonParser var10001 = var10000;

      label13: {
         try {
            var10001./* $QF: Unable to resugar constructor */<init>();
            loadFile(var10000.parse(new InputStreamReader(var3)).getAsJsonObject(), var2);
         } catch (IllegalStateException var5) {
            Rebirth.LOGGER.error(String.valueOf(new StringBuilder().append("Bad Config File for: ").append(var2.getName()).append(". Resetting...")));
            loadFile(new JsonObject(), var2);
            break label13;
         }

         boolean var6 = false;
      }

      var3.close();
   }

   public String loadCurrentConfig() {
      File var1 = new File("Rebirth/currentconfig.txt");
      String var2 = "config";
      File var10000 = var1;

      try {
         if (var10000.exists()) {
            Scanner var3;
            for(var3 = new Scanner(var1); var3.hasNextLine(); var5 = false) {
               var2 = var3.nextLine();
            }

            var3.close();
         }
      } catch (Exception var4) {
         var4.printStackTrace();
         return var2;
      }

      boolean var6 = false;
      return var2;
   }

   public JsonObject writeSettings(Mod var1) {
      JsonObject var2 = new JsonObject();
      JsonParser var3 = new JsonParser();

      for(Setting var5 : var1.getSettings()) {
         if (var5.getValue() instanceof Color) {
            var2.add(var5.getName(), var3.parse(String.valueOf(((Color)var5.getValue()).getRGB())));
            if (var5.hasBoolean) {
               var2.add(String.valueOf(new StringBuilder().append("should").append(var5.getName())), var3.parse(String.valueOf(var5.booleanValue)));
            }

            var2.add(String.valueOf(new StringBuilder().append("Rainbow").append(var5.getName())), var3.parse(String.valueOf(var5.isRainbow)));
            boolean var12 = false;
         } else if (var5.isEnumSetting()) {
            EnumConverter var8 = new EnumConverter(((Enum)var5.getValue()).getClass());
            var2.add(var5.getName(), var8.doForward((Enum)var5.getValue()));
            boolean var11 = false;
         } else {
            if (var5.isStringSetting()) {
               String var6 = (String)var5.getValue();
               var5.setValue(var6.replace(" ", "_"));
            }

            JsonObject var10000 = var2;
            Setting var10001 = var5;

            label32: {
               try {
                  var10000.add(var10001.getName(), var3.parse(var5.getValue().toString()));
               } catch (Exception var7) {
                  break label32;
               }

               boolean var9 = false;
            }

            boolean var10 = false;
         }
      }

      return var2;
   }

   public void loadConfig(String var1) {
      List var2 = Arrays.stream(Objects.requireNonNull(new File("Rebirth").listFiles())).filter(File::isDirectory).collect(Collectors.toList());
      if (var2.contains(new File(String.valueOf(new StringBuilder().append("Rebirth/").append(var1).append("/"))))) {
         this.config = String.valueOf(new StringBuilder().append("Rebirth/").append(var1).append("/"));
         boolean var10000 = false;
      } else {
         this.config = "Rebirth/config/";
      }

      Managers.FRIENDS.onLoad();

      for(Mod var4 : this.mods) {
         ConfigManager var7 = this;
         Mod var10001 = var4;

         label24: {
            try {
               var7.loadSettings(var10001);
            } catch (IOException var6) {
               var6.printStackTrace();
               break label24;
            }

            boolean var8 = false;
         }

         boolean var9 = false;
      }

      this.saveCurrentConfig();
   }
}
