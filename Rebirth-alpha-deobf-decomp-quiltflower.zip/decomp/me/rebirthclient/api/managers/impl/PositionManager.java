package me.rebirthclient.api.managers.impl;

import me.rebirthclient.mod.Mod;
import net.minecraft.network.play.client.CPacketPlayer.Position;

public class PositionManager extends Mod {
   private double z;
   private double y;
   private double x;
   private boolean onGround;

   public void updatePosition() {
      this.x = mc.player.posX;
      this.y = mc.player.posY;
      this.z = mc.player.posZ;
      this.onGround = mc.player.onGround;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public double getX() {
      return this.x;
   }

   public void setZ(double var1) {
      this.z = var1;
   }

   public void setPlayerPosition(double var1, double var3, double var5, boolean var7) {
      mc.player.posX = var1;
      mc.player.posY = var3;
      mc.player.posZ = var5;
      mc.player.onGround = var7;
   }

   public double getY() {
      return this.y;
   }

   public void setPlayerPosition(double var1, double var3, double var5) {
      mc.player.posX = var1;
      mc.player.posY = var3;
      mc.player.posZ = var5;
   }

   public void restorePosition() {
      mc.player.posX = this.x;
      mc.player.posY = this.y;
      mc.player.posZ = this.z;
      mc.player.onGround = this.onGround;
   }

   public void setPositionPacket(double var1, double var3, double var5, boolean var7, boolean var8, boolean var9) {
      mc.player.connection.sendPacket(new Position(var1, var3, var5, var7));
      if (var8) {
         mc.player.setPosition(var1, var3, var5);
         if (var9) {
            this.updatePosition();
         }
      }
   }

   public double getZ() {
      return this.z;
   }

   public void setY(double var1) {
      this.y = var1;
   }
}
