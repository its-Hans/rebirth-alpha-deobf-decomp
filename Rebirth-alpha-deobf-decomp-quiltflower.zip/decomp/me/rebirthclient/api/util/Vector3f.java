package me.rebirthclient.api.util;

import java.util.Objects;

public class Vector3f {
   public final float y;
   public final float z;
   public final float x;

   public Vector3f(float var1, float var2, float var3) {
      this.x = var1;
      this.y = var2;
      this.z = var3;
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return true;
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         Vector3f var2 = (Vector3f)var1;
         boolean var10000;
         if (Float.compare(var2.x, this.x) == 0 && Float.compare(var2.y, this.y) == 0 && Float.compare(var2.z, this.z) == 0) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.x, this.y, this.z);
   }
}
