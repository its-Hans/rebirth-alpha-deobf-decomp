package me.rebirthclient.api.util;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;

public class InterpolationUtil implements Wrapper {
   public static Vec3d getInterpolatedPos(Entity var0, float var1, boolean var2) {
      Vec3d var3 = new Vec3d(
         (var0.posX - var0.lastTickPosX) * (double)var1, (var0.posY - var0.lastTickPosY) * (double)var1, (var0.posZ - var0.lastTickPosZ) * (double)var1
      );
      Vec3d var4 = new Vec3d(var0.lastTickPosX, var0.lastTickPosY, var0.lastTickPosZ).add(var3);
      return var2 ? var4.subtract(mc.getRenderManager().renderPosX, mc.getRenderManager().renderPosY, mc.getRenderManager().renderPosZ) : var4;
   }

   public static AxisAlignedBB getInterpolatedAxis(AxisAlignedBB var0) {
      return new AxisAlignedBB(
         var0.minX - mc.getRenderManager().viewerPosX,
         var0.minY - mc.getRenderManager().viewerPosY,
         var0.minZ - mc.getRenderManager().viewerPosZ,
         var0.maxX - mc.getRenderManager().viewerPosX,
         var0.maxY - mc.getRenderManager().viewerPosY,
         var0.maxZ - mc.getRenderManager().viewerPosZ
      );
   }

   public static Vec3d interpolateEntity(Entity var0, float var1) {
      return new Vec3d(
         var0.lastTickPosX + (var0.posX - var0.lastTickPosX) * (double)var1,
         var0.lastTickPosY + (var0.posY - var0.lastTickPosY) * (double)var1,
         var0.lastTickPosZ + (var0.posZ - var0.lastTickPosZ) * (double)var1
      );
   }

   public static Vec3d getInterpolatedRenderPos(Entity var0, float var1) {
      return interpolateEntity(var0, var1).subtract(mc.getRenderManager().renderPosX, mc.getRenderManager().renderPosY, mc.getRenderManager().renderPosZ);
   }

   public static double getInterpolatedDouble(double var0, double var2, float var4) {
      return var0 + (var2 - var0) * (double)var4;
   }

   public static float getInterpolatedFloat(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }
}
