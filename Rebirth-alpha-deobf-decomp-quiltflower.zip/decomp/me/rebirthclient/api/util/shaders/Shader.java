package me.rebirthclient.api.util.shaders;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class Shader {
   protected int program;
   protected Map<String, Integer> uniformsMap;

   public void stopShader() {
      GL20.glUseProgram(0);
      GL11.glPopMatrix();
   }

   private String getLogInfo(int var1) {
      return ARBShaderObjects.glGetInfoLogARB(var1, ARBShaderObjects.glGetObjectParameteriARB(var1, 35716));
   }

   public void setupUniforms() {
   }

   public void setUniform(String var1, int var2) {
      this.uniformsMap.put(var1, var2);
      boolean var10000 = false;
   }

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   private int createShader(String var1, int var2) {
      int var3 = 0;
      int var10000 = var2;

      label34: {
         try {
            var3 = ARBShaderObjects.glCreateShaderObjectARB(var10000);
            if (var3 == 0) {
               return 0;
            }
         } catch (Exception var6) {
            var7 = var6;
            boolean var10001 = false;
            break label34;
         }

         var10000 = var3;
         String var9 = var1;

         try {
            ARBShaderObjects.glShaderSourceARB(var10000, var9);
            ARBShaderObjects.glCompileShaderARB(var3);
            if (ARBShaderObjects.glGetObjectParameteriARB(var3, 35713) == 0) {
               throw new RuntimeException(String.valueOf(new StringBuilder().append("Error creating shader: ").append(this.getLogInfo(var3))));
            }

            return var3;
         } catch (Exception var5) {
            var7 = var5;
            boolean var10 = false;
         }
      }

      Exception var4 = var7;
      ARBShaderObjects.glDeleteObjectARB(var3);
      throw var4;
   }

   public void updateUniforms(float var1) {
   }

   public void setupUniform(String var1) {
      this.setUniform(var1, GL20.glGetUniformLocation(this.program, var1));
   }

   public int getUniform(String var1) {
      return this.uniformsMap.get(var1);
   }

   public void startShader(float var1) {
      GL11.glPushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms(var1);
   }

   public Shader(String var1) {
      Shader var10000 = this;

      int var2;
      int var3;
      try {
         InputStream var4 = var10000.getClass().getResourceAsStream("/assets/minecraft/shaders/vertex.vert");
         var3 = this.createShader(IOUtils.toString(var4), 35633);
         IOUtils.closeQuietly(var4);
         InputStream var5 = this.getClass()
            .getResourceAsStream(String.valueOf(new StringBuilder().append("/assets/minecraft/shaders/fragment/").append(var1)));
         var2 = this.createShader(IOUtils.toString(var5), 35632);
         IOUtils.closeQuietly(var5);
      } catch (Exception var6) {
         var6.printStackTrace();
         return;
      }

      boolean var7 = false;
      if (var3 != 0 && var2 != 0) {
         this.program = ARBShaderObjects.glCreateProgramObjectARB();
         if (this.program != 0) {
            ARBShaderObjects.glAttachObjectARB(this.program, var3);
            ARBShaderObjects.glAttachObjectARB(this.program, var2);
            ARBShaderObjects.glLinkProgramARB(this.program);
            ARBShaderObjects.glValidateProgramARB(this.program);
         }
      }
   }
}
