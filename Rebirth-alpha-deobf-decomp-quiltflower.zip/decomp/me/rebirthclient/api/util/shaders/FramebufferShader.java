package me.rebirthclient.api.util.shaders;

import java.awt.Color;
import me.rebirthclient.asm.accessors.IEntityRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class FramebufferShader extends Shader {
   protected float blue;
   protected boolean entityShadows;
   protected float radius;
   protected float red;
   protected float alpha = 1.0F;
   protected float green;
   protected Minecraft mc;
   protected Framebuffer framebuffer;
   protected float quality;

   public Framebuffer setupFrameBuffer(Framebuffer var1) {
      if (var1 == null) {
         return new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
      } else {
         if (var1.framebufferWidth != this.mc.displayWidth || var1.framebufferHeight != this.mc.displayHeight) {
            var1.deleteFramebuffer();
            var1 = new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
         }

         return var1;
      }
   }

   public void stopDraw(Color var1, float var2, float var3, float var4) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      this.framebuffer.unbindFramebuffer();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.red = (float)var1.getRed() / 255.0F;
      this.green = (float)var1.getGreen() / 255.0F;
      this.blue = (float)var1.getBlue() / 255.0F;
      this.alpha = (float)var1.getAlpha() / 255.0F;
      this.radius = var2;
      this.quality = var3;
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader(var4);
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(this.framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }

   public void startDraw(float var1) {
      GlStateManager.enableAlpha();
      GlStateManager.pushMatrix();
      GlStateManager.pushAttrib();
      this.framebuffer = this.setupFrameBuffer(this.framebuffer);
      this.framebuffer.framebufferClear();
      this.framebuffer.bindFramebuffer(true);
      this.entityShadows = this.mc.gameSettings.entityShadows;
      this.mc.gameSettings.entityShadows = false;
      ((IEntityRenderer)this.mc.entityRenderer).invokeSetupCameraTransform(var1, 0);
   }

   public void drawFramebuffer(Framebuffer var1) {
      ScaledResolution var2 = new ScaledResolution(this.mc);
      GL11.glBindTexture(3553, var1.framebufferTexture);
      GL11.glBegin(7);
      GL11.glTexCoord2d(0.0, 1.0);
      GL11.glVertex2d(0.0, 0.0);
      GL11.glTexCoord2d(0.0, 0.0);
      GL11.glVertex2d(0.0, (double)var2.getScaledHeight());
      GL11.glTexCoord2d(1.0, 0.0);
      GL11.glVertex2d((double)var2.getScaledWidth(), (double)var2.getScaledHeight());
      GL11.glTexCoord2d(1.0, 1.0);
      GL11.glVertex2d((double)var2.getScaledWidth(), 0.0);
      GL11.glEnd();
      GL20.glUseProgram(0);
   }

   public FramebufferShader(String var1) {
      super(var1);
      this.radius = 2.0F;
      this.quality = 1.0F;
      this.mc = Minecraft.getMinecraft();
   }
}
