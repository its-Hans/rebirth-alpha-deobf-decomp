package me.rebirthclient.api.util.shaders.impl.outline;

import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.util.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public final class SmokeOutlineShader extends FramebufferShader {
   public float time = 0.0F;
   public static final SmokeOutlineShader INSTANCE = new SmokeOutlineShader();

   public void startShader(Color var1, float var2, float var3, boolean var4, int var5, float var6, Color var7, Color var8, int var9) {
      GL11.glPushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public void update(double var1) {
      this.time = (float)((double)this.time + var1);
   }

   public void stopDraw(Color var1, float var2, float var3, boolean var4, int var5, float var6, Color var7, Color var8, int var9) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      this.framebuffer.unbindFramebuffer();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader(var1, var2, var3, var4, var5, var6, var7, var8, var9);
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(this.framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }

   public void updateUniforms(Color var1, float var2, float var3, boolean var4, int var5, float var6, Color var7, Color var8, int var9) {
      GL20.glUniform1i(this.getUniform("texture"), 0);
      GL20.glUniform2f(this.getUniform("texelSize"), 1.0F / (float)this.mc.displayWidth * var2 * var3, 1.0F / (float)this.mc.displayHeight * var2 * var3);
      GL20.glUniform1f(this.getUniform("divider"), 140.0F);
      GL20.glUniform1f(this.getUniform("radius"), var2);
      GL20.glUniform1f(this.getUniform("maxSample"), 10.0F);
      int var10000 = this.getUniform("alpha0");
      float var10001;
      if (var4) {
         var10001 = -1.0F;
         boolean var10002 = false;
      } else {
         var10001 = (float)var5 / 255.0F;
      }

      GL20.glUniform1f(var10000, var10001);
      GL20.glUniform2f(
         this.getUniform("resolution"),
         (float)new ScaledResolution(this.mc).getScaledWidth() / var6,
         (float)new ScaledResolution(this.mc).getScaledHeight() / var6
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform4f(
         this.getUniform("first"),
         (float)var1.getRed() / 255.0F * 5.0F,
         (float)var1.getGreen() / 255.0F * 5.0F,
         (float)var1.getBlue() / 255.0F * 5.0F,
         (float)var1.getAlpha() / 255.0F
      );
      GL20.glUniform3f(
         this.getUniform("second"), (float)var7.getRed() / 255.0F * 5.0F, (float)var7.getGreen() / 255.0F * 5.0F, (float)var7.getBlue() / 255.0F * 5.0F
      );
      GL20.glUniform3f(
         this.getUniform("third"), (float)var8.getRed() / 255.0F * 5.0F, (float)var8.getGreen() / 255.0F * 5.0F, (float)var8.getBlue() / 255.0F * 5.0F
      );
      GL20.glUniform1i(this.getUniform("oct"), var9);
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("texture");
      this.setupUniform("texelSize");
      this.setupUniform("divider");
      this.setupUniform("radius");
      this.setupUniform("maxSample");
      this.setupUniform("alpha0");
      this.setupUniform("resolution");
      this.setupUniform("time");
      this.setupUniform("first");
      this.setupUniform("second");
      this.setupUniform("third");
      this.setupUniform("oct");
   }

   public SmokeOutlineShader() {
      super("smokeOutline.frag");
   }
}
