package me.rebirthclient.api.util.shaders.impl.fill;

import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.util.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class CircleShader extends FramebufferShader {
   public static final CircleShader INSTANCE = new CircleShader();
   public float time;

   public void startShader(float var1, Color var2, Float var3, Float var4) {
      GL11.glPushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms(var1, var2, var3, var4);
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
      this.setupUniform("colors");
      this.setupUniform("PI");
      this.setupUniform("rad");
   }

   public void updateUniforms(float var1, Color var2, Float var3, Float var4) {
      GL20.glUniform2f(
         this.getUniform("resolution"),
         (float)new ScaledResolution(this.mc).getScaledWidth() / var1,
         (float)new ScaledResolution(this.mc).getScaledHeight() / var1
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform1f(this.getUniform("PI"), var3);
      GL20.glUniform1f(this.getUniform("rad"), var4);
      GL20.glUniform4f(
         this.getUniform("colors"),
         (float)var2.getRed() / 255.0F,
         (float)var2.getGreen() / 255.0F,
         (float)var2.getBlue() / 255.0F,
         (float)var2.getAlpha() / 255.0F
      );
   }

   public void update(double var1) {
      this.time = (float)((double)this.time + var1);
   }

   public CircleShader() {
      super("circle.frag");
   }

   public void stopDraw(float var1, Color var2, Float var3, Float var4) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      this.framebuffer.unbindFramebuffer();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader(var1, var2, var3, var4);
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(this.framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }
}
