package me.rebirthclient.api.util.shaders.impl.fill;

import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.util.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class FlowShader extends FramebufferShader {
   public static final FlowShader INSTANCE = new FlowShader();
   public float time;

   public void update(double var1) {
      this.time = (float)((double)this.time + var1);
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
      this.setupUniform("color");
      this.setupUniform("iterations");
      this.setupUniform("formuparam2");
      this.setupUniform("stepsize");
      this.setupUniform("volsteps");
      this.setupUniform("zoom");
      this.setupUniform("tile");
      this.setupUniform("distfading");
      this.setupUniform("saturation");
      this.setupUniform("fadeBol");
   }

   public FlowShader() {
      super("flow.frag");
   }

   public void stopDraw(
      Color var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      int var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      float var15,
      float var16,
      float var17,
      int var18
   ) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      this.framebuffer.unbindFramebuffer();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.radius = var2;
      this.quality = var3;
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader(var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18);
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(this.framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }

   public void startShader(
      float var1,
      float var2,
      float var3,
      float var4,
      float var5,
      int var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      int var15
   ) {
      GL11.glPushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms(var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15);
   }

   public void updateUniforms(
      float var1,
      float var2,
      float var3,
      float var4,
      float var5,
      int var6,
      float var7,
      float var8,
      float var9,
      float var10,
      float var11,
      float var12,
      float var13,
      float var14,
      int var15
   ) {
      GL20.glUniform2f(
         this.getUniform("resolution"),
         (float)new ScaledResolution(this.mc).getScaledWidth() / var1,
         (float)new ScaledResolution(this.mc).getScaledHeight() / var1
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform4f(this.getUniform("color"), var2, var3, var4, var5);
      GL20.glUniform1i(this.getUniform("iterations"), var6);
      GL20.glUniform1f(this.getUniform("formuparam2"), var7);
      GL20.glUniform1i(this.getUniform("volsteps"), (int)var9);
      GL20.glUniform1f(this.getUniform("stepsize"), var10);
      GL20.glUniform1f(this.getUniform("zoom"), var8);
      GL20.glUniform1f(this.getUniform("tile"), var11);
      GL20.glUniform1f(this.getUniform("distfading"), var12);
      GL20.glUniform1f(this.getUniform("saturation"), var13);
      GL20.glUniform1i(this.getUniform("fadeBol"), var15);
   }
}
