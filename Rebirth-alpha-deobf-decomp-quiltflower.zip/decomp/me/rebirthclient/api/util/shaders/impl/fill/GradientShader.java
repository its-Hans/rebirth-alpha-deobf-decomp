package me.rebirthclient.api.util.shaders.impl.fill;

import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.util.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class GradientShader extends FramebufferShader {
   public static final GradientShader INSTANCE = new GradientShader();
   public float time;

   public void startShader(float var1, float var2, float var3, float var4, int var5) {
      GL11.glPushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms(var1, var2, var3, var4, var5);
   }

   public GradientShader() {
      super("gradient.frag");
   }

   public void update(double var1) {
      this.time = (float)((double)this.time + var1);
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
      this.setupUniform("moreGradient");
      this.setupUniform("Creepy");
      this.setupUniform("alpha");
      this.setupUniform("NUM_OCTAVES");
   }

   public void stopDraw(Color var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      this.framebuffer.unbindFramebuffer();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.red = (float)var1.getRed() / 255.0F;
      this.green = (float)var1.getGreen() / 255.0F;
      this.blue = (float)var1.getBlue() / 255.0F;
      this.radius = var2;
      this.quality = var3;
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader(var4, var5, var6, var7, var8);
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(this.framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }

   public void updateUniforms(float var1, float var2, float var3, float var4, int var5) {
      GL20.glUniform2f(
         this.getUniform("resolution"),
         (float)new ScaledResolution(this.mc).getScaledWidth() / var1,
         (float)new ScaledResolution(this.mc).getScaledHeight() / var1
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform1f(this.getUniform("moreGradient"), var2);
      GL20.glUniform1f(this.getUniform("Creepy"), var3);
      GL20.glUniform1f(this.getUniform("alpha"), var4);
      GL20.glUniform1i(this.getUniform("NUM_OCTAVES"), var5);
   }
}
