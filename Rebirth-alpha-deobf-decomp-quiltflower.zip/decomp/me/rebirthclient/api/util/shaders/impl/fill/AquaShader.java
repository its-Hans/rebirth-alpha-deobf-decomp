package me.rebirthclient.api.util.shaders.impl.fill;

import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.util.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public class AquaShader extends FramebufferShader {
   public float time;
   public static final AquaShader INSTANCE = new AquaShader();

   public void startShader(float var1, Color var2, int var3, double var4) {
      GL11.glPushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms(var1, var2, var3, var4);
   }

   public AquaShader() {
      super("aqua.frag");
   }

   public void stopDraw(Color var1, float var2, float var3, float var4, int var5, double var6) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      this.framebuffer.unbindFramebuffer();
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.red = (float)var1.getRed() / 255.0F;
      this.green = (float)var1.getGreen() / 255.0F;
      this.blue = (float)var1.getBlue() / 255.0F;
      this.alpha = (float)var1.getAlpha() / 255.0F;
      this.radius = var2;
      this.quality = var3;
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader(var4, var1, var5, var6);
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(this.framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }

   public void updateUniforms(float var1, Color var2, int var3, double var4) {
      GL20.glUniform2f(
         this.getUniform("resolution"),
         (float)new ScaledResolution(this.mc).getScaledWidth() / var1,
         (float)new ScaledResolution(this.mc).getScaledHeight() / var1
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform4f(
         this.getUniform("rgba"),
         (float)var2.getRed() / 255.0F,
         (float)var2.getGreen() / 255.0F,
         (float)var2.getBlue() / 255.0F,
         (float)var2.getAlpha() / 255.0F
      );
      GL20.glUniform1i(this.getUniform("lines"), var3);
      GL20.glUniform1f(this.getUniform("tau"), (float)var4);
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
      this.setupUniform("rgba");
      this.setupUniform("lines");
      this.setupUniform("tau");
   }

   public void update(double var1) {
      this.time = (float)((double)this.time + var1);
   }
}
