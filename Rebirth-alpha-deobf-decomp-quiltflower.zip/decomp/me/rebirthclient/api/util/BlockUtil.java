package me.rebirthclient.api.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.mod.modules.impl.combat.CombatSetting;
import me.rebirthclient.mod.modules.impl.render.PlaceRender;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockCake;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;

public class BlockUtil implements Wrapper {
   public static final List<Block> canUseList = Arrays.asList(
      Blocks.ENDER_CHEST,
      Blocks.CHEST,
      Blocks.TRAPPED_CHEST,
      Blocks.CRAFTING_TABLE,
      Blocks.ANVIL,
      Blocks.BREWING_STAND,
      Blocks.HOPPER,
      Blocks.DROPPER,
      Blocks.DISPENSER,
      Blocks.TRAPDOOR,
      Blocks.ENCHANTING_TABLE
   );
   public static final List<Block> shulkerList = Arrays.asList(
      Blocks.WHITE_SHULKER_BOX,
      Blocks.ORANGE_SHULKER_BOX,
      Blocks.MAGENTA_SHULKER_BOX,
      Blocks.LIGHT_BLUE_SHULKER_BOX,
      Blocks.YELLOW_SHULKER_BOX,
      Blocks.LIME_SHULKER_BOX,
      Blocks.PINK_SHULKER_BOX,
      Blocks.GRAY_SHULKER_BOX,
      Blocks.SILVER_SHULKER_BOX,
      Blocks.CYAN_SHULKER_BOX,
      Blocks.PURPLE_SHULKER_BOX,
      Blocks.BLUE_SHULKER_BOX,
      Blocks.BROWN_SHULKER_BOX,
      Blocks.GREEN_SHULKER_BOX,
      Blocks.RED_SHULKER_BOX,
      Blocks.BLACK_SHULKER_BOX
   );

   public static boolean canPlaceCrystal(BlockPos var0) {
      BlockPos var1 = var0.down();
      BlockPos var2 = var1.up();
      BlockPos var3 = var1.up(2);
      boolean var10000;
      if ((getBlock(var1) == Blocks.BEDROCK || getBlock(var1) == Blocks.OBSIDIAN)
         && getBlock(var2) == Blocks.AIR
         && getBlock(var3) == Blocks.AIR
         && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var2)).isEmpty()
         && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var3)).isEmpty()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean canBeClicked(BlockPos var0) {
      return getBlock(var0).canCollideCheck(getState(var0), false);
   }

   public static List<EnumFacing> getPlacableFacings(BlockPos var0, boolean var1, boolean var2) {
      ArrayList var3 = new ArrayList();

      for(EnumFacing var7 : EnumFacing.values()) {
         if (getRaytrace(var0, var7)) {
            boolean var10000 = false;
         } else {
            getPlaceFacing(var0, var1, var3, var7);
         }

         boolean var12 = false;
      }

      for(EnumFacing var11 : EnumFacing.values()) {
         if (var2 && getRaytrace(var0, var11)) {
            boolean var13 = false;
         } else {
            getPlaceFacing(var0, var1, var3, var11);
         }

         boolean var14 = false;
      }

      return var3;
   }

   public static void rightClickBlock(BlockPos var0, Vec3d var1, EnumHand var2, EnumFacing var3, boolean var4) {
      if (var4) {
         float var5 = (float)(var1.x - (double)var0.getX());
         float var6 = (float)(var1.y - (double)var0.getY());
         float var7 = (float)(var1.z - (double)var0.getZ());
         mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(var0, var3, var2, var5, var6, var7));
         boolean var10000 = false;
      } else {
         mc.playerController.processRightClickBlock(mc.player, mc.world, var0, var3, var1, var2);
         boolean var8 = false;
      }

      mc.player.swingArm(var2);
      mc.rightClickDelayTimer = 4;
   }

   public static boolean strictPlaceCheck(BlockPos var0) {
      if (!CombatSetting.INSTANCE.strictPlace.getValue()) {
         return true;
      } else {
         for(EnumFacing var2 : getPlacableFacings(var0, true, CombatSetting.INSTANCE.checkRaytrace.getValue())) {
            if (canClick(var0.offset(var2))) {
               return true;
            }

            boolean var10000 = false;
         }

         return false;
      }
   }

   public static boolean rayTracePlaceCheck(BlockPos var0, boolean var1, float var2) {
      boolean var10000;
      if (var1
         && mc.world
               .rayTraceBlocks(
                  new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
                  new Vec3d((double)var0.getX(), (double)((float)var0.getY() + var2), (double)var0.getZ()),
                  false,
                  true,
                  false
               )
            != null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isFence(Block var0) {
      boolean var10000;
      if (!(var0 instanceof BlockFence) && !(var0 instanceof BlockFenceGate)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static EnumFacing getFirstFacing(BlockPos var0) {
      if (!CombatSetting.INSTANCE.strictPlace.getValue()) {
         Iterator var1 = getPossibleSides(var0).iterator();
         if (var1.hasNext()) {
            return (EnumFacing)var1.next();
         }

         boolean var10000 = false;
      } else {
         for(EnumFacing var2 : getPlacableFacings(var0, true, CombatSetting.INSTANCE.checkRaytrace.getValue())) {
            if (canClick(var0.offset(var2))) {
               return var2;
            }

            boolean var4 = false;
         }
      }

      return null;
   }

   public static List<EnumFacing> getPossibleSides(BlockPos var0) {
      ArrayList var1 = new ArrayList();

      for(EnumFacing var5 : EnumFacing.values()) {
         BlockPos var6 = var0.offset(var5);
         if (getBlock(var6).canCollideCheck(getState(var6), false)) {
            if (canReplace(var6)) {
               boolean var10000 = false;
            } else {
               var1.add(var5);
               boolean var7 = false;
            }
         }

         boolean var8 = false;
      }

      return var1;
   }

   public static boolean canPlaceEnum(BlockPos var0) {
      return !canBlockFacing(var0) ? false : strictPlaceCheck(var0);
   }

   public static BlockPos[] getHorizontalOffsets(BlockPos var0) {
      return new BlockPos[]{var0.north(), var0.south(), var0.east(), var0.west(), var0.down()};
   }

   public static int getPlaceAbility(BlockPos var0, boolean var1, boolean var2) {
      Block var3 = getBlock(var0);
      if (!(var3 instanceof BlockAir)
         && !(var3 instanceof BlockLiquid)
         && !(var3 instanceof BlockTallGrass)
         && !(var3 instanceof BlockFire)
         && !(var3 instanceof BlockDeadBush)
         && !(var3 instanceof BlockSnow)) {
         return 0;
      } else if (var1 && !raytraceCheck(var0, 0.0F)) {
         return -1;
      } else if (var2 && checkForEntities(var0)) {
         return 1;
      } else {
         for(EnumFacing var5 : getPossibleSides(var0)) {
            if (canBeClicked(var0.offset(var5))) {
               return 3;
            }

            boolean var10000 = false;
         }

         return 2;
      }
   }

   public static NonNullList<BlockPos> getBox(float var0, BlockPos var1) {
      NonNullList var2 = NonNullList.create();
      var2.addAll(getSphere(var1, var0, 0, false, true, 0));
      boolean var10000 = false;
      return var2;
   }

   public static boolean canPlace3(BlockPos var0) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > 6.0) {
         return false;
      } else if (!canBlockFacing(var0)) {
         return false;
      } else if (!canReplace(var0)) {
         return false;
      } else if (!strictPlaceCheck(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!checkPlayer(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static boolean isAir(BlockPos var0) {
      return mc.world.isAirBlock(var0);
   }

   public static boolean checkPlayer(BlockPos var0) {
      for(Entity var2 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var0))) {
         if (!var2.isDead
            && !(var2 instanceof EntityItem)
            && !(var2 instanceof EntityXPOrb)
            && !(var2 instanceof EntityExpBottle)
            && !(var2 instanceof EntityArrow)) {
            if (!(var2 instanceof EntityEnderCrystal)) {
               return true;
            }

            boolean var10000 = false;
         }
      }

      return false;
   }

   public static boolean canPlaceCrystal(BlockPos var0, double var1) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > var1) {
         return false;
      } else {
         BlockPos var3 = var0.down();
         BlockPos var4 = var3.up();
         BlockPos var5 = var3.up(2);
         boolean var10000;
         if ((getBlock(var3) == Blocks.BEDROCK || getBlock(var3) == Blocks.OBSIDIAN)
            && getBlock(var4) == Blocks.AIR
            && getBlock(var5) == Blocks.AIR
            && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var4)).isEmpty()
            && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var5)).isEmpty()) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static boolean checkEntity(BlockPos var0) {
      for(Entity var2 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var0))) {
         if (!var2.isDead && !(var2 instanceof EntityItem) && !(var2 instanceof EntityXPOrb) && !(var2 instanceof EntityExpBottle)) {
            if (!(var2 instanceof EntityArrow)) {
               return true;
            }

            boolean var10000 = false;
         }
      }

      return false;
   }

   public static Vec3d blockPosToVec3(BlockPos var0) {
      return new Vec3d((double)var0.getX(), (double)var0.getY(), (double)var0.getZ());
   }

   public static double distanceToXZ(double var0, double var2) {
      double var4 = mc.player.posX - var0;
      double var6 = mc.player.posZ - var2;
      return Math.sqrt(var4 * var4 + var6 * var6);
   }

   public static boolean canBlockFacing(BlockPos var0) {
      boolean var1 = false;

      for(EnumFacing var5 : EnumFacing.values()) {
         if (canClick(var0.offset(var5))) {
            var1 = true;
         }

         boolean var10000 = false;
      }

      return var1;
   }

   public static void placeCrystal(BlockPos var0, boolean var1) {
      boolean var10000;
      if (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var2 = var10000;
      BlockPos var3 = var0.down();
      RayTraceResult var4 = mc.world
         .rayTraceBlocks(
            new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
            new Vec3d((double)var0.getX() + 0.5, (double)var0.getY() - 0.5, (double)var0.getZ() + 0.5)
         );
      EnumFacing var8;
      if (var4 != null && var4.sideHit != null) {
         var8 = var4.sideHit;
      } else {
         var8 = EnumFacing.UP;
         boolean var11 = false;
      }

      EnumFacing var5 = var8;
      EnumFacing var6 = var5.getOpposite();
      Vec3d var7 = new Vec3d(var3).add(0.5, 0.5, 0.5).add(new Vec3d(var6.getDirectionVec()));
      if (var1) {
         EntityUtil.faceVector(var7);
      }

      NetHandlerPlayClient var9 = mc.player.connection;
      CPacketPlayerTryUseItemOnBlock var12 = new CPacketPlayerTryUseItemOnBlock;
      EnumHand var10005;
      if (var2) {
         var10005 = EnumHand.OFF_HAND;
         boolean var10006 = false;
      } else {
         var10005 = EnumHand.MAIN_HAND;
      }

      var12./* $QF: Unable to resugar constructor */<init>(var3, var5, var10005, 0.0F, 0.0F, 0.0F);
      var9.sendPacket(var12);
      EntityPlayerSP var10 = mc.player;
      EnumHand var13;
      if (var2) {
         var13 = EnumHand.OFF_HAND;
         boolean var10002 = false;
      } else {
         var13 = EnumHand.MAIN_HAND;
      }

      var10.swingArm(var13);
   }

   public static IBlockState getState(BlockPos var0) {
      return mc.world.getBlockState(var0);
   }

   public static int getPlaceAbility(BlockPos var0, boolean var1) {
      return getPlaceAbility(var0, var1, true);
   }

   public static boolean canPlace4(BlockPos var0) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > 6.0) {
         return false;
      } else if (!canBlockFacing(var0)) {
         return false;
      } else if (!strictPlaceCheck(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!checkEntity(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static boolean canPlace2(BlockPos var0, double var1) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > var1) {
         return false;
      } else if (!canReplace(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!checkPlayer(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static EnumFacing getRayTraceFacing(BlockPos var0) {
      RayTraceResult var1 = mc.world
         .rayTraceBlocks(
            new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
            new Vec3d((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5)
         );
      if (var1 != null && var1.sideHit != null) {
         return var1.sideHit;
      } else {
         EnumFacing var2 = null;
         double var3 = 0.0;

         for(EnumFacing var8 : EnumFacing.values()) {
            if (var2 == null || mc.player.getDistanceSq(var0.offset(var8)) < var3) {
               var2 = var8;
               var3 = mc.player.getDistanceSq(var0.offset(var8));
            }

            boolean var10000 = false;
         }

         return var2 == null ? EnumFacing.UP : var2;
      }
   }

   public static boolean isStair(Block var0) {
      return var0 instanceof BlockStairs;
   }

   public static boolean isHole(BlockPos var0) {
      BlockPos[] var1 = getHorizontalOffsets(var0);
      int var2 = var1.length;
      int var3 = 0;

      while(true) {
         if (var3 >= var2) {
            return true;
         }

         BlockPos var4 = var1[var3];
         if (getBlock(var4) == Blocks.AIR) {
            break;
         }

         if (getBlock(var4) != Blocks.BEDROCK && getBlock(var4) != Blocks.OBSIDIAN) {
            if (getBlock(var4) != Blocks.ENDER_CHEST) {
               break;
            }

            boolean var10000 = false;
         }

         boolean var5 = false;
         ++var3;
      }

      return false;
   }

   public static ArrayList<EnumFacing> checkAxis(double var0, EnumFacing var2, EnumFacing var3, boolean var4) {
      ArrayList var5 = new ArrayList();
      if (var0 < -0.5) {
         var5.add(var2);
         boolean var10000 = false;
      }

      if (var0 > 0.5) {
         var5.add(var3);
         boolean var6 = false;
      }

      if (var4) {
         if (!var5.contains(var2)) {
            var5.add(var2);
            boolean var7 = false;
         }

         if (!var5.contains(var3)) {
            var5.add(var3);
            boolean var8 = false;
         }
      }

      return var5;
   }

   public static boolean canReplace(BlockPos var0) {
      return getState(var0).getMaterial().isReplaceable();
   }

   public static Block getBlock(BlockPos var0) {
      return getState(var0).getBlock();
   }

   public static boolean isSafe(Block var0) {
      List var1 = Arrays.asList(Blocks.OBSIDIAN, Blocks.BEDROCK, Blocks.ENDER_CHEST, Blocks.ANVIL);
      boolean var10000;
      if (!var1.contains(var0)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean canPlace(BlockPos var0, double var1) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > var1) {
         return false;
      } else if (!canBlockFacing(var0)) {
         return false;
      } else if (!canReplace(var0)) {
         return false;
      } else if (!strictPlaceCheck(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!checkEntity(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static boolean checkForEntities(BlockPos var0) {
      for(Entity var2 : mc.world.loadedEntityList) {
         if (!(var2 instanceof EntityItem) && !(var2 instanceof EntityEnderCrystal) && !(var2 instanceof EntityXPOrb) && !(var2 instanceof EntityExpBottle)) {
            if (var2 instanceof EntityArrow) {
               boolean var10000 = false;
            } else {
               if (new AxisAlignedBB(var0).intersects(var2.getEntityBoundingBox())) {
                  return true;
               }

               boolean var3 = false;
            }
         }
      }

      return false;
   }

   public static boolean canPlace(BlockPos var0) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > 6.0) {
         return false;
      } else if (!canBlockFacing(var0)) {
         return false;
      } else if (!canReplace(var0)) {
         return false;
      } else if (!strictPlaceCheck(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!checkEntity(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static boolean canClick(BlockPos var0) {
      return mc.world.getBlockState(var0).getBlock().canCollideCheck(mc.world.getBlockState(var0), false);
   }

   public static boolean isSlab(Block var0) {
      boolean var10000;
      if (!(var0 instanceof BlockSlab) && !(var0 instanceof BlockCarpet) && !(var0 instanceof BlockCake)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static NonNullList<BlockPos> getBox(float var0) {
      NonNullList var1 = NonNullList.create();
      var1.addAll(getSphere(new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ)), var0, 0, false, true, 0));
      boolean var10000 = false;
      return var1;
   }

   public static void placeBlock(BlockPos var0, EnumHand var1, boolean var2, boolean var3) {
      EnumFacing var4 = getFirstFacing(var0);
      if (var4 != null) {
         BlockPos var5 = var0.offset(var4);
         EnumFacing var6 = var4.getOpposite();
         Vec3d var7 = new Vec3d(var5).add(0.5, 0.5, 0.5).add(new Vec3d(var6.getDirectionVec()).scale(0.5));
         Block var8 = mc.world.getBlockState(var5).getBlock();
         boolean var9 = false;
         if (!SneakManager.isSneaking && (canUseList.contains(var8) || shulkerList.contains(var8))) {
            mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
            var9 = true;
         }

         if (var2) {
            EntityUtil.faceVector(var7);
         }

         PlaceRender.PlaceMap.put(var0, new PlaceRender.placePosition(var0));
         boolean var10000 = false;
         rightClickBlock(var5, var7, var1, var6, var3);
         if (var9) {
            mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
         }
      }
   }

   public static EnumFacing getBestNeighboring(BlockPos var0, EnumFacing var1) {
      for(EnumFacing var5 : EnumFacing.VALUES) {
         if (var1 == null || !var0.offset(var5).equals(var0.offset(var1, -1))) {
            if (var5 == EnumFacing.DOWN) {
               boolean var16 = false;
            } else {
               for(EnumFacing var7 : getPlacableFacings(var0.offset(var5), true, true)) {
                  if (canClick(var0.offset(var5).offset(var7))) {
                     return var5;
                  }

                  boolean var10000 = false;
               }
            }
         }

         boolean var17 = false;
      }

      EnumFacing var11 = null;
      double var12 = 0.0;

      for(EnumFacing var8 : EnumFacing.VALUES) {
         if (var1 == null || !var0.offset(var8).equals(var0.offset(var1, -1))) {
            if (var8 == EnumFacing.DOWN) {
               boolean var20 = false;
            } else {
               for(EnumFacing var10 : getPlacableFacings(var0.offset(var8), true, false)) {
                  if (!canClick(var0.offset(var8).offset(var10))) {
                     boolean var19 = false;
                  } else {
                     if (var11 == null || mc.player.getDistanceSq(var0.offset(var8)) < var12) {
                        var11 = var8;
                        var12 = mc.player.getDistanceSq(var0.offset(var8));
                     }

                     boolean var18 = false;
                  }
               }
            }
         }

         boolean var21 = false;
      }

      return null;
   }

   private static boolean getRaytrace(BlockPos var0, EnumFacing var1) {
      Vec3d var2 = new Vec3d(var0).add(0.5, 0.5, 0.5).add(new Vec3d(var1.getDirectionVec()).scale(0.5));
      RayTraceResult var3 = mc.world.rayTraceBlocks(mc.player.getPositionEyes(1.0F), var2);
      boolean var10000;
      if (var3 != null && var3.typeOfHit != Type.MISS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean canPlaceShulker(BlockPos var0) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > 6.0) {
         return false;
      } else if (canBlockReplace(var0.down())) {
         return false;
      } else if (!canReplace(var0)) {
         return false;
      } else if (checkEntity(var0)) {
         return false;
      } else if (!CombatSetting.INSTANCE.strictPlace.getValue()) {
         return true;
      } else {
         for(EnumFacing var2 : getPlacableFacings(var0, true, CombatSetting.INSTANCE.checkRaytrace.getValue())) {
            if (canClick(var0.offset(var2))) {
               if (var2 == EnumFacing.DOWN) {
                  return true;
               }

               boolean var10000 = false;
            }
         }

         return false;
      }
   }

   public static boolean canBlockReplace(BlockPos var0) {
      boolean var10000;
      if (!mc.world.isAirBlock(var0)
         && getBlock(var0) != Blocks.FIRE
         && getBlock(var0) != Blocks.LAVA
         && getBlock(var0) != Blocks.FLOWING_LAVA
         && getBlock(var0) != Blocks.WATER
         && getBlock(var0) != Blocks.FLOWING_WATER) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static void placeBlock(BlockPos var0, boolean var1) {
      placeBlock(var0, EnumHand.MAIN_HAND, false, var1);
   }

   public static boolean raytraceCheck(BlockPos var0, float var1) {
      boolean var10000;
      if (mc.world
            .rayTraceBlocks(
               new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
               new Vec3d((double)var0.getX(), (double)((float)var0.getY() + var1), (double)var0.getZ()),
               false,
               true,
               false
            )
         == null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static List<BlockPos> getSphere(BlockPos var0, float var1, int var2, boolean var3, boolean var4, int var5) {
      ArrayList var6 = new ArrayList();
      int var7 = var0.getX();
      int var8 = var0.getY();
      int var9 = var0.getZ();

      for(int var10 = var7 - (int)var1; (float)var10 <= (float)var7 + var1; ++var10) {
         for(int var11 = var9 - (int)var1; (float)var11 <= (float)var9 + var1; ++var11) {
            int var10000;
            if (var4) {
               var10000 = var8 - (int)var1;
               boolean var10001 = false;
            } else {
               var10000 = var8;
            }

            int var12 = var10000;

            while(true) {
               float var13 = (float)var12;
               float var18;
               if (var4) {
                  var18 = (float)var8 + var1;
                  boolean var25 = false;
               } else {
                  var18 = (float)(var8 + var2);
               }

               float var14 = var18;
               if (!(var13 < var14)) {
                  boolean var22 = false;
                  var22 = false;
                  break;
               }

               var10000 = (var7 - var10) * (var7 - var10) + (var9 - var11) * (var9 - var11);
               int var26;
               if (var4) {
                  var26 = (var8 - var12) * (var8 - var12);
                  boolean var10002 = false;
               } else {
                  var26 = 0;
               }

               double var15 = (double)(var10000 + var26);
               if (var15 < (double)(var1 * var1) && (!var3 || var15 >= (double)((var1 - 1.0F) * (var1 - 1.0F)))) {
                  BlockPos var17 = new BlockPos(var10, var12 + var5, var11);
                  var6.add(var17);
                  boolean var20 = false;
               }

               boolean var21 = false;
               ++var12;
            }
         }

         boolean var24 = false;
      }

      return var6;
   }

   public static void placeBlock(BlockPos var0, EnumHand var1, boolean var2, boolean var3, boolean var4, boolean var5) {
      if (var4) {
         CombatUtil.attackCrystal(var0, var2, var5);
      }

      placeBlock(var0, var1, var2, var3);
   }

   private static void getPlaceFacing(BlockPos var0, boolean var1, ArrayList<EnumFacing> var2, EnumFacing var3) {
      BlockPos var4 = var0.offset(var3);
      if (var1) {
         Vec3d var5 = mc.player.getPositionEyes(1.0F);
         Vec3d var6 = new Vec3d((double)var4.getX() + 0.5, (double)var4.getY() + 0.5, (double)var4.getZ() + 0.5);
         IBlockState var7 = mc.world.getBlockState(var4);
         boolean var10000;
         if (var7.getBlock() != Blocks.AIR && !var7.isFullBlock()) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var10001 = false;
         }

         boolean var8 = var10000;
         ArrayList var9 = new ArrayList();
         double var15 = var5.x - var6.x;
         EnumFacing var10002 = EnumFacing.WEST;
         EnumFacing var10003 = EnumFacing.EAST;
         boolean var10004;
         if (!var8) {
            var10004 = true;
            boolean var10005 = false;
         } else {
            var10004 = false;
         }

         var9.addAll(checkAxis(var15, var10002, var10003, var10004));
         var10000 = false;
         var9.addAll(checkAxis(var5.y - var6.y, EnumFacing.DOWN, EnumFacing.UP, true));
         var10000 = false;
         var15 = var5.z - var6.z;
         var10002 = EnumFacing.NORTH;
         var10003 = EnumFacing.SOUTH;
         if (!var8) {
            var10004 = true;
            boolean var20 = false;
         } else {
            var10004 = false;
         }

         var9.addAll(checkAxis(var15, var10002, var10003, var10004));
         var10000 = false;
         if (!var9.contains(var3.getOpposite())) {
            return;
         }
      }

      IBlockState var10 = mc.world.getBlockState(var4);
      if (var10.getBlock().canCollideCheck(var10, false) && !var10.getMaterial().isReplaceable()) {
         var2.add(var3);
         boolean var14 = false;
      }
   }

   public static boolean posHasCrystal(BlockPos var0) {
      for(Entity var2 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var0))) {
         if (var2 instanceof EntityEnderCrystal && new BlockPos(var2.posX, var2.posY, var2.posZ).equals(var0)) {
            return true;
         }

         boolean var10000 = false;
      }

      return false;
   }

   public static BlockPos getFlooredPosition(Entity var0) {
      return new BlockPos(Math.floor(var0.posX), (double)Math.round(var0.posY), Math.floor(var0.posZ));
   }

   public static BlockPos vec3toBlockPos(Vec3d var0) {
      return new BlockPos(Math.floor(var0.x), (double)Math.round(var0.y), Math.floor(var0.z));
   }

   public static boolean canPlace2(BlockPos var0) {
      if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY() + 0.5, (double)var0.getZ() + 0.5) > 6.0) {
         return false;
      } else if (!canReplace(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!checkPlayer(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }
}
