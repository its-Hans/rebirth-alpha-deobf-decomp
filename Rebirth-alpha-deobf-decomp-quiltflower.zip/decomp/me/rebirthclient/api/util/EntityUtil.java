package me.rebirthclient.api.util;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.modules.impl.combat.CombatSetting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDeadBush;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSnow;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityShulkerBullet;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.input.Mouse;

public class EntityUtil implements Wrapper {
   public static int getDamagePercent(ItemStack var0) {
      return (int)((double)(var0.getMaxDamage() - var0.getItemDamage()) / Math.max(0.1, (double)var0.getMaxDamage()) * 100.0);
   }

   public static Vec3d getInterpolatedRenderPos(Entity var0, float var1) {
      return getInterpolatedPos(var0, var1).subtract(mc.getRenderManager().renderPosX, mc.getRenderManager().renderPosY, mc.getRenderManager().renderPosZ);
   }

   public static void facePlacePos(BlockPos var0) {
      EnumFacing var1 = BlockUtil.getFirstFacing(var0);
      if (var1 != null) {
         BlockPos var2 = var0.offset(var1);
         EnumFacing var3 = var1.getOpposite();
         Vec3d var4 = new Vec3d(var2).add(0.5, 0.5, 0.5).add(new Vec3d(var3.getDirectionVec()).scale(0.5));
         faceVector(var4);
      }
   }

   public static boolean isArmorLow(EntityPlayer var0, int var1) {
      for(ItemStack var3 : var0.inventory.armorInventory) {
         if (var3 == null) {
            return true;
         }

         if (getDamagePercent(var3) < var1) {
            return true;
         }

         boolean var10000 = false;
      }

      return false;
   }

   public static BlockPos getRoundedPos(Entity var0) {
      return new BlockPos(MathUtil.roundVec(var0.getPositionVector(), 0));
   }

   public static void facePosFacing(BlockPos var0, EnumFacing var1) {
      Vec3d var2 = new Vec3d(var0).add(0.5, 0.5, 0.5).add(new Vec3d(var1.getDirectionVec()).scale(0.5));
      faceVector(var2);
   }

   public static List<Vec3d> getVarOffsetList(int var0, int var1, int var2) {
      ArrayList var3 = new ArrayList();
      var3.add(new Vec3d((double)var0, (double)var1, (double)var2));
      boolean var10000 = false;
      return var3;
   }

   public static boolean isPassive(Entity var0) {
      if (var0 instanceof EntityWolf && ((EntityWolf)var0).isAngry()) {
         return false;
      } else if (!(var0 instanceof EntityAgeable) && !(var0 instanceof EntityAmbientCreature) && !(var0 instanceof EntitySquid)) {
         boolean var10000;
         if (var0 instanceof EntityIronGolem && ((EntityIronGolem)var0).getRevengeTarget() == null) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      } else {
         return true;
      }
   }

   public static boolean isSafe(Entity var0) {
      return isSafe(var0, 0, false);
   }

   public static float getHealth(Entity var0) {
      if (isLiving(var0)) {
         EntityLivingBase var1 = (EntityLivingBase)var0;
         return var1.getHealth() + var1.getAbsorptionAmount();
      } else {
         return 0.0F;
      }
   }

   public static boolean isVehicle(Entity var0) {
      boolean var10000;
      if (!(var0 instanceof EntityBoat) && !(var0 instanceof EntityMinecart)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static List<Vec3d> getOffsetList(int var0, boolean var1) {
      ArrayList var2 = new ArrayList();
      var2.add(new Vec3d(-1.0, (double)var0, 0.0));
      boolean var10000 = false;
      var2.add(new Vec3d(1.0, (double)var0, 0.0));
      var10000 = false;
      var2.add(new Vec3d(0.0, (double)var0, -1.0));
      var10000 = false;
      var2.add(new Vec3d(0.0, (double)var0, 1.0));
      var10000 = false;
      if (var1) {
         var2.add(new Vec3d(0.0, (double)(var0 - 1), 0.0));
         var10000 = false;
      }

      return var2;
   }

   public static Vec3d getEyesPos() {
      return new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ);
   }

   public static Vec3d[] getVarOffsets(int var0, int var1, int var2) {
      List var3 = getVarOffsetList(var0, var1, var2);
      Vec3d[] var4 = new Vec3d[var3.size()];
      return var3.toArray(var4);
   }

   public static boolean isDead(Entity var0) {
      boolean var10000;
      if (!isAlive(var0)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isFeetVisible(Entity var0) {
      boolean var10000;
      if (mc.world
            .rayTraceBlocks(
               new Vec3d(mc.player.posX, mc.player.posX + (double)mc.player.getEyeHeight(), mc.player.posZ),
               new Vec3d(var0.posX, var0.posY, var0.posZ),
               false,
               true,
               false
            )
         == null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isNeutralMob(Entity var0) {
      boolean var10000;
      if (!(var0 instanceof EntityPigZombie) && !(var0 instanceof EntityWolf) && !(var0 instanceof EntityEnderman)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isProjectile(Entity var0) {
      boolean var10000;
      if (!(var0 instanceof EntityShulkerBullet) && !(var0 instanceof EntityFireball)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isEating() {
      boolean var10000;
      if ((!mc.player.isHandActive() || !(mc.player.getActiveItemStack().getItem() instanceof ItemFood))
         && (!(mc.player.getHeldItemMainhand().getItem() instanceof ItemFood) || !Mouse.isButtonDown(1))) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isSafe(Entity var0, int var1, boolean var2) {
      boolean var10000;
      if (getUnsafeBlocksList(var0, var1, var2).size() == 0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isAlive(Entity var0) {
      boolean var10000;
      if (isLiving(var0) && !var0.isDead && ((EntityLivingBase)var0).getHealth() > 0.0F) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isMobAggressive(Entity var0) {
      if (var0 instanceof EntityPigZombie) {
         if (((EntityPigZombie)var0).isArmsRaised() || ((EntityPigZombie)var0).isAngry()) {
            return true;
         }
      } else {
         if (var0 instanceof EntityWolf) {
            boolean var10000;
            if (((EntityWolf)var0).isAngry() && !mc.player.equals(((EntityWolf)var0).getOwner())) {
               var10000 = true;
               boolean var10001 = false;
            } else {
               var10000 = false;
            }

            return var10000;
         }

         if (var0 instanceof EntityEnderman) {
            return ((EntityEnderman)var0).isScreaming();
         }
      }

      return isHostileMob(var0);
   }

   public static List<Vec3d> getTrapOffsetList(Vec3d var0, boolean var1, boolean var2, boolean var3, boolean var4, boolean var5, boolean var6) {
      ArrayList var7 = new ArrayList();
      if (!var2) {
         List var8 = getUnsafeBlocksList(var0, 2, false);
         if (var8.size() == 4) {
            for(Vec3d var10 : var8) {
               BlockPos var11 = new BlockPos(var0).add(var10.x, var10.y, var10.z);
               switch(BlockUtil.getPlaceAbility(var11, var6)) {
                  case -1:
                  case 1:
                  case 2:
                     boolean var13 = false;
                     continue;
                  case 0:
                     boolean var12 = false;
                     break;
                  case 3:
                     var7.add(var0.add(var10));
                     boolean var10000 = false;
               }

               Collections.addAll(var7, MathUtil.convertVectors(var0, getTrapOffsets(var1, false, var3, var4, var5)));
               boolean var14 = false;
               return var7;
            }
         }
      }

      Collections.addAll(var7, MathUtil.convertVectors(var0, getTrapOffsets(var1, var2, var3, var4, var5)));
      boolean var15 = false;
      return var7;
   }

   public static void faceYawAndPitch(float var0, float var1) {
      sendPlayerRot(var0, var1, mc.player.onGround);
   }

   public static EntityPlayer getClosestEnemy(double var0) {
      EntityPlayer var2 = null;

      for(EntityPlayer var4 : mc.world.playerEntities) {
         if (!isValid(var4, var0)) {
            boolean var10000 = false;
         } else if (var2 == null) {
            var2 = var4;
            boolean var5 = false;
         } else if (!(mc.player.getDistanceSq(var4) < mc.player.getDistanceSq(var2))) {
            boolean var6 = false;
         } else {
            var2 = var4;
            boolean var7 = false;
         }
      }

      return var2;
   }

   public static float getXYZYaw(double var0, double var2, double var4) {
      float[] var6 = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(var0, var2, var4));
      return var6[0];
   }

   public static float getXYZPitch(double var0, double var2, double var4) {
      float[] var6 = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(var0, var2, var4));
      return var6[1];
   }

   public static EntityPlayer getCopiedPlayer(EntityPlayer var0) {
      int var1 = var0.getItemInUseCount();
      EntityPlayer var2 = new EntityPlayer(mc.world, new GameProfile(UUID.randomUUID(), var0.getName()), var1) {
         final int val$count;

         public boolean isSpectator() {
            return false;
         }

         {
            this.val$count = var3;
         }

         public int getItemInUseCount() {
            return this.val$count;
         }

         public boolean isCreative() {
            return false;
         }
      };
      var2.setSneaking(var0.isSneaking());
      var2.swingProgress = var0.swingProgress;
      var2.limbSwing = var0.limbSwing;
      var2.limbSwingAmount = var0.prevLimbSwingAmount;
      var2.inventory.copyInventory(var0.inventory);
      var2.setPrimaryHand(var0.getPrimaryHand());
      var2.ticksExisted = var0.ticksExisted;
      var2.setEntityId(var0.getEntityId());
      var2.copyLocationAndAnglesFrom(var0);
      return var2;
   }

   public static boolean isInHole(Entity var0) {
      return BlockUtil.isHole(new BlockPos(var0.posX, var0.posY, var0.posZ));
   }

   public static void faceVector(Vec3d var0) {
      float[] var1 = getLegitRotations(var0);
      CombatSetting.vec = var0;
      CombatSetting.timer.reset();
      boolean var10000 = false;
      sendPlayerRot(var1[0], var1[1], mc.player.onGround);
   }

   public static boolean stopSneaking(boolean var0) {
      if (var0 && mc.player != null) {
         mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
      }

      return false;
   }

   public static List<Vec3d> getUnsafeBlocksList(Entity var0, int var1, boolean var2) {
      return getUnsafeBlocksList(var0.getPositionVector(), var1, var2);
   }

   public static Vec3d[] getTrapOffsets(boolean var0, boolean var1, boolean var2, boolean var3, boolean var4) {
      ArrayList var5 = new ArrayList(getOffsetList(1, false));
      var5.add(new Vec3d(0.0, 2.0, 0.0));
      boolean var10000 = false;
      if (var0) {
         var5.add(new Vec3d(0.0, 3.0, 0.0));
         var10000 = false;
      }

      if (var1) {
         var5.addAll(getOffsetList(2, false));
         var10000 = false;
      }

      if (var2) {
         var5.addAll(getOffsetList(0, false));
         var10000 = false;
      }

      if (var3) {
         var5.addAll(getOffsetList(-1, false));
         var10000 = false;
         var5.add(new Vec3d(0.0, -1.0, 0.0));
         var10000 = false;
      }

      if (var4) {
         var5.add(new Vec3d(0.0, -2.0, 0.0));
         var10000 = false;
      }

      Vec3d[] var6 = new Vec3d[var5.size()];
      return var5.toArray(var6);
   }

   public static void sendPlayerRot(float var0, float var1, boolean var2) {
      mc.player.connection.sendPacket(new Rotation(var0, var1, var2));
   }

   public static float[] getLegitRotations(Vec3d var0) {
      Vec3d var1 = getEyesPos();
      double var2 = var0.x - var1.x;
      double var4 = var0.y - var1.y;
      double var6 = var0.z - var1.z;
      double var8 = Math.sqrt(var2 * var2 + var6 * var6);
      float var10 = (float)Math.toDegrees(Math.atan2(var6, var2)) - 90.0F;
      float var11 = (float)(-Math.toDegrees(Math.atan2(var4, var8)));
      return new float[]{
         mc.player.rotationYaw + MathHelper.wrapDegrees(var10 - mc.player.rotationYaw),
         mc.player.rotationPitch + MathHelper.wrapDegrees(var11 - mc.player.rotationPitch)
      };
   }

   public static Vec3d getInterpolatedAmount(Entity var0, float var1) {
      return getInterpolatedAmount(var0, (double)var1, (double)var1, (double)var1);
   }

   public static boolean isHoldingWeapon(EntityPlayer var0) {
      boolean var10000;
      if (!(var0.getHeldItemMainhand().getItem() instanceof ItemSword) && !(var0.getHeldItemMainhand().getItem() instanceof ItemAxe)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isValid(Entity var0, double var1) {
      boolean var10000;
      if (var0 != null
         && !isDead(var0)
         && !var0.equals(mc.player)
         && (!(var0 instanceof EntityPlayer) || !Managers.FRIENDS.isFriend(var0.getName()))
         && !(mc.player.getDistanceSq(var0) > MathUtil.square(var1))) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      boolean var3 = var10000;
      if (!var3) {
         var10000 = true;
         boolean var5 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isHostileMob(Entity var0) {
      boolean var10000;
      if (var0.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(var0)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static void faceXYZ(double var0, double var2, double var4) {
      faceYawAndPitch(getXYZYaw(var0, var2, var4), getXYZPitch(var0, var2, var4));
   }

   public static BlockPos getPlayerPos() {
      return getEntityPos(mc.player);
   }

   public static Vec3d getEyePosition(Entity var0) {
      return new Vec3d(var0.posX, var0.posY + (double)var0.getEyeHeight(), var0.posZ);
   }

   public static BlockPos getEntityPos(Entity var0) {
      return new BlockPos(var0.posX, var0.posY + 0.5, var0.posZ);
   }

   public static boolean isTrapped(EntityPlayer var0, boolean var1, boolean var2, boolean var3, boolean var4, boolean var5) {
      boolean var10000;
      if (getUntrappedBlocks(var0, var1, var2, var3, var4, var5).size() == 0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static Vec3d getInterpolatedPos(Entity var0, float var1) {
      return new Vec3d(var0.lastTickPosX, var0.lastTickPosY, var0.lastTickPosZ).add(getInterpolatedAmount(var0, var1));
   }

   public static Vec3d getInterpolatedAmount(Entity var0, double var1, double var3, double var5) {
      return new Vec3d((var0.posX - var0.lastTickPosX) * var1, (var0.posY - var0.lastTickPosY) * var3, (var0.posZ - var0.lastTickPosZ) * var5);
   }

   public static Vec3d interpolateEntity(Entity var0, float var1) {
      return new Vec3d(
         var0.lastTickPosX + (var0.posX - var0.lastTickPosX) * (double)var1,
         var0.lastTickPosY + (var0.posY - var0.lastTickPosY) * (double)var1,
         var0.lastTickPosZ + (var0.posZ - var0.lastTickPosZ) * (double)var1
      );
   }

   public static boolean isLiving(Entity var0) {
      return var0 instanceof EntityLivingBase;
   }

   public static List<Vec3d> getUnsafeBlocksList(Vec3d var0, int var1, boolean var2) {
      ArrayList var3 = new ArrayList();

      for(Vec3d var7 : getOffsets(var1, var2)) {
         BlockPos var8 = new BlockPos(var0).add(var7.x, var7.y, var7.z);
         Block var9 = mc.world.getBlockState(var8).getBlock();
         if (!(var9 instanceof BlockAir)
            && !(var9 instanceof BlockLiquid)
            && !(var9 instanceof BlockTallGrass)
            && !(var9 instanceof BlockFire)
            && !(var9 instanceof BlockDeadBush)
            && !(var9 instanceof BlockSnow)) {
            boolean var10 = false;
         } else {
            var3.add(var7);
            boolean var10000 = false;
         }

         boolean var11 = false;
      }

      return var3;
   }

   public static Vec3d[] getOffsets(int var0, boolean var1) {
      List var2 = getOffsetList(var0, var1);
      Vec3d[] var3 = new Vec3d[var2.size()];
      return var2.toArray(var3);
   }

   public static Vec3d getInterpolatedAmount(Entity var0, Vec3d var1) {
      return getInterpolatedAmount(var0, var1.x, var1.y, var1.z);
   }

   public static boolean isHolding32k(EntityPlayer var0) {
      boolean var10000;
      if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, var0.getHeldItemMainhand()) >= 1000) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean invalid(Entity var0, double var1) {
      boolean var10000;
      if (var0 != null
         && !isDead(var0)
         && !var0.equals(mc.player)
         && (!(var0 instanceof EntityPlayer) || !Managers.FRIENDS.isFriend(var0.getName()))
         && !(mc.player.getDistanceSq(var0) > MathUtil.square(var1))) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static int getHitCoolDown(EntityPlayer var0) {
      Item var1 = var0.getHeldItemMainhand().getItem();
      if (var1 instanceof ItemSword) {
         return 600;
      } else if (var1 instanceof ItemPickaxe) {
         return 850;
      } else if (var1 == Items.IRON_AXE) {
         return 1100;
      } else if (var1 == Items.STONE_HOE) {
         return 500;
      } else if (var1 == Items.IRON_HOE) {
         return 350;
      } else if (var1 == Items.WOODEN_AXE || var1 == Items.STONE_AXE) {
         return 1250;
      } else {
         return !(var1 instanceof ItemSpade) && var1 != Items.GOLDEN_AXE && var1 != Items.DIAMOND_AXE && var1 != Items.WOODEN_HOE && var1 != Items.GOLDEN_HOE
            ? 250
            : 1000;
      }
   }

   public static boolean isInLiquid() {
      if (mc.player.fallDistance >= 3.0F) {
         return false;
      } else {
         boolean var0 = false;
         AxisAlignedBB var10000;
         if (mc.player.getRidingEntity() != null) {
            var10000 = mc.player.getRidingEntity().getEntityBoundingBox();
            boolean var10001 = false;
         } else {
            var10000 = mc.player.getEntityBoundingBox();
         }

         AxisAlignedBB var1 = var10000;
         int var2 = (int)var1.minY;

         for(int var3 = MathHelper.floor(var1.minX); var3 < MathHelper.floor(var1.maxX) + 1; ++var3) {
            for(int var4 = MathHelper.floor(var1.minZ); var4 < MathHelper.floor(var1.maxZ) + 1; ++var4) {
               Block var5 = mc.world.getBlockState(new BlockPos(var3, var2, var4)).getBlock();
               if (!(var5 instanceof BlockAir)) {
                  if (!(var5 instanceof BlockLiquid)) {
                     return false;
                  }

                  var0 = true;
               }

               boolean var6 = false;
            }

            boolean var7 = false;
         }

         return var0;
      }
   }

   public static List<Vec3d> getUntrappedBlocks(EntityPlayer var0, boolean var1, boolean var2, boolean var3, boolean var4, boolean var5) {
      ArrayList var6 = new ArrayList();
      if (!var2 && getUnsafeBlocksList(var0, 2, false).size() == 4) {
         var6.addAll(getUnsafeBlocksList(var0, 2, false));
         boolean var10000 = false;
      }

      for(int var7 = 0; var7 < getTrapOffsets(var1, var2, var3, var4, var5).length; ++var7) {
         Vec3d var8 = getTrapOffsets(var1, var2, var3, var4, var5)[var7];
         BlockPos var9 = new BlockPos(var0.getPositionVector()).add(var8.x, var8.y, var8.z);
         Block var10 = mc.world.getBlockState(var9).getBlock();
         if (!(var10 instanceof BlockAir)
            && !(var10 instanceof BlockLiquid)
            && !(var10 instanceof BlockTallGrass)
            && !(var10 instanceof BlockFire)
            && !(var10 instanceof BlockDeadBush)
            && !(var10 instanceof BlockSnow)) {
            boolean var12 = false;
         } else {
            var6.add(var8);
            boolean var11 = false;
         }

         boolean var13 = false;
      }

      return var6;
   }
}
