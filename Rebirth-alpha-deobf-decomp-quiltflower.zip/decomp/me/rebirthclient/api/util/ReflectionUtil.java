package me.rebirthclient.api.util;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Member;

public class ReflectionUtil {
   public static boolean isStatic(Member var0) {
      boolean var10000;
      if ((var0.getModifiers() & 8) != 0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static <F, T extends F> void copyOf(F var0, T var1, boolean var2) throws IllegalAccessException, NoSuchFieldException {
      boolean var10000 = false;
      var10000 = false;
      Class var3 = var0.getClass();

      for(Field var7 : var3.getDeclaredFields()) {
         makePublic(var7);
         if (!isStatic(var7)) {
            if (var2 && isFinal(var7)) {
               var10000 = false;
            } else {
               makeMutable(var7);
               var7.set(var1, var7.get(var0));
            }
         }

         var10000 = false;
      }
   }

   public static boolean isFinal(Member var0) {
      boolean var10000;
      if ((var0.getModifiers() & 16) != 0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static void makeAccessible(AccessibleObject var0, boolean var1) {
      boolean var10000 = false;
      var0.setAccessible(var1);
   }

   public static void makeMutable(Member var0) throws NoSuchFieldException, IllegalAccessException {
      boolean var10000 = false;
      Field var1 = Field.class.getDeclaredField("modifiers");
      makePublic(var1);
      var1.setInt(var0, var0.getModifiers() & -17);
   }

   public static <F, T extends F> void copyOf(F var0, T var1) throws NoSuchFieldException, IllegalAccessException {
      copyOf(var0, var1, false);
   }

   public static void makePublic(AccessibleObject var0) {
      makeAccessible(var0, true);
   }
}
