package me.rebirthclient.api.util;

public class FadeUtils {
   protected long start;
   protected long length;

   public FadeUtils(long var1) {
      this.length = var1;
      this.reset();
   }

   public void reset() {
      this.start = System.currentTimeMillis();
   }

   public double getFadeOutDefault() {
      return 1.0 - Math.tanh((double)this.getTime() / (double)this.length * 3.0);
   }

   public double def() {
      double var10000;
      if (this.isEnd()) {
         var10000 = 1.0;
         boolean var10001 = false;
      } else {
         var10000 = this.getFadeOne();
      }

      return var10000;
   }

   private double getFadeOne() {
      double var10000;
      if (this.isEnd()) {
         var10000 = 1.0;
         boolean var10001 = false;
      } else {
         var10000 = (double)this.getTime() / (double)this.length;
      }

      return var10000;
   }

   public double getEpsEzFadeOut() {
      return Math.sin((Math.PI / 2) * this.getFadeOne()) * Math.sin((Math.PI * 4.0 / 5.0) * this.getFadeOne());
   }

   public double easeOutQuad() {
      return this.length == 0L ? 1.0 : 1.0 - (1.0 - this.getFadeOne()) * (1.0 - this.getFadeOne());
   }

   public boolean isEnd() {
      boolean var10000;
      if (this.getTime() >= this.length) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void setLength(long var1) {
      this.length = var1;
   }

   public double easeInQuad() {
      return this.getFadeOne() * this.getFadeOne();
   }

   public double getEpsEzFadeIn() {
      return 1.0 - Math.sin((Math.PI / 2) * this.getFadeOne()) * Math.sin((Math.PI * 4.0 / 5.0) * this.getFadeOne());
   }

   public double getFadeInDefault() {
      return Math.tanh((double)this.getTime() / (double)this.length * 3.0);
   }

   protected long getTime() {
      return System.currentTimeMillis() - this.start;
   }
}
