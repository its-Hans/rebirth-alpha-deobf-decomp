package me.rebirthclient.api.util;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.impl.combat.CombatSetting;
import me.rebirthclient.mod.modules.impl.combat.PacketMine;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class CombatUtil implements Wrapper {
   public static final Timer breakTimer = new Timer();

   public static Block getBlock(BlockPos var0) {
      return mc.world.getBlockState(var0).getBlock();
   }

   public static void attackCrystal(Entity var0, boolean var1, boolean var2) {
      if (breakTimer.passedMs((long)CombatSetting.INSTANCE.attackDelay.getValue().intValue())) {
         if (!var2 || !EntityUtil.isEating()) {
            if (var0 != null) {
               breakTimer.reset();
               boolean var10000 = false;
               mc.player.connection.sendPacket(new CPacketUseEntity(var0));
               mc.player.swingArm(EnumHand.MAIN_HAND);
               if (var1) {
                  EntityUtil.faceXYZ(var0.posX, var0.posY + 0.25, var0.posZ);
               }
            }
         }
      }
   }

   public static void attackCrystal(BlockPos var0, boolean var1, boolean var2) {
      if (breakTimer.passedMs((long)CombatSetting.INSTANCE.attackDelay.getValue().intValue())) {
         if (!var2 || !EntityUtil.isEating()) {
            for(Entity var4 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var0))) {
               if (var4 instanceof EntityEnderCrystal) {
                  breakTimer.reset();
                  boolean var5 = false;
                  mc.player.connection.sendPacket(new CPacketUseEntity(var4));
                  mc.player.swingArm(EnumHand.MAIN_HAND);
                  if (var1) {
                     EntityUtil.faceXYZ(var4.posX, var4.posY + 0.25, var4.posZ);
                     var5 = false;
                  }
                  break;
               }

               boolean var10000 = false;
            }
         }
      }
   }

   public static boolean isHole(BlockPos var0, boolean var1, int var2, boolean var3) {
      int var4 = 0;
      if (var1) {
         if (!canBlockReplace(var0.add(0, 0, 1))
            || !canBlockReplace(var0.add(0, 0, 2))
               && !canBlockReplace(var0.add(0, 1, 1))
               && !canBlockReplace(var0.add(1, 0, 1))
               && !canBlockReplace(var0.add(-1, 0, 1))) {
            ++var4;
         }

         if (!canBlockReplace(var0.add(0, 0, -1))
            || !canBlockReplace(var0.add(0, 0, -2))
               && !canBlockReplace(var0.add(0, 1, -1))
               && !canBlockReplace(var0.add(1, 0, -1))
               && !canBlockReplace(var0.add(-1, 0, -1))) {
            ++var4;
         }

         if (!canBlockReplace(var0.add(1, 0, 0))
            || !canBlockReplace(var0.add(2, 0, 0))
               && !canBlockReplace(var0.add(1, 1, 0))
               && !canBlockReplace(var0.add(1, 0, 1))
               && !canBlockReplace(var0.add(1, 0, -1))) {
            ++var4;
         }

         if (!canBlockReplace(var0.add(-1, 0, 0))
            || !canBlockReplace(var0.add(-2, 0, 0))
               && !canBlockReplace(var0.add(-1, 1, 0))
               && !canBlockReplace(var0.add(-1, 0, 1))
               && !canBlockReplace(var0.add(-1, 0, -1))) {
            ++var4;
            boolean var10000 = false;
         }
      } else {
         if (getBlock(var0.add(0, 0, 1)) == Blocks.OBSIDIAN
            || getBlock(var0.add(0, 0, 1)) == Blocks.BEDROCK
            || (getBlock(var0.add(0, 0, 2)) == Blocks.OBSIDIAN || getBlock(var0.add(0, 0, 2)) == Blocks.BEDROCK)
               && (getBlock(var0.add(0, 1, 1)) == Blocks.OBSIDIAN || getBlock(var0.add(0, 1, 1)) == Blocks.BEDROCK)
               && (getBlock(var0.add(1, 0, 1)) == Blocks.OBSIDIAN || getBlock(var0.add(1, 0, 1)) == Blocks.BEDROCK)
               && (getBlock(var0.add(-1, 0, 1)) == Blocks.OBSIDIAN || getBlock(var0.add(-1, 0, 1)) == Blocks.BEDROCK)) {
            ++var4;
         }

         if (getBlock(var0.add(0, 0, -1)) == Blocks.OBSIDIAN
            || getBlock(var0.add(0, 0, -1)) == Blocks.BEDROCK
            || (getBlock(var0.add(0, 0, -2)) == Blocks.OBSIDIAN || getBlock(var0.add(0, 0, -2)) == Blocks.BEDROCK)
               && (getBlock(var0.add(0, 1, -1)) == Blocks.OBSIDIAN || getBlock(var0.add(0, 1, -1)) == Blocks.BEDROCK)
               && (getBlock(var0.add(1, 0, -1)) == Blocks.OBSIDIAN || getBlock(var0.add(1, 0, -1)) == Blocks.BEDROCK)
               && (getBlock(var0.add(-1, 0, -1)) == Blocks.OBSIDIAN || getBlock(var0.add(-1, 0, -1)) == Blocks.BEDROCK)) {
            ++var4;
         }

         if (getBlock(var0.add(1, 0, 0)) == Blocks.OBSIDIAN
            || getBlock(var0.add(1, 0, 0)) == Blocks.BEDROCK
            || (getBlock(var0.add(2, 0, 0)) == Blocks.OBSIDIAN || getBlock(var0.add(2, 0, 0)) == Blocks.BEDROCK)
               && (getBlock(var0.add(1, 1, 0)) == Blocks.OBSIDIAN || getBlock(var0.add(1, 1, 0)) == Blocks.BEDROCK)
               && (getBlock(var0.add(1, 0, 1)) == Blocks.OBSIDIAN || getBlock(var0.add(1, 0, 1)) == Blocks.BEDROCK)
               && (getBlock(var0.add(1, 0, -1)) == Blocks.OBSIDIAN || getBlock(var0.add(1, 0, -1)) == Blocks.BEDROCK)) {
            ++var4;
         }

         if (getBlock(var0.add(-1, 0, 0)) == Blocks.OBSIDIAN
            || getBlock(var0.add(-1, 0, 0)) == Blocks.BEDROCK
            || (getBlock(var0.add(-2, 0, 0)) == Blocks.OBSIDIAN || getBlock(var0.add(-2, 0, 0)) == Blocks.BEDROCK)
               && (getBlock(var0.add(-1, 1, 0)) == Blocks.OBSIDIAN || getBlock(var0.add(-1, 1, 0)) == Blocks.BEDROCK)
               && (getBlock(var0.add(-1, 0, 1)) == Blocks.OBSIDIAN || getBlock(var0.add(-1, 0, 1)) == Blocks.BEDROCK)
               && (getBlock(var0.add(-1, 0, -1)) == Blocks.OBSIDIAN || getBlock(var0.add(-1, 0, -1)) == Blocks.BEDROCK)) {
            ++var4;
         }
      }

      boolean var5;
      if (getBlock(var0) == Blocks.AIR
         && getBlock(var0.add(0, 1, 0)) == Blocks.AIR
         && (getBlock(var0.add(0, -1, 0)) != Blocks.AIR || !var3)
         && getBlock(var0.add(0, 2, 0)) == Blocks.AIR
         && var4 > var2 - 1) {
         var5 = true;
         boolean var10001 = false;
      } else {
         var5 = false;
      }

      return var5;
   }

   public static void mineBlock(BlockPos var0) {
      if (!PacketMine.godBlocks.contains(getBlock(var0)) || !PacketMine.INSTANCE.godCancel.getValue()) {
         if (!var0.equals(PacketMine.breakPos)) {
            mc.playerController.onPlayerDamageBlock(var0, BlockUtil.getRayTraceFacing(var0));
            boolean var10000 = false;
         }
      }
   }

   public static EntityPlayer getTarget(double var0) {
      EntityPlayer var2 = null;
      double var3 = var0;

      for(EntityPlayer var6 : mc.world.playerEntities) {
         if (EntityUtil.invalid(var6, var0)) {
            boolean var10000 = false;
         } else if (var2 == null) {
            var2 = var6;
            var3 = mc.player.getDistanceSq(var6);
            boolean var7 = false;
         } else if (mc.player.getDistanceSq(var6) >= var3) {
            boolean var8 = false;
         } else {
            var2 = var6;
            var3 = mc.player.getDistanceSq(var6);
            boolean var9 = false;
         }
      }

      return var2;
   }

   public static EntityPlayer getTarget(double var0, double var2) {
      EntityPlayer var4 = null;
      double var5 = var0;

      for(EntityPlayer var8 : mc.world.playerEntities) {
         if (!(Managers.SPEED.getPlayerSpeed(var8) > var2)) {
            if (EntityUtil.invalid(var8, var0)) {
               boolean var10000 = false;
            } else if (var4 == null) {
               var4 = var8;
               var5 = mc.player.getDistanceSq(var8);
               boolean var9 = false;
            } else if (mc.player.getDistanceSq(var8) >= var5) {
               boolean var10 = false;
            } else {
               var4 = var8;
               var5 = mc.player.getDistanceSq(var8);
               boolean var11 = false;
            }
         }
      }

      return var4;
   }

   public static boolean canBlockReplace(BlockPos var0) {
      boolean var10000;
      if (!mc.world.isAirBlock(var0)
         && getBlock(var0) != Blocks.FIRE
         && getBlock(var0) != Blocks.LAVA
         && getBlock(var0) != Blocks.FLOWING_LAVA
         && getBlock(var0) != Blocks.WATER
         && getBlock(var0) != Blocks.FLOWING_WATER) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }
}
