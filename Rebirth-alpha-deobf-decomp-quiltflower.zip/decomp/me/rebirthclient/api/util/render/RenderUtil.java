package me.rebirthclient.api.util.render;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.IntStream;
import javax.imageio.ImageIO;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InterpolationUtil;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.modules.impl.render.RenderSetting;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class RenderUtil implements Wrapper {
   public static final ICamera camera = new Frustum();
   private static final FloatBuffer screenCoords = BufferUtils.createFloatBuffer(3);
   private static final FloatBuffer projection = BufferUtils.createFloatBuffer(16);
   private static final IntBuffer viewport = BufferUtils.createIntBuffer(16);
   private static final FloatBuffer modelView = BufferUtils.createFloatBuffer(16);

   public static void drawText(AxisAlignedBB var0, String var1) {
      if (var0 != null && var1 != null) {
         double var2 = var0.minX + (var0.maxX - var0.minX) / 2.0 - mc.getRenderManager().renderPosX;
         double var4 = var0.minY + (var0.maxY - var0.minY) / 2.0 - mc.getRenderManager().renderPosY - 1.5;
         double var6 = var0.minZ + (var0.maxZ - var0.minZ) / 2.0 - mc.getRenderManager().renderPosZ;
         drawText(var1, var2, var4, var6, new Color(255, 255, 255, 255));
      }
   }

   public static void drawCircle(float var0, float var1, float var2, int var3) {
      float var4 = (float)(var3 >> 24 & 0xFF) / 255.0F;
      float var5 = (float)(var3 >> 16 & 0xFF) / 255.0F;
      float var6 = (float)(var3 >> 8 & 0xFF) / 255.0F;
      float var7 = (float)(var3 & 0xFF) / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GL11.glColor4f(var5, var6, var7, var4);
      GL11.glBegin(9);

      for(int var8 = 0; var8 <= 360; ++var8) {
         GL11.glVertex2d(
            (double)var0 + Math.sin((double)var8 * 3.141526 / 180.0) * (double)var2, (double)var1 + Math.cos((double)var8 * 3.141526 / 180.0) * (double)var2
         );
         boolean var10000 = false;
      }

      GL11.glEnd();
      GlStateManager.resetColor();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static ByteBuffer readImageToBuffer(InputStream var0) throws IOException {
      BufferedImage var1 = ImageIO.read(var0);
      int[] var2 = var1.getRGB(0, 0, var1.getWidth(), var1.getHeight(), null, 0, var1.getWidth());
      ByteBuffer var3 = ByteBuffer.allocate(4 * var2.length);
      IntStream var10000 = Arrays.stream(var2).map(RenderUtil::lambda$readImageToBuffer$0);
      boolean var10001 = false;
      var10000.forEach(var3::putInt);
      ((Buffer)var3).flip();
      boolean var4 = false;
      return var3;
   }

   public static void drawBoxESP(
      BlockPos var0, Color var1, boolean var2, Color var3, float var4, boolean var5, boolean var6, int var7, boolean var8, double var9
   ) {
      if (var6) {
         drawBox(var0, new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var7), var9, false, false, 0);
      }

      if (var5) {
         Color var10001;
         if (var2) {
            var10001 = var3;
            boolean var10002 = false;
         } else {
            var10001 = var1;
         }

         drawBlockOutline(var0, var10001, var4, var8, var9, false, false, 0, false);
      }
   }

   private static void buildPosColor(
      BufferBuilder var0,
      float var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      double var9,
      double var11,
      double var13,
      double var15,
      double var17,
      double var19
   ) {
      var0.pos(var9, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var9, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var9, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var9, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var9, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var11, var13).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var15, var11, var19).color(var1, var2, var3, var4).endVertex();
      var0.pos(var9, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var9, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var9, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var17, var13).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var17, var19).color(var5, var6, var7, var8).endVertex();
      var0.pos(var15, var17, var19).color(var5, var6, var7, var8).endVertex();
   }

   public static void drawGradientLine(float var0, float var1, float var2, float var3, float var4, int var5, int var6) {
      float var7 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var8 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var9 = (float)(var5 & 0xFF) / 255.0F;
      float var10 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var11 = (float)(var6 >> 16 & 0xFF) / 255.0F;
      float var12 = (float)(var6 >> 8 & 0xFF) / 255.0F;
      float var13 = (float)(var6 & 0xFF) / 255.0F;
      float var14 = (float)(var6 >> 24 & 0xFF) / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.shadeModel(7425);
      GL11.glLineWidth(var4);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      Tessellator var15 = Tessellator.getInstance();
      BufferBuilder var16 = var15.getBuffer();
      var16.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var16.pos((double)var0, (double)var1, 0.0).color(var7, var8, var9, var10).endVertex();
      var16.pos((double)var0, (double)var3, 0.0).color(var7, var8, var9, var10).endVertex();
      var16.pos((double)var2, (double)var3, 0.0).color(var11, var12, var13, var14).endVertex();
      var16.pos((double)var2, (double)var1, 0.0).color(var11, var12, var13, var14).endVertex();
      var15.draw();
      GlStateManager.shadeModel(7424);
      GL11.glDisable(2848);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
      GlStateManager.popMatrix();
   }

   public static void drawSelectionBoxESP(BlockPos var0, Color var1, boolean var2, Color var3, float var4, boolean var5, boolean var6, int var7, boolean var8) {
      AxisAlignedBB var9 = mc.world.getBlockState(var0).getSelectedBoundingBox(mc.world, var0).grow(0.002);
      AxisAlignedBB var10 = InterpolationUtil.getInterpolatedAxis(var9);
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(var9)) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         if (var8) {
            GlStateManager.enableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(true);
            boolean var10000 = false;
         } else {
            GlStateManager.disableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(false);
         }

         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         GL11.glLineWidth(var4);
         if (var6) {
            RenderGlobal.renderFilledBox(
               var10, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var7 / 255.0F
            );
         }

         if (var5) {
            Color var10001;
            if (var2) {
               var10001 = var3;
               boolean var10002 = false;
            } else {
               var10001 = var1;
            }

            drawBlockOutline(var10, var10001, var4, var8);
         }

         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void testESP(AxisAlignedBB var0, Color var1, boolean var2, Color var3, float var4, boolean var5, boolean var6, int var7, boolean var8) {
      AxisAlignedBB var9 = InterpolationUtil.getInterpolatedAxis(var0);
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(var0)) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         if (var8) {
            GlStateManager.enableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(true);
            boolean var10000 = false;
         } else {
            GlStateManager.disableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(false);
         }

         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         GL11.glLineWidth(var4);
         if (var6) {
            RenderGlobal.renderFilledBox(
               var9, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var7 / 255.0F
            );
         }

         if (var5) {
            Color var10001;
            if (var2) {
               var10001 = var3;
               boolean var10002 = false;
            } else {
               var10001 = var1;
            }

            drawBlockOutline(var9, var10001, var4, false);
         }

         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void drawFadingBox(BlockPos var0, Color var1, Color var2, double var3) {
      for(EnumFacing var8 : EnumFacing.values()) {
         if (var8 != EnumFacing.UP) {
            drawFadingSide(var0, var8, var1, var2, var3);
         }

         boolean var10000 = false;
      }
   }

   private static int lambda$readImageToBuffer$0(int var0) {
      return var0 << 8 | var0 >> 24 & 0xFF;
   }

   public static void drawGlow(double var0, double var2, double var4, double var6, int var8) {
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      drawVGradientRect(
         (float)((int)var0),
         (float)((int)var2),
         (float)((int)var4),
         (float)((int)(var2 + (var6 - var2) / 2.0)),
         ColorUtil.toRGBA(new Color(var8).getRed(), new Color(var8).getGreen(), new Color(var8).getBlue(), 0),
         var8
      );
      drawVGradientRect(
         (float)((int)var0),
         (float)((int)(var2 + (var6 - var2) / 2.0)),
         (float)((int)var4),
         (float)((int)var6),
         var8,
         ColorUtil.toRGBA(new Color(var8).getRed(), new Color(var8).getGreen(), new Color(var8).getBlue(), 0)
      );
      int var9 = (int)((var6 - var2) / 2.0);
      drawPolygonPart(
         var0, var2 + (var6 - var2) / 2.0, var9, 0, var8, ColorUtil.toRGBA(new Color(var8).getRed(), new Color(var8).getGreen(), new Color(var8).getBlue(), 0)
      );
      drawPolygonPart(
         var0, var2 + (var6 - var2) / 2.0, var9, 1, var8, ColorUtil.toRGBA(new Color(var8).getRed(), new Color(var8).getGreen(), new Color(var8).getBlue(), 0)
      );
      drawPolygonPart(
         var4, var2 + (var6 - var2) / 2.0, var9, 2, var8, ColorUtil.toRGBA(new Color(var8).getRed(), new Color(var8).getGreen(), new Color(var8).getBlue(), 0)
      );
      drawPolygonPart(
         var4, var2 + (var6 - var2) / 2.0, var9, 3, var8, ColorUtil.toRGBA(new Color(var8).getRed(), new Color(var8).getGreen(), new Color(var8).getBlue(), 0)
      );
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }

   public static void drawEntityBoxESP(Entity var0, Color var1, boolean var2, Color var3, float var4, boolean var5, boolean var6, int var7) {
      Vec3d var8 = InterpolationUtil.getInterpolatedPos(var0, mc.getRenderPartialTicks(), true);
      AxisAlignedBB var9 = new AxisAlignedBB(
         var0.getEntityBoundingBox().minX - 0.05 - var0.posX + var8.x,
         var0.getEntityBoundingBox().minY - 0.0 - var0.posY + var8.y,
         var0.getEntityBoundingBox().minZ - 0.05 - var0.posZ + var8.z,
         var0.getEntityBoundingBox().maxX + 0.05 - var0.posX + var8.x,
         var0.getEntityBoundingBox().maxY + 0.1 - var0.posY + var8.y,
         var0.getEntityBoundingBox().maxZ + 0.05 - var0.posZ + var8.z
      );
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(var4);
      if (var0 instanceof EntityPlayer && Managers.FRIENDS.isFriend(var0.getName())) {
         var1 = Managers.COLORS.getFriendColor(var1.getAlpha());
      }

      if (var6) {
         RenderGlobal.renderFilledBox(
            var9, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var7 / 255.0F
         );
      }

      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
      if (var5) {
         Color var10001;
         if (var2) {
            var10001 = var3;
            boolean var10002 = false;
         } else {
            var10001 = var1;
         }

         drawBlockOutline(var9, var10001, var4, false);
      }
   }

   public static void glColor(Color var0) {
      GL11.glColor4f((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F);
   }

   public static void drawBBFill(AxisAlignedBB var0, Color var1, int var2) {
      AxisAlignedBB var3 = new AxisAlignedBB(
         var0.minX - mc.getRenderManager().viewerPosX,
         var0.minY - mc.getRenderManager().viewerPosY,
         var0.minZ - mc.getRenderManager().viewerPosZ,
         var0.maxX - mc.getRenderManager().viewerPosX,
         var0.maxY - mc.getRenderManager().viewerPosY,
         var0.maxZ - mc.getRenderManager().viewerPosZ
      );
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(
         new AxisAlignedBB(
            var3.minX + mc.getRenderManager().viewerPosX,
            var3.minY + mc.getRenderManager().viewerPosY,
            var3.minZ + mc.getRenderManager().viewerPosZ,
            var3.maxX + mc.getRenderManager().viewerPosX,
            var3.maxY + mc.getRenderManager().viewerPosY,
            var3.maxZ + mc.getRenderManager().viewerPosZ
         )
      )) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.renderFilledBox(
            var3, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var2 / 255.0F
         );
         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void drawBlockWireframe(BlockPos var0, Color var1, float var2, double var3, boolean var5) {
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(var2);
      double var6 = (double)var0.getX() - mc.getRenderManager().viewerPosX;
      double var8 = (double)var0.getY() - mc.getRenderManager().viewerPosY;
      double var10 = (double)var0.getZ() - mc.getRenderManager().viewerPosZ;
      int var12 = var1.getRed();
      int var13 = var1.getGreen();
      int var14 = var1.getBlue();
      int var15 = var1.getAlpha();
      AxisAlignedBB var16 = new AxisAlignedBB(var6, var8, var10, var6 + 1.0, var8 + 1.0 + var3, var10 + 1.0);
      Tessellator var17 = Tessellator.getInstance();
      BufferBuilder var18 = var17.getBuffer();
      var18.begin(1, DefaultVertexFormats.POSITION_COLOR);
      var18.pos(var16.minX, var16.minY, var16.minZ).color(var12, var13, var14, var15).endVertex();
      var18.pos(var16.maxX, var16.minY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
      var18.pos(var16.minX, var16.minY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
      var18.pos(var16.maxX, var16.minY, var16.minZ).color(var12, var13, var14, var15).endVertex();
      if (!var5) {
         var18.pos(var16.minX, var16.maxY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.maxY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.maxY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.maxY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.minY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.maxY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.minY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.maxY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.minY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.maxY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.minY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.maxY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.minY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.maxY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.minY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.maxY, var16.minZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.minY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.maxY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.maxX, var16.minY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
         var18.pos(var16.minX, var16.maxY, var16.maxZ).color(var12, var13, var14, var15).endVertex();
      }

      var17.draw();
      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawBlockOutline(AxisAlignedBB var0, Color var1, float var2, boolean var3) {
      float var4 = (float)var1.getRed() / 255.0F;
      float var5 = (float)var1.getGreen() / 255.0F;
      float var6 = (float)var1.getBlue() / 255.0F;
      float var7 = (float)var1.getAlpha() / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      if (var3) {
         GlStateManager.enableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(true);
         boolean var10000 = false;
      } else {
         GlStateManager.disableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(false);
      }

      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(var2);
      Tessellator var8 = Tessellator.getInstance();
      BufferBuilder var9 = var8.getBuffer();
      var9.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var9.pos(var0.minX, var0.minY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.minY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.minY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.minY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.minY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.maxY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.maxY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.minY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.minY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.maxY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.maxY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.maxY, var0.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.maxY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.minY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.maxX, var0.maxY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var0.minX, var0.maxY, var0.minZ).color(var4, var5, var6, var7).endVertex();
      var8.draw();
      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawBlockOutline(BlockPos var0, Color var1, float var2, boolean var3) {
      IBlockState var4 = mc.world.getBlockState(var0);
      if ((var3 || var4.getMaterial() != Material.AIR) && mc.world.getWorldBorder().contains(var0)) {
         Vec3d var5 = EntityUtil.interpolateEntity(mc.player, mc.getRenderPartialTicks());
         drawBlockOutline(var4.getSelectedBoundingBox(mc.world, var0).grow(0.002F).offset(-var5.x, -var5.y, -var5.z), var1, var2);
      }
   }

   public static void drawVGradientRect(float var0, float var1, float var2, float var3, int var4, int var5) {
      float var6 = (float)(var4 >> 24 & 0xFF) / 255.0F;
      float var7 = (float)(var4 >> 16 & 0xFF) / 255.0F;
      float var8 = (float)(var4 >> 8 & 0xFF) / 255.0F;
      float var9 = (float)(var4 & 0xFF) / 255.0F;
      float var10 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var11 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var12 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var13 = (float)(var5 & 0xFF) / 255.0F;
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      Tessellator var14 = Tessellator.getInstance();
      BufferBuilder var15 = var14.getBuffer();
      var15.begin(7, DefaultVertexFormats.POSITION_COLOR);
      var15.pos((double)var2, (double)var1, 0.0).color(var7, var8, var9, var6).endVertex();
      var15.pos((double)var0, (double)var1, 0.0).color(var7, var8, var9, var6).endVertex();
      var15.pos((double)var0, (double)var3, 0.0).color(var11, var12, var13, var10).endVertex();
      var15.pos((double)var2, (double)var3, 0.0).color(var11, var12, var13, var10).endVertex();
      var14.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }

   public static void drawBox(BlockPos var0, Color var1) {
      AxisAlignedBB var2 = new AxisAlignedBB(
         (double)var0.getX() - mc.getRenderManager().viewerPosX,
         (double)var0.getY() - mc.getRenderManager().viewerPosY,
         (double)var0.getZ() - mc.getRenderManager().viewerPosZ,
         (double)(var0.getX() + 1) - mc.getRenderManager().viewerPosX,
         (double)(var0.getY() + 1) - mc.getRenderManager().viewerPosY,
         (double)(var0.getZ() + 1) - mc.getRenderManager().viewerPosZ
      );
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(
         new AxisAlignedBB(
            var2.minX + mc.getRenderManager().viewerPosX,
            var2.minY + mc.getRenderManager().viewerPosY,
            var2.minZ + mc.getRenderManager().viewerPosZ,
            var2.maxX + mc.getRenderManager().viewerPosX,
            var2.maxY + mc.getRenderManager().viewerPosY,
            var2.maxZ + mc.getRenderManager().viewerPosZ
         )
      )) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.renderFilledBox(
            var2, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F
         );
         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void drawBBBox(AxisAlignedBB var0, Color var1, int var2) {
      AxisAlignedBB var3 = interpolateAxis(new AxisAlignedBB(var0.minX, var0.minY, var0.minZ, var0.maxX, var0.maxY, var0.maxZ));
      float var4 = (float)var1.getRed() / 255.0F;
      float var5 = (float)var1.getGreen() / 255.0F;
      float var6 = (float)var1.getBlue() / 255.0F;
      float var7 = (float)var2 / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(RenderSetting.INSTANCE.outlineWidth.getValue());
      Tessellator var8 = Tessellator.getInstance();
      BufferBuilder var9 = var8.getBuffer();
      var9.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var9.pos(var3.minX, var3.minY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.minY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.minY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.minY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.minY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.maxY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.maxY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.minY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.minY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.maxY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.maxY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.maxY, var3.maxZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.maxY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.minY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.maxX, var3.maxY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var9.pos(var3.minX, var3.maxY, var3.minZ).color(var4, var5, var6, var7).endVertex();
      var8.draw();
      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawBoxESP(BlockPos var0, Color var1, boolean var2, Color var3, float var4, boolean var5, boolean var6, int var7, boolean var8) {
      if (var6) {
         drawBox(var0, new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var7));
      }

      if (var5) {
         Color var10001;
         if (var2) {
            var10001 = var3;
            boolean var10002 = false;
         } else {
            var10001 = var1;
         }

         drawBlockOutline(var0, var10001, var4, var8);
      }
   }

   public static void drawBoxESP(BlockPos var0, Color var1, int var2) {
      drawBox(var0, new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var2));
   }

   public static void drawBlockOutline(AxisAlignedBB var0, Color var1, float var2) {
      float var3 = (float)var1.getRed() / 255.0F;
      float var4 = (float)var1.getGreen() / 255.0F;
      float var5 = (float)var1.getBlue() / 255.0F;
      float var6 = (float)var1.getAlpha() / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(var2);
      Tessellator var7 = Tessellator.getInstance();
      BufferBuilder var8 = var7.getBuffer();
      var8.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var8.pos(var0.minX, var0.minY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.minY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.minY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.minY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.minY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.maxY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.maxY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.minY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.minY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.maxY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.maxY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.maxY, var0.maxZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.maxY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.minY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.maxX, var0.maxY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var8.pos(var0.minX, var0.maxY, var0.minZ).color(var3, var4, var5, var6).endVertex();
      var7.draw();
      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawBlockOutline(BlockPos var0, Color var1, float var2, boolean var3, double var4, boolean var6, boolean var7, int var8, boolean var9) {
      if (var6) {
         Color var12 = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var8);
         Color var10001;
         if (var7) {
            var10001 = var1;
            boolean var10002 = false;
         } else {
            var10001 = var12;
         }

         Color var13;
         if (var7) {
            var13 = var12;
            boolean var10003 = false;
         } else {
            var13 = var1;
         }

         drawFadingOutline(var0, var10001, var13, var2, var4);
      } else {
         IBlockState var10 = mc.world.getBlockState(var0);
         if ((var3 || var10.getMaterial() != Material.AIR) && mc.world.getWorldBorder().contains(var0)) {
            AxisAlignedBB var11 = new AxisAlignedBB(
               (double)var0.getX() - mc.getRenderManager().viewerPosX,
               (double)var0.getY() - mc.getRenderManager().viewerPosY,
               (double)var0.getZ() - mc.getRenderManager().viewerPosZ,
               (double)(var0.getX() + 1) - mc.getRenderManager().viewerPosX,
               (double)(var0.getY() + 1) - mc.getRenderManager().viewerPosY + var4,
               (double)(var0.getZ() + 1) - mc.getRenderManager().viewerPosZ
            );
            drawBlockOutline(var11.grow(0.002F), var1, var2, var9);
         }
      }
   }

   public static AxisAlignedBB interpolateAxis(AxisAlignedBB var0) {
      return new AxisAlignedBB(
         var0.minX - mc.getRenderManager().viewerPosX,
         var0.minY - mc.getRenderManager().viewerPosY,
         var0.minZ - mc.getRenderManager().viewerPosZ,
         var0.maxX - mc.getRenderManager().viewerPosX,
         var0.maxY - mc.getRenderManager().viewerPosY,
         var0.maxZ - mc.getRenderManager().viewerPosZ
      );
   }

   private static void buildPosColor(
      BufferBuilder var0, float var1, float var2, float var3, float var4, double var5, double var7, double var9, double var11, double var13, double var15
   ) {
      buildPosColor(var0, var1, var2, var3, var4, var1, var2, var3, var4, var5, var7, var9, var11, var13, var15);
   }

   public static void drawSexyBoxPhobosIsRetardedFuckYouESP(
      AxisAlignedBB var0, Color var1, Color var2, float var3, boolean var4, boolean var5, boolean var6, float var7, float var8, float var9
   ) {
      double var10 = 0.5 * (double)(1.0F - var8);
      AxisAlignedBB var12 = interpolateAxis(
         new AxisAlignedBB(
            var0.minX + var10, var0.minY + var10 + (double)(1.0F - var9), var0.minZ + var10, var0.maxX - var10, var0.maxY - var10, var0.maxZ - var10
         )
      );
      float var13 = (float)var1.getRed() / 255.0F;
      float var14 = (float)var1.getGreen() / 255.0F;
      float var15 = (float)var1.getBlue() / 255.0F;
      float var16 = (float)var1.getAlpha() / 255.0F;
      float var17 = (float)var2.getRed() / 255.0F;
      float var18 = (float)var2.getGreen() / 255.0F;
      float var19 = (float)var2.getBlue() / 255.0F;
      float var20 = (float)var2.getAlpha() / 255.0F;
      if (var6) {
         var13 = (float)Managers.COLORS.getCurrent().getRed() / 255.0F;
         var14 = (float)Managers.COLORS.getCurrent().getGreen() / 255.0F;
         var15 = (float)Managers.COLORS.getCurrent().getBlue() / 255.0F;
         var17 = (float)Managers.COLORS.getCurrent().getRed() / 255.0F;
         var18 = (float)Managers.COLORS.getCurrent().getGreen() / 255.0F;
         var19 = (float)Managers.COLORS.getCurrent().getBlue() / 255.0F;
      }

      if (var7 > 1.0F) {
         var7 = 1.0F;
      }

      var16 *= var7;
      var20 *= var7;
      if (var5) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.renderFilledBox(var12, var13, var14, var15, var16);
         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }

      if (var4) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         GL11.glLineWidth(var3);
         Tessellator var21 = Tessellator.getInstance();
         BufferBuilder var22 = var21.getBuffer();
         var22.begin(3, DefaultVertexFormats.POSITION_COLOR);
         var22.pos(var12.minX, var12.minY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.minY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.minY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.minY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.minY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.maxY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.maxY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.minY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.minY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.maxY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.maxY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.maxY, var12.maxZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.maxY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.minY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.maxX, var12.maxY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var22.pos(var12.minX, var12.maxY, var12.minZ).color(var17, var18, var19, var20).endVertex();
         var21.draw();
         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void drawRectangleCorrectly(int var0, int var1, int var2, int var3, int var4) {
      GL11.glLineWidth(1.0F);
      Gui.drawRect(var0, var1, var0 + var2, var1 + var3, var4);
   }

   public static void drawCircleVertices(AxisAlignedBB var0, float var1, Color var2) {
      float var3 = (float)var2.getRed() / 255.0F;
      float var4 = (float)var2.getGreen() / 255.0F;
      float var5 = (float)var2.getBlue() / 255.0F;
      float var6 = (float)var2.getAlpha() / 255.0F;
      Tessellator var7 = Tessellator.getInstance();
      BufferBuilder var8 = var7.getBuffer();
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(1.0F);

      for(int var9 = 0; var9 < 360; ++var9) {
         var8.begin(3, DefaultVertexFormats.POSITION_COLOR);
         var8.pos(
               var0.getCenter().x + Math.sin((double)var9 * 3.1415926 / 180.0) * (double)var1,
               var0.minY,
               var0.getCenter().z + Math.cos((double)var9 * 3.1415926 / 180.0) * (double)var1
            )
            .color(var3, var4, var5, var6)
            .endVertex();
         var8.pos(
               var0.getCenter().x + Math.sin((double)(var9 + 1) * 3.1415926 / 180.0) * (double)var1,
               var0.minY,
               var0.getCenter().z + Math.cos((double)(var9 + 1) * 3.1415926 / 180.0) * (double)var1
            )
            .color(var3, var4, var5, var6)
            .endVertex();
         var7.draw();
         boolean var10000 = false;
      }

      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawBox(AxisAlignedBB var0, Color var1) {
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(
         new AxisAlignedBB(
            var0.minX + mc.getRenderManager().viewerPosX,
            var0.minY + mc.getRenderManager().viewerPosY,
            var0.minZ + mc.getRenderManager().viewerPosZ,
            var0.maxX + mc.getRenderManager().viewerPosX,
            var0.maxY + mc.getRenderManager().viewerPosY,
            var0.maxZ + mc.getRenderManager().viewerPosZ
         )
      )) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         GlStateManager.disableDepth();
         GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
         GlStateManager.disableTexture2D();
         GlStateManager.depthMask(false);
         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         RenderGlobal.renderFilledBox(
            var0, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F
         );
         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void drawModalRect(int var0, int var1, float var2, float var3, int var4, int var5, int var6, int var7, float var8, float var9) {
      Gui.drawScaledCustomSizeModalRect(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   public static void drawFadingOutline(AxisAlignedBB var0, Color var1, Color var2, float var3, double var4) {
      float var6 = (float)var1.getRed() / 255.0F;
      float var7 = (float)var1.getGreen() / 255.0F;
      float var8 = (float)var1.getBlue() / 255.0F;
      float var9 = (float)var1.getAlpha() / 255.0F;
      float var10 = (float)var2.getRed() / 255.0F;
      float var11 = (float)var2.getGreen() / 255.0F;
      float var12 = (float)var2.getBlue() / 255.0F;
      float var13 = (float)var2.getAlpha() / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glLineWidth(var3);
      Tessellator var14 = Tessellator.getInstance();
      BufferBuilder var15 = var14.getBuffer();
      var15.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var15.pos(var0.minX, var0.minY, var0.minZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.minX, var0.minY, var0.maxZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.maxX, var0.minY, var0.maxZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.maxX, var0.minY, var0.minZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.minX, var0.minY, var0.minZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.minX, var0.maxY + var4, var0.minZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.minX, var0.maxY + var4, var0.maxZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.minX, var0.minY, var0.maxZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.maxX, var0.minY, var0.maxZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.maxX, var0.maxY + var4, var0.maxZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.minX, var0.maxY + var4, var0.maxZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.maxX, var0.maxY + var4, var0.maxZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.maxX, var0.maxY + var4, var0.minZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.maxX, var0.minY, var0.minZ).color(var10, var11, var12, var13).endVertex();
      var15.pos(var0.maxX, var0.maxY + var4, var0.minZ).color(var6, var7, var8, var9).endVertex();
      var15.pos(var0.minX, var0.maxY + var4, var0.minZ).color(var6, var7, var8, var9).endVertex();
      var14.draw();
      GL11.glDisable(2848);
      GlStateManager.depthMask(true);
      GlStateManager.enableDepth();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawText(AxisAlignedBB var0, String var1, Color var2) {
      if (var0 != null && var1 != null) {
         double var3 = var0.minX + (var0.maxX - var0.minX) / 2.0 - mc.getRenderManager().renderPosX;
         double var5 = var0.minY + (var0.maxY - var0.minY) / 2.0 - mc.getRenderManager().renderPosY - 1.5;
         double var7 = var0.minZ + (var0.maxZ - var0.minZ) / 2.0 - mc.getRenderManager().renderPosZ;
         drawText(var1, var3, var5, var7, var2);
      }
   }

   public static void glColor(int var0) {
      float var1 = (float)(var0 >> 16 & 0xFF) / 255.0F;
      float var2 = (float)(var0 >> 8 & 0xFF) / 255.0F;
      float var3 = (float)(var0 & 0xFF) / 255.0F;
      float var4 = (float)(var0 >> 24 & 0xFF) / 255.0F;
      GL11.glColor4f(var1, var2, var3, var4);
   }

   public static void drawBoxESP(AxisAlignedBB var0, Color var1, boolean var2, Color var3, float var4, boolean var5, boolean var6, int var7, boolean var8) {
      AxisAlignedBB var9 = var0.offset(-mc.getRenderManager().viewerPosX, -mc.getRenderManager().viewerPosY, -mc.getRenderManager().viewerPosZ);
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(var0)) {
         GlStateManager.pushMatrix();
         GlStateManager.enableBlend();
         if (var8) {
            GlStateManager.enableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(true);
            boolean var10000 = false;
         } else {
            GlStateManager.disableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(false);
         }

         GL11.glEnable(2848);
         GL11.glHint(3154, 4354);
         GL11.glLineWidth(var4);
         if (var6) {
            RenderGlobal.renderFilledBox(
               var9, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var7 / 255.0F
            );
         }

         if (var5) {
            Color var10001;
            if (var2) {
               var10001 = var3;
               boolean var10002 = false;
            } else {
               var10001 = var1;
            }

            drawBlockOutline(var9, var10001, var4, var8);
         }

         GL11.glDisable(2848);
         GlStateManager.depthMask(true);
         GlStateManager.enableDepth();
         GlStateManager.enableTexture2D();
         GlStateManager.disableBlend();
         GlStateManager.popMatrix();
      }
   }

   public static void drawFadingOutline(BlockPos var0, Color var1, Color var2, float var3, double var4) {
      IBlockState var6 = mc.world.getBlockState(var0);
      Vec3d var7 = InterpolationUtil.getInterpolatedPos(mc.player, mc.getRenderPartialTicks(), false);
      drawFadingOutline(
         var6.getSelectedBoundingBox(mc.world, var0).grow(0.002F).offset(-var7.x, -var7.y, -var7.z).expand(0.0, 0.0, 0.0), var1, var2, var3, var4
      );
   }

   public static void drawLine(float var0, float var1, float var2, float var3, float var4, int var5) {
      float var6 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var7 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var8 = (float)(var5 & 0xFF) / 255.0F;
      float var9 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      GlStateManager.pushMatrix();
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.shadeModel(7425);
      GL11.glLineWidth(var4);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      Tessellator var10 = Tessellator.getInstance();
      BufferBuilder var11 = var10.getBuffer();
      var11.begin(3, DefaultVertexFormats.POSITION_COLOR);
      var11.pos((double)var0, (double)var1, 0.0).color(var6, var7, var8, var9).endVertex();
      var11.pos((double)var2, (double)var3, 0.0).color(var6, var7, var8, var9).endVertex();
      var10.draw();
      GlStateManager.shadeModel(7424);
      GL11.glDisable(2848);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
      GlStateManager.popMatrix();
   }

   public static Vec3d get2DPos(double var0, double var2, double var4) {
      GL11.glGetFloat(2982, modelView);
      GL11.glGetFloat(2983, projection);
      GL11.glGetInteger(2978, viewport);
      boolean var6 = GLU.gluProject((float)var0, (float)var2, (float)var4, modelView, projection, viewport, screenCoords);
      return var6 ? new Vec3d((double)screenCoords.get(0), (double)((float)Display.getHeight() - screenCoords.get(1)), (double)screenCoords.get(2)) : null;
   }

   public static void drawRect(float var0, float var1, float var2, float var3, int var4) {
      float var5 = (float)(var4 >> 24 & 0xFF) / 255.0F;
      float var6 = (float)(var4 >> 16 & 0xFF) / 255.0F;
      float var7 = (float)(var4 >> 8 & 0xFF) / 255.0F;
      float var8 = (float)(var4 & 0xFF) / 255.0F;
      Tessellator var9 = Tessellator.getInstance();
      BufferBuilder var10 = var9.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      var10.begin(7, DefaultVertexFormats.POSITION_COLOR);
      var10.pos((double)var0, (double)var3, 0.0).color(var6, var7, var8, var5).endVertex();
      var10.pos((double)var2, (double)var3, 0.0).color(var6, var7, var8, var5).endVertex();
      var10.pos((double)var2, (double)var1, 0.0).color(var6, var7, var8, var5).endVertex();
      var10.pos((double)var0, (double)var1, 0.0).color(var6, var7, var8, var5).endVertex();
      var9.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }

   public static void drawNameTagOutline(float var0, float var1, float var2, float var3, float var4, int var5, int var6, boolean var7) {
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      var0 *= 2.0F;
      var2 *= 2.0F;
      var1 *= 2.0F;
      var3 *= 2.0F;
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      int var10005;
      if (var7) {
         var10005 = ColorUtil.rainbow(5000).getRGB();
         boolean var10006 = false;
      } else {
         var10005 = var5;
      }

      drawLine(var0, var1, var0, var3, var4, var10005);
      if (var7) {
         var10005 = ColorUtil.rainbow(1000).getRGB();
         boolean var15 = false;
      } else {
         var10005 = var6;
      }

      drawLine(var2, var1, var2, var3, var4, var10005);
      if (var7) {
         var10005 = ColorUtil.rainbow(5000).getRGB();
         boolean var16 = false;
      } else {
         var10005 = var5;
      }

      int var17;
      if (var7) {
         var17 = ColorUtil.rainbow(1000).getRGB();
         boolean var10007 = false;
      } else {
         var17 = var6;
      }

      drawGradientLine(var0, var1, var2, var1, var4, var10005, var17);
      if (var7) {
         var10005 = ColorUtil.rainbow(5000).getRGB();
         boolean var18 = false;
      } else {
         var10005 = var5;
      }

      if (var7) {
         var17 = ColorUtil.rainbow(1000).getRGB();
         boolean var20 = false;
      } else {
         var17 = var6;
      }

      drawGradientLine(var0, var3, var2, var3, var4, var10005, var17);
      GL11.glScalef(2.0F, 2.0F, 2.0F);
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }

   public static void drawCircle(float var0, float var1, float var2, float var3, Color var4) {
      AxisAlignedBB var5 = new AxisAlignedBB(
         (double)var0 - mc.getRenderManager().viewerPosX,
         (double)var1 - mc.getRenderManager().viewerPosY,
         (double)var2 - mc.getRenderManager().viewerPosZ,
         (double)(var0 + 1.0F) - mc.getRenderManager().viewerPosX,
         (double)(var1 + 1.0F) - mc.getRenderManager().viewerPosY,
         (double)(var2 + 1.0F) - mc.getRenderManager().viewerPosZ
      );
      camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
      if (camera.isBoundingBoxInFrustum(
         new AxisAlignedBB(
            var5.minX + mc.getRenderManager().viewerPosX,
            var5.minY + mc.getRenderManager().viewerPosY,
            var5.minZ + mc.getRenderManager().viewerPosZ,
            var5.maxX + mc.getRenderManager().viewerPosX,
            var5.maxY + mc.getRenderManager().viewerPosY,
            var5.maxZ + mc.getRenderManager().viewerPosZ
         )
      )) {
         drawCircleVertices(var5, var3, var4);
      }
   }

   public static void drawBox(BlockPos var0, Color var1, double var2, boolean var4, boolean var5, int var6) {
      if (var4) {
         Color var8 = new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var6);
         Color var10001;
         if (var5) {
            var10001 = var8;
            boolean var10002 = false;
         } else {
            var10001 = var1;
         }

         Color var9;
         if (var5) {
            var9 = var1;
            boolean var10003 = false;
         } else {
            var9 = var8;
         }

         drawFadingBox(var0, var10001, var9, var2);
      } else {
         AxisAlignedBB var7 = new AxisAlignedBB(
            (double)var0.getX() - mc.getRenderManager().viewerPosX,
            (double)var0.getY() - mc.getRenderManager().viewerPosY,
            (double)var0.getZ() - mc.getRenderManager().viewerPosZ,
            (double)(var0.getX() + 1) - mc.getRenderManager().viewerPosX,
            (double)(var0.getY() + 1) - mc.getRenderManager().viewerPosY + var2,
            (double)(var0.getZ() + 1) - mc.getRenderManager().viewerPosZ
         );
         camera.setPosition(Objects.requireNonNull(mc.getRenderViewEntity()).posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
         if (camera.isBoundingBoxInFrustum(
            new AxisAlignedBB(
               var7.minX + mc.getRenderManager().viewerPosX,
               var7.minY + mc.getRenderManager().viewerPosY,
               var7.minZ + mc.getRenderManager().viewerPosZ,
               var7.maxX + mc.getRenderManager().viewerPosX,
               var7.maxY + mc.getRenderManager().viewerPosY,
               var7.maxZ + mc.getRenderManager().viewerPosZ
            )
         )) {
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.disableDepth();
            GlStateManager.tryBlendFuncSeparate(770, 771, 0, 1);
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask(false);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            RenderGlobal.renderFilledBox(
               var7, (float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F
            );
            GL11.glDisable(2848);
            GlStateManager.depthMask(true);
            GlStateManager.enableDepth();
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
         }
      }
   }

   public static void drawHGradientRect(float var0, float var1, float var2, float var3, int var4, int var5) {
      float var6 = (float)(var4 >> 16 & 0xFF) / 255.0F;
      float var7 = (float)(var4 >> 8 & 0xFF) / 255.0F;
      float var8 = (float)(var4 & 0xFF) / 255.0F;
      float var9 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var10 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var11 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var12 = (float)(var5 & 0xFF) / 255.0F;
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      Tessellator var13 = Tessellator.getInstance();
      BufferBuilder var14 = var13.getBuffer();
      var14.begin(7, DefaultVertexFormats.POSITION_COLOR);
      var14.pos((double)var0, (double)var1, 0.0).color(var6, var7, var8, var9).endVertex();
      var14.pos((double)var0, (double)var3, 0.0).color(var6, var7, var8, var9).endVertex();
      var14.pos((double)var2, (double)var3, 0.0).color(var10, var11, var12, var9).endVertex();
      var14.pos((double)var2, (double)var1, 0.0).color(var10, var11, var12, var9).endVertex();
      var13.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }

   public static void drawPolygonPart(double var0, double var2, int var4, int var5, int var6, int var7) {
      float var8 = (float)(var6 >> 24 & 0xFF) / 255.0F;
      float var9 = (float)(var6 >> 16 & 0xFF) / 255.0F;
      float var10 = (float)(var6 >> 8 & 0xFF) / 255.0F;
      float var11 = (float)(var6 & 0xFF) / 255.0F;
      float var12 = (float)(var7 >> 24 & 0xFF) / 255.0F;
      float var13 = (float)(var7 >> 16 & 0xFF) / 255.0F;
      float var14 = (float)(var7 >> 8 & 0xFF) / 255.0F;
      float var15 = (float)(var7 & 0xFF) / 255.0F;
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      Tessellator var16 = Tessellator.getInstance();
      BufferBuilder var17 = var16.getBuffer();
      var17.begin(6, DefaultVertexFormats.POSITION_COLOR);
      var17.pos(var0, var2, 0.0).color(var9, var10, var11, var8).endVertex();
      double var18 = Math.PI * 2;

      for(int var20 = var5 * 90; var20 <= var5 * 90 + 90; ++var20) {
         double var21 = (Math.PI * 2) * (double)var20 / 360.0 + Math.toRadians(180.0);
         var17.pos(var0 + Math.sin(var21) * (double)var4, var2 + Math.cos(var21) * (double)var4, 0.0).color(var13, var14, var15, var12).endVertex();
         boolean var10000 = false;
      }

      var16.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }

   public static void drawText(String var0, double var1, double var3, double var5, Color var7) {
      Entity var8 = mc.getRenderViewEntity();
      if (var8 != null) {
         double var9 = var8.posX;
         double var11 = var8.posY;
         double var13 = var8.posZ;
         var8.posX = var8.prevPosX;
         var8.posY = var8.prevPosY;
         var8.posZ = var8.prevPosZ;
         int var15 = Managers.TEXT.getMCStringWidth(var0) / 2;
         double var16 = 0.027999999999999997;
         GlStateManager.pushMatrix();
         RenderHelper.enableStandardItemLighting();
         GlStateManager.enablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
         GlStateManager.disableLighting();
         GlStateManager.translate((float)var1, (float)var3 + 1.4F, (float)var5);
         GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
         float var10000 = mc.getRenderManager().playerViewX;
         float var10001;
         if (mc.gameSettings.thirdPersonView == 2) {
            var10001 = -1.0F;
            boolean var10002 = false;
         } else {
            var10001 = 1.0F;
         }

         GlStateManager.rotate(var10000, var10001, 0.0F, 0.0F);
         GlStateManager.scale(-var16, -var16, var16);
         GlStateManager.disableDepth();
         Managers.TEXT.drawMCString(var0, (float)(-var15), (float)(-(Managers.TEXT.getFontHeight() - 1)), ColorUtil.toRGBA(var7), true);
         GlStateManager.enableDepth();
         var8.posX = var9;
         var8.posY = var11;
         var8.posZ = var13;
         GlStateManager.disablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
         GlStateManager.popMatrix();
      }
   }

   public static void drawFadingSide(BlockPos var0, EnumFacing var1, Color var2, Color var3, double var4) {
      Tessellator var6 = Tessellator.getInstance();
      BufferBuilder var7 = var6.getBuffer();
      IBlockState var8 = BlockUtil.getState(var0);
      Vec3d var9 = InterpolationUtil.getInterpolatedPos(mc.player, mc.getRenderPartialTicks(), false);
      AxisAlignedBB var10 = var8.getSelectedBoundingBox(mc.world, var0).grow(0.002F).offset(-var9.x, -var9.y, -var9.z).expand(0.0, 0.0, 0.0);
      float var11 = (float)var2.getRed() / 255.0F;
      float var12 = (float)var2.getGreen() / 255.0F;
      float var13 = (float)var2.getBlue() / 255.0F;
      float var14 = (float)var2.getAlpha() / 255.0F;
      float var15 = (float)var3.getRed() / 255.0F;
      float var16 = (float)var3.getGreen() / 255.0F;
      float var17 = (float)var3.getBlue() / 255.0F;
      float var18 = (float)var3.getAlpha() / 255.0F;
      double var19 = 0.0;
      double var21 = 0.0;
      double var23 = 0.0;
      double var25 = 0.0;
      double var27 = 0.0;
      double var29 = 0.0;
      if (var1 == EnumFacing.DOWN) {
         var19 = var10.minX;
         var25 = var10.maxX;
         var21 = var10.minY;
         var27 = var10.minY;
         var23 = var10.minZ;
         var29 = var10.maxZ;
         boolean var10000 = false;
      } else if (var1 == EnumFacing.UP) {
         var19 = var10.minX;
         var25 = var10.maxX;
         var21 = var10.maxY + var4;
         var27 = var10.maxY + var4;
         var23 = var10.minZ;
         var29 = var10.maxZ;
         boolean var31 = false;
      } else if (var1 == EnumFacing.EAST) {
         var19 = var10.maxX;
         var25 = var10.maxX;
         var21 = var10.minY;
         var27 = var10.maxY + var4;
         var23 = var10.minZ;
         var29 = var10.maxZ;
         boolean var32 = false;
      } else if (var1 == EnumFacing.WEST) {
         var19 = var10.minX;
         var25 = var10.minX;
         var21 = var10.minY;
         var27 = var10.maxY + var4;
         var23 = var10.minZ;
         var29 = var10.maxZ;
         boolean var33 = false;
      } else if (var1 == EnumFacing.SOUTH) {
         var19 = var10.minX;
         var25 = var10.maxX;
         var21 = var10.minY;
         var27 = var10.maxY + var4;
         var23 = var10.maxZ;
         var29 = var10.maxZ;
         boolean var34 = false;
      } else if (var1 == EnumFacing.NORTH) {
         var19 = var10.minX;
         var25 = var10.maxX;
         var21 = var10.minY;
         var27 = var10.maxY + var4;
         var23 = var10.minZ;
         var29 = var10.minZ;
      }

      GlStateManager.pushMatrix();
      GlStateManager.disableDepth();
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.depthMask(false);
      var7.begin(5, DefaultVertexFormats.POSITION_COLOR);
      if (var1 == EnumFacing.EAST || var1 == EnumFacing.WEST || var1 == EnumFacing.NORTH || var1 == EnumFacing.SOUTH) {
         buildPosColor(var7, var11, var12, var13, var14, var15, var16, var17, var18, var19, var21, var23, var25, var27, var29);
         boolean var36 = false;
      } else if (var1 == EnumFacing.UP) {
         buildPosColor(var7, var15, var16, var17, var18, var19, var21, var23, var25, var27, var29);
         boolean var35 = false;
      } else if (var1 == EnumFacing.DOWN) {
         buildPosColor(var7, var11, var12, var13, var14, var19, var21, var23, var25, var27, var29);
      }

      var6.draw();
      GlStateManager.depthMask(true);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
      GlStateManager.enableDepth();
      GlStateManager.popMatrix();
   }

   public static void drawArrowPointer(float var0, float var1, float var2, float var3, float var4, boolean var5, float var6, int var7) {
      boolean var8 = GL11.glIsEnabled(3042);
      float var9 = (float)(var7 >> 24 & 0xFF) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glPushMatrix();
      glColor(var7);
      GL11.glBegin(7);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glVertex2d((double)(var0 - var2 / var3), (double)(var1 + var2));
      GL11.glVertex2d((double)var0, (double)(var1 + var2 / var4));
      GL11.glVertex2d((double)(var0 + var2 / var3), (double)(var1 + var2));
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glEnd();
      if (var5) {
         GL11.glLineWidth(var6);
         GL11.glColor4f(0.0F, 0.0F, 0.0F, var9);
         GL11.glBegin(2);
         GL11.glVertex2d((double)var0, (double)var1);
         GL11.glVertex2d((double)(var0 - var2 / var3), (double)(var1 + var2));
         GL11.glVertex2d((double)var0, (double)(var1 + var2 / var4));
         GL11.glVertex2d((double)(var0 + var2 / var3), (double)(var1 + var2));
         GL11.glVertex2d((double)var0, (double)var1);
         GL11.glEnd();
      }

      GL11.glPopMatrix();
      GL11.glEnable(3553);
      if (!var8) {
         GL11.glDisable(3042);
      }

      GL11.glDisable(2848);
   }
}
