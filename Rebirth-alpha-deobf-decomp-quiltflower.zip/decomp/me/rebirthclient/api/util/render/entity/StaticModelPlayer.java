package me.rebirthclient.api.util.render.entity;

import me.rebirthclient.api.util.Wrapper;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelBiped.ArmPose;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;

public class StaticModelPlayer extends ModelPlayer implements Wrapper {
   private float limbSwingAmount;
   private float yawHead;
   private float yaw;
   private final EntityPlayer player;
   private float limbSwing;
   private float pitch;

   public float getPitch() {
      return this.pitch;
   }

   public void setLimbSwingAmount(float var1) {
      this.limbSwingAmount = var1;
   }

   public void render(float var1) {
      this.render(this.player, this.limbSwing, this.limbSwingAmount, (float)this.player.ticksExisted, this.yawHead, this.pitch, var1);
   }

   private static ArmPose getArmPose(EntityPlayer var0, ItemStack var1) {
      if (var1.isEmpty()) {
         return ArmPose.EMPTY;
      } else {
         return var1.getItem() instanceof ItemBow && var0.getItemInUseCount() > 0 ? ArmPose.BOW_AND_ARROW : ArmPose.ITEM;
      }
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public void setLimbSwing(float var1) {
      this.limbSwing = var1;
   }

   public float getLimbSwingAmount() {
      return this.limbSwingAmount;
   }

   public float getYawHead() {
      return this.yawHead;
   }

   public void disableArmorLayers() {
      this.bipedBodyWear.showModel = false;
      this.bipedLeftLegwear.showModel = false;
      this.bipedRightLegwear.showModel = false;
      this.bipedLeftArmwear.showModel = false;
      this.bipedRightArmwear.showModel = false;
      this.bipedHeadwear.showModel = true;
      this.bipedHead.showModel = false;
   }

   public float getLimbSwing() {
      return this.limbSwing;
   }

   public StaticModelPlayer(EntityPlayer var1, boolean var2, float var3) {
      super(var3, var2);
      this.player = var1;
      this.limbSwing = this.player.limbSwing;
      this.limbSwingAmount = this.player.limbSwingAmount;
      this.yaw = this.player.rotationYaw;
      this.yawHead = this.player.rotationYawHead;
      this.pitch = this.player.rotationPitch;
      this.isSneak = this.player.isSneaking();
      EntityPlayer var10001 = this.player;
      ItemStack var10002;
      if (this.player.getPrimaryHand() == EnumHandSide.RIGHT) {
         var10002 = this.player.getHeldItemMainhand();
         boolean var10003 = false;
      } else {
         var10002 = this.player.getHeldItemOffhand();
      }

      this.rightArmPose = getArmPose(var10001, var10002);
      var10001 = this.player;
      if (this.player.getPrimaryHand() == EnumHandSide.RIGHT) {
         var10002 = this.player.getHeldItemOffhand();
         boolean var6 = false;
      } else {
         var10002 = this.player.getHeldItemMainhand();
      }

      this.leftArmPose = getArmPose(var10001, var10002);
      this.swingProgress = this.player.swingProgress;
      this.setLivingAnimations(this.player, this.limbSwing, this.limbSwingAmount, mc.getRenderPartialTicks());
   }

   public EntityPlayer getPlayer() {
      return this.player;
   }

   public void setYawHead(float var1) {
      this.yawHead = var1;
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public float getYaw() {
      return this.yaw;
   }
}
