package me.rebirthclient.api.util.render.shaders;

import me.rebirthclient.api.util.render.shaders.shaders.AquaGlShader;
import me.rebirthclient.api.util.render.shaders.shaders.AquaShader;
import me.rebirthclient.api.util.render.shaders.shaders.BasicShader;
import me.rebirthclient.api.util.render.shaders.shaders.FlowGlShader;
import me.rebirthclient.api.util.render.shaders.shaders.FlowShader;
import me.rebirthclient.api.util.render.shaders.shaders.GangGlShader;
import me.rebirthclient.api.util.render.shaders.shaders.GlowShader;
import me.rebirthclient.api.util.render.shaders.shaders.HolyFuckShader;
import me.rebirthclient.api.util.render.shaders.shaders.PurpleShader;
import me.rebirthclient.api.util.render.shaders.shaders.RedShader;
import me.rebirthclient.api.util.render.shaders.shaders.SmokeShader;

public enum ShaderMode {
   BLUEFLAMES("BlueFlames", ShaderMode::lambda$static$1),
   STROXINJAT("Stroxinjat", ShaderMode::lambda$static$18),
   Aqua("Aqua", AquaShader::INSTANCE),
   FLOWGLOW("FlowGLow", FlowGlShader::INSTANCE),
   SNOW("Snow", ShaderMode::lambda$static$7),
   CODEX("Codex", ShaderMode::lambda$static$3),
   HIDEF("Hidef", ShaderMode::lambda$static$12),
   GOLDEN("Golden", ShaderMode::lambda$static$9),
   SMOKE("Smoke", SmokeShader::INSTANCE),
   TECHNO("Techno", ShaderMode::lambda$static$8),
   CRAZY("Crazy", ShaderMode::lambda$static$6),
   YIPPIEOWNS("YippieOwns", ShaderMode::lambda$static$20),
   HOMIE("Homie", ShaderMode::lambda$static$13),
   SHELDON("Sheldon", ShaderMode::lambda$static$16),
   SMOKY("Smoky", ShaderMode::lambda$static$17),
   WEIRD("Weird", ShaderMode::lambda$static$19),
   GUISHADER("GuiShader", ShaderMode::lambda$static$11),
   HOTSHIT("HotShit", ShaderMode::lambda$static$10),
   AQUAGLOW("AquaGlow", AquaGlShader::INSTANCE),
   FLOWBLUR("FlowBlur", ShaderMode::lambda$static$0),
   HOLYFUCK("HolyFuck", HolyFuckShader::INSTANCE),
   PURPLE("Purple", PurpleShader::INSTANCE),
   GANG("Gang", GangGlShader::INSTANCE),
   KFC("KFC", ShaderMode::lambda$static$14),
   GAMER("Gamer", ShaderMode::lambda$static$2),
   OHMYLORD("Lord", ShaderMode::lambda$static$15),
   FLOW("Flow", FlowShader::INSTANCE),
   RED("Red", RedShader::INSTANCE),
   DDEV("Ddev", ShaderMode::lambda$static$5),
   GHOST("Glow", GlowShader::INSTANCE),
   GALAXY("Galaxy", ShaderMode::lambda$static$4);
   private final String name;
   private final ShaderProducer shaderProducer;
   private static final ShaderMode[] $VALUES = new ShaderMode[]{
      Aqua,
      AQUAGLOW,
      ShaderMode.FLOW,
      ShaderMode.FLOWBLUR,
      FLOWGLOW,
      ShaderMode.GHOST,
      SMOKE,
      ShaderMode.RED,
      ShaderMode.HOLYFUCK,
      ShaderMode.GANG,
      BLUEFLAMES,
      ShaderMode.GAMER,
      CODEX,
      ShaderMode.GALAXY,
      ShaderMode.DDEV,
      CRAZY,
      SNOW,
      TECHNO,
      GOLDEN,
      HOTSHIT,
      GUISHADER,
      HIDEF,
      HOMIE,
      ShaderMode.KFC,
      ShaderMode.OHMYLORD,
      SHELDON,
      SMOKY,
      STROXINJAT,
      WEIRD,
      YIPPIEOWNS,
      ShaderMode.PURPLE
   };

   private static FramebufferShader lambda$static$7() {
      return BasicShader.INSTANCE("snow.frag", 0.01F);
   }

   private ShaderMode(String var3, ShaderProducer var4) {
      this.name = var3;
      this.shaderProducer = var4;
   }

   private static FramebufferShader lambda$static$20() {
      return BasicShader.INSTANCE("yippieOwns.frag");
   }

   private static FramebufferShader lambda$static$10() {
      return BasicShader.INSTANCE("hotshit.frag", 0.005F);
   }

   private static FramebufferShader lambda$static$15() {
      return BasicShader.INSTANCE("ohmylord.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$12() {
      return BasicShader.INSTANCE("hidef.frag", 0.05F);
   }

   private static FramebufferShader lambda$static$18() {
      return BasicShader.INSTANCE("stroxinjat.frag");
   }

   private static FramebufferShader lambda$static$13() {
      return BasicShader.INSTANCE("homie.frag", 0.001F);
   }

   private static FramebufferShader lambda$static$2() {
      return BasicShader.INSTANCE("gamer.frag", 0.03F);
   }

   private static FramebufferShader lambda$static$11() {
      return BasicShader.INSTANCE("clickguishader.frag", 0.02F);
   }

   private static FramebufferShader lambda$static$17() {
      return BasicShader.INSTANCE("smoky.frag", 0.001F);
   }

   private static FramebufferShader lambda$static$5() {
      return BasicShader.INSTANCE("ddev.frag");
   }

   private static FramebufferShader lambda$static$16() {
      return BasicShader.INSTANCE("sheldon.frag", 0.001F);
   }

   private static FramebufferShader lambda$static$0() {
      return BasicShader.INSTANCE("flowglow_z.frag", 5.0E-4F);
   }

   private static FramebufferShader lambda$static$14() {
      return BasicShader.INSTANCE("kfc.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$6() {
      return BasicShader.INSTANCE("crazy.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$9() {
      return BasicShader.INSTANCE("golden.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$8() {
      return BasicShader.INSTANCE("techno.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$4() {
      return BasicShader.INSTANCE("galaxy33.frag", 0.001F);
   }

   public FramebufferShader getShader() {
      return this.shaderProducer.INSTANCE();
   }

   private static FramebufferShader lambda$static$19() {
      return BasicShader.INSTANCE("weird.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$1() {
      return BasicShader.INSTANCE("blueflames.frag", 0.01F);
   }

   private static FramebufferShader lambda$static$3() {
      return BasicShader.INSTANCE("codex.frag");
   }

   public String getName() {
      return this.name;
   }
}
