package me.rebirthclient.api.util.render.shaders.shaders;

import me.rebirthclient.api.util.render.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class RedShader extends FramebufferShader {
   protected float time = 0.0F;
   private static RedShader INSTANCE;

   private RedShader() {
      super("red.frag");
   }

   public static RedShader INSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new RedShader();
      }

      return INSTANCE;
   }

   @Override
   public void updateUniforms() {
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform2f(
         this.getUniform("resolution"), (float)new ScaledResolution(this.mc).getScaledWidth(), (float)new ScaledResolution(this.mc).getScaledHeight()
      );
      GL20.glUniform2f(
         this.getUniform("texelSize"),
         1.0F / (float)this.mc.displayWidth * this.radius * this.quality,
         1.0F / (float)this.mc.displayHeight * this.radius * this.quality
      );
      if (this.animation) {
         float var10001;
         if (this.time > 100.0F) {
            var10001 = 0.0F;
            boolean var10002 = false;
         } else {
            var10001 = (float)((double)this.time + 0.05 * (double)this.animationSpeed);
         }

         this.time = var10001;
      }
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("time");
      this.setupUniform("resolution");
      this.setupUniform("texelSize");
   }
}
