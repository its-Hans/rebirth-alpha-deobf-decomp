package me.rebirthclient.api.util.render.shaders;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public abstract class FramebufferShader extends Shader {
   protected float red;
   protected int animationSpeed;
   protected float radius;
   protected float alpha;
   protected static int lastScaleHeight;
   private boolean entityShadows;
   protected float divider;
   protected float maxSample;
   protected float blue;
   protected boolean animation;
   protected float quality;
   protected static int lastScaleWidth;
   protected float green;
   protected static int lastScale;
   private static Framebuffer framebuffer;
   public final Minecraft mc = Minecraft.getMinecraft();

   public Framebuffer setupFrameBuffer(Framebuffer var1) {
      if (!Display.isActive() && !Display.isVisible()) {
         if (var1 == null) {
            var1 = new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
         }
      } else if (var1 != null) {
         var1.framebufferClear();
         ScaledResolution var2 = new ScaledResolution(this.mc);
         int var3 = var2.getScaleFactor();
         int var4 = var2.getScaledWidth();
         int var5 = var2.getScaledHeight();
         if (lastScale != var3 || lastScaleWidth != var4 || lastScaleHeight != var5) {
            var1.deleteFramebuffer();
            var1 = new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
            var1.framebufferClear();
         }

         lastScale = var3;
         lastScaleWidth = var4;
         lastScaleHeight = var5;
         boolean var10000 = false;
      } else {
         var1 = new Framebuffer(this.mc.displayWidth, this.mc.displayHeight, true);
         boolean var6 = false;
      }

      return var1;
   }

   public void setShaderParams(Boolean var1, int var2, Color var3, float var4, float var5, float var6) {
      this.setShaderParams(var1, var2, var3, var4);
      this.divider = var5;
      this.maxSample = var6;
   }

   public void setShaderParams(Boolean var1, int var2, Color var3) {
      this.animation = var1;
      this.animationSpeed = var2;
      this.red = (float)var3.getRed() / 255.0F;
      this.green = (float)var3.getGreen() / 255.0F;
      this.blue = (float)var3.getBlue() / 255.0F;
      this.alpha = (float)var3.getAlpha() / 255.0F;
   }

   public void setShaderParams(Boolean var1, int var2, Color var3, float var4) {
      this.setShaderParams(var1, var2, var3);
      this.radius = var4;
   }

   public FramebufferShader(String var1) {
      super(var1);
      this.alpha = 1.0F;
      this.radius = 2.0F;
      this.quality = 1.0F;
      this.animation = true;
      this.animationSpeed = 1;
      this.divider = 1.0F;
      this.maxSample = 1.0F;
   }

   public void drawFramebuffer(Framebuffer var1) {
      ScaledResolution var2 = new ScaledResolution(this.mc);
      GL11.glBindTexture(3553, var1.framebufferTexture);
      GL11.glBegin(7);
      GL11.glTexCoord2d(0.0, 1.0);
      GL11.glVertex2d(0.0, 0.0);
      GL11.glTexCoord2d(0.0, 0.0);
      GL11.glVertex2d(0.0, (double)var2.getScaledHeight());
      GL11.glTexCoord2d(1.0, 0.0);
      GL11.glVertex2d((double)var2.getScaledWidth(), (double)var2.getScaledHeight());
      GL11.glTexCoord2d(1.0, 1.0);
      GL11.glVertex2d((double)var2.getScaledWidth(), 0.0);
      GL11.glEnd();
      GL20.glUseProgram(0);
   }

   public void stopDraw() {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      GlStateManager.enableBlend();
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader();
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
   }

   public void stopDraw(Color var1, float var2, float var3, Runnable... var4) {
      this.mc.gameSettings.entityShadows = this.entityShadows;
      GlStateManager.enableBlend();
      GL11.glBlendFunc(770, 771);
      this.mc.getFramebuffer().bindFramebuffer(true);
      this.red = (float)var1.getRed() / 255.0F;
      this.green = (float)var1.getGreen() / 255.0F;
      this.blue = (float)var1.getBlue() / 255.0F;
      this.alpha = (float)var1.getAlpha() / 255.0F;
      this.radius = var2;
      this.quality = var3;
      this.mc.entityRenderer.disableLightmap();
      RenderHelper.disableStandardItemLighting();
      this.startShader();
      this.mc.entityRenderer.setupOverlayRendering();
      this.drawFramebuffer(framebuffer);
      this.stopShader();
      this.mc.entityRenderer.disableLightmap();
      GlStateManager.popMatrix();
      GlStateManager.popAttrib();
   }

   public void startDraw(float var1) {
      GlStateManager.enableAlpha();
      GlStateManager.pushMatrix();
      (framebuffer = this.setupFrameBuffer(framebuffer)).bindFramebuffer(true);
      this.entityShadows = this.mc.gameSettings.entityShadows;
      this.mc.gameSettings.entityShadows = false;
   }
}
