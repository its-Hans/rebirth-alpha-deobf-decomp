package me.rebirthclient.api.util.render.shaders.shaders;

import me.rebirthclient.api.util.render.shaders.FramebufferShader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class PurpleShader extends FramebufferShader {
   public float time;
   public static PurpleShader INSTANCE;
   public final float timeMult = 0.05F;

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
   }

   public static PurpleShader INSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new PurpleShader();
      }

      return INSTANCE;
   }

   public PurpleShader() {
      super("purple.frag");
   }

   @Override
   public void updateUniforms() {
      GL20.glUniform2f(
         this.getUniform("resolution"),
         (float)new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth(),
         (float)new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight()
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      this.time += this.timeMult * (float)this.animationSpeed;
   }
}
