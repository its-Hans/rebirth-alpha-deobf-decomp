package me.rebirthclient.api.util.render.shaders.shaders;

import me.rebirthclient.api.util.render.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class BasicShader extends FramebufferShader {
   private final float timeMult;
   private float time = 0.0F;
   private static BasicShader INSTANCE;

   @Override
   public void setupUniforms() {
      this.setupUniform("time");
      this.setupUniform("resolution");
   }

   private BasicShader(String var1) {
      super(var1);
      this.timeMult = 0.1F;
   }

   public static FramebufferShader INSTANCE(String var0, float var1) {
      if (INSTANCE != null) {
         String var10000 = INSTANCE.fragmentShader;
         if (Integer.valueOf(var0.hashCode()).equals(var10000.hashCode())) {
            return INSTANCE;
         }
      }

      INSTANCE = new BasicShader(var0, var1);
      return INSTANCE;
   }

   private BasicShader(String var1, float var2) {
      super(var1);
      this.timeMult = var2;
   }

   @Override
   public void updateUniforms() {
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform2f(
         this.getUniform("resolution"), (float)new ScaledResolution(this.mc).getScaledWidth(), (float)new ScaledResolution(this.mc).getScaledHeight()
      );
      if (this.animation) {
         boolean var1 = true;
         float var10001;
         if (this.time > 10000.0F) {
            var10001 = 0.0F;
            boolean var10002 = false;
         } else {
            var10001 = this.time + this.timeMult * (float)this.animationSpeed;
         }

         this.time = var10001;
      }
   }

   public static FramebufferShader INSTANCE(String var0) {
      if (INSTANCE != null) {
         String var10000 = INSTANCE.fragmentShader;
         if (Integer.valueOf(var0.hashCode()).equals(var10000.hashCode())) {
            return INSTANCE;
         }
      }

      INSTANCE = new BasicShader(var0);
      return INSTANCE;
   }
}
