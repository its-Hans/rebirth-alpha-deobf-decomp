package me.rebirthclient.api.util.render.shaders;

import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.renderer.GlStateManager;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.GL20;

public abstract class Shader {
   public int program;
   public Map<String, Integer> uniformsMap;
   protected final String fragmentShader;

   public Shader(String var1) {
      this.fragmentShader = var1;
      Shader var10000 = this;

      int var2;
      int var3;
      try {
         InputStream var4 = var10000.getClass().getResourceAsStream("/shader/vertex.vert");
         var2 = this.createShader(IOUtils.toString(var4, Charset.defaultCharset()), 35633);
         IOUtils.closeQuietly(var4);
         InputStream var5 = this.getClass().getResourceAsStream(String.valueOf(new StringBuilder().append("/shader/").append(var1)));
         var3 = this.createShader(IOUtils.toString(var5, Charset.defaultCharset()), 35632);
         IOUtils.closeQuietly(var5);
      } catch (Exception var6) {
         var6.printStackTrace();
         return;
      }

      boolean var7 = false;
      if (var2 != 0 && var3 != 0) {
         this.program = ARBShaderObjects.glCreateProgramObjectARB();
         if (this.program != 0) {
            ARBShaderObjects.glAttachObjectARB(this.program, var2);
            ARBShaderObjects.glAttachObjectARB(this.program, var3);
            ARBShaderObjects.glLinkProgramARB(this.program);
            ARBShaderObjects.glValidateProgramARB(this.program);
         }
      }
   }

   public void setUniform(String var1, int var2) {
      this.uniformsMap.put(var1, var2);
      boolean var10000 = false;
   }

   public void stopShader() {
      GL20.glUseProgram(0);
      GlStateManager.popMatrix();
   }

   public int getProgramId() {
      return this.program;
   }

   public void setupUniform(String var1) {
      this.setUniform(var1, GL20.glGetUniformLocation(this.program, var1));
   }

   public void startShader() {
      GlStateManager.pushMatrix();
      GL20.glUseProgram(this.program);
      if (this.uniformsMap == null) {
         this.uniformsMap = new HashMap<>();
         this.setupUniforms();
      }

      this.updateUniforms();
   }

   public abstract void updateUniforms();

   public int getUniform(String var1) {
      return this.uniformsMap.get(var1);
   }

   public abstract void setupUniforms();

   public String getLogInfo(int var1) {
      return ARBShaderObjects.glGetInfoLogARB(var1, ARBShaderObjects.glGetObjectParameteriARB(var1, 35716));
   }

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public int createShader(String var1, int var2) {
      int var3 = 0;
      int var10000 = var2;

      label34: {
         try {
            var3 = ARBShaderObjects.glCreateShaderObjectARB(var10000);
            if (var3 == 0) {
               return 0;
            }
         } catch (Exception var6) {
            var7 = var6;
            boolean var10001 = false;
            break label34;
         }

         var10000 = var3;
         String var9 = var1;

         try {
            ARBShaderObjects.glShaderSourceARB(var10000, var9);
            ARBShaderObjects.glCompileShaderARB(var3);
            if (ARBShaderObjects.glGetObjectParameteriARB(var3, 35713) == 0) {
               throw new RuntimeException(String.valueOf(new StringBuilder().append("Error creating shader: ").append(this.getLogInfo(var3))));
            }

            return var3;
         } catch (Exception var5) {
            var7 = var5;
            boolean var10 = false;
         }
      }

      Exception var4 = var7;
      ARBShaderObjects.glDeleteObjectARB(var3);
      throw var4;
   }
}
