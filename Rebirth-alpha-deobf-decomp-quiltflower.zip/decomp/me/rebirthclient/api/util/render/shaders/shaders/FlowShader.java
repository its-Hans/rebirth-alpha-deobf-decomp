package me.rebirthclient.api.util.render.shaders.shaders;

import me.rebirthclient.api.util.render.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class FlowShader extends FramebufferShader {
   public static FlowShader INSTANCE;
   protected float time = 0.0F;

   @Override
   public void updateUniforms() {
      GL20.glUniform2f(
         this.getUniform("resolution"), (float)new ScaledResolution(this.mc).getScaledWidth(), (float)new ScaledResolution(this.mc).getScaledHeight()
      );
      GL20.glUniform1f(this.getUniform("time"), this.time);
      if (this.animation) {
         float var10001;
         if (this.time > 100.0F) {
            var10001 = 0.0F;
            boolean var10002 = false;
         } else {
            var10001 = (float)((double)this.time + 0.001 * (double)this.animationSpeed);
         }

         this.time = var10001;
      }
   }

   public static FlowShader INSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new FlowShader();
      }

      return INSTANCE;
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
   }

   private FlowShader() {
      super("flow.frag");
   }
}
