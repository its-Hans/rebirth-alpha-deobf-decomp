package me.rebirthclient.api.util.render.shaders.shaders;

import me.rebirthclient.api.util.render.shaders.FramebufferShader;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class AquaShader extends FramebufferShader {
   private static AquaShader INSTANCE;
   public float time = 0.0F;

   public static FramebufferShader INSTANCE() {
      if (INSTANCE == null) {
         INSTANCE = new AquaShader();
      }

      return INSTANCE;
   }

   private AquaShader() {
      super("aqua.frag");
   }

   @Override
   public void updateUniforms() {
      GL20.glUniform1f(this.getUniform("time"), this.time);
      GL20.glUniform2f(
         this.getUniform("resolution"), (float)new ScaledResolution(this.mc).getScaledWidth(), (float)new ScaledResolution(this.mc).getScaledHeight()
      );
      if (this.animation) {
         float var10001;
         if (this.time > 100.0F) {
            var10001 = 0.0F;
            boolean var10002 = false;
         } else {
            var10001 = (float)((double)this.time + 0.01 * (double)this.animationSpeed);
         }

         this.time = var10001;
      }
   }

   @Override
   public void setupUniforms() {
      this.setupUniform("resolution");
      this.setupUniform("time");
   }
}
