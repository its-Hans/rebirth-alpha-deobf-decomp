package me.rebirthclient.api.util.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Random;
import java.util.regex.Pattern;

public class TextUtil {
   public static final String DARK_GREEN = String.valueOf(ChatFormatting.DARK_GREEN);
   public static final String DARK_RED = String.valueOf(ChatFormatting.DARK_RED);
   public static final String DARK_GRAY = String.valueOf(ChatFormatting.DARK_GRAY);
   public static final String RESET = String.valueOf(ChatFormatting.RESET);
   public static final String YELLOW = String.valueOf(ChatFormatting.YELLOW);
   public static final String BLUE = String.valueOf(ChatFormatting.BLUE);
   public static final String GOLD = String.valueOf(ChatFormatting.GOLD);
   public static final String RED = String.valueOf(ChatFormatting.RED);
   public static final String GREEN = String.valueOf(ChatFormatting.GREEN);
   public static final String STRIKE = String.valueOf(ChatFormatting.STRIKETHROUGH);
   public static final String ITALIC = String.valueOf(ChatFormatting.ITALIC);
   private static final Random rand = new Random();
   public static final String DARK_AQUA = String.valueOf(ChatFormatting.DARK_AQUA);
   public static final String OBFUSCATED = String.valueOf(ChatFormatting.OBFUSCATED);
   public static final String DARK_BLUE = String.valueOf(ChatFormatting.DARK_BLUE);
   public static final String BOLD = String.valueOf(ChatFormatting.BOLD);
   public static final String DARK_PURPLE = String.valueOf(ChatFormatting.DARK_PURPLE);
   public static final String LIGHT_PURPLE = String.valueOf(ChatFormatting.LIGHT_PURPLE);
   public static final String GRAY = String.valueOf(ChatFormatting.GRAY);
   public static final String AQUA = String.valueOf(ChatFormatting.AQUA);
   public static final String BLACK = String.valueOf(ChatFormatting.BLACK);
   public static final String UNDERLINE = String.valueOf(ChatFormatting.UNDERLINE);
   public static final String WHITE = String.valueOf(ChatFormatting.WHITE);

   public static String coloredString(String var0, TextUtil.Color var1) {
      String var2 = var0;
      switch(null.$SwitchMap$me$rebirthclient$api$util$render$TextUtil$Color[var1.ordinal()]) {
         case 1:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.AQUA).append(var0).append(ChatFormatting.RESET));
            boolean var16 = false;
            break;
         case 2:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.WHITE).append(var0).append(ChatFormatting.RESET));
            boolean var15 = false;
            break;
         case 3:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.BLACK).append(var0).append(ChatFormatting.RESET));
            boolean var14 = false;
            break;
         case 4:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_BLUE).append(var0).append(ChatFormatting.RESET));
            boolean var13 = false;
            break;
         case 5:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_GREEN).append(var0).append(ChatFormatting.RESET));
            boolean var12 = false;
            break;
         case 6:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_AQUA).append(var0).append(ChatFormatting.RESET));
            boolean var11 = false;
            break;
         case 7:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_RED).append(var0).append(ChatFormatting.RESET));
            boolean var10 = false;
            break;
         case 8:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_PURPLE).append(var0).append(ChatFormatting.RESET));
            boolean var9 = false;
            break;
         case 9:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.GOLD).append(var0).append(ChatFormatting.RESET));
            boolean var8 = false;
            break;
         case 10:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_GRAY).append(var0).append(ChatFormatting.RESET));
            boolean var7 = false;
            break;
         case 11:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append(var0).append(ChatFormatting.RESET));
            boolean var6 = false;
            break;
         case 12:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.BLUE).append(var0).append(ChatFormatting.RESET));
            boolean var5 = false;
            break;
         case 13:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.RED).append(var0).append(ChatFormatting.RESET));
            boolean var4 = false;
            break;
         case 14:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append(var0).append(ChatFormatting.RESET));
            boolean var3 = false;
            break;
         case 15:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.LIGHT_PURPLE).append(var0).append(ChatFormatting.RESET));
            boolean var10000 = false;
            break;
         case 16:
            var2 = String.valueOf(new StringBuilder().append(ChatFormatting.YELLOW).append(var0).append(ChatFormatting.RESET));
      }

      return var2;
   }

   public static String stripColor(String var0) {
      return var0 != null ? Pattern.compile("(?i)§[0-9A-FK-OR]").matcher(var0).replaceAll("") : "";
   }

   public static String cropMaxLengthMessage(String var0, int var1) {
      String var2 = "";
      if (var0.length() >= 256 - var1) {
         var2 = var0.substring(0, 256 - var1);
      }

      return var2;
   }

   public static enum Color {
      DARK_RED,
      BLUE,
      DARK_GREEN,
      GRAY,
      WHITE,
      DARK_AQUA,
      NONE,
      DARK_BLUE,
      DARK_GRAY,
      GOLD,
      LIGHT_PURPLE,
      GREEN,
      DARK_PURPLE,
      RED,
      BLACK,
      YELLOW,
      AQUA;

      private static final TextUtil.Color[] $VALUES = new TextUtil.Color[]{
         NONE, WHITE, BLACK, DARK_BLUE, DARK_GREEN, DARK_AQUA, DARK_RED, DARK_PURPLE, GOLD, GRAY, DARK_GRAY, BLUE, GREEN, AQUA, RED, LIGHT_PURPLE, YELLOW
      };
   }
}
