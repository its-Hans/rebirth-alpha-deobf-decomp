package me.rebirthclient.api.util.render;

import java.awt.Color;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.impl.client.ClickGui;

public class ColorUtil {
   public static int toHex(int var0, int var1, int var2) {
      return 0xFF000000 | (var0 & 0xFF) << 16 | (var1 & 0xFF) << 8 | var2 & 0xFF;
   }

   public static int toARGB(int var0, int var1, int var2, int var3) {
      return new Color(var0, var1, var2, var3).getRGB();
   }

   public static Color gradientColor(Color var0, Color var1, double var2) {
      if (var2 > 1.0) {
         double var4 = var2 % 1.0;
         int var6 = (int)var2;
         double var10000;
         if (var6 % 2 == 0) {
            var10000 = var4;
            boolean var10001 = false;
         } else {
            var10000 = 1.0 - var4;
         }

         var2 = var10000;
      }

      double var9 = 1.0 - var2;
      int var10 = (int)((double)var0.getRed() * var9 + (double)var1.getRed() * var2);
      int var7 = (int)((double)var0.getGreen() * var9 + (double)var1.getGreen() * var2);
      int var8 = (int)((double)var0.getBlue() * var9 + (double)var1.getBlue() * var2);
      return new Color(var10, var7, var8);
   }

   public static float[] toArray(int var0) {
      return new float[]{
         (float)(var0 >> 16 & 0xFF) / 255.0F, (float)(var0 >> 8 & 0xFF) / 255.0F, (float)(var0 & 0xFF) / 255.0F, (float)(var0 >> 24 & 0xFF) / 255.0F
      };
   }

   public static Color injectAlpha(Color var0, int var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var1);
   }

   public static Color rainbow(int var0) {
      long var10000;
      if (ClickGui.INSTANCE.rainbowSpeed.getValue() == 0) {
         var10000 = System.currentTimeMillis();
         boolean var10001 = false;
      } else {
         var10000 = (long)Managers.COLORS.rainbowProgress;
      }

      double var1 = Math.ceil((double)(var10000 + (long)var0) / 20.0);
      if (ClickGui.INSTANCE.rainbowMode.getValue() == ClickGui.Rainbow.DOUBLE) {
         Color var3 = ClickGui.INSTANCE.color.getValue();
         Color var4 = ClickGui.INSTANCE.secondColor.getValue();
         long var10002;
         if (ClickGui.INSTANCE.rainbowSpeed.getValue() == 0) {
            var10002 = System.currentTimeMillis();
            boolean var10003 = false;
         } else {
            var10002 = (long)Managers.COLORS.rainbowProgress;
         }

         return gradientColor(var3, var4, (double)Math.abs(((float)(var10002 % 2000L) / 1000.0F + 20.0F / (float)(var0 / 15 * 2 + 10) * 2.0F) % 2.0F - 1.0F));
      } else {
         return ClickGui.INSTANCE.rainbowMode.getValue() == ClickGui.Rainbow.PLAIN
            ? pulseColor(ClickGui.INSTANCE.color.getValue(), 50, var0)
            : Color.getHSBColor((float)(var1 % 360.0 / 360.0), ClickGui.INSTANCE.rainbowSaturation.getValue() / 255.0F, 1.0F);
      }
   }

   public static Color interpolate(float var0, Color var1, Color var2) {
      float var3 = (float)var1.getRed() / 255.0F;
      float var4 = (float)var1.getGreen() / 255.0F;
      float var5 = (float)var1.getBlue() / 255.0F;
      float var6 = (float)var1.getAlpha() / 255.0F;
      float var7 = (float)var2.getRed() / 255.0F;
      float var8 = (float)var2.getGreen() / 255.0F;
      float var9 = (float)var2.getBlue() / 255.0F;
      float var10 = (float)var2.getAlpha() / 255.0F;
      float var11 = var3 * var0 + var7 * (1.0F - var0);
      float var12 = var4 * var0 + var8 * (1.0F - var0);
      float var13 = var5 * var0 + var9 * (1.0F - var0);
      float var14 = var6 * var0 + var10 * (1.0F - var0);
      return new Color(var11, var12, var13, var14);
   }

   public static int toRGBA(float var0, float var1, float var2, float var3) {
      return toRGBA((int)(var0 * 255.0F), (int)(var1 * 255.0F), (int)(var2 * 255.0F), (int)(var3 * 255.0F));
   }

   public static Color pulseColor(Color var0, int var1, int var2) {
      float[] var3 = new float[3];
      Color.RGBtoHSB(var0.getRed(), var0.getGreen(), var0.getBlue(), var3);
      boolean var10000 = false;
      float var4 = Math.abs(
         (
                  (float)(System.currentTimeMillis() % 2000L) / Float.intBitsToFloat(Float.floatToIntBits(0.0013786979F) ^ 2127476077)
                     + (float)var1 / (float)var2 * Float.intBitsToFloat(Float.floatToIntBits(0.09192204F) ^ 2109489567)
               )
               % Float.intBitsToFloat(Float.floatToIntBits(0.7858098F) ^ 2135501525)
            - Float.intBitsToFloat(Float.floatToIntBits(6.46708F) ^ 2135880274)
      );
      var4 = Float.intBitsToFloat(Float.floatToIntBits(18.996923F) ^ 2123889075) + Float.intBitsToFloat(Float.floatToIntBits(2.7958195F) ^ 2134044341) * var4;
      var3[2] = var4 % Float.intBitsToFloat(Float.floatToIntBits(0.8992331F) ^ 2137404452);
      return new Color(Color.HSBtoRGB(var3[0], var3[1], var3[2]));
   }

   public static int injectAlpha(int var0, int var1) {
      return toRGBA(new Color(var0).getRed(), new Color(var0).getGreen(), new Color(var0).getBlue(), var1);
   }

   public static int toRGBA(int var0, int var1, int var2, int var3) {
      return (var0 << 16) + (var1 << 8) + var2 + (var3 << 24);
   }

   public static int toRGBA(int var0, int var1, int var2) {
      return toRGBA(var0, var1, var2, 255);
   }

   public static int toRGBA(Color var0) {
      return toRGBA(var0.getRed(), var0.getGreen(), var0.getBlue(), var0.getAlpha());
   }

   public static Color getGradientOffset(Color var0, Color var1, double var2) {
      if (var2 > 1.0) {
         double var4 = var2 % 1.0;
         int var6 = (int)var2;
         double var10000;
         if (var6 % 2 == 0) {
            var10000 = var4;
            boolean var10001 = false;
         } else {
            var10000 = 1.0 - var4;
         }

         var2 = var10000;
      }

      double var9 = 1.0 - var2;
      int var10 = (int)((double)var0.getRed() * var9 + (double)var1.getRed() * var2);
      int var7 = (int)((double)var0.getGreen() * var9 + (double)var1.getGreen() * var2);
      int var8 = (int)((double)var0.getBlue() * var9 + (double)var1.getBlue() * var2);
      return new Color(var10, var7, var8);
   }

   public static class Colors {
      public static final int ORANGE = ColorUtil.toRGBA(255, 128, 0, 255);
      public static final int YELLOW = ColorUtil.toRGBA(255, 255, 0, 255);
      public static final int PURPLE = ColorUtil.toRGBA(163, 73, 163, 255);
      public static final int GREEN = ColorUtil.toRGBA(0, 255, 0, 255);
      public static final int RED = ColorUtil.toRGBA(255, 0, 0, 255);
      public static final int GRAY = ColorUtil.toRGBA(127, 127, 127, 255);
      public static final int BLACK = ColorUtil.toRGBA(0, 0, 0, 255);
      public static final int RAINBOW = Integer.MIN_VALUE;
      public static final int DARK_RED = ColorUtil.toRGBA(64, 0, 0, 255);
      public static final int WHITE = ColorUtil.toRGBA(255, 255, 255, 255);
      public static final int BLUE = ColorUtil.toRGBA(0, 0, 255, 255);
   }
}
