package me.rebirthclient.api.util;

import java.util.Arrays;
import java.util.List;
import me.rebirthclient.mod.modules.impl.combat.CrystalBot;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class CrystalUtil implements Wrapper {
   private static final List<Block> valid = Arrays.asList(Blocks.OBSIDIAN, Blocks.BEDROCK, Blocks.ENDER_CHEST, Blocks.ANVIL);

   public static boolean rayTracePlace(BlockPos var0) {
      if (CrystalBot.getInstance().directionMode.getValue() != CrystalBot.DirectionMode.VANILLA) {
         double var33 = 0.45;
         double var34 = 0.05;
         double var35 = 0.95;
         Vec3d var7 = new Vec3d(mc.player.posX, mc.player.getEntityBoundingBox().minY + (double)mc.player.getEyeHeight(), mc.player.posZ);

         boolean var41;
         for(double var8 = var34; var8 <= var35; var41 = false) {
            for(double var10 = var34; var10 <= var35; var41 = false) {
               for(double var12 = var34; var12 <= var35; var41 = false) {
                  Vec3d var14 = new Vec3d(var0).add(var8, var10, var12);
                  double var15 = var7.distanceTo(var14);
                  if (CrystalBot.getInstance().strictDirection.getValue() && var15 > (double)CrystalBot.getInstance().placeRange.getValue().floatValue()) {
                     var41 = false;
                  } else {
                     double var17 = var14.x - var7.x;
                     double var19 = var14.y - var7.y;
                     double var21 = var14.z - var7.z;
                     double var23 = (double)MathHelper.sqrt(var17 * var17 + var21 * var21);
                     double[] var25 = new double[]{
                        (double)MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2(var21, var17)) - 90.0F),
                        (double)MathHelper.wrapDegrees((float)(-Math.toDegrees(Math.atan2(var19, var23))))
                     };
                     float var26 = MathHelper.cos((float)(-var25[0] * (float) (Math.PI / 180.0) - (float) Math.PI));
                     float var27 = MathHelper.sin((float)(-var25[0] * (float) (Math.PI / 180.0) - (float) Math.PI));
                     float var28 = -MathHelper.cos((float)(-var25[1] * (float) (Math.PI / 180.0)));
                     float var29 = MathHelper.sin((float)(-var25[1] * (float) (Math.PI / 180.0)));
                     Vec3d var30 = new Vec3d((double)(var27 * var28), (double)var29, (double)(var26 * var28));
                     Vec3d var31 = var7.add(var30.x * var15, var30.y * var15, var30.z * var15);
                     RayTraceResult var32 = mc.world.rayTraceBlocks(var7, var31, false, false, false);
                     if (var32 != null && var32.typeOfHit == Type.BLOCK) {
                        if (var32.getBlockPos().equals(var0)) {
                           return true;
                        }

                        var41 = false;
                     }
                  }

                  var12 += var33;
               }

               var10 += var33;
            }

            var8 += var33;
         }

         return false;
      } else {
         for(EnumFacing var4 : EnumFacing.values()) {
            Vec3d var6 = new Vec3d(
               (double)var0.getX() + 0.5 + (double)var4.getDirectionVec().getX() * 0.5,
               (double)var0.getY() + 0.5 + (double)var4.getDirectionVec().getY() * 0.5,
               (double)var0.getZ() + 0.5 + (double)var4.getDirectionVec().getZ() * 0.5
            );
            if (!CrystalBot.getInstance().strictDirection.getValue()
               || !(
                  mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var6)
                     > (double)CrystalBot.getInstance().placeRange.getValue().floatValue()
               )) {
               RayTraceResult var5 = mc.world
                  .rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ), var6, false, true, false);
               if (var5 != null && var5.typeOfHit.equals(Type.BLOCK)) {
                  if (var5.getBlockPos().equals(var0)) {
                     return true;
                  }

                  boolean var10000 = false;
               }
            }

            boolean var36 = false;
         }

         return false;
      }
   }

   public static int ping() {
      if (mc.getConnection() == null) {
         return 50;
      } else if (mc.player == null) {
         return 50;
      } else {
         Minecraft var10000 = mc;

         try {
            return var10000.getConnection().getPlayerInfo(mc.player.getUniqueID()).getResponseTime();
         } catch (NullPointerException var1) {
            return 50;
         }
      }
   }

   public static Vec3d getEntityPosVec(Entity var0, int var1, boolean var2) {
      return var0.getPositionVector().add(getMotionVec(var0, var1, var2));
   }

   public static float calculateDamage(double var0, double var2, double var4, Entity var6) {
      float var7 = 12.0F;
      int var10001;
      if (CrystalBot.predictTicks.getValue() > 0) {
         var10001 = CrystalBot.predictTicks.getValue();
         boolean var10002 = false;
      } else {
         var10001 = 0;
      }

      Vec3d var10 = getEntityPosVec(var6, var10001);
      double var8 = var10.distanceTo(new Vec3d(var0, var2, var4)) / (double)var7;
      Vec3d var11 = new Vec3d(var0, var2, var4);
      double var12 = 0.0;
      Setting var10000 = CrystalBot.terrainIgnore;

      label35: {
         try {
            if (var10000.getValue()) {
               AxisAlignedBB var23;
               if (CrystalBot.predictTicks.getValue() > 0) {
                  var23 = var6.getEntityBoundingBox().offset(getMotionVec(var6, CrystalBot.predictTicks.getValue()));
                  boolean var24 = false;
               } else {
                  var23 = var6.getEntityBoundingBox();
               }

               var12 = (double)getBlockDensity(var11, var23);
               boolean var20 = false;
            } else {
               World var21 = var6.world;
               AxisAlignedBB var25;
               if (CrystalBot.predictTicks.getValue() > 0) {
                  var25 = var6.getEntityBoundingBox().offset(getMotionVec(var6, CrystalBot.predictTicks.getValue()));
                  boolean var10003 = false;
               } else {
                  var25 = var6.getEntityBoundingBox();
               }

               var12 = (double)var21.getBlockDensity(var11, var25);
            }
         } catch (Exception var19) {
            break label35;
         }

         boolean var22 = false;
      }

      double var14 = (1.0 - var8) * var12;
      float var16 = (float)((int)((var14 * var14 + var14) / 2.0 * 7.0 * (double)var7 + 1.0));
      double var17 = 1.0;
      if (var6 instanceof EntityLivingBase) {
         var17 = (double)DamageUtil.getBlastReduction(
            (EntityLivingBase)var6, DamageUtil.getDamageMultiplied(var16), new Explosion(mc.world, mc.player, var0, var2, var4, 6.0F, false, true)
         );
      }

      return (float)var17;
   }

   public static float calculateDamage(Vec3d var0, Entity var1) {
      return calculateDamage(var0.x, var0.y, var0.z, var1);
   }

   public static float getBlockDensity(Vec3d var0, AxisAlignedBB var1) {
      double var2 = 1.0 / ((var1.maxX - var1.minX) * 2.0 + 1.0);
      double var4 = 1.0 / ((var1.maxY - var1.minY) * 2.0 + 1.0);
      double var6 = 1.0 / ((var1.maxZ - var1.minZ) * 2.0 + 1.0);
      double var8 = (1.0 - Math.floor(1.0 / var2) * var2) / 2.0;
      double var10 = (1.0 - Math.floor(1.0 / var6) * var6) / 2.0;
      if (var2 >= 0.0 && var4 >= 0.0 && var6 >= 0.0) {
         int var12 = 0;
         int var13 = 0;

         boolean var24;
         for(float var14 = 0.0F; var14 <= 0.5F; var24 = false) {
            for(float var15 = 0.0F; var15 <= 0.5F; var24 = false) {
               for(float var16 = 0.0F; var16 <= 0.5F; var24 = false) {
                  double var17 = var1.minX + (var1.maxX - var1.minX) * (double)var14;
                  double var19 = var1.minY + (var1.maxY - var1.minY) * (double)var15;
                  double var21 = var1.minZ + (var1.maxZ - var1.minZ) * (double)var16;
                  if (rayTraceBlocks(new Vec3d(var17 + var8, var19, var21 + var10), var0) == null) {
                     ++var12;
                  }

                  ++var13;
                  var16 = (float)((double)var16 + var6);
               }

               var15 = (float)((double)var15 + var4);
            }

            var14 = (float)((double)var14 + var2);
         }

         return (float)var12 / (float)var13;
      } else {
         return 0.0F;
      }
   }

   // $QF: Handled exception range with multiple entry points by splitting it
   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public static float calculateDamage(double var0, double var2, double var4, Entity var6, int var7, boolean var8, boolean var9) {
      float var10;
      double var11;
      double var15;
      label46: {
         var10 = 12.0F;
         Vec3d var13 = getEntityPosVec(var6, Math.max(var7, 0), var8);
         var11 = var13.distanceTo(new Vec3d(var0, var2, var4)) / (double)var10;
         Vec3d var14 = new Vec3d(var0, var2, var4);
         var15 = 0.0;
         if (var9) {
            Vec3d var10000 = var14;
            AxisAlignedBB var30;
            if (var7 > 0) {
               Entity var10001 = var6;

               try {
                  var30 = var10001.getEntityBoundingBox().offset(getMotionVec(var6, var7, var8));
                  boolean var10002 = false;
               } catch (Exception var24) {
                  boolean var29 = false;
                  break label46;
               }
            } else {
               try {
                  var30 = var6.getEntityBoundingBox();
               } catch (Exception var23) {
                  boolean var31 = false;
                  break label46;
               }
            }

            try {
               var15 = (double)getBlockDensity(var10000, var30);
               boolean var26 = false;
            } catch (Exception var22) {
               boolean var32 = false;
               break label46;
            }
         } else {
            try {
               World var27 = var6.world;
               AxisAlignedBB var34;
               if (var7 > 0) {
                  var34 = var6.getEntityBoundingBox().offset(getMotionVec(var6, var7, var8));
                  boolean var10003 = false;
               } else {
                  var34 = var6.getEntityBoundingBox();
               }

               var15 = (double)var27.getBlockDensity(var14, var34);
            } catch (Exception var25) {
               boolean var33 = false;
               break label46;
            }
         }

         boolean var28 = false;
      }

      double var17 = (1.0 - var11) * var15;
      float var19 = (float)((int)((var17 * var17 + var17) / 2.0 * 7.0 * (double)var10 + 1.0));
      double var20 = 1.0;
      if (var6 instanceof EntityLivingBase) {
         var20 = (double)DamageUtil.getBlastReduction(
            (EntityLivingBase)var6, DamageUtil.getDamageMultiplied(var19), new Explosion(mc.world, mc.player, var0, var2, var4, 6.0F, false, true)
         );
      }

      return (float)var20;
   }

   public static RayTraceResult rayTraceBlocks(Vec3d var0, Vec3d var1) {
      return rayTraceBlocks(var0, var1, false, false, false);
   }

   public static int getCrystalSlot() {
      int var0 = -1;
      if (Wrapper.mc.player.getHeldItemMainhand().getItem() == Items.END_CRYSTAL) {
         var0 = Wrapper.mc.player.inventory.currentItem;
      }

      if (var0 == -1) {
         for(int var1 = 0; var1 < 9; ++var1) {
            if (Wrapper.mc.player.inventory.getStackInSlot(var1).getItem() == Items.END_CRYSTAL) {
               var0 = var1;
               boolean var3 = false;
               break;
            }

            boolean var10000 = false;
            var10000 = false;
         }
      }

      return var0;
   }

   public static float calculateDamage(BlockPos var0, Entity var1, int var2, boolean var3, boolean var4) {
      return calculateDamage((double)var0.getX() + 0.5, (double)(var0.getY() + 1), (double)var0.getZ() + 0.5, var1, var2, var3, var4);
   }

   public static boolean isVisible(Vec3d var0) {
      Vec3d var1 = new Vec3d(mc.player.posX, mc.player.getEntityBoundingBox().minY + (double)mc.player.getEyeHeight(), mc.player.posZ);
      boolean var10000;
      if (mc.world.rayTraceBlocks(var1, var0) == null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static float calculateDamage(EntityEnderCrystal var0, Entity var1) {
      return calculateDamage(var0.posX, var0.posY, var0.posZ, var1);
   }

   public static boolean rayTraceBreak(double var0, double var2, double var4) {
      if (mc.world
            .rayTraceBlocks(
               new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
               new Vec3d(var0, var2 + 1.8, var4),
               false,
               true,
               false
            )
         == null) {
         return true;
      } else if (mc.world
            .rayTraceBlocks(
               new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
               new Vec3d(var0, var2 + 1.5, var4),
               false,
               true,
               false
            )
         == null) {
         return true;
      } else {
         boolean var10000;
         if (mc.world
               .rayTraceBlocks(
                  new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
                  new Vec3d(var0, var2, var4),
                  false,
                  true,
                  false
               )
            == null) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static int getSwordSlot() {
      int var0 = -1;
      if (Wrapper.mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_SWORD) {
         var0 = Wrapper.mc.player.inventory.currentItem;
      }

      if (var0 == -1) {
         for(int var1 = 0; var1 < 9; ++var1) {
            if (Wrapper.mc.player.inventory.getStackInSlot(var1).getItem() == Items.DIAMOND_SWORD) {
               var0 = var1;
               boolean var3 = false;
               break;
            }

            boolean var10000 = false;
            var10000 = false;
         }
      }

      return var0;
   }

   public static Vec3d getMotionVec(Entity var0, int var1) {
      double var2 = var0.posX - var0.prevPosX;
      double var4 = var0.posZ - var0.prevPosZ;
      double var6 = 0.0;
      double var8 = 0.0;
      if (CrystalBot.collision.getValue()) {
         for(int var10 = 1;
            var10 <= var1
               && mc.world.getBlockState(new BlockPos(var0.posX + var2 * (double)var10, var0.posY, var0.posZ + var4 * (double)var10)).getBlock() instanceof BlockAir;
            ++var10
         ) {
            var6 = var2 * (double)var10;
            var8 = var4 * (double)var10;
            boolean var10000 = false;
         }

         boolean var11 = false;
      } else {
         var6 = var2 * (double)var1;
         var8 = var4 * (double)var1;
      }

      return new Vec3d(var6, 0.0, var8);
   }

   public static Vec3d getMotionVec(Entity var0, int var1, boolean var2) {
      double var3 = var0.posX - var0.prevPosX;
      double var5 = var0.posZ - var0.prevPosZ;
      double var7 = 0.0;
      double var9 = 0.0;
      if (var2) {
         for(int var11 = 1;
            var11 <= var1
               && mc.world.getBlockState(new BlockPos(var0.posX + var3 * (double)var11, var0.posY, var0.posZ + var5 * (double)var11)).getBlock() instanceof BlockAir;
            ++var11
         ) {
            var7 = var3 * (double)var11;
            var9 = var5 * (double)var11;
            boolean var10000 = false;
         }

         boolean var12 = false;
      } else {
         var7 = var3 * (double)var1;
         var9 = var5 * (double)var1;
      }

      return new Vec3d(var7, 0.0, var9);
   }

   public static RayTraceResult rayTraceBlocks(Vec3d var0, Vec3d var1, boolean var2, boolean var3, boolean var4) {
      if (Double.isNaN(var0.x) || Double.isNaN(var0.y) || Double.isNaN(var0.z)) {
         return null;
      } else if (!Double.isNaN(var1.x) && !Double.isNaN(var1.y) && !Double.isNaN(var1.z)) {
         int var5 = MathHelper.floor(var1.x);
         int var6 = MathHelper.floor(var1.y);
         int var7 = MathHelper.floor(var1.z);
         int var8 = MathHelper.floor(var0.x);
         int var9 = MathHelper.floor(var0.y);
         int var10 = MathHelper.floor(var0.z);
         BlockPos var11 = new BlockPos(var8, var9, var10);
         IBlockState var12 = mc.world.getBlockState(var11);
         Block var13 = var12.getBlock();
         if (!valid.contains(var13)) {
            var13 = Blocks.AIR;
            var12 = Blocks.AIR.getBlockState().getBaseState();
         }

         if ((!var3 || var12.getCollisionBoundingBox(mc.world, var11) != Block.NULL_AABB) && var13.canCollideCheck(var12, var2)) {
            return var12.collisionRayTrace(mc.world, var11, var0, var1);
         } else {
            RayTraceResult var14 = null;

            int var55;
            for(int var15 = 200; var15-- >= 0; var55 = 0) {
               if (Double.isNaN(var0.x) || Double.isNaN(var0.y) || Double.isNaN(var0.z)) {
                  return null;
               }

               if (var8 == var5 && var9 == var6 && var10 == var7) {
                  RayTraceResult var56;
                  if (var4) {
                     var56 = var14;
                     boolean var63 = false;
                  } else {
                     var56 = null;
                  }

                  return var56;
               }

               boolean var16 = true;
               boolean var17 = true;
               boolean var18 = true;
               double var19 = 999.0;
               double var21 = 999.0;
               double var23 = 999.0;
               if (var5 > var8) {
                  var19 = (double)var8 + 1.0;
                  var55 = (boolean)0;
               } else if (var5 < var8) {
                  var19 = (double)var8 + 0.0;
                  var55 = (boolean)0;
               } else {
                  var16 = false;
               }

               if (var6 > var9) {
                  var21 = (double)var9 + 1.0;
                  var55 = (boolean)0;
               } else if (var6 < var9) {
                  var21 = (double)var9 + 0.0;
                  var55 = (boolean)0;
               } else {
                  var17 = false;
               }

               if (var7 > var10) {
                  var23 = (double)var10 + 1.0;
                  var55 = (boolean)0;
               } else if (var7 < var10) {
                  var23 = (double)var10 + 0.0;
                  var55 = (boolean)0;
               } else {
                  var18 = false;
               }

               double var25 = 999.0;
               double var27 = 999.0;
               double var29 = 999.0;
               double var31 = var1.x - var0.x;
               double var33 = var1.y - var0.y;
               double var35 = var1.z - var0.z;
               if (var16) {
                  var25 = (var19 - var0.x) / var31;
               }

               if (var17) {
                  var27 = (var21 - var0.y) / var33;
               }

               if (var18) {
                  var29 = (var23 - var0.z) / var35;
               }

               if (var25 == -0.0) {
                  var25 = -1.0E-4;
               }

               if (var27 == -0.0) {
                  var27 = -1.0E-4;
               }

               if (var29 == -0.0) {
                  var29 = -1.0E-4;
               }

               EnumFacing var37;
               if (var25 < var27 && var25 < var29) {
                  EnumFacing var50;
                  if (var5 > var8) {
                     var50 = EnumFacing.WEST;
                     boolean var59 = false;
                  } else {
                     var50 = EnumFacing.EAST;
                  }

                  var37 = var50;
                  var0 = new Vec3d(var19, var0.y + var33 * var25, var0.z + var35 * var25);
                  var55 = (boolean)0;
               } else if (var27 < var29) {
                  EnumFacing var47;
                  if (var6 > var9) {
                     var47 = EnumFacing.DOWN;
                     boolean var10001 = false;
                  } else {
                     var47 = EnumFacing.UP;
                  }

                  var37 = var47;
                  var0 = new Vec3d(var0.x + var31 * var27, var21, var0.z + var35 * var27);
                  var55 = (boolean)0;
               } else {
                  EnumFacing var49;
                  if (var7 > var10) {
                     var49 = EnumFacing.NORTH;
                     boolean var58 = false;
                  } else {
                     var49 = EnumFacing.SOUTH;
                  }

                  var37 = var49;
                  var0 = new Vec3d(var0.x + var31 * var29, var0.y + var33 * var29, var23);
               }

               var55 = MathHelper.floor(var0.x);
               byte var60;
               if (var37 == EnumFacing.EAST) {
                  var60 = 1;
                  boolean var10002 = false;
               } else {
                  var60 = 0;
               }

               var8 = var55 - var60;
               var55 = MathHelper.floor(var0.y);
               if (var37 == EnumFacing.UP) {
                  var60 = 1;
                  boolean var65 = false;
               } else {
                  var60 = 0;
               }

               var9 = var55 - var60;
               var55 = MathHelper.floor(var0.z);
               if (var37 == EnumFacing.SOUTH) {
                  var60 = 1;
                  boolean var66 = false;
               } else {
                  var60 = 0;
               }

               var10 = var55 - var60;
               var11 = new BlockPos(var8, var9, var10);
               IBlockState var38 = mc.world.getBlockState(var11);
               Block var39 = var38.getBlock();
               if (!valid.contains(var39)) {
                  var39 = Blocks.AIR;
                  var38 = Blocks.AIR.getBlockState().getBaseState();
               }

               if (!var3 || var38.getMaterial() == Material.PORTAL || var38.getCollisionBoundingBox(mc.world, var11) != Block.NULL_AABB) {
                  if (var39.canCollideCheck(var38, var2)) {
                     return var38.collisionRayTrace(mc.world, var11, var0, var1);
                  }

                  var14 = new RayTraceResult(Type.MISS, var0, var37, var11);
               }
            }

            RayTraceResult var57;
            if (var4) {
               var57 = var14;
               boolean var64 = false;
            } else {
               var57 = null;
            }

            return var57;
         }
      } else {
         return null;
      }
   }

   public static float calculateDamage(BlockPos var0, Entity var1) {
      return calculateDamage((double)var0.getX() + 0.5, (double)(var0.getY() + 1), (double)var0.getZ() + 0.5, var1);
   }

   public static Vec3d getEntityPosVec(Entity var0, int var1) {
      return var0.getPositionVector().add(getMotionVec(var0, var1));
   }

   public static float calculateDamage(EntityEnderCrystal var0, Entity var1, int var2, boolean var3, boolean var4) {
      return calculateDamage(var0.posX, var0.posY, var0.posZ, var1, var2, var3, var4);
   }
}
