package me.rebirthclient.api.util;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class PositionUtil implements Wrapper {
   private static boolean inLiquid(int var0) {
      boolean var10000;
      if (findState(BlockLiquid.class, var0) != null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static BlockPos fromBB(AxisAlignedBB var0) {
      return new BlockPos((var0.minX + var0.maxX) / 2.0, (var0.minY + var0.maxY) / 2.0, (var0.minZ + var0.maxZ) / 2.0);
   }

   public static boolean intersects(AxisAlignedBB var0, BlockPos var1) {
      return var0.intersects(
         (double)var1.getX(), (double)var1.getY(), (double)var1.getZ(), (double)(var1.getX() + 1), (double)(var1.getY() + 1), (double)(var1.getZ() + 1)
      );
   }

   public static Entity getPositionEntity() {
      EntityPlayerSP var0 = mc.player;
      Object var10000;
      if (var0 == null) {
         var10000 = null;
         boolean var10001 = false;
      } else {
         Entity var1 = var0.getRidingEntity();
         if (var1 != null && !(var1 instanceof EntityBoat)) {
            var10000 = var1;
            boolean var2 = false;
         } else {
            var10000 = var0;
         }
      }

      return (Entity)var10000;
   }

   public static BlockPos getPosition(Entity var0) {
      return getPosition(var0, 0.0);
   }

   private static IBlockState findState(Class<? extends Block> var0, int var1) {
      Entity var2 = requirePositionEntity();
      int var3 = MathHelper.floor(var2.getEntityBoundingBox().minX);
      int var4 = MathHelper.floor(var2.getEntityBoundingBox().minZ);
      int var5 = MathHelper.ceil(var2.getEntityBoundingBox().maxX);
      int var6 = MathHelper.ceil(var2.getEntityBoundingBox().maxZ);

      for(int var7 = var3; var7 < var5; ++var7) {
         for(int var8 = var4; var8 < var6; ++var8) {
            IBlockState var9 = mc.world.getBlockState(new BlockPos(var7, var1, var8));
            if (var0.isInstance(var9.getBlock())) {
               return var9;
            }

            boolean var10000 = false;
         }

         boolean var10 = false;
      }

      return null;
   }

   public static boolean isMovementBlocked() {
      IBlockState var0 = findState(Block.class, MathHelper.floor(mc.player.getEntityBoundingBox().minY - 0.01));
      boolean var10000;
      if (var0 != null && var0.getMaterial().blocksMovement()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static Vec3d getEyePos(Entity var0) {
      return new Vec3d(var0.posX, getEyeHeight(var0), var0.posZ);
   }

   public static Vec3d getEyePos() {
      return getEyePos(mc.player);
   }

   public static boolean isAbove(BlockPos var0) {
      boolean var10000;
      if (mc.player.getEntityBoundingBox().minY >= (double)var0.getY()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static BlockPos getPosition(Entity var0, double var1) {
      double var3 = var0.posY + var1;
      if (var0.posY - Math.floor(var0.posY) > 0.5) {
         var3 = Math.ceil(var0.posY);
      }

      return new BlockPos(var0.posX, var3, var0.posZ);
   }

   public static boolean inLiquid(boolean var0) {
      double var10000 = requirePositionEntity().getEntityBoundingBox().minY;
      double var10001;
      if (var0) {
         var10001 = 0.03;
         boolean var10002 = false;
      } else {
         var10001 = 0.2;
      }

      return inLiquid(MathHelper.floor(var10000 - var10001));
   }

   public static boolean inLiquid() {
      return inLiquid(MathHelper.floor(requirePositionEntity().getEntityBoundingBox().minY + 0.01));
   }

   public static boolean isBoxColliding() {
      boolean var10000;
      if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(0.0, 0.21, 0.0)).size() > 0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static Set<BlockPos> getBlockedPositions(Entity var0) {
      return getBlockedPositions(var0.getEntityBoundingBox());
   }

   public static Set<BlockPos> getBlockedPositions(AxisAlignedBB var0) {
      return getBlockedPositions(var0, 0.5);
   }

   public static double getEyeHeight() {
      return getEyeHeight(mc.player);
   }

   public static Entity requirePositionEntity() {
      return Objects.requireNonNull(getPositionEntity());
   }

   public static double getEyeHeight(Entity var0) {
      return var0.posY + (double)var0.getEyeHeight();
   }

   public static Set<BlockPos> getBlockedPositions(AxisAlignedBB var0, double var1) {
      HashSet var3 = new HashSet();
      double var4 = var0.minY;
      if (var0.minY - Math.floor(var0.minY) > var1) {
         var4 = Math.ceil(var0.minY);
      }

      var3.add(new BlockPos(var0.maxX, var4, var0.maxZ));
      boolean var10000 = false;
      var3.add(new BlockPos(var0.minX, var4, var0.minZ));
      var10000 = false;
      var3.add(new BlockPos(var0.maxX, var4, var0.minZ));
      var10000 = false;
      var3.add(new BlockPos(var0.minX, var4, var0.maxZ));
      var10000 = false;
      return var3;
   }
}
