package me.rebirthclient.api.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.util.UUIDTypeAdapter;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.UUID;
import me.rebirthclient.mod.commands.Command;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;

public class ProfileUtil implements Wrapper {
   public static UUID getUUIDFromName(String var0) {
      ProfileUtil.UUIDFinder var10000 = new ProfileUtil.UUIDFinder;
      ProfileUtil.UUIDFinder var10001 = var10000;
      String var10002 = var0;

      try {
         var10001./* $QF: Unable to resugar constructor */<init>(var10002);
         ProfileUtil.UUIDFinder var1 = var10000;
         Thread var2 = new Thread(var1);
         var2.start();
         var2.join();
         return var1.getUUID();
      } catch (Exception var3) {
         return null;
      }
   }

   public static String requestIDs(String var0) {
      String var1 = "https://api.mojang.com/profiles/minecraft";
      URL var10000 = new URL;
      URL var10001 = var10000;
      String var10002 = var1;

      try {
         var10001./* $QF: Unable to resugar constructor */<init>(var10002);
         URL var2 = var10000;
         HttpURLConnection var3 = (HttpURLConnection)var2.openConnection();
         var3.setConnectTimeout(5000);
         var3.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
         var3.setDoOutput(true);
         var3.setDoInput(true);
         var3.setRequestMethod("POST");
         OutputStream var4 = var3.getOutputStream();
         var4.write(var0.getBytes(StandardCharsets.UTF_8));
         var4.close();
         BufferedInputStream var5 = new BufferedInputStream(var3.getInputStream());
         String var6 = getStringFromStream(var5);
         var5.close();
         var3.disconnect();
         return var6;
      } catch (Exception var7) {
         return null;
      }
   }

   public static String getStringFromStream(InputStream var0) {
      Scanner var1 = new Scanner(var0).useDelimiter("\\A");
      String var10000;
      if (var1.hasNext()) {
         var10000 = var1.next();
         boolean var10001 = false;
      } else {
         var10000 = "/";
      }

      return var10000;
   }

   public static class UUIDFinder implements Runnable {
      private final String name;
      private UUID uuid;
      static final boolean $assertionsDisabled;

      public UUIDFinder(String var1) {
         this.name = var1;
      }

      private boolean lambda$run$0(NetworkPlayerInfo var1) {
         return Integer.valueOf(this.name.toUpperCase().hashCode()).equals(var1.getGameProfile().getName().toUpperCase().hashCode());
      }

      static {
         boolean var10000;
         if (!ProfileUtil.class.desiredAssertionStatus()) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         $assertionsDisabled = var10000;
      }

      @Override
      public void run() {
         ArrayList var10000 = new ArrayList;
         ArrayList var10001 = var10000;
         Minecraft var10002 = Wrapper.mc;

         NetworkPlayerInfo var1;
         label43: {
            try {
               var10001./* $QF: Unable to resugar constructor */<init>(
                  ((NetHandlerPlayClient)Objects.requireNonNull(var10002.getConnection())).getPlayerInfoMap()
               );
               ArrayList var2 = var10000;
               var1 = (NetworkPlayerInfo)var2.stream().filter(this::lambda$run$0).findFirst().orElse(null);
               if (!$assertionsDisabled && var1 == null) {
                  throw new AssertionError();
               }

               this.uuid = var1.getGameProfile().getId();
            } catch (Exception var6) {
               var1 = null;
               break label43;
            }

            boolean var8 = false;
         }

         if (var1 == null) {
            Command.sendMessage("Player isn't online. Looking up UUID..");
            String var7 = ProfileUtil.requestIDs(String.valueOf(new StringBuilder().append("[\"").append(this.name).append("\"]")));
            if (var7 != null && !var7.isEmpty()) {
               JsonElement var3 = new JsonParser().parse(var7);
               if (var3.getAsJsonArray().size() == 0) {
                  Command.sendMessage("Couldn't find player ID. (1)");
                  boolean var10 = false;
               } else {
                  JsonElement var11 = var3;

                  try {
                     String var4 = var11.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
                     this.uuid = UUIDTypeAdapter.fromString(var4);
                  } catch (Exception var5) {
                     var5.printStackTrace();
                     Command.sendMessage("Couldn't find player ID. (2)");
                     return;
                  }

                  boolean var12 = false;
               }
            } else {
               Command.sendMessage("Couldn't find player ID. Are you connected to the internet? (0)");
               boolean var9 = false;
            }
         }
      }

      public String getName() {
         return this.name;
      }

      public UUID getUUID() {
         return this.uuid;
      }
   }
}
