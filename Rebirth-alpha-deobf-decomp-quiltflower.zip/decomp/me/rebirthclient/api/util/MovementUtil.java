package me.rebirthclient.api.util;

import java.util.Objects;
import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.modules.impl.movement.InventoryMove;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.input.Keyboard;

public class MovementUtil implements Wrapper {
   public static double[] strafe(double var0) {
      return strafe(mc.player, var0);
   }

   public static double[] directionSpeed(double var0) {
      float var2 = MathUtil.mc.player.movementInput.moveForward;
      float var3 = MathUtil.mc.player.movementInput.moveStrafe;
      float var4 = MathUtil.mc.player.prevRotationYaw + (MathUtil.mc.player.rotationYaw - MathUtil.mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
      if (var2 != 0.0F) {
         if (var3 > 0.0F) {
            byte var10001;
            if (var2 > 0.0F) {
               var10001 = -45;
               boolean var10002 = false;
            } else {
               var10001 = 45;
            }

            var4 += (float)var10001;
            boolean var10000 = false;
         } else if (var3 < 0.0F) {
            byte var14;
            if (var2 > 0.0F) {
               var14 = 45;
               boolean var15 = false;
            } else {
               var14 = -45;
            }

            var4 += (float)var14;
         }

         var3 = 0.0F;
         if (var2 > 0.0F) {
            var2 = 1.0F;
            boolean var13 = false;
         } else if (var2 < 0.0F) {
            var2 = -1.0F;
         }
      }

      double var5 = Math.sin(Math.toRadians((double)(var4 + 90.0F)));
      double var7 = Math.cos(Math.toRadians((double)(var4 + 90.0F)));
      double var9 = (double)var2 * var0 * var7 + (double)var3 * var0 * var5;
      double var11 = (double)var2 * var0 * var5 - (double)var3 * var0 * var7;
      return new double[]{var9, var11};
   }

   public static void setMoveSpeed(double var0) {
      double var2 = (double)mc.player.movementInput.moveForward;
      double var4 = (double)mc.player.movementInput.moveStrafe;
      float var6 = mc.player.rotationYaw;
      if (var2 == 0.0 && var4 == 0.0) {
         mc.player.motionX = 0.0;
         mc.player.motionZ = 0.0;
         boolean var8 = false;
      } else {
         if (var2 != 0.0) {
            if (var4 > 0.0) {
               byte var10001;
               if (var2 > 0.0) {
                  var10001 = -45;
                  boolean var10002 = false;
               } else {
                  var10001 = 45;
               }

               var6 += (float)var10001;
               boolean var10000 = false;
            } else if (var4 < 0.0) {
               byte var9;
               if (var2 > 0.0) {
                  var9 = 45;
                  boolean var10 = false;
               } else {
                  var9 = -45;
               }

               var6 += (float)var9;
            }

            var4 = 0.0;
            if (var2 > 0.0) {
               var2 = 1.0;
               boolean var7 = false;
            } else if (var2 < 0.0) {
               var2 = -1.0;
            }
         }

         mc.player.motionX = var2 * var0 * -Math.sin(Math.toRadians((double)var6)) + var4 * var0 * Math.cos(Math.toRadians((double)var6));
         mc.player.motionZ = var2 * var0 * Math.cos(Math.toRadians((double)var6)) - var4 * var0 * -Math.sin(Math.toRadians((double)var6));
      }
   }

   public static boolean isJumping() {
      boolean var10000;
      if (!mc.gameSettings.keyBindJump.isKeyDown()
         && (!InventoryMove.INSTANCE.isOn() || !Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()) || mc.currentScreen instanceof GuiChat)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static void strafe(MoveEvent var0, double var1) {
      if (isMoving()) {
         double[] var3 = strafe(var1);
         var0.setX(var3[0]);
         var0.setZ(var3[1]);
         boolean var10000 = false;
      } else {
         var0.setX(0.0);
         var0.setZ(0.0);
      }
   }

   public static double getDistance3D() {
      double var0 = mc.player.posX - mc.player.prevPosX;
      double var2 = mc.player.posY - mc.player.prevPosY;
      double var4 = mc.player.posZ - mc.player.prevPosZ;
      return Math.sqrt(var0 * var0 + var2 * var2 + var4 * var4);
   }

   public static double getJumpSpeed() {
      double var0 = 0.0;
      if (mc.player.isPotionActive(MobEffects.JUMP_BOOST)) {
         int var2 = mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier();
         var0 += (double)(var2 + 1) * 0.1;
      }

      return var0;
   }

   public static boolean isMoving() {
      boolean var10000;
      if ((double)mc.player.moveForward == 0.0 && (double)mc.player.moveStrafing == 0.0) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean noMovementKeys() {
      boolean var10000;
      if (!mc.player.movementInput.forwardKeyDown
         && !mc.player.movementInput.backKeyDown
         && !mc.player.movementInput.rightKeyDown
         && !mc.player.movementInput.leftKeyDown) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static boolean isInMovementDirection(double var0, double var2, double var4) {
      if (mc.player.motionX == 0.0 && mc.player.motionZ == 0.0) {
         return true;
      } else {
         BlockPos var6 = new BlockPos(mc.player).add(mc.player.motionX * 10000.0, 0.0, mc.player.motionZ * 10000.0);
         BlockPos var7 = new BlockPos(mc.player).add(mc.player.motionX * -10000.0, 0.0, mc.player.motionY * -10000.0);
         boolean var10000;
         if (var6.distanceSq(var0, var2, var4) < var7.distanceSq(var0, var2, var4)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public static double getSpeed(boolean var0) {
      double var1 = 0.2873;
      if (mc.player.isPotionActive(MobEffects.SPEED)) {
         int var3 = ((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SPEED))).getAmplifier();
         var1 *= 1.0 + 0.2 * (double)(var3 + 1);
      }

      if (var0 && mc.player.isPotionActive(MobEffects.SLOWNESS)) {
         int var4 = ((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SLOWNESS))).getAmplifier();
         var1 /= 1.0 + 0.2 * (double)(var4 + 1);
      }

      if (SneakManager.isSneaking) {
         var1 /= 5.0;
      }

      return var1;
   }

   public static double getSpeed() {
      return getSpeed(false);
   }

   public static double[] strafe(Entity var0, MovementInput var1, double var2) {
      float var4 = var1.moveForward;
      float var5 = var1.moveStrafe;
      float var6 = var0.prevRotationYaw + (var0.rotationYaw - var0.prevRotationYaw) * mc.getRenderPartialTicks();
      if (var4 != 0.0F) {
         if (var5 > 0.0F) {
            byte var10001;
            if (var4 > 0.0F) {
               var10001 = -45;
               boolean var10002 = false;
            } else {
               var10001 = 45;
            }

            var6 += (float)var10001;
            boolean var10000 = false;
         } else if (var5 < 0.0F) {
            byte var12;
            if (var4 > 0.0F) {
               var12 = 45;
               boolean var13 = false;
            } else {
               var12 = -45;
            }

            var6 += (float)var12;
         }

         var5 = 0.0F;
         if (var4 > 0.0F) {
            var4 = 1.0F;
            boolean var11 = false;
         } else if (var4 < 0.0F) {
            var4 = -1.0F;
         }
      }

      double var7 = (double)var4 * var2 * -Math.sin(Math.toRadians((double)var6)) + (double)var5 * var2 * Math.cos(Math.toRadians((double)var6));
      double var9 = (double)var4 * var2 * Math.cos(Math.toRadians((double)var6)) - (double)var5 * var2 * -Math.sin(Math.toRadians((double)var6));
      return new double[]{var7, var9};
   }

   public static double getSpeed(boolean var0, double var1) {
      if (mc.player.isPotionActive(MobEffects.SPEED)) {
         int var3 = ((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SPEED))).getAmplifier();
         var1 *= 1.0 + 0.2 * (double)(var3 + 1);
      }

      if (var0 && mc.player.isPotionActive(MobEffects.SLOWNESS)) {
         int var4 = ((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SLOWNESS))).getAmplifier();
         var1 /= 1.0 + 0.2 * (double)(var4 + 1);
      }

      if (SneakManager.isSneaking) {
         var1 /= 5.0;
      }

      return var1;
   }

   public static double getDistance2D() {
      double var0 = mc.player.posX - mc.player.prevPosX;
      double var2 = mc.player.posZ - mc.player.prevPosZ;
      return Math.sqrt(var0 * var0 + var2 * var2);
   }

   public static double[] strafe(Entity var0, double var1) {
      return strafe(var0, mc.player.movementInput, var1);
   }

   public static boolean anyMovementKeys() {
      boolean var10000;
      if (!mc.player.movementInput.forwardKeyDown
         && !mc.player.movementInput.backKeyDown
         && !mc.player.movementInput.leftKeyDown
         && !mc.player.movementInput.rightKeyDown
         && !mc.player.movementInput.jump
         && !mc.player.movementInput.sneak) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static MovementInput inverse(Entity var0, double var1) {
      MovementInput var3 = new MovementInput();
      var3.sneak = var0.isSneaking();

      boolean var15;
      for(float var4 = -1.0F; var4 <= 1.0F; var15 = false) {
         float var5 = -1.0F;

         label41: {
            while(true) {
               if (!(var5 <= 1.0F)) {
                  break label41;
               }

               MovementInput var6 = new MovementInput();
               var6.moveForward = var4;
               var6.moveStrafe = var5;
               var6.sneak = var0.isSneaking();
               double[] var7 = strafe(var0, var6, var1);
               if (var0.isSneaking()) {
                  var7[0] *= 0.3F;
                  var7[1] *= 0.3F;
               }

               label37: {
                  double var8 = var7[0];
                  double var10 = var7[1];
                  if (var8 < 0.0) {
                     if (!(var0.motionX <= var8)) {
                        break label37;
                     }

                     var15 = false;
                  } else if (!(var0.motionX >= var8)) {
                     break label37;
                  }

                  if (var10 < 0.0) {
                     if (var0.motionZ <= var10) {
                        var15 = false;
                        break;
                     }
                  } else if (var0.motionZ >= var10) {
                     break;
                  }
               }

               ++var5;
               var15 = false;
            }

            var3.moveForward = var4;
            var3.moveStrafe = var5;
            var15 = false;
         }

         ++var4;
      }

      return var3;
   }
}
