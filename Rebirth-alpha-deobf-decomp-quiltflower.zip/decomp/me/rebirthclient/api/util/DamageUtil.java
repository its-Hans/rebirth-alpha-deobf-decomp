package me.rebirthclient.api.util;

import java.util.function.BiPredicate;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.MutableBlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class DamageUtil implements Wrapper {
   private static RayTraceResult rayTraceBlocks(World var0, Vec3d var1, Vec3d var2, MutableBlockPos var3, BiPredicate<BlockPos, IBlockState> var4) {
      if (!Double.isNaN(var1.x) && !Double.isNaN(var1.y) && !Double.isNaN(var1.z) && !Double.isNaN(var2.x) && !Double.isNaN(var2.y) && !Double.isNaN(var2.z)) {
         int var5 = MathHelper.floor(var1.x);
         int var6 = MathHelper.floor(var1.y);
         int var7 = MathHelper.floor(var1.z);
         int var8 = MathHelper.floor(var2.x);
         int var9 = MathHelper.floor(var2.y);
         int var10 = MathHelper.floor(var2.z);
         IBlockState var11 = var0.getBlockState(var3.setPos(var5, var6, var7));
         Block var12 = var11.getBlock();
         if (var12.canCollideCheck(var11, false) && var4.test(var3, var11)) {
            return var11.collisionRayTrace(var0, var3, var1, var2);
         }

         int var13 = 20;

         while(var13-- >= 0) {
            if (Double.isNaN(var1.x) || Double.isNaN(var1.y) || Double.isNaN(var1.z)) {
               return null;
            }

            if (var5 == var8 && var6 == var9 && var7 == var10) {
               return null;
            }

            double var14 = var2.x - var1.x;
            double var16 = var2.y - var1.y;
            double var18 = var2.z - var1.z;
            double var20 = 999.0;
            double var22 = 999.0;
            double var24 = 999.0;
            double var26 = 999.0;
            double var28 = 999.0;
            double var30 = 999.0;
            if (var8 > var5) {
               var20 = (double)var5 + 1.0;
               var26 = (var20 - var1.x) / var14;
               boolean var35 = false;
            } else if (var8 < var5) {
               var20 = (double)var5;
               var26 = (var20 - var1.x) / var14;
            }

            if (var9 > var6) {
               var22 = (double)var6 + 1.0;
               var28 = (var22 - var1.y) / var16;
               boolean var36 = false;
            } else if (var9 < var6) {
               var22 = (double)var6;
               var28 = (var22 - var1.y) / var16;
            }

            if (var10 > var7) {
               var24 = (double)var7 + 1.0;
               var30 = (var24 - var1.z) / var18;
               boolean var37 = false;
            } else if (var10 < var7) {
               var24 = (double)var7;
               var30 = (var24 - var1.z) / var18;
            }

            if (var26 == -0.0) {
               var26 = -1.0E-4;
            }

            if (var28 == -0.0) {
               var28 = -1.0E-4;
            }

            if (var30 == -0.0) {
               var30 = -1.0E-4;
            }

            EnumFacing var32;
            if (var26 < var28 && var26 < var30) {
               EnumFacing var41;
               if (var8 > var5) {
                  var41 = EnumFacing.WEST;
                  boolean var49 = false;
               } else {
                  var41 = EnumFacing.EAST;
               }

               var32 = var41;
               var1 = new Vec3d(var20, var1.y + var16 * var26, var1.z + var18 * var26);
               boolean var42 = false;
            } else if (var28 < var30) {
               EnumFacing var38;
               if (var9 > var6) {
                  var38 = EnumFacing.DOWN;
                  boolean var10001 = false;
               } else {
                  var38 = EnumFacing.UP;
               }

               var32 = var38;
               var1 = new Vec3d(var1.x + var14 * var28, var22, var1.z + var18 * var28);
               boolean var39 = false;
            } else {
               EnumFacing var40;
               if (var10 > var7) {
                  var40 = EnumFacing.NORTH;
                  boolean var48 = false;
               } else {
                  var40 = EnumFacing.SOUTH;
               }

               var32 = var40;
               var1 = new Vec3d(var1.x + var14 * var30, var1.y + var16 * var30, var24);
            }

            int var43 = MathHelper.floor(var1.x);
            byte var50;
            if (var32 == EnumFacing.EAST) {
               var50 = 1;
               boolean var10002 = false;
            } else {
               var50 = 0;
            }

            var5 = var43 - var50;
            var43 = MathHelper.floor(var1.y);
            if (var32 == EnumFacing.UP) {
               var50 = 1;
               boolean var53 = false;
            } else {
               var50 = 0;
            }

            var6 = var43 - var50;
            var43 = MathHelper.floor(var1.z);
            if (var32 == EnumFacing.SOUTH) {
               var50 = 1;
               boolean var54 = false;
            } else {
               var50 = 0;
            }

            var7 = var43 - var50;
            var3.setPos(var5, var6, var7);
            boolean var46 = false;
            IBlockState var33 = var0.getBlockState(var3);
            Block var34 = var33.getBlock();
            if (var34.canCollideCheck(var33, false)) {
               if (var4.test(var3, var33)) {
                  return var33.collisionRayTrace(var0, var3, var1, var2);
               }

               var46 = false;
            }
         }
      }

      return null;
   }

   public static float calculateDamage(BlockPos var0, Entity var1) {
      return calculateDamage((double)var0.getX() + 0.5, (double)(var0.getY() + 1), (double)var0.getZ() + 0.5, var1);
   }

   public static int getItemDamage(ItemStack var0) {
      return var0.getMaxDamage() - var0.getItemDamage();
   }

   public static float getBlastReduction(EntityLivingBase var0, float var1, Explosion var2) {
      if (var0 instanceof EntityPlayer) {
         EntityPlayer var4 = (EntityPlayer)var0;
         DamageSource var5 = DamageSource.causeExplosionDamage(var2);
         float var3 = CombatRules.getDamageAfterAbsorb(
            var1, (float)var4.getTotalArmorValue(), (float)var4.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue()
         );
         int var6 = 0;
         EntityPlayer var10000 = var4;

         label19: {
            try {
               var6 = EnchantmentHelper.getEnchantmentModifierDamage(var10000.getArmorInventoryList(), var5);
            } catch (Exception var8) {
               break label19;
            }

            boolean var10 = false;
         }

         float var7 = MathHelper.clamp((float)var6, 0.0F, 20.0F);
         var3 *= 1.0F - var7 / 25.0F;
         if (var0.isPotionActive(MobEffects.RESISTANCE)) {
            var3 -= var3 / 4.0F;
         }

         return Math.max(var3, 0.0F);
      } else {
         return CombatRules.getDamageAfterAbsorb(
            var1, (float)var0.getTotalArmorValue(), (float)var0.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue()
         );
      }
   }

   private static float getBlockDensity(Vec3d var0, AxisAlignedBB var1, MutableBlockPos var2) {
      double var3 = 1.0 / ((var1.maxX - var1.minX) * 2.0 + 1.0);
      double var5 = 1.0 / ((var1.maxY - var1.minY) * 2.0 + 1.0);
      double var7 = 1.0 / ((var1.maxZ - var1.minZ) * 2.0 + 1.0);
      double var9 = (1.0 - Math.floor(1.0 / var3) * var3) / 2.0;
      double var11 = (1.0 - Math.floor(1.0 / var7) * var7) / 2.0;
      if (var3 >= 0.0 && var5 >= 0.0 && var7 >= 0.0) {
         int var13 = 0;
         int var14 = 0;

         boolean var26;
         for(float var15 = 0.0F; var15 <= 1.0F; var26 = false) {
            for(float var16 = 0.0F; var16 <= 1.0F; var26 = false) {
               for(float var17 = 0.0F; var17 <= 1.0F; var26 = false) {
                  double var18 = var1.minX + (var1.maxX - var1.minX) * (double)var15;
                  double var20 = var1.minY + (var1.maxY - var1.minY) * (double)var16;
                  double var22 = var1.minZ + (var1.maxZ - var1.minZ) * (double)var17;
                  RayTraceResult var24 = rayTraceBlocks(mc.world, new Vec3d(var18 + var9, var20, var22 + var11), var0, var2, DamageUtil::isResistant);
                  if (var24 == null) {
                     ++var13;
                  }

                  ++var14;
                  var17 += (float)var7;
               }

               var16 += (float)var5;
            }

            var15 += (float)var3;
         }

         return (float)var13 / (float)var14;
      } else {
         return 0.0F;
      }
   }

   public static float getDifficultyMultiplier(float var0) {
      switch(null.$SwitchMap$net$minecraft$world$EnumDifficulty[mc.world.getDifficulty().ordinal()]) {
         case 1:
            return 0.0F;
         case 2:
            return Math.min(var0 / 2.0F + 1.0F, var0);
         case 3:
            return var0 * 1.5F;
         default:
            return var0;
      }
   }

   public static float getDamageMultiplied(float var0) {
      int var1 = mc.world.getDifficulty().getId();
      float var10001;
      if (var1 == 0) {
         var10001 = 0.0F;
         boolean var10002 = false;
      } else if (var1 == 2) {
         var10001 = 1.0F;
         boolean var2 = false;
      } else if (var1 == 1) {
         var10001 = 0.5F;
         boolean var3 = false;
      } else {
         var10001 = 1.5F;
      }

      return var0 * var10001;
   }

   public static boolean canBreakWeakness() {
      int var0 = 0;
      PotionEffect var1 = mc.player.getActivePotionEffect(MobEffects.STRENGTH);
      if (var1 != null) {
         var0 = var1.getAmplifier();
      }

      boolean var10000;
      if (mc.player.isPotionActive(MobEffects.WEAKNESS)
         && var0 < 1
         && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword)
         && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe)
         && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemAxe)
         && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSpade)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isNaked(EntityPlayer var0) {
      for(ItemStack var2 : var0.inventory.armorInventory) {
         if (var2 != null) {
            if (!var2.isEmpty()) {
               return false;
            }

            boolean var10000 = false;
         }
      }

      return true;
   }

   public static float calculateDamage(Entity var0, Entity var1) {
      return calculateDamage(var0.posX, var0.posY, var0.posZ, var1);
   }

   public static float getDamageInPercent(ItemStack var0) {
      return (float)getItemDamage(var0) / (float)var0.getMaxDamage() * 100.0F;
   }

   public static boolean canTakeDamage(boolean var0) {
      boolean var10000;
      if (!mc.player.capabilities.isCreativeMode && !var0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static float calculateDamage(double var0, double var2, double var4, Entity var6) {
      float var7 = 12.0F;
      double var8 = var6.getDistance(var0, var2, var4) / (double)var7;
      Vec3d var10 = new Vec3d(var0, var2, var4);
      double var11 = 0.0;
      Entity var10000 = var6;

      label17: {
         try {
            var11 = (double)var10000.world.getBlockDensity(var10, var6.getEntityBoundingBox());
         } catch (Exception var18) {
            break label17;
         }

         boolean var19 = false;
      }

      double var13 = (1.0 - var8) * var11;
      float var15 = (float)((int)((var13 * var13 + var13) / 2.0 * 7.0 * (double)var7 + 1.0));
      double var16 = 1.0;
      if (var6 instanceof EntityLivingBase) {
         var16 = (double)getBlastReduction(
            (EntityLivingBase)var6, getDamageMultiplied(var15), new Explosion(mc.world, null, var0, var2, var4, 6.0F, false, true)
         );
      }

      return (float)var16;
   }

   private static boolean isResistant(BlockPos var0, IBlockState var1) {
      boolean var10000;
      if (!var1.getMaterial().isLiquid() && (double)var1.getBlock().getExplosionResistance(mc.world, var0, null, null) >= 19.7) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static int getRoundedDamage(ItemStack var0) {
      return (int)getDamageInPercent(var0);
   }

   public static boolean hasDurability(ItemStack var0) {
      Item var1 = var0.getItem();
      boolean var10000;
      if (!(var1 instanceof ItemArmor) && !(var1 instanceof ItemSword) && !(var1 instanceof ItemTool) && !(var1 instanceof ItemShield)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isArmorLow(EntityPlayer var0, int var1) {
      for(ItemStack var3 : var0.inventory.armorInventory) {
         if (var3 == null) {
            return true;
         }

         if (getItemDamage(var3) < var1) {
            return true;
         }

         boolean var10000 = false;
      }

      return false;
   }
}
