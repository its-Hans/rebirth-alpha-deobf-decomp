package me.rebirthclient.api.util;

import me.rebirthclient.api.util.render.entity.StaticModelPlayer;
import net.minecraft.entity.player.EntityPlayer;

public class CopyOfPlayer {
   private final StaticModelPlayer model;
   private final double z;
   private final EntityPlayer player;
   private final double y;
   private final long time;
   private final double x;

   public StaticModelPlayer getModel() {
      return this.model;
   }

   public double getY() {
      return this.y;
   }

   public CopyOfPlayer(EntityPlayer var1, long var2, double var4, double var6, double var8, boolean var10) {
      this.player = var1;
      this.time = var2;
      this.x = var4;
      double var10002;
      if (var1.isSneaking()) {
         var10002 = 0.125;
         boolean var10003 = false;
      } else {
         var10002 = 0.0;
      }

      this.y = var6 - var10002;
      this.z = var8;
      this.model = new StaticModelPlayer(var1, var10, 0.0F);
      this.model.disableArmorLayers();
   }

   public EntityPlayer getPlayer() {
      return this.player;
   }

   public double getZ() {
      return this.z;
   }

   public long getTime() {
      return this.time;
   }

   public double getX() {
      return this.x;
   }
}
