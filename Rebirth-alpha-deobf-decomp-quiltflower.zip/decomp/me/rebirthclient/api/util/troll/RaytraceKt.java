package me.rebirthclient.api.util.troll;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.MutableBlockPos;
import net.minecraft.world.World;

public final class RaytraceKt {
   public static RayTraceResult rayTrace(
      World var0, Vec3d var1, Vec3d var2, int var3, Function2<? super BlockPos, ? super IBlockState, ? extends RayTraceAction> var4
   ) {
      double var5 = var1.x;
      double var7 = var1.y;
      double var9 = var1.z;
      int var13 = (int)(var5 + 1.07374182E9F) - 1073741824;
      int var16 = (int)(var7 + 1.07374182E9F) - 1073741824;
      int var19 = (int)(var9 + 1.07374182E9F) - 1073741824;
      MutableBlockPos var20 = new MutableBlockPos(var13, var16, var19);
      IBlockState var21 = var0.getBlockState(var20);
      double var22 = var2.x;
      double var24 = var2.y;
      double var26 = var2.z;
      RayTraceAction var28 = (RayTraceAction)var4.invoke(var20, var21);
      if (var28 == RayTraceAction.Null.INSTANCE) {
         return null;
      } else {
         if (var28 == RayTraceAction.Calc.INSTANCE) {
            RayTraceResult var29 = raytrace(var21, var0, var20, var5, var7, var9, var22, var24, var26);
            if (var29 != null) {
               return var29;
            }

            boolean var10000 = false;
         } else if (var28 instanceof RayTraceAction.Result) {
            return ((RayTraceAction.Result)var28).getRayTraceResult();
         }

         int var51 = (int)(var22 + 1.07374182E9F) - 1073741824;
         int var30 = (int)(var24 + 1.07374182E9F) - 1073741824;
         int var31 = (int)(var26 + 1.07374182E9F) - 1073741824;

         boolean var60;
         for(int var32 = var3; var32-- >= 0; var60 = false) {
            if (var13 == var51 && var16 == var30 && var19 == var31) {
               return null;
            }

            int var33 = 999;
            int var34 = 999;
            int var35 = 999;
            double var36 = 999.0;
            double var38 = 999.0;
            double var40 = 999.0;
            double var42 = var2.x - var5;
            double var44 = var2.y - var7;
            double var46 = var2.z - var9;
            if (var51 > var13) {
               var33 = var13 + 1;
               var36 = ((double)var33 - var5) / var42;
               var60 = false;
            } else if (var51 < var13) {
               var33 = var13;
               var36 = ((double)var13 - var5) / var42;
            }

            if (var30 > var16) {
               var34 = var16 + 1;
               var38 = ((double)var34 - var7) / var44;
               var60 = false;
            } else if (var30 < var16) {
               var34 = var16;
               var38 = ((double)var16 - var7) / var44;
            }

            if (var31 > var19) {
               var35 = var19 + 1;
               var40 = ((double)var35 - var9) / var46;
               var60 = false;
            } else if (var31 < var19) {
               var35 = var19;
               var40 = ((double)var19 - var9) / var46;
            }

            if (var36 < var38 && var36 < var40) {
               var5 = (double)var33;
               var7 += var44 * var36;
               var9 += var46 * var36;
               var13 = var33 - (var51 - var13 >>> 31);
               var16 = (int)(var7 + 1.07374182E9F) - 1073741824;
               var19 = (int)(var9 + 1.07374182E9F) - 1073741824;
               var60 = false;
            } else if (var38 < var40) {
               var5 += var42 * var38;
               var7 = (double)var34;
               var9 += var46 * var38;
               var13 = (int)(var5 + 1.07374182E9F) - 1073741824;
               var16 = var34 - (var30 - var16 >>> 31);
               var19 = (int)(var9 + 1.07374182E9F) - 1073741824;
               var60 = false;
            } else {
               var5 += var42 * var40;
               var7 += var44 * var40;
               var9 = (double)var35;
               var13 = (int)(var5 + 1.07374182E9F) - 1073741824;
               var16 = (int)(var7 + 1.07374182E9F) - 1073741824;
               var19 = var35 - (var31 - var19 >>> 31);
            }

            var20.setPos(var13, var16, var19);
            var60 = false;
            IBlockState var48 = var0.getBlockState(var20);
            RayTraceAction var49 = (RayTraceAction)var4.invoke(var20, var48);
            if (var49 == RayTraceAction.Null.INSTANCE) {
               return null;
            }

            if (var49 == RayTraceAction.Calc.INSTANCE) {
               RayTraceResult var50 = raytrace(var48, var0, var20, var5, var7, var9, var22, var24, var26);
               if (var50 != null) {
                  return var50;
               }

               var60 = false;
            } else if (var49 instanceof RayTraceAction.Result) {
               return ((RayTraceAction.Result)var49).getRayTraceResult();
            }
         }

         return null;
      }
   }

   private static RayTraceResult raytrace(
      IBlockState var0, World var1, MutableBlockPos var2, double var3, double var5, double var7, double var9, double var11, double var13
   ) {
      float var15 = (float)(var3 - (double)var2.getX());
      float var16 = (float)(var5 - (double)var2.getY());
      float var17 = (float)(var7 - (double)var2.getZ());
      AxisAlignedBB var18 = var0.getBoundingBox(var1, var2);
      float var19 = (float)var18.minX;
      float var20 = (float)var18.minY;
      float var21 = (float)var18.minZ;
      float var22 = (float)var18.maxX;
      float var23 = (float)var18.maxY;
      float var24 = (float)var18.maxZ;
      float var25 = (float)(var9 - (double)var2.getX()) - var15;
      float var26 = (float)(var11 - (double)var2.getY()) - var16;
      float var27 = (float)(var13 - (double)var2.getZ()) - var17;
      float var28 = Float.NaN;
      float var29 = Float.NaN;
      float var30 = Float.NaN;
      EnumFacing var31 = EnumFacing.WEST;
      boolean var32 = true;
      if (var25 * var25 >= 1.0E-7F) {
         float var33 = (var19 - var15) / var25;
         if (0.0 <= (double)var33 && (double)var33 <= 1.0) {
            float var47 = var16 + var26 * var33;
            float var53 = var17 + var27 * var33;
            if (var20 <= var47 && var47 <= var23 && var21 <= var53 && var53 <= var24) {
               var28 = var15 + var25 * var33;
               var29 = var47;
               var30 = var53;
               var32 = false;
            }

            boolean var10000 = false;
         } else {
            float var34 = (var22 - var15) / var25;
            if (0.0 <= (double)var34 && (double)var34 <= 1.0) {
               float var35 = var16 + var26 * var34;
               float var36 = var17 + var27 * var34;
               if (var20 <= var35 && var35 <= var23 && var21 <= var36 && var36 <= var24) {
                  var28 = var15 + var25 * var34;
                  var29 = var35;
                  var30 = var36;
                  var31 = EnumFacing.EAST;
                  var32 = false;
               }
            }
         }
      }

      if (var26 * var26 >= 1.0E-7F) {
         float var44 = (var20 - var16) / var26;
         label127:
         if (0.0F <= var44 && var44 <= 1.0F) {
            float var49 = var15 + var25 * var44;
            float var55 = var17 + var27 * var44;
            if (var19 <= var49 && var49 <= var22 && var21 <= var55 && var55 <= var24) {
               float var59 = var16 + var26 * var44;
               if (!var32) {
                  float var62 = var49 - var15;
                  float var80 = var62 * var62;
                  var62 = var59 - var16;
                  float var88 = var80 + var62 * var62;
                  var62 = var55 - var17;
                  float var91 = var88 + var62 * var62;
                  var62 = var28 - var15;
                  float var94 = var62 * var62;
                  var62 = var29 - var16;
                  float var97 = var94 + var62 * var62;
                  var62 = var30 - var17;
                  if (var91 >= var97 + var62 * var62) {
                     boolean var103 = false;
                     break label127;
                  }
               }

               var28 = var49;
               var29 = var59;
               var30 = var55;
               var31 = EnumFacing.DOWN;
               var32 = false;
            }

            boolean var102 = false;
         } else {
            float var48 = (var23 - var16) / var26;
            if (0.0F <= var48 && var48 <= 1.0F) {
               float var54 = var15 + var25 * var48;
               float var58 = var17 + var27 * var48;
               label113:
               if (var19 <= var54 && var54 <= var22 && var21 <= var58 && var58 <= var24) {
                  float var37 = var16 + var26 * var48;
                  if (!var32) {
                     float var38 = var54 - var15;
                     float var39 = var38 * var38;
                     var38 = var37 - var16;
                     float var40 = var39 + var38 * var38;
                     var38 = var58 - var17;
                     float var41 = var40 + var38 * var38;
                     var38 = var28 - var15;
                     float var42 = var38 * var38;
                     var38 = var29 - var16;
                     float var43 = var42 + var38 * var38;
                     var38 = var30 - var17;
                     if (var41 >= var43 + var38 * var38) {
                        boolean var101 = false;
                        break label113;
                     }
                  }

                  var28 = var54;
                  var29 = var37;
                  var30 = var58;
                  var31 = EnumFacing.UP;
                  var32 = false;
               }
            }
         }
      }

      if ((double)(var27 * var27) >= 1.0E-7) {
         float var45 = (var21 - var17) / var27;
         label102:
         if (0.0F <= var45 && var45 <= 1.0F) {
            float var51 = var15 + var25 * var45;
            float var57 = var16 + var26 * var45;
            if (var19 <= var51 && var51 <= var22 && var20 <= var57 && var57 <= var23) {
               float var61 = var17 + var27 * var45;
               if (!var32) {
                  float var69 = var51 - var15;
                  float var87 = var69 * var69;
                  var69 = var57 - var16;
                  float var90 = var87 + var69 * var69;
                  var69 = var61 - var17;
                  float var93 = var90 + var69 * var69;
                  var69 = var28 - var15;
                  float var96 = var69 * var69;
                  var69 = var29 - var16;
                  float var99 = var96 + var69 * var69;
                  var69 = var30 - var17;
                  if (var93 >= var99 + var69 * var69) {
                     boolean var106 = false;
                     break label102;
                  }
               }

               var28 = var51;
               var29 = var57;
               var30 = var61;
               var31 = EnumFacing.NORTH;
               var32 = false;
            }

            boolean var105 = false;
         } else {
            float var50 = (var24 - var17) / var27;
            if (0.0F <= var50 && var50 <= 1.0F) {
               float var56 = var15 + var25 * var50;
               float var60 = var16 + var26 * var50;
               label88:
               if (var19 <= var56 && var56 <= var22 && var20 <= var60 && var60 <= var23) {
                  float var68 = var17 + var27 * var50;
                  if (!var32) {
                     float var81 = var56 - var15;
                     float var89 = var81 * var81;
                     var81 = var60 - var16;
                     float var92 = var89 + var81 * var81;
                     var81 = var68 - var17;
                     float var95 = var92 + var81 * var81;
                     var81 = var28 - var15;
                     float var98 = var81 * var81;
                     var81 = var29 - var16;
                     float var100 = var98 + var81 * var81;
                     var81 = var30 - var17;
                     if (var95 >= var100 + var81 * var81) {
                        boolean var104 = false;
                        break label88;
                     }
                  }

                  var28 = var56;
                  var29 = var60;
                  var30 = var68;
                  var31 = EnumFacing.SOUTH;
                  var32 = false;
               }
            }
         }
      }

      RayTraceResult var46;
      if (!var32) {
         Vec3d var52 = new Vec3d((double)var28 + (double)var2.getX(), (double)var29 + (double)var2.getY(), (double)var30 + (double)var2.getZ());
         var46 = new RayTraceResult(var52, var31, var2.toImmutable());
         boolean var107 = false;
      } else {
         var46 = null;
      }

      return var46;
   }
}
