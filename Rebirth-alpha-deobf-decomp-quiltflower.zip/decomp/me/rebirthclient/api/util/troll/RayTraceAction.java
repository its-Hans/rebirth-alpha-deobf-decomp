package me.rebirthclient.api.util.troll;

import net.minecraft.util.math.RayTraceResult;

public abstract class RayTraceAction {
   private RayTraceAction() {
   }

   RayTraceAction(Object var1) {
      this();
   }

   public static final class Calc extends RayTraceAction {
      public static final RayTraceAction.Calc INSTANCE = new RayTraceAction.Calc();

      private Calc() {
      }
   }

   public static final class Null extends RayTraceAction {
      public static final RayTraceAction.Null INSTANCE = new RayTraceAction.Null();

      private Null() {
      }
   }

   public static final class Result extends RayTraceAction {
      private final RayTraceResult rayTraceResult;

      public RayTraceResult getRayTraceResult() {
         return this.rayTraceResult;
      }

      public Result(RayTraceResult var1) {
         this.rayTraceResult = var1;
      }
   }

   public static final class Skip extends RayTraceAction {
      public static final RayTraceAction.Skip INSTANCE = new RayTraceAction.Skip();

      private Skip() {
      }
   }
}
