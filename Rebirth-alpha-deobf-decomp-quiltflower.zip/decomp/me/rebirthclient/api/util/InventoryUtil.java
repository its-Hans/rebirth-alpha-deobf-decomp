package me.rebirthclient.api.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;

public class InventoryUtil implements Wrapper {
   public static void doSwap(int var0) {
      mc.player.inventory.currentItem = var0;
      mc.playerController.updateController();
   }

   public static int getItemDurability(ItemStack var0) {
      return var0 == null ? 0 : var0.getMaxDamage() - var0.itemDamage;
   }

   public static int findHotbarBlock(Class var0) {
      for(int var1 = 0; var1 < 9; ++var1) {
         ItemStack var2 = mc.player.inventory.getStackInSlot(var1);
         if (var2 == ItemStack.EMPTY) {
            boolean var10000 = false;
         } else {
            if (var0.isInstance(var2.getItem())) {
               return var1;
            }

            if (var2.getItem() instanceof ItemBlock) {
               if (var0.isInstance(((ItemBlock)var2.getItem()).getBlock())) {
                  return var1;
               }

               boolean var3 = false;
            }
         }

         boolean var4 = false;
      }

      return -1;
   }

   public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
      HashMap var0 = new HashMap();

      for(int var1 = 9; var1 <= 44; ++var1) {
         var0.put(var1, mc.player.inventoryContainer.getInventory().get(var1));
         boolean var10000 = false;
         var10000 = false;
      }

      return var0;
   }

   public static int findHotbarClass(Class var0) {
      for(int var1 = 0; var1 < 9; ++var1) {
         ItemStack var2 = mc.player.inventory.getStackInSlot(var1);
         if (var2 == ItemStack.EMPTY) {
            boolean var10000 = false;
         } else {
            if (var0.isInstance(var2.getItem())) {
               return var1;
            }

            if (var2.getItem() instanceof ItemBlock) {
               if (var0.isInstance(((ItemBlock)var2.getItem()).getBlock())) {
                  return var1;
               }

               boolean var3 = false;
            }
         }

         boolean var4 = false;
      }

      return -1;
   }

   public static boolean isNull(ItemStack var0) {
      boolean var10000;
      if (var0 != null && !(var0.getItem() instanceof ItemAir)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static boolean isInstanceOf(ItemStack var0, Class var1) {
      if (var0 == null) {
         return false;
      } else {
         Item var2 = var0.getItem();
         if (var1.isInstance(var2)) {
            return true;
         } else if (var2 instanceof ItemBlock) {
            Block var3 = Block.getBlockFromItem(var2);
            return var1.isInstance(var3);
         } else {
            return false;
         }
      }
   }

   public static int findArmorSlot(EntityEquipmentSlot var0, boolean var1, boolean var2) {
      int var3 = findArmorSlot(var0, var1);
      if (var3 == -1 && var2) {
         float var4 = 0.0F;

         for(int var5 = 1; var5 < 5; ++var5) {
            Slot var8 = (Slot)mc.player.inventoryContainer.inventorySlots.get(var5);
            ItemStack var9 = var8.getStack();
            if (var9.getItem() != Items.AIR && var9.getItem() instanceof ItemArmor) {
               ItemArmor var7 = (ItemArmor)var9.getItem();
               if (var7.getEquipmentSlot() != var0) {
                  boolean var10000 = false;
               } else {
                  float var10 = (float)(var7.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, var9));
                  boolean var11;
                  if (var1 && EnchantmentHelper.hasBindingCurse(var9)) {
                     var11 = true;
                     boolean var10001 = false;
                  } else {
                     var11 = false;
                  }

                  boolean var6 = var11;
                  if (var10 > var4) {
                     if (var6) {
                        var11 = false;
                     } else {
                        var4 = var10;
                        var3 = var5;
                     }
                  }
               }
            }

            boolean var13 = false;
         }
      }

      return var3;
   }

   public static int findItemInventorySlot(Class var0, boolean var1, boolean var2) {
      int var3 = findClassInventorySlot(var0, var1);
      if (var3 == -1 && var2) {
         for(int var4 = 1; var4 < 5; ++var4) {
            Slot var5 = (Slot)mc.player.inventoryContainer.inventorySlots.get(var4);
            ItemStack var6 = var5.getStack();
            if (var6.getItem() != Items.AIR) {
               if (!var0.isInstance(var6.getItem())) {
                  boolean var10000 = false;
               } else {
                  var3 = var4;
               }
            }

            boolean var7 = false;
         }
      }

      return var3;
   }

   public static int findItemInHotbar(Item var0) {
      int var1 = -1;

      for(int var2 = 0; var2 < 9; ++var2) {
         ItemStack var3 = mc.player.inventory.getStackInSlot(var2);
         if (var3 == ItemStack.EMPTY) {
            boolean var10000 = false;
         } else {
            var3.getItem();
            boolean var5 = false;
            Item var4 = var3.getItem();
            if (var4.equals(var0)) {
               var1 = var2;
               var5 = false;
               break;
            }
         }

         boolean var6 = false;
      }

      return var1;
   }

   public static boolean holdingItem(Class var0) {
      ItemStack var2 = mc.player.getHeldItemMainhand();
      boolean var1 = isInstanceOf(var2, var0);
      if (!var1) {
         mc.player.getHeldItemOffhand();
         boolean var10000 = false;
         var1 = isInstanceOf(var2, var0);
      }

      return var1;
   }

   public static int findHotbarBlock(Block var0) {
      for(int var1 = 0; var1 < 9; ++var1) {
         ItemStack var2 = mc.player.inventory.getStackInSlot(var1);
         if (var2 != ItemStack.EMPTY && var2.getItem() instanceof ItemBlock) {
            if (((ItemBlock)var2.getItem()).getBlock() == var0) {
               return var1;
            }

            boolean var10000 = false;
         }

         boolean var3 = false;
      }

      return -1;
   }

   public static int findClassInventorySlot(Class var0, boolean var1) {
      AtomicInteger var2 = new AtomicInteger();
      var2.set(-1);

      for(Entry var4 : getInventoryAndHotbarSlots().entrySet()) {
         if (var0.isInstance(((ItemStack)var4.getValue()).getItem())) {
            if (var4.getKey() != 45 || var1) {
               var2.set(var4.getKey());
               return var2.get();
            }

            boolean var10000 = false;
         }
      }

      return var2.get();
   }

   public static int getItemCount(Item var0) {
      int var1 = 0;
      if (mc.player.getHeldItemOffhand().getItem() == var0) {
         var1 += mc.player.getHeldItemOffhand().getCount();
      }

      for(int var2 = 1; var2 < 5; ++var2) {
         ItemStack var3 = ((Slot)mc.player.inventoryContainer.inventorySlots.get(var2)).getStack();
         if (var3.getItem() != var0) {
            boolean var10000 = false;
         } else {
            var1 += var3.getCount();
         }

         boolean var6 = false;
      }

      for(Entry var5 : getInventoryAndHotbarSlots().entrySet()) {
         if (((ItemStack)var5.getValue()).getItem() == var0) {
            if (var5.getKey() == 45) {
               boolean var7 = false;
            } else {
               var1 += ((ItemStack)var5.getValue()).getCount();
               boolean var8 = false;
            }
         }
      }

      return var1;
   }

   public static int findItemInventorySlot(Item var0, boolean var1) {
      AtomicInteger var2 = new AtomicInteger();
      var2.set(-1);

      for(Entry var4 : getInventoryAndHotbarSlots().entrySet()) {
         if (((ItemStack)var4.getValue()).getItem() == var0) {
            if (var4.getKey() != 45 || var1) {
               var2.set(var4.getKey());
               return var2.get();
            }

            boolean var10000 = false;
         }
      }

      return var2.get();
   }

   public static int getItemHotbar(Item var0) {
      for(int var1 = 0; var1 < 9; ++var1) {
         Item var2 = mc.player.inventory.getStackInSlot(var1).getItem();
         if (Item.getIdFromItem(var2) == Item.getIdFromItem(var0)) {
            return var1;
         }

         boolean var10000 = false;
         var10000 = false;
      }

      return -1;
   }

   public static void switchToHotbarSlot(Class var0, boolean var1) {
      int var2 = findHotbarClass(var0);
      if (var2 > -1) {
         switchToHotbarSlot(var2, var1);
      }
   }

   public static boolean isSlotEmpty(int var0) {
      Slot var1 = (Slot)mc.player.inventoryContainer.inventorySlots.get(var0);
      ItemStack var2 = var1.getStack();
      return var2.isEmpty();
   }

   public static int findItemInventorySlot(Item var0, boolean var1, boolean var2) {
      int var3 = findItemInventorySlot(var0, var1);
      if (var3 == -1 && var2) {
         for(int var4 = 1; var4 < 5; ++var4) {
            Slot var5 = (Slot)mc.player.inventoryContainer.inventorySlots.get(var4);
            ItemStack var6 = var5.getStack();
            if (var6.getItem() != Items.AIR) {
               if (var6.getItem() != var0) {
                  boolean var10000 = false;
               } else {
                  var3 = var4;
               }
            }

            boolean var7 = false;
         }
      }

      return var3;
   }

   public static List<Integer> findEmptySlots(boolean var0) {
      ArrayList var1 = new ArrayList();

      for(Entry var3 : getInventoryAndHotbarSlots().entrySet()) {
         if (!((ItemStack)var3.getValue()).isEmpty && ((ItemStack)var3.getValue()).getItem() != Items.AIR) {
            boolean var8 = false;
         } else {
            var1.add(var3.getKey());
            boolean var10000 = false;
            var10000 = false;
         }
      }

      if (var0) {
         for(int var5 = 1; var5 < 5; ++var5) {
            Slot var6 = (Slot)mc.player.inventoryContainer.inventorySlots.get(var5);
            ItemStack var4 = var6.getStack();
            if (!var4.isEmpty() && var4.getItem() != Items.AIR) {
               boolean var10 = false;
            } else {
               var1.add(var5);
               boolean var9 = false;
            }

            boolean var11 = false;
         }
      }

      return var1;
   }

   public static void switchToHotbarSlot(int var0, boolean var1) {
      if (mc.player.inventory.currentItem != var0 && var0 >= 0) {
         if (var1) {
            mc.player.connection.sendPacket(new CPacketHeldItemChange(var0));
            mc.playerController.updateController();
            boolean var10000 = false;
         } else {
            mc.player.connection.sendPacket(new CPacketHeldItemChange(var0));
            mc.player.inventory.currentItem = var0;
            mc.playerController.updateController();
         }
      }
   }

   public static int getEmptyXCarry() {
      for(int var0 = 1; var0 < 5; ++var0) {
         Slot var1 = (Slot)mc.player.inventoryContainer.inventorySlots.get(var0);
         ItemStack var2 = var1.getStack();
         if (var2.isEmpty() || var2.getItem() == Items.AIR) {
            return var0;
         }

         boolean var10000 = false;
         var10000 = false;
      }

      return -1;
   }

   public static int findArmorSlot(EntityEquipmentSlot var0, boolean var1) {
      int var2 = -1;
      float var3 = 0.0F;

      for(int var4 = 9; var4 < 45; ++var4) {
         ItemStack var7 = Minecraft.getMinecraft().player.inventoryContainer.getSlot(var4).getStack();
         if (var7.getItem() != Items.AIR && var7.getItem() instanceof ItemArmor) {
            ItemArmor var6 = (ItemArmor)var7.getItem();
            if (var6.getEquipmentSlot() != var0) {
               boolean var10000 = false;
            } else {
               float var8 = (float)(var6.damageReduceAmount + EnchantmentHelper.getEnchantmentLevel(Enchantments.PROTECTION, var7));
               boolean var9;
               if (var1 && EnchantmentHelper.hasBindingCurse(var7)) {
                  var9 = true;
                  boolean var10001 = false;
               } else {
                  var9 = false;
               }

               boolean var5 = var9;
               if (var8 > var3) {
                  if (var5) {
                     var9 = false;
                  } else {
                     var3 = var8;
                     var2 = var4;
                  }
               }
            }
         }

         boolean var11 = false;
      }

      return var2;
   }

   public static class QueuedTask {
      private final int slot;
      private final boolean quickClick;
      private final boolean update;

      public QueuedTask(int var1, boolean var2) {
         this.slot = var1;
         this.quickClick = var2;
         this.update = false;
      }

      public void run() {
         if (this.update) {
            Wrapper.mc.playerController.updateController();
         }

         if (this.slot != -1) {
            PlayerControllerMP var10000 = Wrapper.mc.playerController;
            int var10002 = this.slot;
            ClickType var10004;
            if (this.quickClick) {
               var10004 = ClickType.QUICK_MOVE;
               boolean var10005 = false;
            } else {
               var10004 = ClickType.PICKUP;
            }

            var10000.windowClick(0, var10002, 0, var10004, Wrapper.mc.player);
            boolean var1 = false;
         }
      }

      public QueuedTask(int var1) {
         this.slot = var1;
         this.quickClick = false;
         this.update = false;
      }

      public QueuedTask() {
         this.update = true;
         this.slot = -1;
         this.quickClick = false;
      }
   }
}
