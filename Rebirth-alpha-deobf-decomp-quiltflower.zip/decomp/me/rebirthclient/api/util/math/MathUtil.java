package me.rebirthclient.api.util.math;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import me.rebirthclient.api.util.Vector3f;
import me.rebirthclient.api.util.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class MathUtil implements Wrapper {
   public static Vec3d calculateLine(Vec3d var0, Vec3d var1, double var2) {
      double var4 = Math.sqrt(multiply(var1.x - var0.x) + multiply(var1.y - var0.y) + multiply(var1.z - var0.z));
      double var6 = (var1.x - var0.x) / var4;
      double var8 = (var1.y - var0.y) / var4;
      double var10 = (var1.z - var0.z) / var4;
      double var12 = var0.x + var6 * var2;
      double var14 = var0.y + var8 * var2;
      double var16 = var0.z + var10 * var2;
      return new Vec3d(var12, var14, var16);
   }

   public static Integer increaseNumber(int var0, int var1, int var2) {
      return var0 < var1 ? var0 + var2 : var1;
   }

   public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> var0, boolean var1) {
      LinkedList var2 = new LinkedList(var0.entrySet());
      if (var1) {
         var2.sort(Entry.comparingByValue(Comparator.reverseOrder()));
         boolean var10000 = false;
      } else {
         var2.sort(Entry.comparingByValue());
      }

      LinkedHashMap var3 = new LinkedHashMap();

      for(Entry var5 : var2) {
         var3.put(var5.getKey(), var5.getValue());
         boolean var6 = false;
         var6 = false;
      }

      return var3;
   }

   public static Float increaseNumber(float var0, float var1, float var2) {
      return var0 < var1 ? var0 + var2 : var1;
   }

   public static float[] calcAngleNoY(Vec3d var0, Vec3d var1) {
      double var2 = var1.x - var0.x;
      double var4 = var1.z - var0.z;
      return new float[]{(float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(var4, var2)) - 90.0)};
   }

   public static double multiply(double var0) {
      return var0 * var0;
   }

   public static double animate(double var0, double var2, double var4) {
      boolean var10000;
      if (var0 > var2) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var6 = var10000;
      if (var4 < 0.0) {
         var4 = 0.0;
         var10000 = false;
      } else if (var4 > 1.0) {
         var4 = 1.0;
      }

      double var7 = Math.max(var0, var2) - Math.min(var0, var2);
      double var9 = var7 * var4;
      if (var9 < 0.1) {
         var9 = 0.1;
      }

      if (var6) {
         var2 += var9;
         var10000 = false;
      } else {
         var2 -= var9;
      }

      return var2;
   }

   public static double round(double var0, int var2) {
      if (var2 < 0) {
         throw new IllegalArgumentException();
      } else {
         BigDecimal var3 = BigDecimal.valueOf(var0);
         var3 = var3.setScale(var2, RoundingMode.FLOOR);
         return var3.doubleValue();
      }
   }

   public static int[] toRGBAArray(int var0) {
      return new int[]{var0 >> 16 & 0xFF, var0 >> 8 & 0xFF, var0 & 0xFF};
   }

   public static int clamp(int var0, int var1, int var2) {
      int var10000;
      if (var0 < var1) {
         var10000 = var1;
         boolean var10001 = false;
      } else {
         var10000 = Math.min(var0, var2);
      }

      return var10000;
   }

   public static float clamp(float var0, float var1, float var2) {
      float var10000;
      if (var0 < var1) {
         var10000 = var1;
         boolean var10001 = false;
      } else {
         var10000 = Math.min(var0, var2);
      }

      return var10000;
   }

   public static Vec3d[] convertVectors(Vec3d var0, Vec3d[] var1) {
      Vec3d[] var2 = new Vec3d[var1.length];

      for(int var3 = 0; var3 < var1.length; ++var3) {
         var2[var3] = var0.add(var1[var3]);
         boolean var10000 = false;
      }

      return var2;
   }

   public static int randomBetween(int var0, int var1) {
      return var0 + new Random().nextInt() * (var1 - var0);
   }

   public static Float decreaseNumber(float var0, float var1, float var2) {
      return var0 > var1 ? var0 - var2 : var1;
   }

   public static double square(double var0) {
      return var0 * var0;
   }

   public static Vec3d extrapolatePlayerPosition(EntityPlayer var0, int var1) {
      Vec3d var2 = new Vec3d(var0.lastTickPosX, var0.lastTickPosY, var0.lastTickPosZ);
      Vec3d var3 = new Vec3d(var0.posX, var0.posY, var0.posZ);
      double var4 = multiply(var0.motionX) + multiply(var0.motionY) + multiply(var0.motionZ);
      Vec3d var6 = calculateLine(var2, var3, var4 * (double)var1);
      return new Vec3d(var6.x, var0.posY, var6.z);
   }

   public static float animate(float var0, float var1, float var2) {
      float var3 = (var1 - var0) / Math.max((float)Minecraft.getDebugFPS(), 5.0F) * 15.0F;
      if (var3 > 0.0F) {
         var3 = Math.max(var2, var3);
         var3 = Math.min(var1 - var0, var3);
         boolean var10000 = false;
      } else if (var3 < 0.0F) {
         var3 = Math.min(-var2, var3);
         var3 = Math.max(var1 - var0, var3);
      }

      return var0 + var3;
   }

   public static float randomBetween(float var0, float var1) {
      return var0 + new Random().nextFloat() * (var1 - var0);
   }

   public static float random(float var0, float var1) {
      return (float)(Math.random() * (double)(var1 - var0) + (double)var0);
   }

   public static float round(float var0, int var1) {
      if (var1 < 0) {
         throw new IllegalArgumentException();
      } else {
         BigDecimal var2 = BigDecimal.valueOf((double)var0);
         var2 = var2.setScale(var1, RoundingMode.FLOOR);
         return var2.floatValue();
      }
   }

   public static double clamp(double var0, double var2, double var4) {
      double var10000;
      if (var0 < var2) {
         var10000 = var2;
         boolean var10001 = false;
      } else {
         var10000 = Math.min(var0, var4);
      }

      return var10000;
   }

   public static Integer decreaseNumber(int var0, int var1, int var2) {
      return var0 > var1 ? var0 - var2 : var1;
   }

   public static List<Vec3d> getBlockBlocks(Entity var0) {
      ArrayList var1 = new ArrayList();
      AxisAlignedBB var2 = var0.getEntityBoundingBox();
      double var3 = var0.posY;
      double var5 = round(var2.minX, 0);
      double var7 = round(var2.minZ, 0);
      double var9 = round(var2.maxX, 0);
      double var11 = round(var2.maxZ, 0);
      if (var5 != var9) {
         var1.add(new Vec3d(var5, var3, var7));
         boolean var10000 = false;
         var1.add(new Vec3d(var9, var3, var7));
         var10000 = false;
         if (var7 != var11) {
            var1.add(new Vec3d(var5, var3, var11));
            var10000 = false;
            var1.add(new Vec3d(var9, var3, var11));
            var10000 = false;
            return var1;
         }
      } else if (var7 != var11) {
         var1.add(new Vec3d(var5, var3, var7));
         boolean var17 = false;
         var1.add(new Vec3d(var5, var3, var11));
         var17 = false;
         return var1;
      }

      var1.add(var0.getPositionVector());
      boolean var16 = false;
      return var1;
   }

   public static Vector3f mix(Vector3f var0, Vector3f var1, float var2) {
      return new Vector3f(var0.x * (1.0F - var2) + var1.x * var2, var0.y * (1.0F - var2) + var1.y * var2, var0.z * (1.0F - var2) + var0.z * var2);
   }

   public static Vec3d roundVec(Vec3d var0, int var1) {
      return new Vec3d(round(var0.x, var1), round(var0.y, var1), round(var0.z, var1));
   }

   public static float[] calcAngle(Vec3d var0, Vec3d var1) {
      double var2 = var1.x - var0.x;
      double var4 = (var1.y - var0.y) * -1.0;
      double var6 = var1.z - var0.z;
      double var8 = (double)MathHelper.sqrt(var2 * var2 + var6 * var6);
      return new float[]{
         (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(var6, var2)) - 90.0), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(var4, var8)))
      };
   }

   public static double normalize(double var0, double var2, double var4) {
      return (var0 - var2) / (var4 - var2);
   }
}
