package me.rebirthclient.api.util;

public class Timer {
   boolean paused;
   private long time = -1L;

   public long getPassedTimeMs() {
      return this.getMs(System.nanoTime() - this.time);
   }

   public void setMs(long var1) {
      this.time = System.nanoTime() - this.convertToNS(var1);
   }

   public void setPaused(boolean var1) {
      this.paused = var1;
   }

   public Timer reset() {
      this.time = System.nanoTime();
      return this;
   }

   public boolean isPaused() {
      return this.paused;
   }

   public boolean passedMs(long var1) {
      boolean var10000;
      if (!this.paused && this.passedNS(this.convertToNS(var1))) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean passedNS(long var1) {
      boolean var10000;
      if (System.nanoTime() - this.time >= var1) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean passed(long var1, boolean var3) {
      if (var3) {
         this.reset();
         boolean var10000 = false;
      }

      boolean var4;
      if (System.currentTimeMillis() - this.time >= var1) {
         var4 = true;
         boolean var10001 = false;
      } else {
         var4 = false;
      }

      return var4;
   }

   public long convertToNS(long var1) {
      return var1 * 1000000L;
   }

   public boolean passedDms(double var1) {
      return this.passedMs((long)var1 * 10L);
   }

   public boolean passedDs(double var1) {
      return this.passedMs((long)var1 * 100L);
   }

   public long getMs(long var1) {
      return var1 / 1000000L;
   }

   public final boolean passed(long var1) {
      return this.passed(var1, false);
   }

   public boolean passedS(double var1) {
      return this.passedMs((long)var1 * 1000L);
   }
}
