package me.rebirthclient.api.events;

import me.rebirthclient.Rebirth;

public class Event extends net.minecraftforge.fml.common.eventhandler.Event {
   private int stage;

   public void cancel() {
      Event var10000 = this;
      boolean var10001 = true;

      try {
         var10000.setCanceled(var10001);
      } catch (Exception var2) {
         Rebirth.LOGGER.info(String.valueOf(new StringBuilder().append(this.getClass().toString()).append(" Isn't cancellable!")));
         return;
      }

      boolean var3 = false;
   }

   public int getStage() {
      return this.stage;
   }

   public Event(int var1) {
      this.stage = var1;
   }

   public void setStage(int var1) {
      this.stage = var1;
   }

   public Event() {
   }
}
