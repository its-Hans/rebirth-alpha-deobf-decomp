package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.entity.MoverType;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class MoveEvent extends Event {
   private MoverType type;
   private double z;
   private double x;
   private double y;

   public void setY(double var1) {
      this.y = var1;
   }

   public void setType(MoverType var1) {
      this.type = var1;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public double getX() {
      return this.x;
   }

   public MoverType getType() {
      return this.type;
   }

   public MoveEvent(int var1, MoverType var2, double var3, double var5, double var7) {
      super(var1);
      this.type = var2;
      this.x = var3;
      this.y = var5;
      this.z = var7;
   }

   public double getZ() {
      return this.z;
   }

   public void setZ(double var1) {
      this.z = var1;
   }

   public double getY() {
      return this.y;
   }
}
