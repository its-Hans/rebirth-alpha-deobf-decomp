package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;

public class Render3DEvent extends Event {
   private final float partialTicks;

   public Render3DEvent(float var1) {
      this.partialTicks = var1;
   }

   public float getPartialTicks() {
      return this.partialTicks;
   }
}
