package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;

public class JumpEvent extends Event {
   public final double motionX;
   public final double motionY;

   public JumpEvent(double var1, double var3) {
      this.motionX = var1;
      this.motionY = var3;
   }
}
