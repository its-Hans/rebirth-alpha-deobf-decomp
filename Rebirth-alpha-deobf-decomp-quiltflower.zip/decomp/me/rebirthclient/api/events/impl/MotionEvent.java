package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import me.rebirthclient.api.util.Wrapper;

public class MotionEvent extends Event implements Wrapper {
   protected float pitch;
   protected double z;
   protected double x;
   public static MotionEvent INSTANCE;
   protected double y;
   protected boolean onGround;
   protected float yaw;

   public boolean isOnGround() {
      return this.onGround;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public float getPitch() {
      return this.pitch;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public void setY(double var1) {
      this.y = var1;
   }

   public void setZ(double var1) {
      this.z = var1;
   }

   public float getYaw() {
      return this.yaw;
   }

   public void setYaw(double var1) {
      this.yaw = (float)var1;
   }

   public void setRotation(float var1, float var2) {
      this.setYaw(var1);
      this.setPitch(var2);
   }

   public void setPitch(float var1) {
      this.pitch = var1;
   }

   public double getX() {
      return this.x;
   }

   public MotionEvent(int var1, MotionEvent var2) {
      this(var1, var2.x, var2.y, var2.z, var2.yaw, var2.pitch, var2.onGround);
   }

   public void setPostion(double var1, double var3, double var5, float var7, float var8, boolean var9) {
      this.setX(var1);
      this.setY(var3);
      this.setZ(var5);
      this.setYaw(var7);
      this.setPitch(var8);
      this.setOnGround(var9);
   }

   public void setPitch(double var1) {
      this.pitch = (float)var1;
   }

   public void setOnGround(boolean var1) {
      this.onGround = var1;
   }

   public double getY() {
      return this.y;
   }

   public void setPostion(double var1, double var3, double var5, boolean var7) {
      this.setX(var1);
      this.setY(var3);
      this.setZ(var5);
      this.setOnGround(var7);
   }

   public double getZ() {
      return this.z;
   }

   public MotionEvent(int var1, double var2, double var4, double var6, float var8, float var9, boolean var10) {
      super(var1);
      INSTANCE = this;
      this.x = var2;
      this.y = var4;
      this.z = var6;
      this.yaw = var8;
      this.pitch = var9;
      this.onGround = var10;
   }
}
