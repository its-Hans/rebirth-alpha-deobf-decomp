package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class FreecamEntityEvent extends Event {
   Entity entity;

   public Entity getEntity() {
      return this.entity;
   }

   public void setEntity(Entity var1) {
      this.entity = var1;
   }

   public FreecamEntityEvent(Entity var1) {
      this.entity = var1;
   }
}
