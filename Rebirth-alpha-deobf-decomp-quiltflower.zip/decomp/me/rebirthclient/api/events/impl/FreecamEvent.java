package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class FreecamEvent extends Event {
}
