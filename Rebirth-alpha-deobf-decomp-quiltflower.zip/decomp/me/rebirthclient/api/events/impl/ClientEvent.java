package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class ClientEvent extends Event {
   private Mod mod;
   private Setting setting;

   public ClientEvent(int var1, Mod var2) {
      super(var1);
      this.mod = var2;
   }

   public ClientEvent(Setting var1) {
      super(2);
      this.setting = var1;
   }

   public Mod getMod() {
      return this.mod;
   }

   public Setting getSetting() {
      return this.setting;
   }
}
