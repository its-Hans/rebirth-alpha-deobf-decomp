package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class PushEvent extends Event {
   public Entity entity;
   public boolean airbone;
   public double y;
   public double x;
   public double z;

   public PushEvent(Entity var1, double var2, double var4, double var6, boolean var8) {
      super(0);
      this.entity = var1;
      this.x = var2;
      this.y = var4;
      this.z = var6;
      this.airbone = var8;
   }

   public PushEvent(int var1, Entity var2) {
      super(var1);
      this.entity = var2;
   }

   public PushEvent(int var1) {
      super(var1);
   }
}
