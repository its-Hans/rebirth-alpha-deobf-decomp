package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class RenderEntityEvent extends Event {
   private Entity entity;
   private float yaw;
   private double z;
   private double x;
   private float partialTicks;
   private double y;

   public void setPartialTicks(float var1) {
      this.partialTicks = var1;
   }

   public double getX() {
      return this.x;
   }

   public void setX(double var1) {
      this.x = var1;
   }

   public float getYaw() {
      return this.yaw;
   }

   public void setY(double var1) {
      this.y = var1;
   }

   public void setZ(double var1) {
      this.z = var1;
   }

   public void setEntity(Entity var1) {
      this.entity = var1;
   }

   public Entity getEntity() {
      return this.entity;
   }

   public RenderEntityEvent(int var1, Entity var2, double var3, double var5, double var7, float var9, float var10) {
      super(var1);
      this.entity = var2;
      this.x = var3;
      this.y = var5;
      this.z = var7;
      this.yaw = var9;
      this.partialTicks = var10;
   }

   public double getZ() {
      return this.z;
   }

   public void setYaw(float var1) {
      this.yaw = var1;
   }

   public float getPartialTicks() {
      return this.partialTicks;
   }

   public double getY() {
      return this.y;
   }
}
