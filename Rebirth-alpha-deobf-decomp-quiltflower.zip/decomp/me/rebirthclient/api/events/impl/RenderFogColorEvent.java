package me.rebirthclient.api.events.impl;

import java.awt.Color;
import me.rebirthclient.api.events.Event;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class RenderFogColorEvent extends Event {
   private Color color;

   public void setColor(Color var1) {
      this.color = var1;
   }

   public Color getColor() {
      return this.color;
   }
}
