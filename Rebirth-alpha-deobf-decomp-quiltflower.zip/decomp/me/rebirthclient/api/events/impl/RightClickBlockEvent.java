package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class RightClickBlockEvent extends Event {
   public final BlockPos pos;
   public final ItemStack stack;
   public final EnumHand hand;

   public RightClickBlockEvent(BlockPos var1, EnumHand var2, ItemStack var3) {
      this.pos = var1;
      this.hand = var2;
      this.stack = var3;
   }
}
