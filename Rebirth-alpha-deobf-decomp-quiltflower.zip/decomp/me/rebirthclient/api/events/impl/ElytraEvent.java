package me.rebirthclient.api.events.impl;

import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class ElytraEvent extends Event {
   private final Entity entity;

   public Entity getEntity() {
      return this.entity;
   }

   public ElytraEvent(Entity var1) {
      this.entity = var1;
   }
}
