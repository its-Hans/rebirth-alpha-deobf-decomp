package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class RenderToolTipEvent extends Event {
   private final int y;
   private final int x;
   private final ItemStack stack;

   public int getY() {
      return this.y;
   }

   public ItemStack getItemStack() {
      return this.stack;
   }

   public RenderToolTipEvent(ItemStack var1, int var2, int var3) {
      this.stack = var1;
      this.x = var2;
      this.y = var3;
   }

   public int getX() {
      return this.x;
   }
}
