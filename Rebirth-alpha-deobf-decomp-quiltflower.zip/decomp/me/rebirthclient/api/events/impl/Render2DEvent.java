package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.client.gui.ScaledResolution;

public class Render2DEvent extends Event {
   public ScaledResolution scaledResolution;
   public float partialTicks;

   public void setScaledResolution(ScaledResolution var1) {
      this.scaledResolution = var1;
   }

   public double getScreenWidth() {
      return this.scaledResolution.getScaledWidth_double();
   }

   public double getScreenHeight() {
      return this.scaledResolution.getScaledHeight_double();
   }

   public void setPartialTicks(float var1) {
      this.partialTicks = var1;
   }

   public Render2DEvent(float var1, ScaledResolution var2) {
      this.partialTicks = var1;
      this.scaledResolution = var2;
   }
}
