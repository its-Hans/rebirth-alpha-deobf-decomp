package me.rebirthclient.api.events.impl;

import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class StepEvent extends Event {
   private float height;
   private final AxisAlignedBB axisAlignedBB;

   public StepEvent(AxisAlignedBB var1, float var2) {
      this.axisAlignedBB = var1;
      this.height = var2;
   }

   public AxisAlignedBB getAxisAlignedBB() {
      return this.axisAlignedBB;
   }

   public float getHeight() {
      return this.height;
   }

   public void setHeight(float var1) {
      this.height = var1;
   }
}
