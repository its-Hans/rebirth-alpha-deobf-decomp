package me.rebirthclient.api.events.impl;

import java.util.UUID;
import me.rebirthclient.api.events.Event;
import net.minecraft.entity.player.EntityPlayer;

public class ConnectionEvent extends Event {
   private final EntityPlayer player;
   private final String name;
   private final UUID uuid;

   public String getName() {
      return this.name;
   }

   public UUID getUuid() {
      return this.uuid;
   }

   public ConnectionEvent(int var1, EntityPlayer var2, UUID var3, String var4) {
      super(var1);
      this.player = var2;
      this.uuid = var3;
      this.name = var4;
   }

   public ConnectionEvent(int var1, UUID var2, String var3) {
      super(var1);
      this.uuid = var2;
      this.name = var3;
      this.player = null;
   }

   public EntityPlayer getPlayer() {
      return this.player;
   }
}
