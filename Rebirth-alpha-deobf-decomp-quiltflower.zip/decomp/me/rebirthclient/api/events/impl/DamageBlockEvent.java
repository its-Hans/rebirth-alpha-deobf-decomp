package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class DamageBlockEvent extends Event {
   final BlockPos pos;
   final int progress;
   final int breakerId;

   public DamageBlockEvent(BlockPos var1, int var2, int var3) {
      this.pos = var1;
      this.progress = var2;
      this.breakerId = var3;
   }

   public int getProgress() {
      return this.progress;
   }

   public int getBreakerId() {
      return this.breakerId;
   }

   public BlockPos getPosition() {
      return this.pos;
   }
}
