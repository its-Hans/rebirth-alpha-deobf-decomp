package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class BlockEvent extends Event {
   private EnumFacing enumFacing;
   private BlockPos blockPos;

   public void setEnumFacing(EnumFacing var1) {
      this.enumFacing = var1;
   }

   public void setBlockPos(BlockPos var1) {
      this.blockPos = var1;
   }

   public BlockPos getBlockPos() {
      return this.blockPos;
   }

   public EnumFacing getEnumFacing() {
      return this.enumFacing;
   }

   public BlockEvent(BlockPos var1, EnumFacing var2) {
      this.blockPos = var1;
      this.enumFacing = var2;
   }
}
