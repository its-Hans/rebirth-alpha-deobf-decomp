package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

public class PacketEvent extends Event {
   private final Packet<?> packet;

   public <T extends Packet<?>> T getPacket() {
      return (T)this.packet;
   }

   public PacketEvent(int var1, Packet<?> var2) {
      super(var1);
      this.packet = var2;
   }

   @Cancelable
   public static class Receive extends PacketEvent {
      public Receive(int var1, Packet<?> var2) {
         super(var1, var2);
      }
   }

   @Cancelable
   public static class Send extends PacketEvent {
      public Send(int var1, Packet<?> var2) {
         super(var1, var2);
      }
   }
}
