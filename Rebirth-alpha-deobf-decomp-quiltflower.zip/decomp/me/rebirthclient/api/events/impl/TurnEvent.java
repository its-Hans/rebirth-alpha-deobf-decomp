package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class TurnEvent extends Event {
   private final float yaw;
   private final float pitch;

   public float getYaw() {
      return this.yaw;
   }

   public TurnEvent(float var1, float var2) {
      this.yaw = var1;
      this.pitch = var2;
   }

   public float getPitch() {
      return this.pitch;
   }
}
