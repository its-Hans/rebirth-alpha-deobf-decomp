package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;

public class PerspectiveEvent extends Event {
   private float angle;

   public PerspectiveEvent(float var1) {
      this.angle = var1;
   }

   public void setAngle(float var1) {
      this.angle = var1;
   }

   public float getAngle() {
      return this.angle;
   }
}
