package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class RenderItemInFirstPersonEvent extends Event {
   public ItemStack stack;
   public final TransformType transformType;
   public final boolean leftHanded;
   public final EntityLivingBase entity;

   public void setStack(ItemStack var1) {
      this.stack = var1;
   }

   public TransformType getTransformType() {
      return this.transformType;
   }

   public ItemStack getStack() {
      return this.stack;
   }

   public RenderItemInFirstPersonEvent(EntityLivingBase var1, ItemStack var2, TransformType var3, boolean var4, int var5) {
      super(var5);
      this.entity = var1;
      this.stack = var2;
      this.transformType = var3;
      this.leftHanded = var4;
   }

   public EntityLivingBase getEntity() {
      return this.entity;
   }
}
