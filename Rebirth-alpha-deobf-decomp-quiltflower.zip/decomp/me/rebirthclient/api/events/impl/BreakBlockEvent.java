package me.rebirthclient.api.events.impl;

import me.rebirthclient.api.events.Event;
import net.minecraft.util.math.BlockPos;

public class BreakBlockEvent extends Event {
   BlockPos pos;

   public BlockPos getPos() {
      return this.pos;
   }

   public BreakBlockEvent(BlockPos var1) {
      this.pos = var1;
   }

   public void setPos(BlockPos var1) {
      this.pos = var1;
   }
}
