package me.rebirthclient;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.gui.screen.Gui;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(
   modid = "rebirth",
   name = "Rebirth",
   version = "alpha"
)
public class Rebirth {
   public static final Logger LOGGER = LogManager.getLogger("Rebirth");
   public static final String MODID = "rebirth";
   public static final String MODNAME = "Rebirth";
   public static final String MODVERISON = "alpha";
   @Instance
   public static Rebirth INSTANCE;

   @EventHandler
   public void init(FMLInitializationEvent var1) {
      load();
   }

   public static void load() {
      LOGGER.info("Loading Rebirth alpha...");
      Managers.load();
      if (Gui.INSTANCE == null) {
         Gui.INSTANCE = new Gui();
      }

      LOGGER.info("Rebirth alpha successfully loaded!\n");
   }

   public static void unload(boolean var0) {
      LOGGER.info("Unloading Rebirth alpha...");
      Managers.unload(var0);
      LOGGER.info("Rebirth alpha successfully unloaded!\n");
   }

   @EventHandler
   public void preInit(FMLPreInitializationEvent param1) {
      // $QF: Couldn't be decompiled
      // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.NullPointerException
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.graphToStatement(DomHelper.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:207)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:141)
      //
      // Bytecode:
      // 000: ldc "Rebirth alpha: Loading..."
      // 002: invokestatic org/lwjgl/opengl/Display.setTitle (Ljava/lang/String;)V
      // 005: invokestatic net/minecraft/util/Util.getOSType ()Lnet/minecraft/util/Util$EnumOS;
      // 008: getstatic net/minecraft/util/Util$EnumOS.OSX Lnet/minecraft/util/Util$EnumOS;
      // 00b: if_acmpeq 109
      // 00e: ldc net/minecraft/client/Minecraft
      // 010: ldc "/assets/minecraft/textures/rebirth/constant/icon16x.png"
      // 012: invokevirtual java/lang/Class.getResourceAsStream (Ljava/lang/String;)Ljava/io/InputStream;
      // 015: astore 2
      // 016: aconst_null
      // 017: astore 3
      // 018: ldc net/minecraft/client/Minecraft
      // 01a: ldc "/assets/minecraft/textures/rebirth/constant/icon32x.png"
      // 01c: invokevirtual java/lang/Class.getResourceAsStream (Ljava/lang/String;)Ljava/io/InputStream;
      // 01f: astore 4
      // 021: aconst_null
      // 022: astore 5
      // 024: bipush 2
      // 025: anewarray 106
      // 028: dup
      // 029: bipush 0
      // 02a: aload 2
      // 02b: invokestatic me/rebirthclient/api/util/render/RenderUtil.readImageToBuffer (Ljava/io/InputStream;)Ljava/nio/ByteBuffer;
      // 02e: aastore
      // 02f: dup
      // 030: bipush 1
      // 031: aload 4
      // 033: invokestatic me/rebirthclient/api/util/render/RenderUtil.readImageToBuffer (Ljava/io/InputStream;)Ljava/nio/ByteBuffer;
      // 036: aastore
      // 037: astore 6
      // 039: aload 6
      // 03b: invokestatic org/lwjgl/opengl/Display.setIcon ([Ljava/nio/ByteBuffer;)I
      // 03e: pop
      // 03f: bipush 0
      // 040: pop
      // 041: aload 4
      // 043: ifnull 0a2
      // 046: aload 5
      // 048: ifnull 063
      // 04b: aload 4
      // 04d: invokevirtual java/io/InputStream.close ()V
      // 050: bipush 0
      // 051: pop
      // 052: goto 0a2
      // 055: astore 6
      // 057: aload 5
      // 059: aload 6
      // 05b: invokevirtual java/lang/Throwable.addSuppressed (Ljava/lang/Throwable;)V
      // 05e: bipush 0
      // 05f: pop
      // 060: goto 0a2
      // 063: aload 4
      // 065: invokevirtual java/io/InputStream.close ()V
      // 068: bipush 0
      // 069: pop
      // 06a: goto 0a2
      // 06d: astore 6
      // 06f: aload 6
      // 071: astore 5
      // 073: aload 6
      // 075: athrow
      // 076: astore 7
      // 078: aload 4
      // 07a: ifnull 09f
      // 07d: aload 5
      // 07f: ifnull 09a
      // 082: aload 4
      // 084: invokevirtual java/io/InputStream.close ()V
      // 087: bipush 0
      // 088: pop
      // 089: goto 09f
      // 08c: astore 8
      // 08e: aload 5
      // 090: aload 8
      // 092: invokevirtual java/lang/Throwable.addSuppressed (Ljava/lang/Throwable;)V
      // 095: bipush 0
      // 096: pop
      // 097: goto 09f
      // 09a: aload 4
      // 09c: invokevirtual java/io/InputStream.close ()V
      // 09f: aload 7
      // 0a1: athrow
      // 0a2: aload 2
      // 0a3: ifnull 0f8
      // 0a6: aload 3
      // 0a7: ifnull 0c0
      // 0aa: aload 2
      // 0ab: invokevirtual java/io/InputStream.close ()V
      // 0ae: bipush 0
      // 0af: pop
      // 0b0: goto 0f8
      // 0b3: astore 4
      // 0b5: aload 3
      // 0b6: aload 4
      // 0b8: invokevirtual java/lang/Throwable.addSuppressed (Ljava/lang/Throwable;)V
      // 0bb: bipush 0
      // 0bc: pop
      // 0bd: goto 0f8
      // 0c0: aload 2
      // 0c1: invokevirtual java/io/InputStream.close ()V
      // 0c4: bipush 0
      // 0c5: pop
      // 0c6: goto 0f8
      // 0c9: nop
      // 0ca: athrow
      // 0cb: nop
      // 0cc: nop
      // 0cd: athrow
      // 0ce: nop
      // 0cf: athrow
      // 0d0: athrow
      // 0d1: astore 9
      // 0d3: aload 2
      // 0d4: ifnull 0f5
      // 0d7: aload 3
      // 0d8: ifnull 0f1
      // 0db: aload 2
      // 0dc: invokevirtual java/io/InputStream.close ()V
      // 0df: bipush 0
      // 0e0: pop
      // 0e1: goto 0f5
      // 0e4: astore 10
      // 0e6: aload 3
      // 0e7: aload 10
      // 0e9: invokevirtual java/lang/Throwable.addSuppressed (Ljava/lang/Throwable;)V
      // 0ec: bipush 0
      // 0ed: pop
      // 0ee: goto 0f5
      // 0f1: aload 2
      // 0f2: invokevirtual java/io/InputStream.close ()V
      // 0f5: aload 9
      // 0f7: athrow
      // 0f8: bipush 0
      // 0f9: pop
      // 0fa: goto 109
      // 0fd: athrow
      // 0fe: nop
      // 0ff: nop
      // 100: nop
      // 101: nop
      // 102: nop
      // 103: nop
      // 104: nop
      // 105: nop
      // 106: nop
      // 107: nop
      // 108: athrow
      // 109: return
   }
}
