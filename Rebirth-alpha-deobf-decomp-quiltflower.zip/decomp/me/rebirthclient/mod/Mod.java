package me.rebirthclient.mod;

import java.util.ArrayList;
import java.util.List;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class Mod implements Wrapper {
   public List<Setting> settings = new ArrayList<>();
   private String name;

   public List<Setting> getSettings() {
      return this.settings;
   }

   public String getName() {
      return this.name;
   }

   public static boolean spawnCheck() {
      boolean var10000;
      if (mc.player.ticksExisted > 15) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void resetSettings() {
      this.settings = new ArrayList<>();
   }

   public static boolean nullCheck() {
      boolean var10000;
      if (mc.player == null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public Mod(String var1) {
      this.name = var1;
   }

   public Setting getSettingByName(String var1) {
      for(Setting var3 : this.settings) {
         if (Integer.valueOf(var1.toUpperCase().hashCode()).equals(var3.getName().toUpperCase().hashCode())) {
            return var3;
         }

         boolean var10000 = false;
      }

      return null;
   }

   public Setting register(Setting var1) {
      var1.setMod(this);
      this.settings.add(var1);
      boolean var10000 = false;
      if (this instanceof Module && mc.currentScreen instanceof Gui) {
         Gui.INSTANCE.updateModule((Module)this);
      }

      return var1;
   }

   public Mod() {
   }

   public static boolean fullNullCheck() {
      boolean var10000;
      if (mc.player != null && mc.world != null) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public Setting add(Setting var1) {
      var1.setMod(this);
      this.settings.add(var1);
      boolean var10000 = false;
      if (this instanceof Module && mc.currentScreen instanceof Gui) {
         Gui.INSTANCE.updateModule((Module)this);
      }

      return var1;
   }
}
