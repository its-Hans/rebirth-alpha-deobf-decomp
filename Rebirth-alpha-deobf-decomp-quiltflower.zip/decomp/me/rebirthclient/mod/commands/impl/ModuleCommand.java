package me.rebirthclient.mod.commands.impl;

import com.google.gson.JsonParser;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.ConfigManager;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class ModuleCommand extends Command {
   public ModuleCommand() {
      super("module", new String[]{"<module>", "<set/reset>", "<setting>", "<value>"});
   }

   @Override
   public void execute(String[] var1) {
      if (var1.length == 1) {
         sendMessage("module <module> <set/reset> <setting> <value>");
      } else {
         Module var3 = Managers.MODULES.getModuleByName(var1[0]);
         if (var3 == null) {
            var3 = Managers.MODULES.getModuleByName(var1[0]);
            if (var3 == null) {
               sendMessage("This module doesnt exist.");
            } else {
               sendMessage(
                  String.valueOf(new StringBuilder().append(" This is the original name of the module. Its current name is: ").append(var3.getName()))
               );
            }
         } else if (var1.length == 2) {
            sendMessage(String.valueOf(new StringBuilder().append(var3.getName()).append(" : ").append(var3.getDescription())));

            for(Setting var10 : var3.getSettings()) {
               sendMessage(String.valueOf(new StringBuilder().append(var10.getName()).append(" : ").append(var10.getValue())));
               boolean var15 = false;
            }
         } else if (var1.length == 3) {
            if (Integer.valueOf("set".toUpperCase().hashCode()).equals(var1[1].toUpperCase().hashCode())) {
               sendMessage("Please specify a setting.");
               boolean var12 = false;
            } else if (Integer.valueOf("reset".toUpperCase().hashCode()).equals(var1[1].toUpperCase().hashCode())) {
               for(Setting var5 : var3.getSettings()) {
                  var5.setValue(var5.getDefaultValue());
                  boolean var13 = false;
               }

               boolean var14 = false;
            } else {
               sendMessage("This command doesnt exist.");
            }
         } else if (var1.length == 4) {
            sendMessage("Please specify a value.");
         } else {
            if (var1.length == 5) {
               Setting var2 = var3.getSettingByName(var1[2]);
               if (var2 != null) {
                  JsonParser var4 = new JsonParser();
                  if (Integer.valueOf("String".toUpperCase().hashCode()).equals(var2.getType().toUpperCase().hashCode())) {
                     var2.setValue(var1[3]);
                     sendMessage(
                        String.valueOf(
                           new StringBuilder()
                              .append(ChatFormatting.DARK_GRAY)
                              .append(var3.getName())
                              .append(" ")
                              .append(var2.getName())
                              .append(" has been set to ")
                              .append(var1[3])
                              .append(".")
                        )
                     );
                     return;
                  }

                  Setting var10000 = var2;

                  try {
                     if (Integer.valueOf("Enabled".toUpperCase().hashCode()).equals(var10000.getName().toUpperCase().hashCode())) {
                        if (Integer.valueOf("true".toUpperCase().hashCode()).equals(var1[3].toUpperCase().hashCode())) {
                           var3.enable();
                        }

                        if (Integer.valueOf("false".toUpperCase().hashCode()).equals(var1[3].toUpperCase().hashCode())) {
                           var3.disable();
                        }
                     }

                     ConfigManager.setValueFromJson(var3, var2, var4.parse(var1[3]));
                  } catch (Exception var6) {
                     sendMessage(String.valueOf(new StringBuilder().append("Bad Value! This setting requires a: ").append(var2.getType()).append(" value.")));
                     return;
                  }

                  boolean var11 = false;
                  sendMessage(
                     String.valueOf(
                        new StringBuilder()
                           .append(ChatFormatting.GRAY)
                           .append(var3.getName())
                           .append(" ")
                           .append(var2.getName())
                           .append(" has been set to ")
                           .append(var1[3])
                           .append(".")
                     )
                  );
               }
            }
         }
      }
   }
}
