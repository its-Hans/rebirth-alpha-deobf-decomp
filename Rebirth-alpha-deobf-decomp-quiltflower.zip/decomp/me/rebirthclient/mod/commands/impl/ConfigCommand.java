package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.commands.Command;

public class ConfigCommand extends Command {
   public ConfigCommand() {
      super("config", new String[]{"<save/load>"});
   }

   @Override
   public void execute(String[] var1) {
      if (var1.length == 1) {
         sendMessage("You`ll find the config files in your gameProfile directory under Rebirth/config");
      } else {
         if (var1.length == 2) {
            if (Integer.valueOf(var1[0].hashCode()).equals("list".hashCode())) {
               String var2 = "Configs: ";
               File var3 = new File("Rebirth/");
               List var4 = Arrays.stream(var3.listFiles()).filter(File::isDirectory).filter(ConfigCommand::lambda$execute$0).collect(Collectors.toList());
               StringBuilder var5 = new StringBuilder(var2);

               for(File var7 : var4) {
                  var5.append(String.valueOf(new StringBuilder().append(var7.getName()).append(", ")));
                  boolean var10000 = false;
                  var10000 = false;
               }

               var2 = String.valueOf(var5);
               sendMessage(var2);
               boolean var12 = false;
            } else {
               sendMessage("Not a valid command... Possible usage: <list>");
            }
         }

         if (var1.length >= 3) {
            String var9 = var1[0];
            byte var10 = -1;
            switch(var9.hashCode()) {
               case 3327206:
                  if (Integer.valueOf("load".hashCode()).equals(var9.hashCode())) {
                     var10 = 1;
                  }
                  break;
               case 3522941:
                  if (Integer.valueOf("save".hashCode()).equals(var9.hashCode())) {
                     var10 = 0;
                     boolean var13 = false;
                  }
            }

            switch(var10) {
               case 0:
                  Managers.CONFIGS.saveConfig(var1[1]);
                  sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append("Config '").append(var1[1]).append("' has been saved.")));
                  return;
               case 1:
                  if (Managers.CONFIGS.configExists(var1[1])) {
                     Managers.CONFIGS.loadConfig(var1[1]);
                     sendMessage(
                        String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append("Config '").append(var1[1]).append("' has been loaded."))
                     );
                     boolean var14 = false;
                  } else {
                     sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Config '").append(var1[1]).append("' does not exist.")));
                  }

                  return;
               default:
                  sendMessage("Not a valid command... Possible usage: <save/load>");
            }
         }
      }
   }

   private static boolean lambda$execute$0(File var0) {
      boolean var10000;
      if (!Integer.valueOf("util".hashCode()).equals(var0.getName().hashCode())) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }
}
