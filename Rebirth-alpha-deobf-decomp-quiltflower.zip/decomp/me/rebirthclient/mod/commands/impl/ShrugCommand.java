package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import me.rebirthclient.mod.commands.Command;

public class ShrugCommand extends Command {
   public ShrugCommand() {
      super("shrug");
   }

   @Override
   public void execute(String[] var1) {
      String var2 = "¯\\_(ツ)_/¯";
      StringSelection var3 = new StringSelection(var2);
      Clipboard var4 = Toolkit.getDefaultToolkit().getSystemClipboard();
      var4.setContents(var3, null);
      Command.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append("copied le shrug to ur clipboard")));
   }
}
