package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import org.lwjgl.input.Keyboard;

public class BindCommand extends Command {
   public BindCommand() {
      super("bind", new String[]{"<module>", "<bind>"});
   }

   @Override
   public void execute(String[] var1) {
      if (var1.length == 1) {
         sendMessage("Please specify a module.");
      } else {
         String var2 = var1[1];
         String var3 = var1[0];
         Module var4 = Managers.MODULES.getModuleByName(var3);
         if (var4 == null) {
            sendMessage(String.valueOf(new StringBuilder().append("Unknown module '").append(var4).append("'!")));
         } else if (var2 == null) {
            sendMessage(
               String.valueOf(new StringBuilder().append(var4.getName()).append(" is bound to ").append(ChatFormatting.GRAY).append(var4.getBind().toString()))
            );
         } else {
            int var5 = Keyboard.getKeyIndex(var2.toUpperCase());
            if (Integer.valueOf("none".toUpperCase().hashCode()).equals(var2.toUpperCase().hashCode())) {
               var5 = -1;
            }

            if (var5 == 0) {
               sendMessage(String.valueOf(new StringBuilder().append("Unknown key '").append(var2).append("'!")));
            } else {
               var4.bind.setValue(new Bind(var5));
               sendMessage(
                  String.valueOf(
                     new StringBuilder()
                        .append("Bind for ")
                        .append(ChatFormatting.GREEN)
                        .append(var4.getName())
                        .append(ChatFormatting.WHITE)
                        .append(" set to ")
                        .append(ChatFormatting.GRAY)
                        .append(var2.toUpperCase())
                  )
               );
            }
         }
      }
   }
}
