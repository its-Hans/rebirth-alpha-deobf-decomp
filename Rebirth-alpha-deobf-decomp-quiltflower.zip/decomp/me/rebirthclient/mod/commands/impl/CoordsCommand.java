package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import me.rebirthclient.mod.commands.Command;

public class CoordsCommand extends Command {
   String coords;

   @Override
   public void execute(String[] var1) {
      int var2 = (int)mc.player.posX;
      int var3 = (int)mc.player.posY;
      int var4 = (int)mc.player.posZ;
      this.coords = String.valueOf(new StringBuilder().append("X: ").append(var2).append(" Y: ").append(var3).append(" Z: ").append(var4));
      String var5 = this.coords;
      StringSelection var6 = new StringSelection(var5);
      Clipboard var7 = Toolkit.getDefaultToolkit().getSystemClipboard();
      var7.setContents(var6, null);
      Command.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append("Coords copied.")));
   }

   public CoordsCommand() {
      super("coords");
   }
}
