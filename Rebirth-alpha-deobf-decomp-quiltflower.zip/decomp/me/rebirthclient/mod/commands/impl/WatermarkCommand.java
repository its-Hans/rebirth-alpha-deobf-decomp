package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.modules.impl.client.FontMod;
import me.rebirthclient.mod.modules.impl.client.HUD;

public class WatermarkCommand extends Command {
   @Override
   public void execute(String[] var1) {
      if (var1.length == 2) {
         FontMod var2 = FontMod.INSTANCE;
         boolean var3 = var2.isOn();
         if (var1[0] != null) {
            if (var3) {
               var2.disable();
            }

            HUD.INSTANCE.watermarkString.setValue(var1[0]);
            if (var3) {
               var2.enable();
            }

            sendMessage(String.valueOf(new StringBuilder().append("Watermark set to ").append(ChatFormatting.GREEN).append(var1[0])));
            boolean var10000 = false;
         } else {
            sendMessage("Not a valid command... Possible usage: <New Watermark>");
         }
      }
   }

   public WatermarkCommand() {
      super("watermark", new String[]{"<watermark>"});
   }
}
