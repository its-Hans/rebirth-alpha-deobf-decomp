package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.mod.commands.Command;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.audio.SoundManager;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;

public class ReloadSoundCommand extends Command {
   public ReloadSoundCommand() {
      super("sound", new String[0]);
   }

   @Override
   public void execute(String[] var1) {
      Class<SoundHandler> var10000 = SoundHandler.class;
      Minecraft var10001 = mc;

      try {
         SoundManager var2 = (SoundManager)ObfuscationReflectionHelper.getPrivateValue(
            var10000, var10001.getSoundHandler(), new String[]{"sndManager", "sndManager"}
         );
         var2.reloadSoundSystem();
         Command.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append("Reloaded Sound System.")));
      } catch (Exception var3) {
         System.out.println(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Could not restart sound manager: ").append(var3)));
         var3.printStackTrace();
         Command.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Couldnt Reload Sound System!")));
         return;
      }

      boolean var4 = false;
   }
}
