package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.commands.Command;

public class HelpCommand extends Command {
   @Override
   public void execute(String[] var1) {
      sendMessage("Commands: ");

      for(Command var3 : Managers.COMMANDS.getCommands()) {
         sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append(Managers.COMMANDS.getCommandPrefix()).append(var3.getName())));
         boolean var10000 = false;
      }
   }

   public HelpCommand() {
      super("help");
   }
}
