package me.rebirthclient.mod.commands.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.FriendManager;
import me.rebirthclient.mod.commands.Command;

public class FriendCommand extends Command {
   public FriendCommand() {
      super("friend", new String[]{"<add/del/name/clear>", "<name>"});
   }

   @Override
   public void execute(String[] var1) {
      if (var1.length != 1) {
         if (var1.length == 2) {
            if (Integer.valueOf(var1[0].hashCode()).equals("reset".hashCode())) {
               Managers.FRIENDS.onLoad();
               sendMessage("Friends got reset.");
            } else {
               StringBuilder var13 = new StringBuilder().append(var1[0]);
               String var14;
               if (Managers.FRIENDS.isFriend(var1[0])) {
                  var14 = " is friended.";
                  boolean var10002 = false;
               } else {
                  var14 = " isn't friended.";
               }

               sendMessage(String.valueOf(var13.append(var14)));
            }
         } else {
            if (var1.length >= 2) {
               String var7 = var1[0];
               byte var8 = -1;
               switch(var7.hashCode()) {
                  case 96417:
                     if (Integer.valueOf("add".hashCode()).equals(var7.hashCode())) {
                        var8 = 0;
                        boolean var12 = false;
                     }
                     break;
                  case 99339:
                     if (Integer.valueOf("del".hashCode()).equals(var7.hashCode())) {
                        var8 = 1;
                     }
               }

               switch(var8) {
                  case 0:
                     Managers.FRIENDS.addFriend(var1[1]);
                     sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append(var1[1]).append(" has been friended")));
                     return;
                  case 1:
                     Managers.FRIENDS.removeFriend(var1[1]);
                     sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append(var1[1]).append(" has been unfriended")));
                     return;
                  default:
                     sendMessage("Unknown Command, try friend add/del (name)");
               }
            }
         }
      } else {
         if (Managers.FRIENDS.getFriends().isEmpty()) {
            sendMessage("Friend list empty D:.");
            boolean var10000 = false;
         } else {
            String var2 = "Friends: ";

            for(FriendManager.Friend var4 : Managers.FRIENDS.getFriends()) {
               StringBuilder var9 = new StringBuilder;
               StringBuilder var10001 = var9;

               label57: {
                  try {
                     var10001./* $QF: Unable to resugar constructor */<init>();
                     var2 = String.valueOf(var9.append(var2).append(var4.getUsername()).append(", "));
                  } catch (Exception var6) {
                     break label57;
                  }

                  boolean var10 = false;
               }

               boolean var11 = false;
            }

            sendMessage(var2);
         }
      }
   }
}
