package me.rebirthclient.mod.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.modules.impl.hud.Notifications;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentBase;

public abstract class Command extends Mod {
   protected final String name;
   protected final String[] commands;

   public String complete(String var1) {
      if (this.name.toLowerCase().startsWith(var1)) {
         return this.name;
      } else {
         for(String var5 : this.commands) {
            if (var5.toLowerCase().startsWith(var1)) {
               return var5;
            }

            boolean var10000 = false;
         }

         return null;
      }
   }

   public Command(String var1, String[] var2) {
      super(var1);
      this.name = var1;
      this.commands = var2;
   }

   @Override
   public String getName() {
      return this.name;
   }

   public Command(String var1) {
      super(var1);
      this.name = var1;
      this.commands = new String[]{""};
   }

   public static void sendMessage(String var0) {
      Notifications.notifyList.add(new Notifications.Notifys(var0));
      boolean var10000 = false;
      sendSilentMessage(String.valueOf(new StringBuilder().append(Managers.TEXT.getPrefix()).append(ChatFormatting.GRAY).append(var0)));
   }

   public static void sendMessageWithID(String var0, int var1) {
      if (!nullCheck()) {
         mc.ingameGUI
            .getChatGUI()
            .printChatMessageWithOptionalDeletion(
               new Command.ChatMessage(String.valueOf(new StringBuilder().append(Managers.TEXT.getPrefix()).append(ChatFormatting.GRAY).append(var0))), var1
            );
      }
   }

   public abstract void execute(String[] var1);

   public static void sendSilentMessage(String var0) {
      if (!nullCheck()) {
         mc.player.sendMessage(new Command.ChatMessage(var0));
      }
   }

   public static String getCommandPrefix() {
      return Managers.COMMANDS.getCommandPrefix();
   }

   public String[] getCommands() {
      return this.commands;
   }

   public static class ChatMessage extends TextComponentBase {
      private final String text;

      public ITextComponent shallowCopy() {
         return new Command.ChatMessage(this.text);
      }

      public ITextComponent createCopy() {
         return null;
      }

      public String getUnformattedComponentText() {
         return this.text;
      }

      public ChatMessage(String var1) {
         Pattern var2 = Pattern.compile("&[0123456789abcdefrlosmk]");
         Matcher var3 = var2.matcher(var1);

         StringBuffer var4;
         boolean var6;
         for(var4 = new StringBuffer(); var3.find(); var6 = false) {
            String var5 = var3.group().substring(1);
            var3.appendReplacement(var4, var5);
            var6 = false;
         }

         var3.appendTail(var4);
         var6 = false;
         this.text = var4.toString();
      }
   }
}
