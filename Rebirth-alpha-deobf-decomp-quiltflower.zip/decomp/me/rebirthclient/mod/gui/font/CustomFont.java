package me.rebirthclient.mod.gui.font;

import java.awt.Font;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

public class CustomFont extends CFont {
   protected final CFont.CharData[] italicChars;
   private final int[] colorCode;
   protected final CFont.CharData[] boldChars = new CFont.CharData[256];
   protected DynamicTexture texItalicBold;
   protected DynamicTexture texBold;
   protected DynamicTexture texItalic;
   protected final CFont.CharData[] boldItalicChars;

   public float drawCenteredString(String var1, float var2, float var3, int var4) {
      return this.drawString(var1, var2 - (float)this.getStringWidth(var1) / 2.0F, var3, var4);
   }

   public CustomFont(CFont.CustomFont var1, boolean var2, boolean var3) {
      super(var1, var2, var3);
      this.italicChars = new CFont.CharData[256];
      this.boldItalicChars = new CFont.CharData[256];
      this.colorCode = new int[32];
      this.setupMinecraftColorcodes();
      this.setupBoldItalicIDs();
   }

   @Override
   public void setFractionalMetrics(boolean var1) {
      super.setFractionalMetrics(var1);
      this.setupBoldItalicIDs();
   }

   @Override
   public void setFont(Font var1) {
      super.setFont(var1);
      this.setupBoldItalicIDs();
   }

   private void setupMinecraftColorcodes() {
      for(int var1 = 0; var1 < 32; ++var1) {
         int var2 = (var1 >> 3 & 1) * 85;
         int var3 = (var1 >> 2 & 1) * 170 + var2;
         int var4 = (var1 >> 1 & 1) * 170 + var2;
         int var5 = (var1 & 1) * 170 + var2;
         if (var1 == 6) {
            var3 += 85;
         }

         if (var1 >= 16) {
            var3 /= 4;
            var4 /= 4;
            var5 /= 4;
         }

         this.colorCode[var1] = (var3 & 0xFF) << 16 | (var4 & 0xFF) << 8 | var5 & 0xFF;
         boolean var10000 = false;
      }
   }

   public float drawString(String var1, float var2, float var3, int var4) {
      return this.drawString(var1, (double)var2, (double)var3, var4, false);
   }

   public float drawStringWithShadow(String var1, double var2, double var4, int var6) {
      float var7 = this.drawString(var1, var2 + 1.0, var4 + 1.0, var6, true);
      return Math.max(var7, this.drawString(var1, var2, var4, var6, false));
   }

   public float drawCenteredStringWithShadow(String var1, float var2, float var3, int var4) {
      return this.drawStringWithShadow(var1, (double)var2 - (double)this.getStringWidth(var1) / 2.0, (double)var3, var4);
   }

   @Override
   public void setAntiAlias(boolean var1) {
      super.setAntiAlias(var1);
      this.setupBoldItalicIDs();
   }

   private void setupBoldItalicIDs() {
      this.texBold = this.setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
      this.texItalic = this.setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
      this.texItalicBold = this.setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
   }

   @Override
   public int getStringWidth(String var1) {
      if (var1 == null) {
         return 0;
      } else {
         int var2 = 0;
         CFont.CharData[] var3 = this.charData;
         int var4 = var1.length();

         for(int var5 = 0; var5 < var4; ++var5) {
            char var6 = var1.charAt(var5);
            if (var6 == 167) {
               ++var5;
               boolean var10000 = false;
            } else if (var6 < var3.length) {
               var2 += var3[var6].width - 8 + this.charOffset;
            }

            boolean var7 = false;
         }

         return var2 / 2;
      }
   }

   private void drawLine(double var1, double var3, double var5, double var7) {
      GL11.glDisable(3553);
      GL11.glLineWidth(1.0F);
      GL11.glBegin(1);
      GL11.glVertex2d(var1, var3);
      GL11.glVertex2d(var5, var7);
      GL11.glEnd();
      GL11.glEnable(3553);
   }

   public CustomFont(Font var1, boolean var2, boolean var3) {
      super(var1, var2, var3);
      this.italicChars = new CFont.CharData[256];
      this.boldItalicChars = new CFont.CharData[256];
      this.colorCode = new int[32];
      this.setupMinecraftColorcodes();
      this.setupBoldItalicIDs();
   }

   public float drawString(String var1, double var2, double var4, int var6, boolean var7) {
      --var2;
      var4 -= 2.0;
      if (var1 == null) {
         return 0.0F;
      } else {
         if (var6 == 553648127) {
            var6 = 16777215;
         }

         if ((var6 & -67108864) == 0) {
            var6 |= -16777216;
         }

         if (var7) {
            var6 = (var6 & 16579836) >> 2 | var6 & 0xFF000000;
         }

         CFont.CharData[] var8 = this.charData;
         float var9 = (float)(var6 >> 24 & 0xFF) / 255.0F;
         boolean var10 = false;
         boolean var11 = false;
         boolean var12 = false;
         boolean var13 = false;
         var2 *= 2.0;
         var4 *= 2.0;
         GL11.glPushMatrix();
         GlStateManager.scale(0.5, 0.5, 0.5);
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 771);
         GlStateManager.color((float)(var6 >> 16 & 0xFF) / 255.0F, (float)(var6 >> 8 & 0xFF) / 255.0F, (float)(var6 & 0xFF) / 255.0F, var9);
         int var14 = var1.length();
         GlStateManager.enableTexture2D();
         GlStateManager.bindTexture(this.tex.getGlTextureId());
         GL11.glBindTexture(3553, this.tex.getGlTextureId());

         for(int var15 = 0; var15 < var14; ++var15) {
            char var16 = var1.charAt(var15);
            if (var16 == 167) {
               int var17 = 21;
               String var10000 = "0123456789abcdefklmnor";
               String var10001 = var1;
               int var10002 = var15 + 1;

               label80: {
                  try {
                     var17 = var10000.indexOf(var10001.charAt(var10002));
                  } catch (Exception var19) {
                     break label80;
                  }

                  boolean var24 = false;
               }

               if (var17 < 16) {
                  var10 = false;
                  var11 = false;
                  var13 = false;
                  var12 = false;
                  GlStateManager.bindTexture(this.tex.getGlTextureId());
                  var8 = this.charData;
                  if (var17 < 0) {
                     var17 = 15;
                  }

                  if (var7) {
                     var17 += 16;
                  }

                  int var18 = this.colorCode[var17];
                  GlStateManager.color((float)(var18 >> 16 & 0xFF) / 255.0F, (float)(var18 >> 8 & 0xFF) / 255.0F, (float)(var18 & 0xFF) / 255.0F, var9);
                  boolean var25 = false;
               } else if (var17 == 17) {
                  var10 = true;
                  if (var11) {
                     GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                     var8 = this.boldItalicChars;
                     boolean var26 = false;
                  } else {
                     GlStateManager.bindTexture(this.texBold.getGlTextureId());
                     var8 = this.boldChars;
                     boolean var27 = false;
                  }
               } else if (var17 == 18) {
                  var12 = true;
                  boolean var28 = false;
               } else if (var17 == 19) {
                  var13 = true;
                  boolean var29 = false;
               } else if (var17 == 20) {
                  var11 = true;
                  if (var10) {
                     GlStateManager.bindTexture(this.texItalicBold.getGlTextureId());
                     var8 = this.boldItalicChars;
                     boolean var30 = false;
                  } else {
                     GlStateManager.bindTexture(this.texItalic.getGlTextureId());
                     var8 = this.italicChars;
                     boolean var31 = false;
                  }
               } else if (var17 == 21) {
                  var10 = false;
                  var11 = false;
                  var13 = false;
                  var12 = false;
                  GlStateManager.color((float)(var6 >> 16 & 0xFF) / 255.0F, (float)(var6 >> 8 & 0xFF) / 255.0F, (float)(var6 & 0xFF) / 255.0F, var9);
                  GlStateManager.bindTexture(this.tex.getGlTextureId());
                  var8 = this.charData;
               }

               ++var15;
               boolean var32 = false;
            } else if (var16 < var8.length) {
               GL11.glBegin(4);
               this.drawChar(var8, var16, (float)var2, (float)var4);
               GL11.glEnd();
               if (var12) {
                  this.drawLine(var2, var4 + (double)var8[var16].height / 2.0, var2 + (double)var8[var16].width - 8.0, var4 + (double)var8[var16].height / 2.0);
               }

               if (var13) {
                  this.drawLine(var2, var4 + (double)var8[var16].height - 2.0, var2 + (double)var8[var16].width - 8.0, var4 + (double)var8[var16].height - 2.0);
               }

               var2 += (double)(var8[var16].width - 8 + this.charOffset);
            }

            boolean var33 = false;
         }

         GL11.glHint(3155, 4352);
         GL11.glPopMatrix();
         return (float)var2 / 2.0F;
      }
   }
}
