package me.rebirthclient.mod.gui.font;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.RenderingHints.Key;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import net.minecraft.client.renderer.texture.DynamicTexture;
import org.lwjgl.opengl.GL11;

public class CFont {
   protected int fontHeight;
   protected boolean antiAlias;
   protected boolean fractionalMetrics;
   protected Font font;
   private final float imgSize;
   protected final CFont.CharData[] charData = new CFont.CharData[256];
   protected DynamicTexture tex;
   protected int charOffset;

   public int getHeight() {
      return (this.fontHeight - 8) / 2;
   }

   protected BufferedImage generateFontImage(Font var1, boolean var2, boolean var3, CFont.CharData[] var4) {
      boolean var10000 = false;
      short var5 = 512;
      BufferedImage var6 = new BufferedImage(var5, var5, 2);
      Graphics2D var7 = (Graphics2D)var6.getGraphics();
      var7.setFont(var1);
      var7.setColor(new Color(255, 255, 255, 0));
      var7.fillRect(0, 0, var5, var5);
      var7.setColor(Color.WHITE);
      Key var10001 = RenderingHints.KEY_FRACTIONALMETRICS;
      Object var10002;
      if (var3) {
         var10002 = RenderingHints.VALUE_FRACTIONALMETRICS_ON;
         boolean var10003 = false;
      } else {
         var10002 = RenderingHints.VALUE_FRACTIONALMETRICS_OFF;
      }

      var7.setRenderingHint(var10001, var10002);
      var10001 = RenderingHints.KEY_TEXT_ANTIALIASING;
      if (var2) {
         var10002 = RenderingHints.VALUE_TEXT_ANTIALIAS_ON;
         boolean var21 = false;
      } else {
         var10002 = RenderingHints.VALUE_TEXT_ANTIALIAS_OFF;
      }

      var7.setRenderingHint(var10001, var10002);
      var10001 = RenderingHints.KEY_ANTIALIASING;
      if (var2) {
         var10002 = RenderingHints.VALUE_ANTIALIAS_ON;
         boolean var22 = false;
      } else {
         var10002 = RenderingHints.VALUE_ANTIALIAS_OFF;
      }

      var7.setRenderingHint(var10001, var10002);
      FontMetrics var8 = var7.getFontMetrics();
      int var9 = 0;
      int var10 = 0;
      int var11 = 1;

      for(int var12 = 0; var12 < var4.length; ++var12) {
         char var13 = (char)var12;
         CFont.CharData var14 = new CFont.CharData();
         Rectangle2D var15 = var8.getStringBounds(String.valueOf(var13), var7);
         var14.width = var15.getBounds().width + 8;
         var14.height = var15.getBounds().height;
         if (var10 + var14.width >= var5) {
            var10 = 0;
            var11 += var9;
            var9 = 0;
         }

         if (var14.height > var9) {
            var9 = var14.height;
         }

         var14.storedX = var10;
         var14.storedY = var11;
         if (var14.height > this.fontHeight) {
            this.fontHeight = var14.height;
         }

         var4[var12] = var14;
         var7.drawString(String.valueOf(var13), var10 + 2, var11 + var8.getAscent());
         var10 += var14.width;
         var10000 = false;
      }

      return var6;
   }

   public boolean isFractionalMetrics() {
      return this.fractionalMetrics;
   }

   public void drawChar(CFont.CharData[] var1, char var2, float var3, float var4) throws ArrayIndexOutOfBoundsException {
      CFont var10000 = this;
      float var10001 = var3;
      float var10002 = var4;
      CFont.CharData[] var10003 = var1;
      char var10004 = var2;

      try {
         var10000.drawQuad(
            var10001,
            var10002,
            (float)var10003[var10004].width,
            (float)var1[var2].height,
            (float)var1[var2].storedX,
            (float)var1[var2].storedY,
            (float)var1[var2].width,
            (float)var1[var2].height
         );
      } catch (Exception var6) {
         var6.printStackTrace();
         return;
      }

      boolean var7 = false;
   }

   protected DynamicTexture setupTexture(Font var1, boolean var2, boolean var3, CFont.CharData[] var4) {
      BufferedImage var5 = this.generateFontImage(var1, var2, var3, var4);
      DynamicTexture var10000 = new DynamicTexture;
      DynamicTexture var10001 = var10000;
      BufferedImage var10002 = var5;

      try {
         var10001./* $QF: Unable to resugar constructor */<init>(var10002);
         return var10000;
      } catch (Exception var7) {
         var7.printStackTrace();
         return null;
      }
   }

   public void setFont(Font var1) {
      this.font = var1;
      this.tex = this.setupTexture(var1, this.antiAlias, this.fractionalMetrics, this.charData);
   }

   public int getStringWidth(String var1) {
      int var2 = 0;

      for(char var6 : var1.toCharArray()) {
         if (var6 >= this.charData.length) {
            boolean var10000 = false;
         } else {
            var2 += this.charData[var6].width - 8 + this.charOffset;
         }

         boolean var7 = false;
      }

      return var2 / 2;
   }

   public void setAntiAlias(boolean var1) {
      if (this.antiAlias != var1) {
         this.antiAlias = var1;
         this.tex = this.setupTexture(this.font, var1, this.fractionalMetrics, this.charData);
      }
   }

   public CFont(CFont.CustomFont var1, boolean var2, boolean var3) {
      this.imgSize = 512.0F;
      this.fontHeight = -1;
      byte var10000 = 0;
      Class<CFont> var10001 = CFont.class;
      CFont.CustomFont var10002 = var1;

      try {
         Font var4 = Font.createFont(var10000, var10001.getResourceAsStream(var10002.getFile())).deriveFont(var1.getSize()).deriveFont(var1.getType());
         this.font = var4;
         this.antiAlias = var2;
         this.fractionalMetrics = var3;
         this.tex = this.setupTexture(var4, var2, var3, this.charData);
      } catch (FontFormatException | IOException var5) {
         return;
      }

      boolean var6 = false;
   }

   protected void drawQuad(float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8) {
      float var9 = var5 / 512.0F;
      float var10 = var6 / 512.0F;
      float var11 = var7 / 512.0F;
      float var12 = var8 / 512.0F;
      GL11.glTexCoord2f(var9 + var11, var10);
      GL11.glVertex2d((double)(var1 + var3), (double)var2);
      GL11.glTexCoord2f(var9, var10);
      GL11.glVertex2d((double)var1, (double)var2);
      GL11.glTexCoord2f(var9, var10 + var12);
      GL11.glVertex2d((double)var1, (double)(var2 + var4));
      GL11.glTexCoord2f(var9, var10 + var12);
      GL11.glVertex2d((double)var1, (double)(var2 + var4));
      GL11.glTexCoord2f(var9 + var11, var10 + var12);
      GL11.glVertex2d((double)(var1 + var3), (double)(var2 + var4));
      GL11.glTexCoord2f(var9 + var11, var10);
      GL11.glVertex2d((double)(var1 + var3), (double)var2);
   }

   public Font getFont() {
      return this.font;
   }

   public void setFractionalMetrics(boolean var1) {
      if (this.fractionalMetrics != var1) {
         this.fractionalMetrics = var1;
         this.tex = this.setupTexture(this.font, this.antiAlias, var1, this.charData);
      }
   }

   public CFont(Font var1, boolean var2, boolean var3) {
      this.imgSize = 512.0F;
      this.fontHeight = -1;
      this.font = var1;
      this.antiAlias = var2;
      this.fractionalMetrics = var3;
      this.tex = this.setupTexture(var1, var2, var3, this.charData);
   }

   public boolean isAntiAlias() {
      return this.antiAlias;
   }

   public int getStringHeight(String var1) {
      return this.getHeight();
   }

   protected static class CharData {
      public int storedX;
      public int storedY;
      public int height;
      public int width;
   }

   public static class CustomFont {
      final String file;
      final int style;
      final float size;

      public int getType() {
         return this.style > 3 ? 3 : Math.max(this.style, 0);
      }

      public float getSize() {
         return this.size;
      }

      public String getFile() {
         return this.file;
      }

      public CustomFont(String var1, float var2, int var3) {
         this.file = var1;
         this.size = var2;
         this.style = var3;
      }
   }
}
