package me.rebirthclient.mod.gui.click;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.ColorManager;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.gui.click.items.Item;
import me.rebirthclient.mod.gui.click.items.buttons.Button;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class Component extends Mod {
   public static int[] counter1 = new int[]{1};
   private boolean hidden;
   private int x2;
   public final Map<Integer, Integer> colorMap = new HashMap<>();
   public boolean drag;
   private int width;
   private int y2;
   private int angle;
   private int y;
   private final ArrayList<Item> items = new ArrayList<>();
   private int height;
   private int x;
   private boolean open;

   public boolean isOpen() {
      return this.open;
   }

   public int getHeight() {
      return this.height;
   }

   public void setupItems() {
   }

   public Component(String var1, int var2, int var3, boolean var4) {
      super(var1);
      this.angle = 180;
      this.x = var2;
      this.y = var3;
      this.width = 88;
      this.height = 18;
      this.open = var4;
      this.setupItems();
   }

   public void mouseClicked(int var1, int var2, int var3) {
      if (var3 == 0 && this.isHovering(var1, var2)) {
         this.x2 = this.x - var1;
         this.y2 = this.y - var2;
         Gui.INSTANCE.getComponents().forEach(Component::lambda$mouseClicked$0);
         this.drag = true;
      } else if (var3 == 1 && this.isHovering(var1, var2)) {
         boolean var10001;
         if (!this.open) {
            var10001 = true;
            boolean var10002 = false;
         } else {
            var10001 = false;
         }

         this.open = var10001;
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      } else if (this.open) {
         this.getItems().forEach(Component::lambda$mouseClicked$1);
      }
   }

   public void setHidden(boolean var1) {
      this.hidden = var1;
   }

   public void setX(int var1) {
      this.x = var1;
   }

   public void onKeyTyped(char var1, int var2) {
      if (this.open) {
         this.getItems().forEach(Component::lambda$onKeyTyped$3);
      }
   }

   public void addButton(Button var1) {
      this.items.add(var1);
      boolean var10000 = false;
   }

   public void setHeight(int var1) {
      this.height = var1;
   }

   public void setWidth(int var1) {
      this.width = var1;
   }

   public int getY() {
      return this.y;
   }

   public int getX() {
      return this.x;
   }

   public int getWidth() {
      return this.width;
   }

   public boolean isHidden() {
      return this.hidden;
   }

   private boolean isHovering(int var1, int var2) {
      if (var1 >= this.getX() && var1 <= this.getX() + this.getWidth() && var2 >= this.getY()) {
         int var10001 = this.getY() + this.getHeight();
         byte var10002;
         if (this.open) {
            var10002 = 2;
            boolean var10003 = false;
         } else {
            var10002 = 0;
         }

         if (var2 <= var10001 - var10002) {
            boolean var3 = false;
            return true;
         }
      }

      return false;
   }

   public void mouseReleased(int var1, int var2, int var3) {
      if (var3 == 0) {
         this.drag = false;
      }

      if (this.open) {
         this.getItems().forEach(Component::lambda$mouseReleased$2);
      }
   }

   public static float calculateRotation(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   private static void lambda$onKeyTyped$3(char var0, int var1, Item var2) {
      var2.onKeyTyped(var0, var1);
   }

   private static void lambda$mouseClicked$1(int var0, int var1, int var2, Item var3) {
      var3.mouseClicked(var0, var1, var2);
   }

   private void drawOutline(int var1) {
      float var2 = 0.0F;
      if (this.open) {
         var2 = this.getTotalItemHeight() - 2.0F;
      }

      float var10000 = (float)this.x;
      float var10001 = (float)this.y - 1.5F;
      float var10002 = (float)this.x;
      float var10003 = (float)(this.y + this.height) + var2;
      int var10005;
      if (ClickGui.INSTANCE.rainbow.getValue()) {
         var10005 = Managers.COLORS.getRainbow().getRGB();
         boolean var10006 = false;
      } else {
         var10005 = var1;
      }

      RenderUtil.drawLine(var10000, var10001, var10002, var10003, 1.0F, var10005);
      var10000 = (float)(this.x + this.width);
      var10001 = (float)this.y - 1.5F;
      var10002 = (float)(this.x + this.width);
      var10003 = (float)(this.y + this.height) + var2;
      if (ClickGui.INSTANCE.rainbow.getValue()) {
         var10005 = Managers.COLORS.getRainbow().getRGB();
         boolean var18 = false;
      } else {
         var10005 = var1;
      }

      RenderUtil.drawLine(var10000, var10001, var10002, var10003, 1.0F, var10005);
      var10000 = (float)this.x;
      var10001 = (float)this.y - 1.5F;
      var10002 = (float)(this.x + this.width);
      var10003 = (float)this.y - 1.5F;
      if (ClickGui.INSTANCE.rainbow.getValue()) {
         var10005 = Managers.COLORS.getRainbow().getRGB();
         boolean var19 = false;
      } else {
         var10005 = var1;
      }

      RenderUtil.drawLine(var10000, var10001, var10002, var10003, 1.0F, var10005);
      var10000 = (float)this.x;
      var10001 = (float)(this.y + this.height) + var2;
      var10002 = (float)(this.x + this.width);
      var10003 = (float)(this.y + this.height) + var2;
      if (ClickGui.INSTANCE.rainbow.getValue()) {
         var10005 = ColorUtil.rainbow(500).getRGB();
         boolean var20 = false;
      } else {
         var10005 = var1;
      }

      RenderUtil.drawLine(var10000, var10001, var10002, var10003, 1.0F, var10005);
   }

   public void setY(int var1) {
      this.y = var1;
   }

   private float getTotalItemHeight() {
      float var1 = 0.0F;

      for(Item var3 : this.getItems()) {
         var1 += (float)var3.getHeight() + 1.5F;
         boolean var10000 = false;
      }

      return var1;
   }

   public final ArrayList<Item> getItems() {
      return this.items;
   }

   private void drag(int var1, int var2) {
      if (this.drag) {
         this.x = this.x2 + var1;
         this.y = this.y2 + var2;
      }
   }

   public void drawScreen(int var1, int var2, float var3) {
      this.drag(var1, var2);
      counter1 = new int[]{1};
      float var10000;
      if (this.open) {
         var10000 = this.getTotalItemHeight() - 2.0F;
         boolean var10001 = false;
      } else {
         var10000 = 0.0F;
      }

      float var4 = var10000;
      boolean var27;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var27 = true;
         boolean var59 = false;
      } else {
         var27 = false;
      }

      boolean var5 = var27;
      int var28 = ClickGui.INSTANCE.color.getValue().getRed();
      int var60 = ClickGui.INSTANCE.color.getValue().getGreen();
      int var10002 = ClickGui.INSTANCE.color.getValue().getBlue();
      byte var10003;
      if (var5) {
         var10003 = 99;
         boolean var10004 = false;
      } else {
         var10003 = 120;
      }

      int var6 = ColorUtil.toARGB(var28, var60, var10002, var10003);
      int var29 = this.x;
      var60 = this.y - 1;
      var10002 = this.x + this.width;
      var10003 = this.y + this.height - 6;
      int var76;
      if (ClickGui.INSTANCE.rainbow.getValue()) {
         ColorManager var75 = Managers.COLORS;
         short var10005;
         if (var5) {
            var10005 = 99;
            boolean var10006 = false;
         } else {
            var10005 = 150;
         }

         var76 = var75.getCurrentWithAlpha(var10005);
         boolean var77 = false;
      } else {
         var76 = var6;
      }

      net.minecraft.client.gui.Gui.drawRect(var29, var60, var10002, var10003, var76);
      if (var5) {
         this.drawArrow();
      }

      if (this.open) {
         if (ClickGui.INSTANCE.line.getValue()) {
            if (ClickGui.INSTANCE.rainbow.getValue() && ClickGui.INSTANCE.rollingLine.getValue()) {
               float var7 = (float)ClickGui.INSTANCE.rainbowDelay.getValue().intValue();
               int var8 = Managers.TEXT.scaledHeight;
               float var9 = var7;

               for(int var10 = 0; var10 <= var8; ++var10) {
                  this.colorMap.put(var10, Color.HSBtoRGB(var9, (float)ClickGui.INSTANCE.rainbowSaturation.getValue().intValue() / 255.0F, 1.0F));
                  boolean var30 = false;
                  var9 += 1.0F / (float)var8 * 5.0F;
                  boolean var31 = false;
               }

               GL11.glLineWidth(1.0F);
               GlStateManager.disableTexture2D();
               GlStateManager.enableBlend();
               GlStateManager.disableAlpha();
               GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
               GlStateManager.shadeModel(7425);
               GL11.glBegin(1);
               Color var20 = new Color(Managers.COLORS.getCurrentWithAlpha(150));
               GL11.glColor4f(
                  (float)var20.getRed() / 255.0F, (float)var20.getGreen() / 255.0F, (float)var20.getBlue() / 255.0F, (float)var20.getAlpha() / 255.0F
               );
               GL11.glVertex3f((float)(this.x + this.width), (float)this.y - 1.5F, 0.0F);
               GL11.glVertex3f((float)this.x, (float)this.y - 1.5F, 0.0F);
               GL11.glVertex3f((float)this.x, (float)this.y - 1.5F, 0.0F);
               float var11 = (float)this.getHeight() - 1.5F;

               for(Item var13 : this.getItems()) {
                  Color var33;
                  if (ClickGui.INSTANCE.rainbowMode.getValue() != ClickGui.Rainbow.NORMAL) {
                     var10000 = (float)this.y;
                     var11 += (float)var13.getHeight() + 1.5F;
                     var33 = ColorUtil.rainbow(MathUtil.clamp((int)(var10000 + var11), 0, Managers.TEXT.scaledHeight));
                     boolean var62 = false;
                  } else {
                     Map var68 = this.colorMap;
                     float var72 = (float)this.y;
                     var11 += (float)var13.getHeight() + 1.5F;
                     var33 = new Color(var68.get(MathUtil.clamp((int)(var72 + var11), 0, Managers.TEXT.scaledHeight)));
                  }

                  var20 = var33;
                  GL11.glColor4f(
                     (float)var20.getRed() / 255.0F, (float)var20.getGreen() / 255.0F, (float)var20.getBlue() / 255.0F, (float)var20.getAlpha() / 255.0F
                  );
                  GL11.glVertex3f((float)this.x, (float)this.y + var11, 0.0F);
                  GL11.glVertex3f((float)this.x, (float)this.y + var11, 0.0F);
                  boolean var34 = false;
               }

               Color var35;
               if (ClickGui.INSTANCE.rainbowMode.getValue() != ClickGui.Rainbow.NORMAL) {
                  var35 = ColorUtil.rainbow(MathUtil.clamp((int)((float)(this.y + this.height) + var4), 0, Managers.TEXT.scaledHeight));
                  boolean var63 = false;
               } else {
                  var35 = new Color(this.colorMap.get(MathUtil.clamp((int)((float)(this.y + this.height) + var4), 0, Managers.TEXT.scaledHeight)));
               }

               var20 = var35;
               GL11.glColor4f(
                  (float)var20.getRed() / 255.0F, (float)var20.getGreen() / 255.0F, (float)var20.getBlue() / 255.0F, (float)var20.getAlpha() / 255.0F
               );
               GL11.glVertex3f((float)(this.x + this.width), (float)(this.y + this.height) + var4, 0.0F);
               GL11.glVertex3f((float)(this.x + this.width), (float)(this.y + this.height) + var4, 0.0F);

               for(Item var26 : this.getItems()) {
                  Color var37;
                  if (ClickGui.INSTANCE.rainbowMode.getValue() != ClickGui.Rainbow.NORMAL) {
                     var10000 = (float)this.y;
                     var11 -= (float)var26.getHeight() + 1.5F;
                     var37 = ColorUtil.rainbow(MathUtil.clamp((int)(var10000 + var11), 0, Managers.TEXT.scaledHeight));
                     boolean var64 = false;
                  } else {
                     Map var69 = this.colorMap;
                     float var73 = (float)this.y;
                     var11 -= (float)var26.getHeight() + 1.5F;
                     var37 = new Color(var69.get(MathUtil.clamp((int)(var73 + var11), 0, Managers.TEXT.scaledHeight)));
                  }

                  var20 = var37;
                  GL11.glColor4f(
                     (float)var20.getRed() / 255.0F, (float)var20.getGreen() / 255.0F, (float)var20.getBlue() / 255.0F, (float)var20.getAlpha() / 255.0F
                  );
                  GL11.glVertex3f((float)(this.x + this.width), (float)this.y + var11, 0.0F);
                  GL11.glVertex3f((float)(this.x + this.width), (float)this.y + var11, 0.0F);
                  boolean var38 = false;
               }

               var20 = new Color(Managers.COLORS.getCurrentWithAlpha(150));
               GL11.glColor4f(
                  (float)var20.getRed() / 255.0F, (float)var20.getGreen() / 255.0F, (float)var20.getBlue() / 255.0F, (float)var20.getAlpha() / 255.0F
               );
               GL11.glVertex3f((float)(this.x + this.width), (float)this.y - 1.5F, 0.0F);
               GL11.glEnd();
               GlStateManager.shadeModel(7424);
               GlStateManager.disableBlend();
               GlStateManager.enableAlpha();
               GlStateManager.enableTexture2D();
               boolean var39 = false;
            } else {
               this.drawOutline(var6);
            }
         }

         if (ClickGui.INSTANCE.rect.getValue()) {
            int var40;
            if (ClickGui.INSTANCE.colorRect.getValue()) {
               var40 = Managers.COLORS.getCurrentWithAlpha(30);
               boolean var65 = false;
            } else {
               var40 = ColorUtil.toARGB(10, 10, 10, 30);
            }

            int var14 = var40;
            RenderUtil.drawRect((float)this.x, (float)this.y + 12.5F, (float)(this.x + this.width), (float)(this.y + this.height) + var4, var14);
         }
      }

      if (ClickGui.INSTANCE.icon.getValue()) {
         String var15 = this.getName();
         byte var17 = -1;
         switch(var15.hashCode()) {
            case -1901885695:
               if (Integer.valueOf("Player".hashCode()).equals(var15.hashCode())) {
                  var17 = 4;
                  boolean var48 = false;
               }
               break;
            case -1850724938:
               if (Integer.valueOf("Render".hashCode()).equals(var15.hashCode())) {
                  var17 = 2;
                  boolean var47 = false;
               }
               break;
            case -39033649:
               if (Integer.valueOf("Movement".hashCode()).equals(var15.hashCode())) {
                  var17 = 3;
                  boolean var46 = false;
               }
               break;
            case 68597:
               if (Integer.valueOf("Dev".hashCode()).equals(var15.hashCode())) {
                  var17 = 8;
               }
               break;
            case 71895:
               if (Integer.valueOf("HUD".hashCode()).equals(var15.hashCode())) {
                  var17 = 7;
                  boolean var45 = false;
               }
               break;
            case 2398476:
               if (Integer.valueOf("Misc".hashCode()).equals(var15.hashCode())) {
                  var17 = 1;
                  boolean var44 = false;
               }
               break;
            case 355504491:
               if (Integer.valueOf("Exploit".hashCode()).equals(var15.hashCode())) {
                  var17 = 5;
                  boolean var43 = false;
               }
               break;
            case 2021122027:
               if (Integer.valueOf("Client".hashCode()).equals(var15.hashCode())) {
                  var17 = 6;
                  boolean var42 = false;
               }
               break;
            case 2024008468:
               if (Integer.valueOf("Combat".hashCode()).equals(var15.hashCode())) {
                  var17 = 0;
                  boolean var41 = false;
               }
         }

         switch(var17) {
            case 0:
               Managers.TEXT.drawStringIcon("b", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var55 = false;
               break;
            case 1:
               Managers.TEXT.drawStringIcon("[", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var54 = false;
               break;
            case 2:
               Managers.TEXT.drawStringIcon("a", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var53 = false;
               break;
            case 3:
               Managers.TEXT.drawStringIcon("8", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var52 = false;
               break;
            case 4:
               Managers.TEXT.drawStringIcon("5", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var51 = false;
               break;
            case 5:
               Managers.TEXT.drawStringIcon("!", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var50 = false;
               break;
            case 6:
            case 7:
               Managers.TEXT.drawStringIcon("7", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
               boolean var49 = false;
               break;
            case 8:
               Managers.TEXT.drawStringIcon("6", (float)this.x + 3.0F, (float)this.y - 5.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
         }
      }

      TextManager var56 = Managers.TEXT;
      String var66 = this.getName();
      float var70;
      if (ClickGui.INSTANCE.icon.getValue()) {
         var70 = (float)this.x + 17.0F;
         boolean var74 = false;
      } else {
         var70 = (float)this.x + 3.0F;
      }

      var56.drawStringWithShadow(var66, var70, (float)this.y - 4.0F - (float)Gui.INSTANCE.getTextOffset(), -1);
      if (this.open) {
         float var16 = (float)(this.getY() + this.getHeight()) - 3.0F;

         for(Item var19 : this.getItems()) {
            counter1[0]++;
            if (var19.isHidden()) {
               boolean var57 = false;
            } else {
               var19.setLocation((float)this.x + 2.0F, var16);
               var19.setHeight(ClickGui.INSTANCE.getButtonHeight());
               var19.setWidth(this.getWidth() - 4);
               var19.drawScreen(var1, var2, var3);
               var16 += (float)var19.getHeight() + 1.5F;
               boolean var58 = false;
            }
         }
      }
   }

   private static void lambda$mouseReleased$2(int var0, int var1, int var2, Item var3) {
      var3.mouseReleased(var0, var1, var2);
   }

   private static void lambda$mouseClicked$0(Component var0) {
      if (var0.drag) {
         var0.drag = false;
      }
   }

   public void drawArrow() {
      if (!this.open) {
         if (this.angle > 0) {
            this.angle -= 6;
            boolean var10000 = false;
         }
      } else if (this.angle < 180) {
         this.angle += 6;
      }

      GlStateManager.pushMatrix();
      GlStateManager.enableBlend();
      RenderUtil.glColor(new Color(255, 255, 255, 255));
      mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/arrow.png"));
      GlStateManager.translate((float)(this.getX() + this.getWidth() - 7), (float)(this.getY() + 6) - 0.3F, 0.0F);
      GlStateManager.rotate(calculateRotation((float)this.angle), 0.0F, 0.0F, 0.0F);
      RenderUtil.drawModalRect(-5, -5, 0.0F, 0.0F, 10, 10, 10, 10, 10.0F, 10.0F);
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }
}
