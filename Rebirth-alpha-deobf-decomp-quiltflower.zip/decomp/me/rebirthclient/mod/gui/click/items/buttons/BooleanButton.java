package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;

public class BooleanButton extends Button {
   private final Setting setting;
   private int progress = 0;

   @Override
   public boolean getState() {
      return this.setting.getValue();
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }

      if (var3 == 1 && this.isHovering(var1, var2)) {
         Setting var10000 = this.setting;
         boolean var10001;
         if (!this.setting.open) {
            var10001 = true;
            boolean var10002 = false;
         } else {
            var10001 = false;
         }

         var10000.open = var10001;
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }

   @Override
   public int getHeight() {
      return ClickGui.INSTANCE.getButtonHeight() - 1;
   }

   public BooleanButton(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.width = 15;
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.NEW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var22 = false;
      } else {
         var10000 = false;
      }

      boolean var5 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.DOTGOD) {
         var10000 = true;
         boolean var23 = false;
      } else {
         var10000 = false;
      }

      boolean var6 = var10000;
      if (var5) {
         float var11 = this.x;
         float var24 = this.y;
         float var10002 = this.x + (float)this.width + 7.4F;
         float var10003 = this.y + (float)this.height - 0.5F;
         int var10004;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var10004 = Managers.COLORS.getCurrentWithAlpha(99);
               boolean var10005 = false;
            } else {
               var10004 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var49 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var10004 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var50 = false;
         } else {
            var10004 = Managers.COLORS.getCurrentWithAlpha(55);
         }

         RenderUtil.drawRect(var11, var24, var10002, var10003, var10004);
         TextManager var12 = Managers.TEXT;
         String var25;
         if (var4) {
            var25 = this.getName().toLowerCase();
            boolean var32 = false;
         } else {
            var25 = this.getName();
         }

         var10002 = this.x + 2.3F;
         var10003 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var10004 = -1;
            boolean var51 = false;
         } else {
            var10004 = -5592406;
         }

         var12.drawStringWithShadow(var25, var10002, var10003, var10004);
         var10000 = false;
      } else if (var6) {
         float var14 = this.x;
         float var26 = this.y;
         float var34 = this.x + (float)this.width + 7.4F;
         float var40 = this.y + (float)this.height - 0.5F;
         int var45;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var45 = Managers.COLORS.getCurrentWithAlpha(65);
               boolean var52 = false;
            } else {
               var45 = Managers.COLORS.getCurrentWithAlpha(90);
               boolean var53 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var45 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var54 = false;
         } else {
            var45 = Managers.COLORS.getCurrentWithAlpha(55);
         }

         RenderUtil.drawRect(var14, var26, var34, var40, var45);
         TextManager var15 = Managers.TEXT;
         String var27 = this.getName().toLowerCase();
         var34 = this.x + 2.3F;
         var40 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var45 = Managers.COLORS.getCurrentGui(240);
            boolean var55 = false;
         } else {
            var45 = 11579568;
         }

         var15.drawStringWithShadow(var27, var34, var40, var45);
         var10000 = false;
      } else {
         float var17 = this.x;
         float var28 = this.y;
         float var36 = this.x + (float)this.width + 7.4F;
         float var42 = this.y + (float)this.height - 0.5F;
         int var47;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var47 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var56 = false;
            } else {
               var47 = Managers.COLORS.getCurrentWithAlpha(200);
               boolean var57 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var47 = 290805077;
            boolean var58 = false;
         } else {
            var47 = -2007673515;
         }

         RenderUtil.drawRect(var17, var28, var36, var42, var47);
         TextManager var18 = Managers.TEXT;
         String var29;
         if (var4) {
            var29 = this.getName().toLowerCase();
            boolean var37 = false;
         } else {
            var29 = this.getName();
         }

         var36 = this.x + 2.3F;
         var42 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var47 = -1;
            boolean var59 = false;
         } else {
            var47 = -5592406;
         }

         var18.drawStringWithShadow(var29, var36, var42, var47);
      }

      if (this.setting.parent) {
         if (this.setting.open) {
            ++this.progress;
         }

         if (var5) {
            if (!this.setting.open) {
               this.progress = 0;
            }

            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/gear.png"));
            GlStateManager.translate(this.getX() + (float)this.getWidth() - 6.7F + 8.0F, this.getY() + 7.7F - 0.3F, 0.0F);
            GlStateManager.rotate(Component.calculateRotation((float)this.progress), 0.0F, 0.0F, 1.0F);
            RenderUtil.drawModalRect(-5, -5, 0.0F, 0.0F, 10, 10, 10, 10, 10.0F, 10.0F);
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
            var10000 = false;
         } else {
            String var20;
            if (!this.getState() && !var4) {
               var20 = String.valueOf(new StringBuilder().append("").append(ChatFormatting.GRAY));
            } else {
               var20 = "";
               boolean var30 = false;
            }

            String var7 = var20;
            String var21;
            if (this.setting.open) {
               var21 = "-";
               boolean var31 = false;
            } else {
               var21 = "+";
            }

            String var8 = var21;
            Managers.TEXT
               .drawStringWithShadow(
                  String.valueOf(new StringBuilder().append(var7).append(var8)),
                  this.x - 1.5F + (float)this.width - 7.4F + 8.0F,
                  this.y - 2.2F - (float)Gui.INSTANCE.getTextOffset(),
                  -1
               );
         }
      }
   }

   @Override
   public void toggle() {
      Setting var10000 = this.setting;
      boolean var10001;
      if (!this.setting.getValue()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      var10000.setValue(var10001);
   }
}
