package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;

public class BindButton extends Button {
   private final Setting setting;
   public boolean isListening;

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }
   }

   @Override
   public void toggle() {
      boolean var10001;
      if (!this.isListening) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.isListening = var10001;
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() != ClickGui.Style.NEW && ClickGui.INSTANCE.style.getValue() != ClickGui.Style.DOTGOD) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      boolean var4 = var10000;
      int var5 = ColorUtil.toARGB(
         ClickGui.INSTANCE.color.getValue().getRed(), ClickGui.INSTANCE.color.getValue().getGreen(), ClickGui.INSTANCE.color.getValue().getBlue(), 255
      );
      float var6 = this.x;
      float var9 = this.y;
      float var10002 = this.x + (float)this.width + 7.4F;
      float var10003 = this.y + (float)this.height - 0.5F;
      int var10004;
      if (this.getState()) {
         if (!this.isHovering(var1, var2)) {
            var10004 = 290805077;
            boolean var10005 = false;
         } else {
            var10004 = -2007673515;
            boolean var17 = false;
         }
      } else if (!this.isHovering(var1, var2)) {
         var10004 = Managers.COLORS.getCurrentGui(200);
         boolean var18 = false;
      } else {
         var10004 = Managers.COLORS.getCurrentGui(90);
      }

      RenderUtil.drawRect(var6, var9, var10002, var10003, var10004);
      if (this.isListening) {
         Managers.TEXT.drawStringWithShadow("Press a Key...", this.x + 2.3F, this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset(), -1);
         var10000 = false;
      } else {
         TextManager var8 = Managers.TEXT;
         StringBuilder var10 = new StringBuilder();
         String var12;
         if (var4) {
            var12 = this.setting.getName().toLowerCase();
            boolean var14 = false;
         } else {
            var12 = this.setting.getName();
         }

         String var11 = String.valueOf(var10.append(var12).append(" ").append(ChatFormatting.GRAY).append(this.setting.getValue().toString().toUpperCase()));
         var10002 = this.x + 2.3F;
         var10003 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var10004 = -1;
            boolean var19 = false;
         } else {
            var10004 = -5592406;
         }

         var8.drawStringWithShadow(var11, var10002, var10003, var10004);
      }
   }

   @Override
   public int getHeight() {
      return ClickGui.INSTANCE.getButtonHeight() - 1;
   }

   public BindButton(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.width = 15;
   }

   @Override
   public void onKeyTyped(char var1, int var2) {
      if (this.isListening) {
         Bind var3 = new Bind(var2);
         if (Integer.valueOf("Escape".toUpperCase().hashCode()).equals(var3.toString().toUpperCase().hashCode())) {
            return;
         }

         if (Integer.valueOf("Delete".toUpperCase().hashCode()).equals(var3.toString().toUpperCase().hashCode())) {
            var3 = new Bind(-1);
         }

         this.setting.setValue(var3);
         this.onMouseClick();
      }
   }

   @Override
   public boolean getState() {
      boolean var10000;
      if (!this.isListening) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }
}
