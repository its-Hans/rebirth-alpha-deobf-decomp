package me.rebirthclient.mod.gui.click.items.other;

import java.util.Random;
import me.rebirthclient.api.util.render.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

public class Snow {
   private int x;
   private int y;
   private int fallingSpeed;
   private int size;

   public void drawSnow(ScaledResolution var1) {
      RenderUtil.drawRect((float)this.getX(), (float)this.getY(), (float)(this.getX() + this.size), (float)(this.getY() + this.size), -1714829883);
      this.setY(this.getY() + this.fallingSpeed);
      if (this.getY() > var1.getScaledHeight() + 10 || this.getY() < -10) {
         this.setY(-10);
         Random var2 = new Random();
         this.fallingSpeed = var2.nextInt(10) + 1;
         this.size = var2.nextInt(4) + 1;
      }
   }

   public void setY(int var1) {
      this.y = var1;
   }

   public int getY() {
      return this.y;
   }

   public Snow(int var1, int var2, int var3, int var4) {
      this.x = var1;
      this.y = var2;
      this.fallingSpeed = var3;
      this.size = var4;
   }

   public int getX() {
      return this.x;
   }

   public void setX(int var1) {
      this.x = var1;
   }
}
