package me.rebirthclient.mod.gui.click.items.buttons;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.gui.click.items.Item;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;

public class Button extends Item {
   private boolean state;

   public boolean getState() {
      return this.state;
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.NEW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var20 = false;
      } else {
         var10000 = false;
      }

      boolean var5 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.DOTGOD) {
         var10000 = true;
         boolean var21 = false;
      } else {
         var10000 = false;
      }

      boolean var6 = var10000;
      if (var4) {
         float var9 = this.x;
         float var22 = this.y;
         float var10002 = this.x + (float)this.width;
         float var10003 = this.y + (float)this.height - 0.5F;
         int var10004;
         if (!this.isHovering(var1, var2)) {
            var10004 = 290805077;
            boolean var10005 = false;
         } else {
            var10004 = -2007673515;
         }

         RenderUtil.drawRect(var9, var22, var10002, var10003, var10004);
         TextManager var10 = Managers.TEXT;
         String var23 = this.getName();
         var10002 = this.x + 2.3F;
         var10003 = this.y - 2.0F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var10004 = Managers.COLORS.getCurrentGui(240);
            boolean var51 = false;
         } else {
            var10004 = -1;
         }

         var10.drawStringWithShadow(var23, var10002, var10003, var10004);
         var10000 = false;
      } else if (var6) {
         float var12 = this.x;
         float var24 = this.y;
         float var31 = this.x + (float)this.width;
         float var38 = this.y + (float)this.height - 0.5F;
         int var45;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var45 = Managers.COLORS.getCurrentWithAlpha(65);
               boolean var52 = false;
            } else {
               var45 = Managers.COLORS.getCurrentWithAlpha(90);
               boolean var53 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var45 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var54 = false;
         } else {
            var45 = Managers.COLORS.getCurrentWithAlpha(35);
         }

         RenderUtil.drawRect(var12, var24, var31, var38, var45);
         TextManager var13 = Managers.TEXT;
         String var25 = this.getName();
         var31 = this.x + 2.3F;
         var38 = this.y - 2.0F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var45 = Managers.COLORS.getCurrentGui(240);
            boolean var55 = false;
         } else {
            var45 = 11579568;
         }

         var13.drawStringWithShadow(var25, var31, var38, var45);
         var10000 = false;
      } else if (var5) {
         float var15 = this.x;
         float var26 = this.y;
         float var33 = this.x + (float)this.width;
         float var40 = this.y + (float)this.height - 0.5F;
         int var47;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var47 = Managers.COLORS.getCurrentWithAlpha(99);
               boolean var56 = false;
            } else {
               var47 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var57 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var47 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var58 = false;
         } else {
            var47 = Managers.COLORS.getCurrentWithAlpha(55);
         }

         RenderUtil.drawRect(var15, var26, var33, var40, var47);
         TextManager var16 = Managers.TEXT;
         String var27 = this.getName();
         var33 = this.x + 2.3F;
         var40 = this.y - 2.0F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var47 = -1;
            boolean var59 = false;
         } else {
            var47 = -5592406;
         }

         var16.drawStringWithShadow(var27, var33, var40, var47);
         var10000 = false;
      } else {
         float var18 = this.x;
         float var28 = this.y;
         float var35 = this.x + (float)this.width;
         float var42 = this.y + (float)this.height - 0.5F;
         int var49;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var49 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var60 = false;
            } else {
               var49 = Managers.COLORS.getCurrentWithAlpha(200);
               boolean var61 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var49 = 290805077;
            boolean var62 = false;
         } else {
            var49 = -2007673515;
         }

         RenderUtil.drawRect(var18, var28, var35, var42, var49);
         TextManager var19 = Managers.TEXT;
         String var29 = this.getName();
         var35 = this.x + 2.3F;
         var42 = this.y - 2.0F - (float)Gui.INSTANCE.getTextOffset();
         if (this.getState()) {
            var49 = -1;
            boolean var63 = false;
         } else {
            var49 = -5592406;
         }

         var19.drawStringWithShadow(var29, var35, var42, var49);
      }
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      if (var3 == 0 && this.isHovering(var1, var2)) {
         this.onMouseClick();
      }
   }

   @Override
   public int getHeight() {
      return ClickGui.INSTANCE.getButtonHeight() - 1;
   }

   public boolean isHovering(int var1, int var2) {
      for(Component var4 : Gui.INSTANCE.getComponents()) {
         if (var4.drag) {
            return false;
         }

         boolean var10000 = false;
      }

      boolean var5;
      if ((float)var1 >= this.getX()
         && (float)var1 <= this.getX() + (float)this.getWidth()
         && (float)var2 >= this.getY()
         && (float)var2 <= this.getY() + (float)this.height) {
         var5 = true;
         boolean var10001 = false;
      } else {
         var5 = false;
      }

      return var5;
   }

   public void toggle() {
   }

   public Button(String var1) {
      super(var1);
      this.height = ClickGui.INSTANCE.getButtonHeight();
   }

   public void onMouseClick() {
      boolean var10001;
      if (!this.state) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.state = var10001;
      this.toggle();
      mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
   }
}
