package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ChatAllowedCharacters;

public class StringButton extends Button {
   public boolean isListening;
   private final Setting setting;
   private StringButton.CurrentString currentString = new StringButton.CurrentString("");

   private void enterString() {
      if (this.currentString.getString().isEmpty()) {
         this.setting.setValue(this.setting.getDefaultValue());
         boolean var10000 = false;
      } else {
         this.setting.setValue(this.currentString.getString());
      }

      this.setString(String.valueOf(new StringBuilder().append(this.setting.getValue().toString()).append("1")));
      this.onMouseClick();
   }

   @Override
   public int getHeight() {
      return ClickGui.INSTANCE.getButtonHeight() - 1;
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.DOTGOD) {
         var10000 = true;
         boolean var14 = false;
      } else {
         var10000 = false;
      }

      boolean var5 = var10000;
      if (var4) {
         float var7 = this.x;
         float var15 = this.y;
         float var10002 = this.x + (float)this.width + 7.4F;
         float var10003 = this.y + (float)this.height - 0.5F;
         int var10004;
         if (!this.isHovering(var1, var2)) {
            var10004 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var10005 = false;
         } else {
            var10004 = Managers.COLORS.getCurrentWithAlpha(90);
         }

         RenderUtil.drawRect(var7, var15, var10002, var10003, var10004);
         var10000 = false;
      } else if (var5) {
         float var9 = this.x;
         float var16 = this.y;
         float var19 = this.x + (float)this.width + 7.4F;
         float var22 = this.y + (float)this.height - 0.5F;
         int var25;
         if (!this.isHovering(var1, var2)) {
            var25 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var28 = false;
         } else {
            var25 = Managers.COLORS.getCurrentWithAlpha(120);
         }

         RenderUtil.drawRect(var9, var16, var19, var22, var25);
         var10000 = false;
      } else if (this.isHovering(var1, var2)) {
         RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4F, this.y + (float)this.height - 0.5F, Managers.COLORS.getCurrentWithAlpha(200));
      }

      RenderUtil.drawRect(
         this.x,
         this.y + (float)this.height - 0.5F,
         this.x + (float)this.width + 7.4F,
         this.y + (float)this.height - 1.5F,
         new Color(255, 255, 255, 200).getRGB()
      );
      if (this.isListening) {
         TextManager var11 = Managers.TEXT;
         String var17 = String.valueOf(new StringBuilder().append(this.currentString.getString()).append(Managers.TEXT.getIdleSign()));
         float var20 = this.x + 2.3F;
         float var23 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
         int var26;
         if (this.getState()) {
            var26 = -1;
            boolean var29 = false;
         } else {
            var26 = -5592406;
         }

         var11.drawStringWithShadow(var17, var20, var23, var26);
         var10000 = false;
      } else {
         TextManager var13 = Managers.TEXT;
         String var18 = String.valueOf(
            new StringBuilder().append(this.setting.getName()).append(" ").append(ChatFormatting.GRAY).append(this.setting.getValue())
         );
         float var21 = this.x + 2.3F;
         float var24 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
         int var27;
         if (this.getState()) {
            var27 = -1;
            boolean var30 = false;
         } else {
            var27 = -5592406;
         }

         var13.drawStringWithShadow(var18, var21, var24, var27);
      }
   }

   @Override
   public void onKeyTyped(char var1, int var2) {
      if (this.isListening) {
         switch(var2) {
            case 1:
               return;
            case 28:
               this.enterString();
            case 14:
               this.setString(removeLastChar(this.currentString.getString()));
            default:
               if (ChatAllowedCharacters.isAllowedCharacter(var1)) {
                  this.setString(String.valueOf(new StringBuilder().append(this.currentString.getString()).append(var1)));
               }
         }
      }
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }
   }

   @Override
   public void toggle() {
      boolean var10001;
      if (!this.isListening) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.isListening = var10001;
   }

   public void setString(String var1) {
      this.currentString = new StringButton.CurrentString(var1);
   }

   @Override
   public boolean getState() {
      boolean var10000;
      if (!this.isListening) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public StringButton(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.width = 15;
   }

   public static String removeLastChar(String var0) {
      String var1 = "";
      if (var0 != null && var0.length() > 0) {
         var1 = var0.substring(0, var0.length() - 1);
      }

      return var1;
   }

   public static class CurrentString {
      private final String string;

      public String getString() {
         return this.string;
      }

      public CurrentString(String var1) {
         this.string = var1;
      }
   }
}
