package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Setting;
import org.lwjgl.input.Mouse;

public class Slider extends Button {
   private final Number min;
   private float renderWidth;
   private float prevRenderWidth;
   private final int difference;
   private final Number max;
   public final Setting setting;

   private float part() {
      return ((Number)this.setting.getValue()).floatValue() - this.min.floatValue();
   }

   @Override
   public boolean isHovering(int var1, int var2) {
      for(Component var4 : Gui.INSTANCE.getComponents()) {
         if (var4.drag) {
            return false;
         }

         boolean var10000 = false;
      }

      boolean var5;
      if ((float)var1 >= this.getX()
         && (float)var1 <= this.getX() + (float)this.getWidth() + 8.0F
         && (float)var2 >= this.getY()
         && (float)var2 <= this.getY() + (float)this.height) {
         var5 = true;
         boolean var10001 = false;
      } else {
         var5 = false;
      }

      return var5;
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.NEW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var20 = false;
      } else {
         var10000 = false;
      }

      boolean var5 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.DOTGOD) {
         var10000 = true;
         boolean var21 = false;
      } else {
         var10000 = false;
      }

      boolean var6 = var10000;
      this.dragSetting(var1, var2);
      this.setRenderWidth(this.x + ((float)this.width + 7.4F) * this.partialMultiplier());
      float var9 = this.x;
      float var22 = this.y;
      float var10002 = this.x + (float)this.width + 7.4F;
      float var10003 = this.y + (float)this.height - 0.5F;
      int var10004;
      if (!this.isHovering(var1, var2)) {
         var10004 = 290805077;
         boolean var10005 = false;
      } else {
         var10004 = -2007673515;
      }

      RenderUtil.drawRect(var9, var22, var10002, var10003, var10004);
      if (var5) {
         float var10 = this.x;
         var22 = this.y;
         if (((Number)this.setting.getValue()).floatValue() <= this.min.floatValue()) {
            var10002 = this.x;
            boolean var37 = false;
         } else {
            var10002 = this.getRenderWidth();
         }

         var10003 = this.y + (float)this.height - 0.5F;
         if (!this.isHovering(var1, var2)) {
            var10004 = Managers.COLORS.getCurrentWithAlpha(99);
            boolean var50 = false;
         } else {
            var10004 = Managers.COLORS.getCurrentWithAlpha(120);
         }

         RenderUtil.drawRect(var10, var22, var10002, var10003, var10004);
         var10000 = false;
      } else if (var6) {
         float var12 = this.x;
         var22 = this.y;
         if (((Number)this.setting.getValue()).floatValue() <= this.min.floatValue()) {
            var10002 = this.x;
            boolean var39 = false;
         } else {
            var10002 = this.getRenderWidth();
         }

         var10003 = this.y + (float)this.height - 0.5F;
         if (!this.isHovering(var1, var2)) {
            var10004 = Managers.COLORS.getCurrentWithAlpha(65);
            boolean var51 = false;
         } else {
            var10004 = Managers.COLORS.getCurrentWithAlpha(90);
         }

         RenderUtil.drawRect(var12, var22, var10002, var10003, var10004);
         var10000 = false;
      } else {
         if (this.isHovering(var1, var2) && Mouse.isButtonDown(0)) {
            float var15 = this.x;
            var22 = this.y;
            if (((Number)this.setting.getValue()).floatValue() <= this.min.floatValue()) {
               var10002 = this.x;
               boolean var43 = false;
            } else {
               var10002 = this.getRenderWidth();
            }

            RenderUtil.drawHGradientRect(
               var15,
               var22,
               var10002,
               this.y + (float)this.height - 0.5F,
               ColorUtil.pulseColor(
                     new Color(
                        ClickGui.INSTANCE.color.getValue().getRed(),
                        ClickGui.INSTANCE.color.getValue().getGreen(),
                        ClickGui.INSTANCE.color.getValue().getBlue(),
                        200
                     ),
                     50,
                     1
                  )
                  .getRGB(),
               ColorUtil.pulseColor(
                     new Color(
                        ClickGui.INSTANCE.color.getValue().getRed(),
                        ClickGui.INSTANCE.color.getValue().getGreen(),
                        ClickGui.INSTANCE.color.getValue().getBlue(),
                        200
                     ),
                     50,
                     1000
                  )
                  .getRGB()
            );
            var10000 = false;
         } else {
            float var14 = this.x;
            var22 = this.y;
            if (((Number)this.setting.getValue()).floatValue() <= this.min.floatValue()) {
               var10002 = this.x;
               boolean var41 = false;
            } else {
               var10002 = this.getRenderWidth();
            }

            var10003 = this.y + (float)this.height - 0.5F;
            if (!this.isHovering(var1, var2)) {
               var10004 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var52 = false;
            } else {
               var10004 = Managers.COLORS.getCurrentWithAlpha(200);
            }

            RenderUtil.drawRect(var14, var22, var10002, var10003, var10004);
         }

         RenderUtil.drawLine(this.x + 1.0F, this.y, this.x + 1.0F, this.y + (float)this.height - 0.5F, 0.9F, Managers.COLORS.getCurrentWithAlpha(255));
      }

      if (var6) {
         TextManager var17 = Managers.TEXT;
         StringBuilder var27 = new StringBuilder().append(this.getName().toLowerCase()).append(":").append(" ").append(ChatFormatting.GRAY);
         Object var34;
         if (this.setting.getValue() instanceof Float) {
            var34 = this.setting.getValue();
            boolean var44 = false;
         } else {
            var34 = ((Number)this.setting.getValue()).doubleValue();
         }

         var17.drawStringWithShadow(
            String.valueOf(var27.append(var34)), this.x + 2.3F, this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset(), Managers.COLORS.getCurrentGui(240)
         );
         var10000 = false;
      } else {
         TextManager var19 = Managers.TEXT;
         StringBuilder var28 = new StringBuilder();
         String var35;
         if (var4) {
            var35 = String.valueOf(new StringBuilder().append(this.getName().toLowerCase()).append(":"));
            boolean var45 = false;
         } else {
            var35 = this.getName();
         }

         StringBuilder var29 = var28.append(var35).append(" ").append(ChatFormatting.GRAY);
         Object var36;
         if (this.setting.getValue() instanceof Float) {
            var36 = this.setting.getValue();
            boolean var46 = false;
         } else {
            var36 = ((Number)this.setting.getValue()).doubleValue();
         }

         var19.drawStringWithShadow(String.valueOf(var29.append(var36)), this.x + 2.3F, this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset(), -1);
      }
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }

   private float partialMultiplier() {
      return this.part() / this.middle();
   }

   private void dragSetting(int var1, int var2) {
      if (this.isHovering(var1, var2) && Mouse.isButtonDown(0)) {
         this.setSettingFromX(var1);
      }
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (this.isHovering(var1, var2)) {
         this.setSettingFromX(var1);
      }
   }

   public Slider(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.min = (Number)var1.getMinValue();
      this.max = (Number)var1.getMaxValue();
      this.difference = this.max.intValue() - this.min.intValue();
      this.width = 15;
   }

   private void setSettingFromX(int var1) {
      float var2 = ((float)var1 - this.x) / ((float)this.width + 7.4F);
      if (this.setting.getValue() instanceof Double) {
         double var3 = this.setting.getMinValue() + (double)((float)this.difference * var2);
         this.setting.setValue((double)Math.round(10.0 * var3) / 10.0);
         boolean var10000 = false;
      } else if (this.setting.getValue() instanceof Float) {
         float var5 = this.setting.getMinValue() + (float)this.difference * var2;
         this.setting.setValue((float)Math.round(10.0F * var5) / 10.0F);
         boolean var6 = false;
      } else if (this.setting.getValue() instanceof Integer) {
         this.setting.setValue(this.setting.getMinValue() + (int)((float)this.difference * var2));
      }
   }

   private float middle() {
      return this.max.floatValue() - this.min.floatValue();
   }

   @Override
   public int getHeight() {
      return ClickGui.INSTANCE.getButtonHeight() - 1;
   }

   public void setRenderWidth(float var1) {
      if (this.renderWidth != var1) {
         this.prevRenderWidth = this.renderWidth;
         this.renderWidth = var1;
      }
   }

   public float getRenderWidth() {
      if (Managers.FPS.getFPS() < 20) {
         return this.renderWidth;
      } else {
         this.renderWidth = this.prevRenderWidth
            + (this.renderWidth - this.prevRenderWidth) * mc.getRenderPartialTicks() / (8.0F * ((float)Math.min(240, Managers.FPS.getFPS()) / 240.0F));
         return this.renderWidth;
      }
   }
}
