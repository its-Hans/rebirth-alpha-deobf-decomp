package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Objects;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;

public class EnumButton extends Button {
   public final Setting setting;

   @Override
   public boolean getState() {
      return true;
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() != ClickGui.Style.NEW && ClickGui.INSTANCE.style.getValue() != ClickGui.Style.DOTGOD) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      boolean var4 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var24 = false;
      } else {
         var10000 = false;
      }

      boolean var5 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.DOTGOD) {
         var10000 = true;
         boolean var25 = false;
      } else {
         var10000 = false;
      }

      boolean var6 = var10000;
      if (var5) {
         float var15 = this.x;
         float var26 = this.y;
         float var10002 = this.x + (float)this.width + 7.4F;
         float var10003 = this.y + (float)this.height - 0.5F;
         int var10004;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var10004 = Managers.COLORS.getCurrentWithAlpha(99);
               boolean var10005 = false;
            } else {
               var10004 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var49 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var10004 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var50 = false;
         } else {
            var10004 = Managers.COLORS.getCurrentWithAlpha(55);
         }

         RenderUtil.drawRect(var15, var26, var10002, var10003, var10004);
         var10000 = false;
      } else if (var6) {
         float var17 = this.x;
         float var27 = this.y;
         float var34 = this.x + (float)this.width + 7.4F;
         float var40 = this.y + (float)this.height - 0.5F;
         int var46;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var46 = Managers.COLORS.getCurrentWithAlpha(65);
               boolean var51 = false;
            } else {
               var46 = Managers.COLORS.getCurrentWithAlpha(90);
               boolean var52 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var46 = Managers.COLORS.getCurrentWithAlpha(26);
            boolean var53 = false;
         } else {
            var46 = Managers.COLORS.getCurrentWithAlpha(35);
         }

         RenderUtil.drawRect(var17, var27, var34, var40, var46);
         var10000 = false;
      } else {
         float var19 = this.x;
         float var28 = this.y;
         float var35 = this.x + (float)this.width + 7.4F;
         float var41 = this.y + (float)this.height - 0.5F;
         int var47;
         if (this.getState()) {
            if (!this.isHovering(var1, var2)) {
               var47 = Managers.COLORS.getCurrentWithAlpha(120);
               boolean var54 = false;
            } else {
               var47 = Managers.COLORS.getCurrentWithAlpha(200);
               boolean var55 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var47 = 290805077;
            boolean var56 = false;
         } else {
            var47 = -2007673515;
         }

         RenderUtil.drawRect(var19, var28, var35, var41, var47);
      }

      TextManager var20 = Managers.TEXT;
      StringBuilder var29 = new StringBuilder();
      String var36;
      if (var4) {
         var36 = String.valueOf(new StringBuilder().append(this.setting.getName().toLowerCase()).append(":"));
         boolean var42 = false;
      } else {
         var36 = this.setting.getName();
      }

      var29 = var29.append(var36).append(" ").append(ChatFormatting.GRAY);
      if (Integer.valueOf("ABC".toUpperCase().hashCode()).equals(this.setting.getCurrentEnumName().toUpperCase().hashCode())) {
         var36 = "ABC";
         boolean var43 = false;
      } else {
         var36 = this.setting.getCurrentEnumName();
      }

      String var31 = String.valueOf(var29.append(var36));
      float var38 = this.x + 2.3F;
      float var44 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
      int var48;
      if (this.getState()) {
         var48 = -1;
         boolean var57 = false;
      } else {
         var48 = -5592406;
      }

      var20.drawStringWithShadow(var31, var38, var44, var48);
      int var7 = (int)this.y;
      if (this.setting.open) {
         for(Object var11 : this.setting.getValue().getClass().getEnumConstants()) {
            var7 += 12;
            String var21;
            if (!Objects.equals(var11.toString(), "ABC")) {
               var21 = String.valueOf(
                  new StringBuilder().append(Character.toUpperCase(var11.toString().charAt(0))).append(var11.toString().toLowerCase().substring(1))
               );
               boolean var32 = false;
            } else {
               var21 = var11.toString();
            }

            String var12 = var21;
            TextManager var22 = Managers.TEXT;
            var29 = new StringBuilder();
            ChatFormatting var39;
            if (Integer.valueOf(var12.hashCode()).equals(this.setting.getCurrentEnumName().hashCode())) {
               var39 = ChatFormatting.WHITE;
               boolean var45 = false;
            } else {
               var39 = ChatFormatting.GRAY;
            }

            var22.drawStringWithShadow(
               String.valueOf(var29.append(var39).append(var12)),
               (float)this.width / 2.0F - (float)Managers.TEXT.getStringWidth(var12) / 2.0F + 2.0F + this.x,
               (float)var7 + 6.0F - (float)mc.fontRenderer.FONT_HEIGHT / 2.0F + 3.5F,
               -1
            );
            var10000 = false;
         }
      }
   }

   @Override
   public int getHeight() {
      return ClickGui.INSTANCE.getButtonHeight() - 1;
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }

      if (var3 == 1 && this.isHovering(var1, var2)) {
         Setting var10000 = this.setting;
         boolean var10001;
         if (!this.setting.open) {
            var10001 = true;
            boolean var10002 = false;
         } else {
            var10001 = false;
         }

         var10000.open = var10001;
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }

      if (this.setting.open) {
         for(Object var7 : this.setting.getValue().getClass().getEnumConstants()) {
            this.y += 12.0F;
            if ((float)var1 > this.x && (float)var1 < this.x + (float)this.width && (float)var2 > this.y && (float)var2 < this.y + 12.0F + 3.5F && var3 == 0) {
               this.setting.setEnumValue(String.valueOf(var7));
               mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
            }

            boolean var8 = false;
         }
      }
   }

   @Override
   public void toggle() {
      this.setting.increaseEnum();
   }

   public EnumButton(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.width = 15;
   }
}
