package me.rebirthclient.mod.gui.click.items.buttons;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.Objects;
import me.rebirthclient.Rebirth;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.init.SoundEvents;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class PickerButton extends Button {
   public static final Tessellator tessellator = Tessellator.getInstance();
   private Color finalColor;
   public static final BufferBuilder builder = tessellator.getBuffer();
   boolean pickingAlpha;
   private float hueX;
   private float prevAlphaX;
   private float alphaX;
   private float prevHueX;
   boolean pickingColor;
   final Setting setting;
   boolean pickingHue;

   public static void drawLeftGradientRect(int var0, int var1, int var2, int var3, int var4, int var5) {
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      builder.begin(7, DefaultVertexFormats.POSITION_COLOR);
      builder.pos((double)var2, (double)var1, 0.0)
         .color(
            (float)(var5 >> 24 & 0xFF) / 255.0F, (float)(var5 >> 16 & 0xFF) / 255.0F, (float)(var5 >> 8 & 0xFF) / 255.0F, (float)(var5 >> 24 & 0xFF) / 255.0F
         )
         .endVertex();
      builder.pos((double)var0, (double)var1, 0.0)
         .color((float)(var4 >> 16 & 0xFF) / 255.0F, (float)(var4 >> 8 & 0xFF) / 255.0F, (float)(var4 & 0xFF) / 255.0F, (float)(var4 >> 24 & 0xFF) / 255.0F)
         .endVertex();
      builder.pos((double)var0, (double)var3, 0.0)
         .color((float)(var4 >> 16 & 0xFF) / 255.0F, (float)(var4 >> 8 & 0xFF) / 255.0F, (float)(var4 & 0xFF) / 255.0F, (float)(var4 >> 24 & 0xFF) / 255.0F)
         .endVertex();
      builder.pos((double)var2, (double)var3, 0.0)
         .color(
            (float)(var5 >> 24 & 0xFF) / 255.0F, (float)(var5 >> 16 & 0xFF) / 255.0F, (float)(var5 >> 8 & 0xFF) / 255.0F, (float)(var5 >> 24 & 0xFF) / 255.0F
         )
         .endVertex();
      tessellator.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }

   public void setAlphaX(float var1) {
      if (this.alphaX != var1) {
         this.prevAlphaX = this.alphaX;
         this.alphaX = var1;
      }
   }

   public float getAlphaX() {
      if (Managers.FPS.getFPS() < 20) {
         return this.alphaX;
      } else {
         this.alphaX = this.prevAlphaX
            + (this.alphaX - this.prevAlphaX) * mc.getRenderPartialTicks() / (8.0F * ((float)Math.min(240, Managers.FPS.getFPS()) / 240.0F));
         return this.alphaX;
      }
   }

   public PickerButton(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.finalColor = (Color)var1.getValue();
   }

   public float getHueX() {
      if (Managers.FPS.getFPS() < 20) {
         return this.hueX;
      } else {
         this.hueX = this.prevHueX
            + (this.hueX - this.prevHueX) * mc.getRenderPartialTicks() / (8.0F * ((float)Math.min(240, Managers.FPS.getFPS()) / 240.0F));
         return this.hueX;
      }
   }

   public boolean isInsideRainbow(int var1, int var2) {
      return mouseOver(
         (int)((float)((int)this.x) + 2.3F),
         (int)this.y + 124,
         (int)((float)((int)this.x) + 2.3F) + Managers.TEXT.getStringWidth("rainbow"),
         (int)(this.y + 123.0F) + Managers.TEXT.getFontHeight(),
         var1,
         var2
      );
   }

   public boolean isInsideCopy(int var1, int var2) {
      return mouseOver(
         (int)((float)((int)this.x) + 2.3F),
         (int)this.y + 113,
         (int)((float)((int)this.x) + 2.3F) + Managers.TEXT.getStringWidth("copy"),
         (int)(this.y + 112.0F) + Managers.TEXT.getFontHeight(),
         var1,
         var2
      );
   }

   public void drawHueSlider(int var1, int var2, int var3, int var4, float var5) {
      int var6 = 0;
      if (var4 > var3) {
         RenderUtil.drawRect((float)var1, (float)var2, (float)(var1 + var3), (float)(var2 + 4), -65536);
         var2 += 4;

         for(int var7 = 0; var7 < 6; ++var7) {
            int var8 = Color.HSBtoRGB((float)var6 / 6.0F, 1.0F, 1.0F);
            int var9 = Color.HSBtoRGB((float)(var6 + 1) / 6.0F, 1.0F, 1.0F);
            drawGradientRect(
               (float)var1,
               (float)var2 + (float)var6 * ((float)var4 / 6.0F),
               (float)(var1 + var3),
               (float)var2 + (float)(var6 + 1) * ((float)var4 / 6.0F),
               var8,
               var9,
               false
            );
            ++var6;
            boolean var10000 = false;
         }

         int var11 = (int)((float)var2 + (float)var4 * var5) - 4;
         RenderUtil.drawRect((float)var1, (float)(var11 - 1), (float)(var1 + var3), (float)(var11 + 1), -1);
         drawOutlineRect((double)var1, (double)(var11 - 1), (double)(var1 + var3), (double)(var11 + 1), Color.BLACK, 1.0F);
         boolean var16 = false;
      } else {
         for(int var12 = 0; var12 < 6; ++var12) {
            int var14 = Color.HSBtoRGB((float)var6 / 6.0F, 1.0F, 1.0F);
            int var15 = Color.HSBtoRGB((float)(var6 + 1) / 6.0F, 1.0F, 1.0F);
            gradient(var1 + var6 * (var3 / 6), var2, var1 + (var6 + 1) * (var3 / 6) + 3, var2 + var4, var14, var15, true);
            ++var6;
            boolean var17 = false;
         }

         int var13 = (int)((float)var1 + (float)var3 * var5);
         RenderUtil.drawRect((float)(var13 - 1), (float)var2 - 1.2F, (float)(var13 + 1), (float)(var2 + var4) + 1.2F, -1);
         drawOutlineRect((double)var13 - 1.2, (double)var2 - 1.2, (double)var13 + 1.2, (double)(var2 + var4) + 1.2, Color.BLACK, 0.1F);
      }
   }

   public void drawPicker(Setting var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      float[] var11 = new float[]{0.0F, 0.0F, 0.0F, 0.0F};
      byte var10000 = 4;

      label84: {
         try {
            float[] var27 = new float[var10000];
            var27[0] = Color.RGBtoHSB(((Color)var1.getValue()).getRed(), ((Color)var1.getValue()).getGreen(), ((Color)var1.getValue()).getBlue(), null)[0];
            var27[1] = Color.RGBtoHSB(((Color)var1.getValue()).getRed(), ((Color)var1.getValue()).getGreen(), ((Color)var1.getValue()).getBlue(), null)[1];
            var27[2] = Color.RGBtoHSB(((Color)var1.getValue()).getRed(), ((Color)var1.getValue()).getGreen(), ((Color)var1.getValue()).getBlue(), null)[2];
            var27[3] = (float)((Color)var1.getValue()).getAlpha() / 255.0F;
            var11 = var27;
         } catch (Exception var23) {
            Rebirth.LOGGER.info("rebirth color picker says it's a bad color!");
            break label84;
         }

         boolean var28 = false;
      }

      int var12 = (int)((float)this.width + 7.4F);
      byte var13 = 78;
      int var14 = var12 + 3;
      byte var15 = 7;
      byte var16 = 7;
      if (this.pickingColor && (!Mouse.isButtonDown(0) || !mouseOver(var2, var3, var2 + var12, var3 + var13, var8, var9))) {
         this.pickingColor = false;
      }

      if (this.pickingHue && (!Mouse.isButtonDown(0) || !mouseOver(var4, var5, var4 + var14, var5 + var15, var8, var9))) {
         this.pickingHue = false;
      }

      if (this.pickingAlpha && (!Mouse.isButtonDown(0) || !mouseOver(var6, var7, var6 + var12, var7 + var16, var8, var9))) {
         this.pickingAlpha = false;
      }

      if (Mouse.isButtonDown(0) && mouseOver(var2, var3, var2 + var12, var3 + var13, var8, var9)) {
         this.pickingColor = true;
      }

      if (Mouse.isButtonDown(0) && mouseOver(var4, var5, var4 + var14, var5 + var15, var8, var9)) {
         this.pickingHue = true;
      }

      if (Mouse.isButtonDown(0) && mouseOver(var6, var7, var6 + var12, var7 + var16, var8, var9)) {
         this.pickingAlpha = true;
      }

      if (this.pickingHue) {
         float var10 = (float)Math.min(Math.max(var4, var8), var4 + var14);
         var11[0] = (var10 - (float)var4) / (float)var14;
      }

      if (this.pickingAlpha && !var1.hideAlpha) {
         float var24 = (float)Math.min(Math.max(var6, var8), var6 + var12);
         var11[3] = 1.0F - (var24 - (float)var6) / (float)var12;
      }

      if (this.pickingColor) {
         float var25 = (float)Math.min(Math.max(var2, var8), var2 + var12);
         float var17 = (float)Math.min(Math.max(var3, var9), var3 + var13);
         var11[1] = (var25 - (float)var2) / (float)var12;
         var11[2] = 1.0F - (var17 - (float)var3) / (float)var13;
      }

      int var26 = Color.HSBtoRGB(var11[0], 1.0F, 1.0F);
      float var18 = (float)(var26 >> 16 & 0xFF) / 255.0F;
      float var19 = (float)(var26 >> 8 & 0xFF) / 255.0F;
      float var20 = (float)(var26 & 0xFF) / 255.0F;
      drawPickerBase(var2, var3, var12, var13, var18, var19, var20, var11[3]);
      this.drawHueSlider(var4, var5, var12 + 1, var15, var11[0]);
      int var21 = (int)((float)var2 + var11[1] * (float)var12);
      int var22 = (int)((float)(var3 + var13) - var11[2] * (float)var13);
      if (this.pickingColor) {
         RenderUtil.drawCircle((float)var21, (float)var22, 6.4F, Color.BLACK.getRGB());
         RenderUtil.drawCircle(
            (float)var21, (float)var22, 6.0F, ColorUtil.toARGB(this.finalColor.getRed(), this.finalColor.getGreen(), this.finalColor.getBlue(), 255)
         );
         boolean var29 = false;
      } else {
         RenderUtil.drawCircle((float)var21, (float)var22, 3.4F, Color.BLACK.getRGB());
         RenderUtil.drawCircle((float)var21, (float)var22, 3.0F, -1);
      }

      if (!var1.hideAlpha) {
         this.drawAlphaSlider(var6, var7, var12 - 1, var16, var18, var19, var20, var11[3]);
      }

      this.finalColor = getColor(new Color(Color.HSBtoRGB(var11[0], var11[1], var11[2])), var11[3]);
   }

   public boolean isInsidePaste(int var1, int var2) {
      return mouseOver(
         (int)(this.x + (float)this.width - 2.3F - (float)Managers.TEXT.getStringWidth("paste") + 11.7F - 4.6F),
         (int)this.y + 113,
         (int)(this.x + (float)this.width - 2.3F - (float)Managers.TEXT.getStringWidth("paste") + 11.7F - 4.6F) + Managers.TEXT.getStringWidth("paste"),
         (int)(this.y + 112.0F) + Managers.TEXT.getFontHeight(),
         var1,
         var2
      );
   }

   public static Color getColor(Color var0, float var1) {
      float var2 = (float)var0.getRed() / 255.0F;
      float var3 = (float)var0.getGreen() / 255.0F;
      float var4 = (float)var0.getBlue() / 255.0F;
      return new Color(var2, var3, var4, var1);
   }

   public static String readClipboard() {
      try {
         return (String)Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
      } catch (IOException | UnsupportedFlavorException var1) {
         return null;
      }
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.NEW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var19 = false;
      } else {
         var10000 = false;
      }

      boolean var5 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.DOTGOD) {
         var10000 = true;
         boolean var20 = false;
      } else {
         var10000 = false;
      }

      boolean var6 = var10000;
      float var11 = this.x;
      float var21 = this.y;
      float var10002 = this.x + (float)this.width + 7.4F;
      float var10003 = this.y + (float)this.height - 0.5F;
      int var10004;
      if (!var5 && !var6) {
         if (this.setting.hasBoolean) {
            if (this.setting.booleanValue) {
               if (!this.isHovering(var1, var2)) {
                  var10004 = Managers.COLORS.getCurrentWithAlpha(120);
                  boolean var47 = false;
               } else {
                  var10004 = Managers.COLORS.getCurrentWithAlpha(200);
                  boolean var48 = false;
               }
            } else if (!this.isHovering(var1, var2)) {
               var10004 = 290805077;
               boolean var49 = false;
            } else {
               var10004 = -2007673515;
               boolean var50 = false;
            }
         } else if (!this.isHovering(var1, var2)) {
            var10004 = 290805077;
            boolean var51 = false;
         } else {
            var10004 = -2007673515;
         }
      } else if (this.setting.hasBoolean && this.setting.booleanValue) {
         if (!this.isHovering(var1, var2)) {
            var10004 = Managers.COLORS.getCurrentWithAlpha(65);
            boolean var45 = false;
         } else {
            var10004 = Managers.COLORS.getCurrentWithAlpha(90);
            boolean var46 = false;
         }
      } else if (!this.isHovering(var1, var2)) {
         var10004 = Managers.COLORS.getCurrentWithAlpha(26);
         boolean var10005 = false;
      } else {
         var10004 = Managers.COLORS.getCurrentWithAlpha(55);
         boolean var44 = false;
      }

      RenderUtil.drawRect(var11, var21, var10002, var10003, var10004);
      PickerButton var12 = this;

      label118: {
         try {
            float var13 = var12.x - 1.5F + (float)this.width + 0.6F - 0.5F;
            var21 = this.y + 5.0F;
            var10002 = this.x + (float)this.width + 7.0F - 2.5F;
            var10003 = this.y + (float)this.height - 4.0F;
            if (this.setting.isRainbow && !this.setting.noRainbow) {
               var10004 = ColorUtil.injectAlpha(Managers.COLORS.getRainbow(), this.finalColor.getAlpha()).getRGB();
               boolean var52 = false;
            } else {
               var10004 = this.finalColor.getRGB();
            }

            RenderUtil.drawRect(var13, var21, var10002, var10003, var10004);
         } catch (Exception var8) {
            var8.printStackTrace();
            break label118;
         }

         var10000 = false;
      }

      TextManager var15 = Managers.TEXT;
      String var23;
      if (!var4 && !var6) {
         var23 = this.getName();
      } else {
         var23 = this.getName().toLowerCase();
         boolean var26 = false;
      }

      var10002 = this.x + 2.3F;
      var10003 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
      if (var6 && this.setting.hasBoolean && this.setting.booleanValue) {
         var10004 = Managers.COLORS.getCurrentGui(240);
         boolean var54 = false;
      } else if (var6) {
         var10004 = 11579568;
         boolean var53 = false;
      } else {
         var10004 = -1;
      }

      var15.drawStringWithShadow(var23, var10002, var10003, var10004);
      if (this.setting.open) {
         Setting var24 = this.setting;
         int var28 = (int)this.x;
         int var34 = (int)this.y + 15;
         var10004 = (int)this.x;
         int var55;
         if (this.setting.hideAlpha) {
            var55 = (int)this.y + 100;
            boolean var10006 = false;
         } else {
            var55 = (int)this.y + 103;
         }

         this.drawPicker(var24, var28, var34, var10004, var55, (int)this.x, (int)this.y + 95, var1, var2);
         TextManager var16 = Managers.TEXT;
         var10002 = this.x + 2.3F;
         var10003 = this.y + 113.0F;
         if (this.isInsideCopy(var1, var2)) {
            var10004 = -1;
            boolean var56 = false;
         } else {
            var10004 = -5592406;
         }

         var16.drawStringWithShadow("copy", var10002, var10003, var10004);
         TextManager var17 = Managers.TEXT;
         var10002 = this.x + (float)this.width - 2.3F - (float)Managers.TEXT.getStringWidth("paste") + 11.7F - 4.6F;
         var10003 = this.y + 113.0F;
         if (this.isInsidePaste(var1, var2)) {
            var10004 = -1;
            boolean var57 = false;
         } else {
            var10004 = -5592406;
         }

         var17.drawStringWithShadow("paste", var10002, var10003, var10004);
         if (!this.setting.noRainbow) {
            TextManager var18 = Managers.TEXT;
            var10002 = this.x + 2.3F;
            var10003 = this.y + 124.0F;
            if (this.setting.isRainbow) {
               var10004 = Managers.COLORS.getRainbow().getRGB();
               boolean var58 = false;
            } else if (this.isInsideRainbow(var1, var2)) {
               var10004 = -1;
               boolean var59 = false;
            } else {
               var10004 = -5592406;
            }

            var18.drawStringWithShadow("rainbow", var10002, var10003, var10004);
         }

         this.setting.setValue(this.finalColor);
      }
   }

   public void setHueX(float var1) {
      if (this.hueX != var1) {
         this.prevHueX = this.hueX;
         this.hueX = var1;
      }
   }

   public static int gradientColor(int var0, int var1) {
      int var2 = ((var0 & 0xFF0000) >> 16) * (100 + var1) / 100;
      int var3 = ((var0 & 0xFF00) >> 8) * (100 + var1) / 100;
      int var4 = (var0 & 0xFF) * (100 + var1) / 100;
      return new Color(var2, var3, var4).hashCode();
   }

   public static boolean mouseOver(int var0, int var1, int var2, int var3, int var4, int var5) {
      boolean var10000;
      if (var4 >= var0 && var5 >= var1 && var4 <= var2 && var5 <= var3) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static void drawPickerBase(int var0, int var1, int var2, int var3, float var4, float var5, float var6, float var7) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glShadeModel(7425);
      GL11.glBegin(9);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      GL11.glVertex2f((float)var0, (float)var1);
      GL11.glVertex2f((float)var0, (float)(var1 + var3));
      GL11.glColor4f(var4, var5, var6, var7);
      GL11.glVertex2f((float)(var0 + var2), (float)(var1 + var3));
      GL11.glVertex2f((float)(var0 + var2), (float)var1);
      GL11.glEnd();
      GL11.glDisable(3008);
      GL11.glBegin(9);
      GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glVertex2f((float)var0, (float)var1);
      GL11.glColor4f(0.0F, 0.0F, 0.0F, 1.0F);
      GL11.glVertex2f((float)var0, (float)(var1 + var3));
      GL11.glVertex2f((float)(var0 + var2), (float)(var1 + var3));
      GL11.glColor4f(0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glVertex2f((float)(var0 + var2), (float)var1);
      GL11.glEnd();
      GL11.glEnable(3008);
      GL11.glShadeModel(7424);
      GL11.glEnable(3553);
      GL11.glDisable(3042);
   }

   public void drawAlphaSlider(int var1, int var2, int var3, int var4, float var5, float var6, float var7, float var8) {
      boolean var9 = true;
      int var10 = var4 / 2;

      boolean var15;
      for(int var11 = -var10; var11 < var3; var15 = false) {
         if (!var9) {
            RenderUtil.drawRect((float)(var1 + var11), (float)var2, (float)(var1 + var11 + var10), (float)(var2 + var4), -1);
            RenderUtil.drawRect((float)(var1 + var11), (float)(var2 + var10), (float)(var1 + var11 + var10), (float)(var2 + var4), -7303024);
            if (var11 < var3 - var10) {
               int var12 = var1 + var11 + var10;
               int var13 = Math.min(var1 + var3, var1 + var11 + var10 * 2);
               RenderUtil.drawRect((float)var12, (float)var2, (float)var13, (float)(var2 + var4), -7303024);
               RenderUtil.drawRect((float)var12, (float)(var2 + var10), (float)var13, (float)(var2 + var4), -1);
            }
         }

         if (!var9) {
            var15 = true;
            boolean var10001 = false;
         } else {
            var15 = false;
         }

         var9 = var15;
         var11 += var10;
      }

      drawLeftGradientRect(var1, var2, var1 + var3, var2 + var4, new Color(var5, var6, var7, 1.0F).getRGB(), 0);
      int var14 = (int)((float)(var1 + var3) - (float)var3 * var8);
      RenderUtil.drawRect((float)(var14 - 1), (float)var2 - 1.2F, (float)(var14 + 1), (float)(var2 + var4) + 1.2F, -1);
      drawOutlineRect((double)var14 - 1.2, (double)var2 - 1.2, (double)var14 + 1.2, (double)(var2 + var4) + 1.2, Color.BLACK, 0.1F);
   }

   @Override
   public void mouseReleased(int var1, int var2, int var3) {
      this.pickingAlpha = false;
      this.pickingHue = false;
      this.pickingColor = false;
   }

   public static void drawOutlineRect(double var0, double var2, double var4, double var6, Color var8, float var9) {
      if (var0 < var4) {
         double var10 = var0;
         var0 = var4;
         var4 = var10;
      }

      if (var2 < var6) {
         double var16 = var2;
         var2 = var6;
         var6 = var16;
      }

      float var17 = (float)(var8.getRGB() >> 24 & 0xFF) / 255.0F;
      float var11 = (float)(var8.getRGB() >> 16 & 0xFF) / 255.0F;
      float var12 = (float)(var8.getRGB() >> 8 & 0xFF) / 255.0F;
      float var13 = (float)(var8.getRGB() & 0xFF) / 255.0F;
      Tessellator var14 = Tessellator.getInstance();
      BufferBuilder var15 = var14.getBuffer();
      GlStateManager.enableBlend();
      GL11.glPolygonMode(1032, 6913);
      GL11.glLineWidth(var9);
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.color(var11, var12, var13, var17);
      var15.begin(7, DefaultVertexFormats.POSITION);
      var15.pos(var0, var6, 0.0).endVertex();
      var15.pos(var4, var6, 0.0).endVertex();
      var15.pos(var4, var2, 0.0).endVertex();
      var15.pos(var0, var2, 0.0).endVertex();
      var14.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GL11.glPolygonMode(1032, 6914);
   }

   public static void drawGradientRect(float var0, float var1, float var2, float var3, int var4, int var5, boolean var6) {
      if (var6) {
         var4 = gradientColor(var4, -20);
         var5 = gradientColor(var5, -20);
      }

      float var7 = (float)(var4 >> 24 & 0xFF) / 255.0F;
      float var8 = (float)(var4 >> 16 & 0xFF) / 255.0F;
      float var9 = (float)(var4 >> 8 & 0xFF) / 255.0F;
      float var10 = (float)(var4 & 0xFF) / 255.0F;
      float var11 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var12 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var13 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var14 = (float)(var5 & 0xFF) / 255.0F;
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.disableAlpha();
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.shadeModel(7425);
      Tessellator var15 = Tessellator.getInstance();
      BufferBuilder var16 = var15.getBuffer();
      var16.begin(7, DefaultVertexFormats.POSITION_COLOR);
      var16.pos((double)var2, (double)var1, 0.0).color(var8, var9, var10, var7).endVertex();
      var16.pos((double)var0, (double)var1, 0.0).color(var8, var9, var10, var7).endVertex();
      var16.pos((double)var0, (double)var3, 0.0).color(var12, var13, var14, var11).endVertex();
      var16.pos((double)var2, (double)var3, 0.0).color(var12, var13, var14, var11).endVertex();
      var15.draw();
      GlStateManager.shadeModel(7424);
      GlStateManager.disableBlend();
      GlStateManager.enableAlpha();
      GlStateManager.enableTexture2D();
   }

   public static void gradient(int var0, int var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (var6) {
         float var7 = (float)(var4 >> 24 & 0xFF) / 255.0F;
         float var8 = (float)(var4 >> 16 & 0xFF) / 255.0F;
         float var9 = (float)(var4 >> 8 & 0xFF) / 255.0F;
         float var10 = (float)(var4 & 0xFF) / 255.0F;
         float var11 = (float)(var5 >> 24 & 0xFF) / 255.0F;
         float var12 = (float)(var5 >> 16 & 0xFF) / 255.0F;
         float var13 = (float)(var5 >> 8 & 0xFF) / 255.0F;
         float var14 = (float)(var5 & 0xFF) / 255.0F;
         GL11.glEnable(3042);
         GL11.glDisable(3553);
         GL11.glBlendFunc(770, 771);
         GL11.glShadeModel(7425);
         GL11.glBegin(9);
         GL11.glColor4f(var8, var9, var10, var7);
         GL11.glVertex2f((float)var0, (float)var1);
         GL11.glVertex2f((float)var0, (float)var3);
         GL11.glColor4f(var12, var13, var14, var11);
         GL11.glVertex2f((float)var2, (float)var3);
         GL11.glVertex2f((float)var2, (float)var1);
         GL11.glEnd();
         GL11.glShadeModel(7424);
         GL11.glEnable(3553);
         GL11.glDisable(3042);
         boolean var10000 = false;
      } else {
         drawGradientRect((double)var0, (double)var1, (double)var2, (double)var3, var4, var5);
      }
   }

   public static void drawGradientRect(double var0, double var2, double var4, double var6, int var8, int var9) {
      float var10 = (float)(var8 >> 24 & 0xFF) / 255.0F;
      float var11 = (float)(var8 >> 16 & 0xFF) / 255.0F;
      float var12 = (float)(var8 >> 8 & 0xFF) / 255.0F;
      float var13 = (float)(var8 & 0xFF) / 255.0F;
      float var14 = (float)(var9 >> 24 & 0xFF) / 255.0F;
      float var15 = (float)(var9 >> 16 & 0xFF) / 255.0F;
      float var16 = (float)(var9 >> 8 & 0xFF) / 255.0F;
      float var17 = (float)(var9 & 0xFF) / 255.0F;
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      GL11.glShadeModel(7425);
      GL11.glPushMatrix();
      GL11.glBegin(7);
      GL11.glColor4f(var11, var12, var13, var10);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glColor4f(var15, var16, var17, var14);
      GL11.glVertex2d(var4, var6);
      GL11.glVertex2d(var4, var2);
      GL11.glEnd();
      GL11.glPopMatrix();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
      GL11.glShadeModel(7424);
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      if (var3 == 1 && this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         Setting var10000 = this.setting;
         boolean var10001;
         if (!this.setting.open) {
            var10001 = true;
            boolean var10002 = false;
         } else {
            var10001 = false;
         }

         var10000.open = var10001;
      }

      if (var3 == 0 && this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         Setting var14 = this.setting;
         boolean var19;
         if (!this.setting.booleanValue) {
            var19 = true;
            boolean var21 = false;
         } else {
            var19 = false;
         }

         var14.booleanValue = var19;
      }

      if (var3 == 0 && this.isInsideRainbow(var1, var2) && this.setting.open) {
         Setting var15 = this.setting;
         boolean var20;
         if (!this.setting.isRainbow) {
            var20 = true;
            boolean var22 = false;
         } else {
            var20 = false;
         }

         var15.isRainbow = var20;
      }

      if (var3 == 0 && this.isInsideCopy(var1, var2) && this.setting.open) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         String var4 = String.format(
            "#%02x%02x%02x%02x", this.finalColor.getAlpha(), this.finalColor.getRed(), this.finalColor.getGreen(), this.finalColor.getBlue()
         );
         StringSelection var5 = new StringSelection(var4);
         Clipboard var6 = Toolkit.getDefaultToolkit().getSystemClipboard();
         var6.setContents(var5, var5);
         Command.sendMessage("Copied the color to your clipboard.");
      }

      if (var3 == 0 && this.isInsidePaste(var1, var2) && this.setting.open) {
         try {
            if (readClipboard() != null) {
               if (Objects.requireNonNull(readClipboard()).startsWith("#")) {
                  String var10 = Objects.requireNonNull(readClipboard());
                  int var12 = Integer.valueOf(var10.substring(1, 3), 16);
                  int var13 = Integer.valueOf(var10.substring(3, 5), 16);
                  int var7 = Integer.valueOf(var10.substring(5, 7), 16);
                  int var8 = Integer.valueOf(var10.substring(7, 9), 16);
                  if (this.setting.hideAlpha) {
                     this.setting.setValue(new Color(var13, var7, var8));
                     boolean var16 = false;
                  } else {
                     this.setting.setValue(new Color(var13, var7, var8, var12));
                  }

                  boolean var17 = false;
               } else {
                  String[] var11 = readClipboard().split(",");
                  this.setting.setValue(new Color(Integer.parseInt(var11[0]), Integer.parseInt(var11[1]), Integer.parseInt(var11[2])));
               }
            }
         } catch (NumberFormatException var9) {
            Command.sendMessage("Bad color format! Use Hex (#FFFFFFFF)");
            return;
         }

         boolean var18 = false;
      }
   }
}
