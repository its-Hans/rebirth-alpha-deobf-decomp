package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;

public class UnlimitedSlider extends Button {
   public final Setting setting;

   @Override
   public boolean getState() {
      return true;
   }

   @Override
   public int getHeight() {
      return 14;
   }

   public boolean isRight(int var1) {
      boolean var10000;
      if ((float)var1 > this.x + ((float)this.width + 7.4F) / 2.0F) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public UnlimitedSlider(Setting var1) {
      super(var1.getName());
      this.setting = var1;
      this.width = 15;
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (this.isHovering(var1, var2)) {
         mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         if (this.isRight(var1)) {
            if (this.setting.getValue() instanceof Double) {
               this.setting.setValue(this.setting.getValue() + 1.0);
               boolean var10000 = false;
            } else if (this.setting.getValue() instanceof Float) {
               this.setting.setValue(this.setting.getValue() + 1.0F);
               boolean var4 = false;
            } else if (this.setting.getValue() instanceof Integer) {
               this.setting.setValue(this.setting.getValue() + 1);
               boolean var5 = false;
            }
         } else if (this.setting.getValue() instanceof Double) {
            this.setting.setValue(this.setting.getValue() - 1.0);
            boolean var6 = false;
         } else if (this.setting.getValue() instanceof Float) {
            this.setting.setValue(this.setting.getValue() - 1.0F);
            boolean var7 = false;
         } else if (this.setting.getValue() instanceof Integer) {
            this.setting.setValue(this.setting.getValue() - 1);
         }
      }
   }

   @Override
   public void toggle() {
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.NEW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      float var5 = this.x;
      float var7 = this.y;
      float var10002 = this.x + (float)this.width + 7.4F;
      float var10003 = this.y + (float)this.height - 0.5F;
      int var10004;
      if (!this.isHovering(var1, var2)) {
         var10004 = Managers.COLORS.getCurrentWithAlpha(120);
         boolean var10005 = false;
      } else {
         var10004 = Managers.COLORS.getCurrentWithAlpha(200);
      }

      RenderUtil.drawRect(var5, var7, var10002, var10003, var10004);
      RenderUtil.drawLine(this.x + 1.0F, this.y, this.x + 1.0F, this.y + (float)this.height - 0.5F, 0.9F, Managers.COLORS.getCurrentWithAlpha(255));
      TextManager var6 = Managers.TEXT;
      StringBuilder var8 = new StringBuilder().append(" - ");
      String var10;
      if (var4) {
         var10 = String.valueOf(new StringBuilder().append(this.setting.getName().toLowerCase()).append(":"));
         boolean var12 = false;
      } else {
         var10 = this.setting.getName();
      }

      String var9 = String.valueOf(
         var8.append(var10).append(" ").append(ChatFormatting.GRAY).append(this.setting.getValue()).append(ChatFormatting.WHITE).append(" +")
      );
      var10002 = this.x + 2.3F;
      var10003 = this.y - 1.7F - (float)Gui.INSTANCE.getTextOffset();
      if (this.getState()) {
         var10004 = -1;
         boolean var15 = false;
      } else {
         var10004 = -5592406;
      }

      var6.drawStringWithShadow(var9, var10002, var10003, var10004);
   }

   @Override
   public void update() {
      boolean var10001;
      if (!this.setting.isVisible()) {
         var10001 = true;
         boolean var10002 = false;
      } else {
         var10001 = false;
      }

      this.setHidden(var10001);
   }
}
