package me.rebirthclient.mod.gui.click.items;

import me.rebirthclient.mod.Mod;

public class Item extends Mod {
   protected float y;
   protected int width;
   protected float x;
   private boolean hidden;
   protected int height;

   public boolean isHidden() {
      return this.hidden;
   }

   public void setHidden(boolean var1) {
      this.hidden = var1;
   }

   public Item(String var1) {
      super(var1);
   }

   public void onKeyTyped(char var1, int var2) {
   }

   public float getY() {
      return this.y;
   }

   public void setLocation(float var1, float var2) {
      this.x = var1;
      this.y = var2;
   }

   public int getWidth() {
      return this.width;
   }

   public float getX() {
      return this.x;
   }

   public int getHeight() {
      return this.height;
   }

   public void update() {
   }

   public void setWidth(int var1) {
      this.width = var1;
   }

   public void drawScreen(int var1, int var2, float var3) {
   }

   public void mouseReleased(int var1, int var2, int var3) {
   }

   public void setHeight(int var1) {
      this.height = var1;
   }

   public void mouseClicked(int var1, int var2, int var3) {
   }
}
