package me.rebirthclient.mod.gui.click.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.gui.click.items.Item;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import me.rebirthclient.mod.modules.impl.client.FontMod;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;

public class ModuleButton extends Button {
   private boolean subOpen;
   private final Module module;
   private List<Item> items = new ArrayList<>();
   static final boolean $assertionsDisabled;
   private int progress = 0;

   @Override
   public void onKeyTyped(char var1, int var2) {
      super.onKeyTyped(var1, var2);
      if (!this.items.isEmpty() && this.subOpen) {
         for(Item var4 : this.items) {
            if (var4.isHidden()) {
               boolean var10000 = false;
            } else {
               var4.onKeyTyped(var1, var2);
               boolean var5 = false;
            }
         }
      }
   }

   public Module getModule() {
      return this.module;
   }

   @Override
   public void drawScreen(int var1, int var2, float var3) {
      super.drawScreen(var1, var2, var3);
      if (!this.items.isEmpty()) {
         this.drawGear();
         if (this.subOpen) {
            ++this.progress;
            float var4 = 1.0F;

            for(Item var6 : this.items) {
               Component.counter1[0]++;
               if (!var6.isHidden()) {
                  float var10001 = this.x + 1.0F;
                  float var10002 = this.y;
                  var4 += (float)ClickGui.INSTANCE.getButtonHeight();
                  var6.setLocation(var10001, var10002 + var4);
                  var6.setHeight(ClickGui.INSTANCE.getButtonHeight());
                  var6.setWidth(this.width - 9);
                  var6.drawScreen(var1, var2, var3);
                  if (var6 instanceof PickerButton && ((PickerButton)var6).setting.open) {
                     if (((PickerButton)var6).setting.noRainbow) {
                        var4 += 110.0F;
                        boolean var10000 = false;
                     } else {
                        var4 += 120.0F;
                     }
                  }

                  if (var6 instanceof EnumButton && ((EnumButton)var6).setting.open) {
                     var4 += (float)(((EnumButton)var6).setting.getValue().getClass().getEnumConstants().length * 12);
                  }
               }

               var6.update();
               boolean var8 = false;
            }
         }
      }

      if (this.isHovering(var1, var2) && ClickGui.INSTANCE.isOn()) {
         String var7 = String.valueOf(new StringBuilder().append(ChatFormatting.GRAY).append(this.module.getDescription()));
         Gui.drawRect(
            0,
            mc.currentScreen.height - 11,
            Managers.TEXT.getStringWidth(var7) + 2,
            mc.currentScreen.height,
            ColorUtil.injectAlpha(new Color(-1072689136), 200).getRGB()
         );
         if (!$assertionsDisabled && mc.currentScreen == null) {
            throw new AssertionError();
         }

         Managers.TEXT.drawStringWithShadow(var7, 2.0F, (float)(mc.currentScreen.height - 10), -1);
      }
   }

   @Override
   public void mouseClicked(int var1, int var2, int var3) {
      super.mouseClicked(var1, var2, var3);
      if (!this.items.isEmpty()) {
         if (var3 == 1 && this.isHovering(var1, var2)) {
            boolean var10001;
            if (!this.subOpen) {
               var10001 = true;
               boolean var10002 = false;
            } else {
               var10001 = false;
            }

            this.subOpen = var10001;
            mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
         }

         if (this.subOpen) {
            for(Item var5 : this.items) {
               if (var5.isHidden()) {
                  boolean var10000 = false;
               } else {
                  var5.mouseClicked(var1, var2, var3);
                  boolean var6 = false;
               }
            }
         }
      }
   }

   public void drawGear() {
      boolean var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.NEW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var1 = var10000;
      if (ClickGui.INSTANCE.style.getValue() == ClickGui.Style.FUTURE) {
         var10000 = true;
         boolean var11 = false;
      } else {
         var10000 = false;
      }

      boolean var2 = var10000;
      if (ClickGui.INSTANCE.gear.getValue()) {
         if (var2) {
            if (!this.subOpen) {
               this.progress = 0;
            }

            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/gear.png"));
            GlStateManager.translate(this.getX() + (float)this.getWidth() - 6.7F, this.getY() + 7.7F - 0.3F, 0.0F);
            GlStateManager.rotate(Component.calculateRotation((float)this.progress), 0.0F, 0.0F, 1.0F);
            RenderUtil.drawModalRect(-5, -5, 0.0F, 0.0F, 10, 10, 10, 10, 10.0F, 10.0F);
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
            var10000 = false;
         } else {
            String var8;
            if (!this.module.isOn() && !var1) {
               var8 = String.valueOf(ChatFormatting.GRAY);
            } else {
               var8 = "";
               boolean var12 = false;
            }

            String var3 = var8;
            String var9;
            if (this.subOpen) {
               var9 = "-";
               boolean var13 = false;
            } else {
               var9 = "+";
            }

            String var4 = var9;
            float var5 = this.x - 1.5F + (float)this.width - 7.4F;
            TextManager var10 = Managers.TEXT;
            String var14 = String.valueOf(new StringBuilder().append(var3).append(var4));
            float var10003;
            if (FontMod.INSTANCE.isOn() && Integer.valueOf("-".hashCode()).equals(var4.hashCode())) {
               var10003 = 1.0F;
               boolean var10004 = false;
            } else {
               var10003 = 0.0F;
            }

            var10.drawStringWithShadow(var14, var5 + var10003, this.y - 2.2F - (float)me.rebirthclient.mod.gui.screen.Gui.INSTANCE.getTextOffset(), -1);
         }
      }
   }

   public void initSettings() {
      ArrayList var1 = new ArrayList();
      if (!this.module.getSettings().isEmpty()) {
         for(Setting var3 : this.module.getSettings()) {
            if (var3.getValue() instanceof Boolean && !Integer.valueOf("Enabled".hashCode()).equals(var3.getName().hashCode())) {
               var1.add(new BooleanButton(var3));
               boolean var10000 = false;
            }

            if (var3.getValue() instanceof Bind
               && !Integer.valueOf("Keybind".toUpperCase().hashCode()).equals(var3.getName().toUpperCase().hashCode())
               && !Integer.valueOf("Hud".toUpperCase().hashCode()).equals(this.module.getName().toUpperCase().hashCode())) {
               var1.add(new BindButton(var3));
               boolean var4 = false;
            }

            if ((var3.getValue() instanceof String || var3.getValue() instanceof Character)
               && !Integer.valueOf("displayName".toUpperCase().hashCode()).equals(var3.getName().toUpperCase().hashCode())) {
               var1.add(new StringButton(var3));
               boolean var5 = false;
            }

            if (var3.getValue() instanceof Color) {
               var1.add(new PickerButton(var3));
               boolean var6 = false;
            }

            if (var3.isNumberSetting() && var3.hasRestriction()) {
               var1.add(new Slider(var3));
               boolean var10 = false;
               var10 = false;
            } else if (!var3.isEnumSetting()) {
               boolean var7 = false;
            } else {
               var1.add(new EnumButton(var3));
               boolean var8 = false;
               var8 = false;
            }
         }
      }

      var1.add(new BindButton(this.module.getSettingByName("Keybind")));
      boolean var12 = false;
      this.items = var1;
   }

   static {
      boolean var10000;
      if (!ModuleButton.class.desiredAssertionStatus()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      $assertionsDisabled = var10000;
   }

   @Override
   public void toggle() {
      this.module.toggle();
   }

   public ModuleButton(Module var1) {
      super(var1.getName());
      this.module = var1;
      this.initSettings();
   }

   @Override
   public boolean getState() {
      return this.module.isOn();
   }

   @Override
   public int getHeight() {
      if (this.subOpen) {
         int var1 = ClickGui.INSTANCE.getButtonHeight() - 1;

         for(Item var3 : this.items) {
            if (var3.isHidden()) {
               boolean var10000 = false;
            } else {
               var1 += var3.getHeight() + 1;
               if (var3 instanceof PickerButton && ((PickerButton)var3).setting.open) {
                  if (((PickerButton)var3).setting.noRainbow) {
                     var1 = (int)((float)var1 + 110.0F);
                     boolean var4 = false;
                  } else {
                     var1 = (int)((float)var1 + 120.0F);
                  }
               }

               if (var3 instanceof EnumButton && ((EnumButton)var3).setting.open) {
                  var1 += ((EnumButton)var3).setting.getValue().getClass().getEnumConstants().length * 12;
               }

               boolean var5 = false;
            }
         }

         return var1 + 2;
      } else {
         return ClickGui.INSTANCE.getButtonHeight() - 1;
      }
   }
}
