package me.rebirthclient.mod.gui.click.items.other;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;

public class Particle {
   private float alpha;
   private final Vector2f pos;
   private final Vector2f velocity;
   private float size;
   private static final Random random = new Random();

   public float getSize() {
      return this.size;
   }

   public float getDistanceTo(Particle var1) {
      return this.getDistanceTo(var1.getX(), var1.getY());
   }

   public Particle(Vector2f var1, float var2, float var3, float var4) {
      this.velocity = var1;
      this.pos = new Vector2f(var2, var3);
      this.size = var4;
   }

   public float getY() {
      return this.pos.getY();
   }

   public float getAlpha() {
      return this.alpha;
   }

   public static Particle getParticle() {
      Vector2f var0 = new Vector2f((float)(Math.random() * 3.0 - 1.0), (float)(Math.random() * 3.0 - 1.0));
      float var1 = (float)random.nextInt(Display.getWidth());
      float var2 = (float)random.nextInt(Display.getHeight());
      float var3 = (float)(Math.random() * 4.0) + 2.0F;
      return new Particle(var0, var1, var2, var3);
   }

   public void setup(int var1, float var2) {
      Vector2f var3 = this.pos;
      var3.x += this.velocity.getX() * (float)var1 * (var2 / 2.0F);
      Vector2f var4 = this.pos;
      var4.y += this.velocity.getY() * (float)var1 * (var2 / 2.0F);
      if (this.alpha < 180.0F) {
         this.alpha += 0.75F;
      }

      if (this.pos.getX() > (float)Display.getWidth()) {
         this.pos.setX(0.0F);
      }

      if (this.pos.getX() < 0.0F) {
         this.pos.setX((float)Display.getWidth());
      }

      if (this.pos.getY() > (float)Display.getHeight()) {
         this.pos.setY(0.0F);
      }

      if (this.pos.getY() < 0.0F) {
         this.pos.setY((float)Display.getHeight());
      }
   }

   public void setX(float var1) {
      this.pos.setX(var1);
   }

   public void setSize(float var1) {
      this.size = var1;
   }

   public float getDistanceTo(float var1, float var2) {
      return (float)Particle.Util.getDistance(this.getX(), this.getY(), var1, var2);
   }

   public void setY(float var1) {
      this.pos.setY(var1);
   }

   public float getX() {
      return this.pos.getX();
   }

   public static class Util {
      private final List<Particle> particles = new ArrayList<>();

      public void drawParticles() {
         GL11.glPushMatrix();
         GL11.glEnable(3042);
         GL11.glDisable(3553);
         GL11.glBlendFunc(770, 771);
         GL11.glDisable(2884);
         GL11.glDisable(2929);
         GL11.glDepthMask(false);
         if (Wrapper.mc.currentScreen != null) {
            for(Particle var2 : this.particles) {
               var2.setup(2, 0.1F);
               int var3 = Mouse.getEventX() * Wrapper.mc.currentScreen.width / Wrapper.mc.displayWidth;
               int var4 = Wrapper.mc.currentScreen.height - Mouse.getEventY() * Wrapper.mc.currentScreen.height / Wrapper.mc.displayHeight - 1;
               boolean var5 = true;
               float var6 = (float)MathHelper.clamp(
                  (double)var2.getAlpha() - (double)(var2.getAlpha() / 300.0F) * getDistance((float)var3, (float)var4, var2.getX(), var2.getY()),
                  0.0,
                  (double)var2.getAlpha()
               );
               Color var10000;
               if (ClickGui.INSTANCE.colorParticles.getValue()) {
                  var10000 = Managers.COLORS.getCurrent();
                  boolean var10001 = false;
               } else {
                  var10000 = new Color(-1714829883);
               }

               Color var7 = ColorUtil.injectAlpha(var10000, (int)var6);
               GL11.glColor4f((float)var7.getRed() / 255.0F, (float)var7.getGreen() / 255.0F, (float)var7.getBlue() / 255.0F, (float)var7.getAlpha() / 255.0F);
               GL11.glPointSize(var2.getSize());
               GL11.glBegin(0);
               GL11.glVertex2f(var2.getX(), var2.getY());
               GL11.glEnd();
               float var8 = 0.0F;
               Particle var9 = null;

               for(Particle var11 : this.particles) {
                  float var12 = var2.getDistanceTo(var11);
                  if (var12 <= 300.0F
                     && (
                        getDistance((float)var3, (float)var4, var2.getX(), var2.getY()) <= 300.0
                           || getDistance((float)var3, (float)var4, var11.getX(), var11.getY()) <= 300.0
                     )) {
                     if (var8 > 0.0F && var12 > var8) {
                        boolean var14 = false;
                        continue;
                     }

                     var8 = var12;
                     var9 = var11;
                  }

                  boolean var13 = false;
               }

               if (var9 == null) {
                  boolean var15 = false;
               } else {
                  this.drawTracer(var2.getX(), var2.getY(), var9.getX(), var9.getY(), var7, ColorUtil.injectAlpha(new Color(8618112), (int)var6), var7);
                  boolean var16 = false;
               }
            }

            GL11.glPushMatrix();
            GL11.glTranslatef(0.5F, 0.5F, 0.5F);
            GL11.glNormal3f(0.0F, 1.0F, 0.0F);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glEnable(3553);
            GL11.glPopMatrix();
            GL11.glDepthMask(true);
            GL11.glEnable(2884);
            GL11.glEnable(2929);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
         }
      }

      public void addParticle(int var1) {
         for(int var2 = 0; var2 < var1; ++var2) {
            this.particles.add(Particle.getParticle());
            boolean var10000 = false;
            var10000 = false;
         }
      }

      private void drawTracer(float var1, float var2, float var3, float var4, Color var5, Color var6, Color var7) {
         GL11.glPushMatrix();
         GL11.glDisable(3553);
         GL11.glEnable(3042);
         GL11.glBlendFunc(770, 771);
         GL11.glShadeModel(7425);
         GL11.glColor4f((float)var5.getRed() / 255.0F, (float)var5.getGreen() / 255.0F, (float)var5.getBlue() / 255.0F, (float)var5.getAlpha() / 255.0F);
         GL11.glLineWidth(0.6F);
         GL11.glBegin(1);
         GL11.glVertex2f(var1, var2);
         GL11.glColor4f((float)var6.getRed() / 255.0F, (float)var6.getGreen() / 255.0F, (float)var6.getBlue() / 255.0F, (float)var6.getAlpha() / 255.0F);
         float var8;
         if (var2 >= var4) {
            var8 = var4 + (var2 - var4) / 2.0F;
            boolean var10000 = false;
         } else {
            var8 = var2 + (var4 - var2) / 2.0F;
         }

         float var9;
         if (var1 >= var3) {
            var9 = var3 + (var1 - var3) / 2.0F;
            boolean var10 = false;
         } else {
            var9 = var1 + (var3 - var1) / 2.0F;
         }

         GL11.glVertex2f(var9, var8);
         GL11.glEnd();
         GL11.glBegin(1);
         GL11.glColor4f((float)var6.getRed() / 255.0F, (float)var6.getGreen() / 255.0F, (float)var6.getBlue() / 255.0F, (float)var6.getAlpha() / 255.0F);
         GL11.glVertex2f(var9, var8);
         GL11.glColor4f((float)var7.getRed() / 255.0F, (float)var7.getGreen() / 255.0F, (float)var7.getBlue() / 255.0F, (float)var7.getAlpha() / 255.0F);
         GL11.glVertex2f(var3, var4);
         GL11.glEnd();
         GL11.glPopMatrix();
      }

      public static double getDistance(float var0, float var1, float var2, float var3) {
         return Math.sqrt((double)((var0 - var2) * (var0 - var2) + (var1 - var3) * (var1 - var3)));
      }

      public Util(int var1) {
         this.addParticle(var1);
      }
   }
}
