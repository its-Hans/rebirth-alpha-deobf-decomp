package me.rebirthclient.mod.gui.screen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.gui.click.items.Item;
import me.rebirthclient.mod.gui.click.items.buttons.ModuleButton;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

public class Appearance extends GuiScreen {
   private final ArrayList<Component> components = new ArrayList<>();
   private static Appearance INSTANCE = new Appearance();

   public void onGuiClosed() {
      Appearance var10000 = this;

      try {
         var10000.onGuiClosed();
         this.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
      } catch (Exception var2) {
         var2.printStackTrace();
         return;
      }

      boolean var3 = false;
   }

   public Component getComponentByName(String var1) {
      for(Component var3 : this.components) {
         if (Integer.valueOf(var1.toUpperCase().hashCode()).equals(var3.getName().toUpperCase().hashCode())) {
            return var3;
         }

         boolean var10000 = false;
      }

      return null;
   }

   public void mouseReleased(int var1, int var2, int var3) {
      this.components.forEach(Appearance::lambda$mouseReleased$3);
   }

   public void mouseClicked(int var1, int var2, int var3) {
      this.components.forEach(Appearance::lambda$mouseClicked$2);
   }

   private static void lambda$keyTyped$6(char var0, int var1, Component var2) {
      var2.onKeyTyped(var0, var1);
   }

   private static void lambda$checkMouseWheel$4(Component var0) {
      var0.setY(var0.getY() - 10);
   }

   public Appearance() {
      INSTANCE = this;
      this.load();
   }

   public int getTextOffset() {
      return -6;
   }

   private static void lambda$mouseReleased$3(int var0, int var1, int var2, Component var3) {
      var3.mouseReleased(var0, var1, var2);
   }

   public boolean doesGuiPauseGame() {
      return false;
   }

   public void checkMouseWheel() {
      int var1 = Mouse.getDWheel();
      if (var1 < 0) {
         this.components.forEach(Appearance::lambda$checkMouseWheel$4);
         boolean var10000 = false;
      } else if (var1 > 0) {
         this.components.forEach(Appearance::lambda$checkMouseWheel$5);
      }
   }

   private static void lambda$drawScreen$1(int var0, int var1, float var2, Component var3) {
      var3.drawScreen(var0, var1, var2);
   }

   public final ArrayList<Component> getComponents() {
      return this.components;
   }

   public void drawScreen(int var1, int var2, float var3) {
      this.checkMouseWheel();
      this.components.forEach(Appearance::lambda$drawScreen$1);
   }

   private static void lambda$mouseClicked$2(int var0, int var1, int var2, Component var3) {
      var3.mouseClicked(var0, var1, var2);
   }

   public static Appearance getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new Appearance();
      }

      return INSTANCE;
   }

   public void updateModule(Module var1) {
      for(Component var3 : this.components) {
         for(Item var5 : var3.getItems()) {
            if (!(var5 instanceof ModuleButton)) {
               boolean var10000 = false;
            } else {
               ModuleButton var6 = (ModuleButton)var5;
               Module var7 = var6.getModule();
               if (var1 != null) {
                  if (!var1.equals(var7)) {
                     boolean var8 = false;
                  } else {
                     var6.initSettings();
                     boolean var9 = false;
                  }
               }
            }
         }

         boolean var10 = false;
      }
   }

   public static Appearance getClickGui() {
      return getInstance();
   }

   public void keyTyped(char var1, int var2) throws IOException {
      super.keyTyped(var1, var2);
      this.components.forEach(Appearance::lambda$keyTyped$6);
   }

   private static void lambda$load$0(Component var0) {
      var0.getItems().sort(Comparator.comparing(Mod::getName));
   }

   private void load() {
      int var1 = -84;

      for(Category var3 : Managers.MODULES.getCategories()) {
         if (var3 == Category.HUD) {
            ArrayList var10000 = this.components;
            String var10004 = var3.getName();
            var1 += 90;
            var10000.add(new Component(this, var10004, var1, 4, true, var3) {
               final Appearance this$0;
               final Category val$category;

               @Override
               public void setupItems() {
                  counter1 = new int[]{1};
                  Managers.MODULES.getModulesByCategory(this.val$category).forEach(this::lambda$setupItems$0);
               }

               private void lambda$setupItems$0(Module var1) {
                  this.addButton(new ModuleButton(var1));
               }

               {
                  this.this$0 = var1;
                  this.val$category = var6;
               }
            });
            boolean var4 = false;
         }

         boolean var5 = false;
      }

      this.components.forEach(Appearance::lambda$load$0);
   }

   private static void lambda$checkMouseWheel$5(Component var0) {
      var0.setY(var0.getY() + 10);
   }
}
