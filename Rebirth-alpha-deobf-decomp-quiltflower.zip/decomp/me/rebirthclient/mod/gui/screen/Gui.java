package me.rebirthclient.mod.gui.screen;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.gui.click.Component;
import me.rebirthclient.mod.gui.click.items.Item;
import me.rebirthclient.mod.gui.click.items.buttons.ModuleButton;
import me.rebirthclient.mod.gui.click.items.other.Snow;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class Gui extends GuiScreen {
   final Minecraft mc = Minecraft.getMinecraft();
   private final ArrayList<Component> components;
   public static Gui INSTANCE;
   private final ArrayList<Snow> snow = new ArrayList<>();

   public void onGuiClosed() {
      super.onGuiClosed();
      if (this.mc.entityRenderer.isShaderActive()) {
         this.mc.entityRenderer.getShaderGroup().deleteShaderGroup();
      }
   }

   public void checkMouseWheel() {
      int var1 = Mouse.getDWheel();
      if (var1 < 0) {
         this.components.forEach(Gui::lambda$checkMouseWheel$5);
         boolean var10000 = false;
      } else if (var1 > 0) {
         this.components.forEach(Gui::lambda$checkMouseWheel$6);
      }
   }

   private static void lambda$mouseReleased$4(int var0, int var1, int var2, Component var3) {
      var3.mouseReleased(var0, var1, var2);
   }

   public int getTextOffset() {
      return -6;
   }

   public final ArrayList<Component> getComponents() {
      return this.components;
   }

   public void mouseReleased(int var1, int var2, int var3) {
      this.components.forEach(Gui::lambda$mouseReleased$4);
   }

   public void mouseClicked(int var1, int var2, int var3) {
      this.components.forEach(Gui::lambda$mouseClicked$3);
   }

   private static void lambda$checkMouseWheel$6(Component var0) {
      var0.setY(var0.getY() + 10);
   }

   public void updateModule(Module var1) {
      for(Component var3 : this.components) {
         for(Item var5 : var3.getItems()) {
            if (!(var5 instanceof ModuleButton)) {
               boolean var10000 = false;
            } else {
               ModuleButton var6 = (ModuleButton)var5;
               Module var7 = var6.getModule();
               if (var1 != null) {
                  if (!var1.equals(var7)) {
                     boolean var8 = false;
                  } else {
                     var6.initSettings();
                     boolean var9 = false;
                  }
               }
            }
         }

         boolean var10 = false;
      }
   }

   private static void lambda$drawScreen$1(int var0, int var1, float var2, Component var3) {
      var3.drawScreen(var0, var1, var2);
   }

   private static void lambda$mouseClicked$3(int var0, int var1, int var2, Component var3) {
      var3.mouseClicked(var0, var1, var2);
   }

   private static void lambda$checkMouseWheel$5(Component var0) {
      var0.setY(var0.getY() - 10);
   }

   private void onLoad() {
      INSTANCE = this;
      int var1 = -84;

      for(Category var3 : Managers.MODULES.getCategories()) {
         if (var3 != Category.HUD) {
            ArrayList var10000 = this.components;
            String var10004 = var3.getName();
            var1 += 90;
            var10000.add(new Component(this, var10004, var1, 4, true, var3) {
               final Category val$category;
               final Gui this$0;

               private void lambda$setupItems$0(Module var1) {
                  this.addButton(new ModuleButton(var1));
               }

               @Override
               public void setupItems() {
                  counter1 = new int[]{1};
                  Managers.MODULES.getModulesByCategory(this.val$category).forEach(this::lambda$setupItems$0);
               }

               {
                  this.this$0 = var1;
                  this.val$category = var6;
               }
            });
            boolean var8 = false;
         }

         boolean var9 = false;
      }

      this.components.forEach(Gui::lambda$onLoad$0);
      Random var6 = new Random();

      for(int var7 = 0; var7 < 100; ++var7) {
         for(int var4 = 0; var4 < 3; ++var4) {
            Snow var5 = new Snow(25 * var7, var4 * -50, var6.nextInt(3) + 1, var6.nextInt(2) + 1);
            this.snow.add(var5);
            boolean var10 = false;
            var10 = false;
         }

         boolean var12 = false;
      }
   }

   private static void lambda$drawScreen$2(ScaledResolution var0, Snow var1) {
      var1.drawSnow(var0);
   }

   public void drawScreen(int var1, int var2, float var3) {
      this.checkMouseWheel();
      if (this.mc.world != null) {
         this.drawDefaultBackground();
         boolean var10000 = false;
      } else {
         net.minecraft.client.gui.Gui.drawRect(0, 0, 1920, 1080, ColorUtil.injectAlpha(new Color(-1072689136), 150).getRGB());
      }

      if (ClickGui.INSTANCE.background.getValue() && this.mc.currentScreen instanceof Gui && this.mc.world != null) {
         RenderUtil.drawVGradientRect(
            0.0F,
            0.0F,
            (float)Managers.TEXT.scaledWidth,
            (float)Managers.TEXT.scaledHeight,
            new Color(0, 0, 0, 0).getRGB(),
            Managers.COLORS.getCurrentWithAlpha(60)
         );
      }

      float var4 = (float)ClickGui.animation.easeOutQuad();
      GlStateManager.pushMatrix();
      GL11.glScaled((double)var4, (double)var4, (double)var4);
      this.components.forEach(Gui::lambda$drawScreen$1);
      GlStateManager.popMatrix();
      ScaledResolution var5 = new ScaledResolution(this.mc);
      if (!this.snow.isEmpty() && ClickGui.INSTANCE.snow.getValue()) {
         this.snow.forEach(Gui::lambda$drawScreen$2);
      }
   }

   public void keyTyped(char var1, int var2) throws IOException {
      super.keyTyped(var1, var2);
      this.components.forEach(Gui::lambda$keyTyped$7);
   }

   private static void lambda$onLoad$0(Component var0) {
      var0.getItems().sort(Comparator.comparing(Mod::getName));
   }

   public boolean doesGuiPauseGame() {
      return false;
   }

   private static void lambda$keyTyped$7(char var0, int var1, Component var2) {
      var2.onKeyTyped(var0, var1);
   }

   public Gui() {
      this.components = new ArrayList<>();
      this.onLoad();
   }
}
