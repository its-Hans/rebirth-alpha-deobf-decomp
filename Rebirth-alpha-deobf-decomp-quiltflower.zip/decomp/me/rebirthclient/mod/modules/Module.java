package me.rebirthclient.mod.modules;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.Mod;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.modules.impl.client.HUD;
import me.rebirthclient.mod.modules.impl.hud.Notifications;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.common.MinecraftForge;

public abstract class Module extends Mod {
   public final Setting<Boolean> enabled = this.add(new Setting<>("Enabled", this.shouldEnable()));
   public final Setting<Boolean> drawn = this.add(new Setting<>("Drawn", this.shouldDrawn()));
   public final Setting<Bind> bind;
   public final Setting<String> displayerName;
   private final boolean shouldListen;
   private final String description;
   private final Category category;

   public void enable() {
      this.enabled.setValue(true);
      this.onEnable();
      Notifications.add(String.valueOf(new StringBuilder().append(this.getPrefix()).append("toggled§a on.")));
      Command.sendMessageWithID(String.valueOf(new StringBuilder().append(this.getPrefix()).append("toggled§a on.")), 1);
      if (this.isOn() && this.shouldListen) {
         MinecraftForge.EVENT_BUS.register(this);
      }
   }

   private String getPrefix() {
      return String.valueOf(new StringBuilder().append("§f[§r").append(this.getDisplayName()).append("§f] "));
   }

   public void onTick() {
   }

   public String getArrayListInfo() {
      StringBuilder var10000 = new StringBuilder();
      String var10001;
      if (HUD.INSTANCE.space.getValue()) {
         var10001 = Managers.TEXT.capitalSpace(this.getDisplayName());
         boolean var10002 = false;
      } else {
         var10001 = this.getDisplayName();
      }

      var10000 = var10000.append(var10001).append(ChatFormatting.GRAY);
      if (this.getInfo() != null) {
         var10001 = String.valueOf(
            new StringBuilder().append(" [").append(ChatFormatting.WHITE).append(this.getInfo()).append(ChatFormatting.GRAY).append("]")
         );
         boolean var3 = false;
      } else {
         var10001 = "";
      }

      return String.valueOf(var10000.append(var10001));
   }

   public void onTotemPop(EntityPlayer var1) {
   }

   public void onLoad() {
   }

   public String getDisplayName() {
      return this.displayerName.getValue();
   }

   public String getInfo() {
      return null;
   }

   public void onLogout() {
   }

   private boolean shouldEnable() {
      boolean var10000;
      if (!Integer.valueOf("HUD".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("Title".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("CombatSetting".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("RenderSetting".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("Rotations".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("Chat".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("GuiAnimation".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public void onRender3D(Render3DEvent var1) {
   }

   public boolean isDrawn() {
      return this.drawn.getValue();
   }

   public Module(String var1, String var2, Category var3) {
      super(var1);
      Setting var10002 = new Setting;
      Bind var10005;
      if (Integer.valueOf("ClickGui".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())) {
         var10005 = new Bind(21);
         boolean var10006 = false;
      } else {
         var10005 = new Bind(-1);
      }

      var10002./* $QF: Unable to resugar constructor */<init>("Keybind", var10005);
      this.bind = this.add(var10002);
      this.displayerName = this.add(new Setting<>("Display", var1));
      this.description = var2;
      this.category = var3;
      this.shouldListen = true;
   }

   public boolean isOff() {
      boolean var10000;
      if (!this.enabled.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public String getDescription() {
      return this.description;
   }

   public Category getCategory() {
      return this.category;
   }

   public void onLogin() {
   }

   public void onUnload() {
   }

   public boolean isOn() {
      return this.enabled.getValue();
   }

   public boolean isListening() {
      boolean var10000;
      if (this.shouldListen && this.isOn()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void sendMessageWithID(String var1, int var2) {
      if (!nullCheck()) {
         mc.ingameGUI
            .getChatGUI()
            .printChatMessageWithOptionalDeletion(
               new Command.ChatMessage(String.valueOf(new StringBuilder().append(Managers.TEXT.getPrefix()).append(this.getPrefix()).append(var1))), var2
            );
      }
   }

   private boolean shouldDrawn() {
      boolean var10000;
      if (!Integer.valueOf("CombatSetting".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("Title".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("HUD".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("Rotations".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("RenderSetting".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("Chat".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())
         && !Integer.valueOf("GuiAnimation".toUpperCase().hashCode()).equals(this.getName().toUpperCase().hashCode())) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public Bind getBind() {
      return this.bind.getValue();
   }

   public void sendMessage(String var1) {
      Notifications.notifyList.add(new Notifications.Notifys(var1));
      boolean var10000 = false;
      Command.sendSilentMessage(String.valueOf(new StringBuilder().append(Managers.TEXT.getPrefix()).append(this.getPrefix()).append(var1)));
   }

   public void onUpdate() {
   }

   public void toggle() {
      if (this.isOn()) {
         this.disable();
         boolean var10000 = false;
      } else {
         this.enable();
      }
   }

   public void onRender2D(Render2DEvent var1) {
   }

   public void onEnable() {
   }

   public void setBind(int var1) {
      this.bind.setValue(new Bind(var1));
   }

   public void onDisable() {
   }

   public void disable() {
      if (this.shouldListen) {
         MinecraftForge.EVENT_BUS.unregister(this);
      }

      this.enabled.setValue(false);
      this.onDisable();
      Notifications.add(String.valueOf(new StringBuilder().append(this.getPrefix()).append("toggled§c off.")));
      Command.sendMessageWithID(String.valueOf(new StringBuilder().append(this.getPrefix()).append("toggled§c off.")), 1);
   }

   public void onDeath(EntityPlayer var1) {
   }
}
