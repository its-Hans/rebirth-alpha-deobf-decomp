package me.rebirthclient.mod.modules;

public enum Category {
   EXPLOIT("Exploit"),
   PLAYER("Player"),
   CLIENT("Client"),
   MISC("Misc"),
   RENDER("Render"),
   MOVEMENT("Movement"),
   HUD("HUD"),
   COMBAT("Combat");
   private final String name;
   private static final Category[] $VALUES = new Category[]{Category.COMBAT, MISC, RENDER, Category.MOVEMENT, PLAYER, EXPLOIT, CLIENT, Category.HUD};

   private Category(String var3) {
      this.name = var3;
   }

   public String getName() {
      return this.name;
   }
}
