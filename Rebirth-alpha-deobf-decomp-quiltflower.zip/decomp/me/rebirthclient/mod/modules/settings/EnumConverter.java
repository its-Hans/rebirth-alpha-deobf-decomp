package me.rebirthclient.mod.modules.settings;

import com.google.common.base.Converter;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class EnumConverter extends Converter<Enum, JsonElement> {
   private final Class<? extends Enum> clazz;

   public JsonElement doForward(Enum var1) {
      return new JsonPrimitive(var1.toString());
   }

   public Enum doBackward(JsonElement var1) {
      Class var10000 = this.clazz;
      JsonElement var10001 = var1;

      try {
         return Enum.valueOf(var10000, var10001.getAsString());
      } catch (IllegalArgumentException var3) {
         return null;
      }
   }

   public Object doForward(Object var1) {
      return this.doForward((Enum)var1);
   }

   public static String getProperName(Enum var0) {
      return String.valueOf(new StringBuilder().append(Character.toUpperCase(var0.name().charAt(0))).append(var0.name().toLowerCase().substring(1)));
   }

   public EnumConverter(Class<? extends Enum> var1) {
      this.clazz = var1;
   }

   public static Enum increaseEnum(Enum var0) {
      int var1 = currentEnum(var0);

      for(int var2 = 0; var2 < ((Enum[])var0.getClass().getEnumConstants()).length; ++var2) {
         Enum var3 = ((Enum[])var0.getClass().getEnumConstants())[var2];
         if (var2 == var1 + 1) {
            return var3;
         }

         boolean var10000 = false;
         var10000 = false;
      }

      return ((Enum[])var0.getClass().getEnumConstants())[0];
   }

   public static int currentEnum(Enum var0) {
      for(int var1 = 0; var1 < ((Enum[])var0.getClass().getEnumConstants()).length; ++var1) {
         Enum var2 = ((Enum[])var0.getClass().getEnumConstants())[var1];
         if (Integer.valueOf(var0.name().toUpperCase().hashCode()).equals(var2.name().toUpperCase().hashCode())) {
            return var1;
         }

         boolean var10000 = false;
         var10000 = false;
      }

      return -1;
   }

   public Object doBackward(Object var1) {
      return this.doBackward((JsonElement)var1);
   }
}
