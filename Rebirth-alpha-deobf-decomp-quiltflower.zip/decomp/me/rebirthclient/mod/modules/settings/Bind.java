package me.rebirthclient.mod.modules.settings;

import com.google.common.base.Converter;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import org.lwjgl.input.Keyboard;

public class Bind {
   private int key;

   @Override
   public String toString() {
      String var10000;
      if (this.isEmpty()) {
         var10000 = "None";
         boolean var10001 = false;
      } else if (this.key < 0) {
         var10000 = "None";
         boolean var1 = false;
      } else {
         var10000 = this.capitalise(Keyboard.getKeyName(this.key));
      }

      return var10000;
   }

   public static Bind none() {
      return new Bind(-1);
   }

   public Bind(int var1) {
      this.key = var1;
   }

   public boolean isDown() {
      boolean var10000;
      if (!this.isEmpty() && Keyboard.isKeyDown(this.getKey())) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void setKey(int var1) {
      this.key = var1;
   }

   public boolean isEmpty() {
      boolean var10000;
      if (this.key < 0) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private String capitalise(String var1) {
      if (var1.isEmpty()) {
         return "";
      } else {
         StringBuilder var10000 = new StringBuilder().append(Character.toUpperCase(var1.charAt(0)));
         String var10001;
         if (var1.length() != 1) {
            var10001 = var1.substring(1).toLowerCase();
            boolean var10002 = false;
         } else {
            var10001 = "";
         }

         return String.valueOf(var10000.append(var10001));
      }
   }

   public int getKey() {
      return this.key;
   }

   public static class BindConverter extends Converter<Bind, JsonElement> {
      public Object doForward(Object var1) {
         return this.doForward((Bind)var1);
      }

      public JsonElement doForward(Bind var1) {
         return new JsonPrimitive(var1.toString());
      }

      public Bind doBackward(JsonElement var1) {
         String var2 = var1.getAsString();
         if (Integer.valueOf("None".toUpperCase().hashCode()).equals(var2.toUpperCase().hashCode())) {
            return Bind.none();
         } else {
            int var3 = -1;
            String var10000 = var2;

            try {
               var3 = Keyboard.getKeyIndex(var10000.toUpperCase());
            } catch (Exception var5) {
               return var3 == 0 ? Bind.none() : new Bind(var3);
            }

            boolean var6 = false;
            return var3 == 0 ? Bind.none() : new Bind(var3);
         }
      }

      public Object doBackward(Object var1) {
         return this.doBackward((JsonElement)var1);
      }
   }
}
