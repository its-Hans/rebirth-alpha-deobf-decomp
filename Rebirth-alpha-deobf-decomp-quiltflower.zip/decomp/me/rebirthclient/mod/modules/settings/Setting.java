package me.rebirthclient.mod.modules.settings;

import java.awt.Color;
import java.util.function.Predicate;
import me.rebirthclient.api.events.impl.ClientEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.Mod;
import net.minecraftforge.common.MinecraftForge;

public class Setting<T> {
   public boolean open;
   private Mod mod;
   private boolean restriction;
   public boolean hasBoolean;
   private T value;
   public boolean noRainbow;
   public boolean parent;
   public boolean isRainbow;
   private final String name;
   private T plannedValue;
   private Predicate<T> visibility;
   public boolean hideAlpha;
   public boolean booleanValue;
   private T maxValue;
   private T minValue;
   private final T defaultValue;

   public Setting(String var1, T var2, T var3, T var4) {
      this.name = var1;
      this.defaultValue = (T)var2;
      this.value = (T)var2;
      this.minValue = (T)var3;
      this.maxValue = (T)var4;
      this.plannedValue = (T)var2;
      this.restriction = true;
   }

   public T getPlannedValue() {
      return this.plannedValue;
   }

   public String getCurrentEnumName() {
      return EnumConverter.getProperName((Enum)this.value);
   }

   public Setting<T> setParent() {
      this.parent = true;
      return this;
   }

   public void setMod(Mod var1) {
      this.mod = var1;
   }

   public String getType() {
      return this.isEnumSetting() ? "Enum" : this.getClassName(this.defaultValue);
   }

   public void setEnumValue(String var1) {
      for(Enum var5 : (Enum[])((Enum)this.value).getClass().getEnumConstants()) {
         if (!Integer.valueOf(var1.toUpperCase().hashCode()).equals(var5.name().toUpperCase().hashCode())) {
            boolean var10000 = false;
         } else {
            this.value = var5;
         }

         boolean var6 = false;
      }
   }

   public T getValue() {
      return (T)(this.value instanceof Color && this.isRainbow && !this.noRainbow
         ? ColorUtil.injectAlpha(Managers.COLORS.getRainbow(), ((Color)this.value).getAlpha())
         : this.value);
   }

   public boolean isStringSetting() {
      return this.value instanceof String;
   }

   public void setValue(T var1) {
      this.setPlannedValue((T)var1);
      if (this.restriction) {
         if (((Number)this.minValue).floatValue() > ((Number)var1).floatValue()) {
            this.setPlannedValue(this.minValue);
         }

         if (((Number)this.maxValue).floatValue() < ((Number)var1).floatValue()) {
            this.setPlannedValue(this.maxValue);
         }
      }

      ClientEvent var2 = new ClientEvent(this);
      MinecraftForge.EVENT_BUS.post(var2);
      boolean var10000 = false;
      if (!var2.isCanceled()) {
         this.value = this.plannedValue;
         var10000 = false;
      } else {
         this.plannedValue = this.value;
      }
   }

   public void increaseEnum() {
      this.plannedValue = EnumConverter.increaseEnum((Enum)this.value);
      ClientEvent var1 = new ClientEvent(this);
      MinecraftForge.EVENT_BUS.post(var1);
      boolean var10000 = false;
      if (!var1.isCanceled()) {
         this.value = this.plannedValue;
         var10000 = false;
      } else {
         this.plannedValue = this.value;
      }
   }

   public boolean isVisible() {
      return this.visibility == null ? true : this.visibility.test(this.getValue());
   }

   public boolean isOpen() {
      boolean var10000;
      if (this.open && this.parent) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean isEnumSetting() {
      boolean var10000;
      if (!this.isNumberSetting()
         && !(this.value instanceof String)
         && !(this.value instanceof Bind)
         && !(this.value instanceof Character)
         && !(this.value instanceof Boolean)
         && !(this.value instanceof Color)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void setPlannedValue(T var1) {
      this.plannedValue = (T)var1;
   }

   public Setting(String var1, T var2) {
      this.name = var1;
      this.defaultValue = (T)var2;
      this.value = (T)var2;
      this.plannedValue = (T)var2;
   }

   public Setting(String var1, T var2, T var3, T var4, Predicate<T> var5) {
      this.name = var1;
      this.defaultValue = (T)var2;
      this.value = (T)var2;
      this.minValue = (T)var3;
      this.maxValue = (T)var4;
      this.plannedValue = (T)var2;
      this.visibility = var5;
      this.restriction = true;
   }

   public Mod getMod() {
      return this.mod;
   }

   public Setting<T> hideAlpha() {
      this.hideAlpha = true;
      return this;
   }

   public Setting<T> noRainbow() {
      this.noRainbow = true;
      return this;
   }

   public T getMinValue() {
      return this.minValue;
   }

   public Setting(String var1, T var2, Predicate<T> var3) {
      this.name = var1;
      this.defaultValue = (T)var2;
      this.value = (T)var2;
      this.plannedValue = (T)var2;
      this.visibility = var3;
   }

   public boolean isNumberSetting() {
      boolean var10000;
      if (!(this.value instanceof Double)
         && !(this.value instanceof Integer)
         && !(this.value instanceof Short)
         && !(this.value instanceof Long)
         && !(this.value instanceof Float)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public T getMaxValue() {
      return this.maxValue;
   }

   public boolean hasRestriction() {
      return this.restriction;
   }

   public <T> String getClassName(T var1) {
      return var1.getClass().getSimpleName();
   }

   public T getDefaultValue() {
      return this.defaultValue;
   }

   public String getName() {
      return this.name;
   }

   public Setting<T> injectBoolean(boolean var1) {
      if (this.value instanceof Color) {
         this.hasBoolean = true;
         this.booleanValue = var1;
      }

      return this;
   }
}
