package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.PushEvent;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.asm.accessors.ISPacketEntityVelocity;
import me.rebirthclient.asm.accessors.ISPacketExplosion;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Velocity extends Module {
   private final Setting<Float> vertical;
   private final Setting<Boolean> entityPush;
   private final Setting<Boolean> blockPush;
   private final Setting<Boolean> noWaterPush;
   public static Velocity INSTANCE;
   private final Setting<Float> horizontal = this.add(new Setting<>("Horizontal", 0.0F, 0.0F, 100.0F));

   @Override
   public String getInfo() {
      return String.valueOf(
         new StringBuilder()
            .append(MathUtil.round(this.horizontal.getValue(), 1))
            .append("%,")
            .append(MathUtil.round(this.vertical.getValue(), 1))
            .append("%")
      );
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            float var2 = this.horizontal.getValue() / 100.0F;
            float var3 = this.vertical.getValue() / 100.0F;
            if (var1.getPacket() instanceof EntityFishHook) {
               var1.setCanceled(true);
            }

            if (var1.getPacket() instanceof SPacketExplosion) {
               ISPacketExplosion var4 = var1.getPacket();
               var4.setX(var4.getX() * var2);
               var4.setY(var4.getY() * var3);
               var4.setZ(var4.getZ() * var2);
            }

            if (var1.getPacket() instanceof SPacketEntityVelocity) {
               ISPacketEntityVelocity var5 = var1.getPacket();
               if (var5.getEntityID() == mc.player.getEntityId()) {
                  if (this.horizontal.getValue() == 0.0F && this.vertical.getValue() == 0.0F) {
                     var1.setCanceled(true);
                     boolean var10000 = false;
                  } else {
                     var5.setX((int)((float)var5.getX() * var2));
                     var5.setY((int)((float)var5.getY() * var3));
                     var5.setZ((int)((float)var5.getZ() * var2));
                  }
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onPush(PushEvent var1) {
      if (var1.getStage() == 0 && this.entityPush.getValue() && var1.entity.equals(mc.player)) {
         var1.x = -var1.x * 0.0;
         var1.y = -var1.y * 0.0;
         var1.z = -var1.z * 0.0;
         boolean var2 = false;
      } else if (var1.getStage() == 1 && this.blockPush.getValue()) {
         var1.setCanceled(true);
         boolean var10000 = false;
      } else if (var1.getStage() == 2 && this.noWaterPush.getValue() && mc.player != null && mc.player.equals(var1.entity)) {
         var1.setCanceled(true);
      }
   }

   public Velocity() {
      super("Velocity", "Cancels all the pushing your player receives", Category.MOVEMENT);
      this.vertical = this.add(new Setting<>("Vertical", 0.0F, 0.0F, 100.0F));
      this.noWaterPush = this.add(new Setting<>("LiquidPush", true));
      this.blockPush = this.add(new Setting<>("BlockPush", true));
      this.entityPush = this.add(new Setting<>("EntityPush", true));
      INSTANCE = this;
   }
}
