package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.exploit.Clip;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoCenter extends Module {
   private final Setting<Boolean> reset = this.add(new Setting<>("Reset", true));
   public static AutoCenter INSTANCE;

   public AutoCenter() {
      super("AutoCenter", "move center", Category.MOVEMENT);
      INSTANCE = this;
   }

   private boolean isFlying(EntityPlayer var1) {
      boolean var10000;
      if (!var1.isElytraFlying() && !var1.capabilities.isFlying) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      this.doCenter();
   }

   @Override
   public void onEnable() {
      this.doCenter();
   }

   private void doCenter() {
      if (!Clip.INSTANCE.isOn() && !this.isFlying(mc.player)) {
         BlockPos var1 = EntityUtil.getPlayerPos();
         if (mc.player.posX - (double)var1.getX() - 0.5 <= 0.2
            && mc.player.posX - (double)var1.getX() - 0.5 >= -0.2
            && mc.player.posZ - (double)var1.getZ() - 0.5 <= 0.2
            && mc.player.posZ - 0.5 - (double)var1.getZ() >= -0.2) {
            this.disable();
            boolean var10000 = false;
         } else {
            mc.player.motionX = ((double)var1.getX() + 0.5 - mc.player.posX) / 2.0;
            mc.player.motionZ = ((double)var1.getZ() + 0.5 - mc.player.posZ) / 2.0;
         }
      } else {
         this.disable();
      }
   }

   @SubscribeEvent
   public void onInput(InputUpdateEvent var1) {
      if (var1.getMovementInput() instanceof MovementInputFromOptions) {
         MovementInput var2 = var1.getMovementInput();
         var2.moveForward = 0.0F;
         var2.moveStrafe = 0.0F;
         var2.forwardKeyDown = false;
         var2.backKeyDown = false;
         var2.leftKeyDown = false;
         var2.rightKeyDown = false;
      }
   }

   @Override
   public void onDisable() {
      if (this.reset.getValue()) {
         mc.player.motionX = 0.0;
         mc.player.motionZ = 0.0;
      }
   }
}
