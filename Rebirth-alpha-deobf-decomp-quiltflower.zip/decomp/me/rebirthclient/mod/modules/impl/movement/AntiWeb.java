package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class AntiWeb extends Module {
   public final Setting<AntiWeb.AntiMode> antiModeSetting = this.add(new Setting<>("AntiMode", AntiWeb.AntiMode.Block));
   public static AntiWeb INSTANCE;

   @Override
   public void onUpdate() {
      if (this.antiModeSetting.getValue() == AntiWeb.AntiMode.Ignore && mc.player.isInWeb) {
         mc.player.isInWeb = false;
      }
   }

   public AntiWeb() {
      super("AntiWeb", "Solid web", Category.MOVEMENT);
      INSTANCE = this;
   }

   public static enum AntiMode {
      Block,
      Ignore;
      private static final AntiWeb.AntiMode[] $VALUES = new AntiWeb.AntiMode[]{Block, AntiWeb.AntiMode.Ignore};
   }
}
