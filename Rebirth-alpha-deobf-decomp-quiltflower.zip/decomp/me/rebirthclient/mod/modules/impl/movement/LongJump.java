package me.rebirthclient.mod.modules.impl.movement;

import java.util.List;
import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class LongJump extends Module {
   public double distance;
   boolean inAir;
   public final Setting<Boolean> noKick;
   public final Setting<Boolean> autoDisable;
   public int groundTicks;
   public final Setting<Double> boost = this.add(new Setting<>("Boost", 4.5, 0.1, 20.0));
   public static LongJump INSTANCE = new LongJump();
   public double speed;
   public int airTicks;
   public int stage;

   public LongJump() {
      super("LongJump", "ear", Category.MOVEMENT);
      this.noKick = this.add(new Setting<>("AntiKick", true));
      this.autoDisable = this.add(new Setting<>("AutoDisable", true));
      this.inAir = false;
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (var1.getPacket() instanceof SPacketPlayerPosLook) {
         if (this.noKick.getValue()) {
            this.disable();
         }

         this.speed = 0.0;
         this.stage = 0;
         this.airTicks = 0;
         this.groundTicks = 0;
      }
   }

   @Override
   public void onEnable() {
      this.inAir = false;
      if (mc.player != null) {
         this.distance = MovementUtil.getDistance2D();
         this.speed = MovementUtil.getSpeed();
      }

      this.stage = 0;
      this.airTicks = 0;
      this.groundTicks = 0;
   }

   @SubscribeEvent
   public void MoveEvent(MoveEvent var1) {
      if (mc.player.moveStrafing <= 0.0F && mc.player.moveForward <= 0.0F) {
         this.stage = 1;
      }

      if (MathUtil.round(mc.player.posY - (double)((int)mc.player.posY), 3) == MathUtil.round(0.943, 3)) {
         mc.player.motionY -= 0.03;
         var1.setY(var1.getY() - 0.03);
      }

      if (this.stage == 1 && MovementUtil.isMoving()) {
         this.stage = 2;
         this.speed = this.boost.getValue() * MovementUtil.getSpeed() - 0.01;
         boolean var11 = false;
      } else if (this.stage == 2) {
         this.stage = 3;
         mc.player.motionY = 0.424;
         var1.setY(0.424);
         this.speed *= 2.149802;
         boolean var10000 = false;
      } else if (this.stage == 3) {
         this.stage = 4;
         double var2 = 0.66 * (this.distance - MovementUtil.getSpeed());
         this.speed = this.distance - var2;
         boolean var10 = false;
      } else {
         if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(0.0, mc.player.motionY, 0.0)).size() > 0
            || mc.player.collidedVertically) {
            this.stage = 1;
         }

         this.speed = this.distance - this.distance / 159.0;
      }

      this.speed = Math.max(this.speed, MovementUtil.getSpeed());
      MovementUtil.strafe(var1, this.speed);
      float var9 = mc.player.movementInput.moveForward;
      float var3 = mc.player.movementInput.moveStrafe;
      float var4 = mc.player.rotationYaw;
      if (var9 == 0.0F && var3 == 0.0F) {
         var1.setX(0.0);
         var1.setZ(0.0);
         boolean var14 = false;
      } else if (var9 != 0.0F) {
         if (var3 >= 1.0F) {
            byte var10001;
            if (var9 > 0.0F) {
               var10001 = -45;
               boolean var10002 = false;
            } else {
               var10001 = 45;
            }

            var4 += (float)var10001;
            var3 = 0.0F;
            boolean var12 = false;
         } else if (var3 <= -1.0F) {
            byte var15;
            if (var9 > 0.0F) {
               var15 = 45;
               boolean var16 = false;
            } else {
               var15 = -45;
            }

            var4 += (float)var15;
            var3 = 0.0F;
         }

         if (var9 > 0.0F) {
            var9 = 1.0F;
            boolean var13 = false;
         } else if (var9 < 0.0F) {
            var9 = -1.0F;
         }
      }

      double var5 = Math.cos(Math.toRadians((double)(var4 + 90.0F)));
      double var7 = Math.sin(Math.toRadians((double)(var4 + 90.0F)));
      var1.setX((double)var9 * this.speed * var5 + (double)var3 * this.speed * var7);
      var1.setZ((double)var9 * this.speed * var7 - (double)var3 * this.speed * var5);
   }

   public double getDistance(EntityPlayer var1, double var2) {
      List var4 = var1.world.getCollisionBoxes(var1, var1.getEntityBoundingBox().offset(0.0, -var2, 0.0));
      if (var4.isEmpty()) {
         return 0.0;
      } else {
         double var5 = 0.0;

         for(AxisAlignedBB var8 : var4) {
            if (var8.maxY > var5) {
               var5 = var8.maxY;
            }

            boolean var10000 = false;
         }

         return var1.posY - var5;
      }
   }

   @Override
   public void onUpdate() {
      if (!mc.player.onGround) {
         this.inAir = true;
      }

      if (mc.player.onGround && this.inAir && this.autoDisable.getValue()) {
         this.disable();
      }
   }

   @SubscribeEvent
   public void onUpdate(UpdateWalkingPlayerEvent var1) {
      this.distance = MovementUtil.getDistance2D();
   }

   @Override
   public void onDisable() {
      this.inAir = false;
   }
}
