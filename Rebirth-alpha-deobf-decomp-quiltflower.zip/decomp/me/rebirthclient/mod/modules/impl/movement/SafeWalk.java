package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SafeWalk extends Module {
   public SafeWalk() {
      super("SafeWalk", "stop at the edge", Category.MOVEMENT);
   }

   public boolean isOffsetBBEmpty(double var1, double var3, double var5) {
      EntityPlayerSP var7 = mc.player;
      return mc.world.getCollisionBoxes(var7, var7.getEntityBoundingBox().offset(var1, var3, var5)).isEmpty();
   }

   @SubscribeEvent
   public void onMove(MoveEvent var1) {
      double var2 = var1.getX();
      double var4 = var1.getY();
      double var6 = var1.getZ();
      if (mc.player.onGround) {
         double var8 = 0.05;

         while(var2 != 0.0 && this.isOffsetBBEmpty(var2, -1.0, 0.0)) {
            if (var2 < var8 && var2 >= -var8) {
               var2 = 0.0;
               boolean var11 = false;
            } else if (var2 > 0.0) {
               var2 -= var8;
               boolean var10000 = false;
            } else {
               var2 += var8;
               boolean var10 = false;
            }
         }

         while(var6 != 0.0 && this.isOffsetBBEmpty(0.0, -1.0, var6)) {
            if (var6 < var8 && var6 >= -var8) {
               var6 = 0.0;
               boolean var14 = false;
            } else if (var6 > 0.0) {
               var6 -= var8;
               boolean var12 = false;
            } else {
               var6 += var8;
               boolean var13 = false;
            }
         }

         while(var2 != 0.0 && var6 != 0.0 && this.isOffsetBBEmpty(var2, -1.0, var6)) {
            double var15;
            if (var2 < var8 && var2 >= -var8) {
               var15 = 0.0;
               boolean var19 = false;
            } else if (var2 > 0.0) {
               var15 = var2 - var8;
               boolean var10001 = false;
            } else {
               var15 = var2 + var8;
            }

            var2 = var15;
            if (var6 < var8 && var6 >= -var8) {
               var6 = 0.0;
               boolean var18 = false;
            } else if (var6 > 0.0) {
               var6 -= var8;
               boolean var16 = false;
            } else {
               var6 += var8;
               boolean var17 = false;
            }
         }
      }

      var1.setX(var2);
      var1.setY(var4);
      var1.setZ(var6);
   }
}
