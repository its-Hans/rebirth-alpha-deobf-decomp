package me.rebirthclient.mod.modules.impl.movement;

import java.util.HashMap;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FastFall extends Module {
   private final Setting<Boolean> noLag;
   private final Setting<FastFall.Mode> mode = this.add(new Setting<>("Mode", FastFall.Mode.FAST));
   private boolean useTimer;
   private final Setting<Integer> height;
   private final Timer lagTimer;

   private int traceDown() {
      int var1 = 0;
      int var2 = (int)Math.round(mc.player.posY) - 1;

      for(int var3 = var2; var3 >= 0; --var3) {
         RayTraceResult var4 = mc.world.rayTraceBlocks(mc.player.getPositionVector(), new Vec3d(mc.player.posX, (double)var3, mc.player.posZ), false);
         if (var4 != null && var4.typeOfHit == Type.BLOCK) {
            return var1;
         }

         ++var1;
         boolean var10000 = false;
      }

      return var1;
   }

   @Override
   public String getInfo() {
      return Managers.TEXT.normalizeCases(this.mode.getValue());
   }

   @Override
   public void onTick() {
      if ((this.height.getValue() <= 0 || this.traceDown() <= this.height.getValue())
         && !mc.player.isEntityInsideOpaqueBlock()
         && !mc.player.isInWater()
         && !mc.player.isInLava()
         && !mc.player.isOnLadder()
         && this.lagTimer.passedMs(1000L)
         && !fullNullCheck()) {
         if (!mc.player.isInWeb) {
            if (mc.player.onGround && this.mode.getValue() == FastFall.Mode.FAST) {
               EntityPlayerSP var10000 = mc.player;
               double var10001 = mc.player.motionY;
               float var10002;
               if (this.noLag.getValue()) {
                  var10002 = 0.62F;
                  boolean var10003 = false;
               } else {
                  var10002 = 1.0F;
               }

               var10000.motionY = var10001 - (double)var10002;
            }

            if (this.traceDown() != 0 && this.traceDown() <= this.height.getValue() && this.trace() && mc.player.onGround) {
               mc.player.motionX *= 0.05F;
               mc.player.motionZ *= 0.05F;
            }

            if (this.mode.getValue() == FastFall.Mode.STRICT) {
               if (!mc.player.onGround) {
                  if (mc.player.motionY < 0.0 && this.useTimer) {
                     Managers.TIMER.set(2.5F);
                     return;
                  }

                  this.useTimer = false;
                  boolean var1 = false;
               } else {
                  mc.player.motionY = -0.08;
                  this.useTimer = true;
               }
            }

            Managers.TIMER.reset();
         }
      } else {
         if ((ElytraFly.INSTANCE.isOff() || !ElytraFly.INSTANCE.boostTimer.getValue()) && !NewStep.timer) {
            Managers.TIMER.reset();
         }
      }
   }

   @SubscribeEvent
   public void onPacket(PacketEvent var1) {
      if (!fullNullCheck() && var1.getPacket() instanceof SPacketPlayerPosLook) {
         this.lagTimer.reset();
         boolean var10000 = false;
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == FastFall.Mode.FAST) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onDisable() {
      Managers.TIMER.reset();
      this.useTimer = false;
   }

   private boolean trace() {
      AxisAlignedBB var1 = mc.player.getEntityBoundingBox();
      Vec3d var2 = var1.getCenter();
      double var3 = var1.minX;
      double var5 = var1.minZ;
      double var7 = var1.maxX;
      double var9 = var1.maxZ;
      HashMap var11 = new HashMap();
      var11.put(var2, new Vec3d(var2.x, var2.y - 1.0, var2.z));
      boolean var10000 = false;
      var11.put(new Vec3d(var3, var2.y, var5), new Vec3d(var3, var2.y - 1.0, var5));
      var10000 = false;
      var11.put(new Vec3d(var7, var2.y, var5), new Vec3d(var7, var2.y - 1.0, var5));
      var10000 = false;
      var11.put(new Vec3d(var3, var2.y, var9), new Vec3d(var3, var2.y - 1.0, var9));
      var10000 = false;
      var11.put(new Vec3d(var7, var2.y, var9), new Vec3d(var7, var2.y - 1.0, var9));
      var10000 = false;

      for(Vec3d var13 : var11.keySet()) {
         RayTraceResult var14 = mc.world.rayTraceBlocks(var13, (Vec3d)var11.get(var13), true);
         if (var14 != null && var14.typeOfHit == Type.BLOCK) {
            return false;
         }

         var10000 = false;
      }

      IBlockState var15 = mc.world.getBlockState(new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ));
      if (var15.getBlock() == Blocks.AIR) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public FastFall() {
      super("FastFall", "Miyagi son simulator", Category.MOVEMENT);
      this.noLag = this.add(new Setting<>("NoLag", true, this::lambda$new$0));
      this.height = this.add(new Setting<>("Height", 10, 1, 20));
      this.lagTimer = new Timer();
   }

   private static enum Mode {
      FAST,
      STRICT;
      private static final FastFall.Mode[] $VALUES = new FastFall.Mode[]{FastFall.Mode.FAST, FastFall.Mode.STRICT};
   }
}
