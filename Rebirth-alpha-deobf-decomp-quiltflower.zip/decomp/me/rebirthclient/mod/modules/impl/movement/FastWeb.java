package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class FastWeb extends Module {
   private final Setting<Float> fastSpeed;
   private final Setting<FastWeb.Mode> mode = this.add(new Setting<>("Mode", FastWeb.Mode.FAST));
   private final Setting<Boolean> onlySneak;

   public FastWeb() {
      super("FastWeb", "So you don't need to keep timer on keybind", Category.MOVEMENT);
      this.fastSpeed = this.add(new Setting<>("FastSpeed", 3.0F, 0.0F, 5.0F, this::lambda$new$0));
      this.onlySneak = this.add(new Setting<>("OnlySneak", false));
   }

   @Override
   public void onUpdate() {
      if (mc.player.isInWeb) {
         if ((this.mode.getValue() != FastWeb.Mode.FAST || !mc.gameSettings.keyBindSneak.isKeyDown()) && this.onlySneak.getValue()) {
            if ((this.mode.getValue() != FastWeb.Mode.STRICT || mc.player.onGround || !mc.gameSettings.keyBindSneak.isKeyDown()) && this.onlySneak.getValue()) {
               if ((ElytraFly.INSTANCE.isOff() || !ElytraFly.INSTANCE.boostTimer.getValue()) && !NewStep.timer) {
                  Managers.TIMER.reset();
                  boolean var2 = false;
               }
            } else {
               Managers.TIMER.set(8.0F);
               boolean var1 = false;
            }
         } else {
            Managers.TIMER.reset();
            mc.player.motionY -= (double)this.fastSpeed.getValue().floatValue();
            boolean var10000 = false;
         }
      } else if ((ElytraFly.INSTANCE.isOff() || !ElytraFly.INSTANCE.boostTimer.getValue()) && !NewStep.timer) {
         Managers.TIMER.reset();
      }
   }

   @Override
   public void onDisable() {
      Managers.TIMER.reset();
   }

   @Override
   public String getInfo() {
      return Managers.TEXT.normalizeCases(this.mode.getValue());
   }

   private boolean lambda$new$0(Float var1) {
      boolean var10000;
      if (this.mode.getValue() == FastWeb.Mode.FAST) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static enum Mode {
      STRICT,
      FAST;

      private static final FastWeb.Mode[] $VALUES = new FastWeb.Mode[]{FAST, STRICT};
   }
}
