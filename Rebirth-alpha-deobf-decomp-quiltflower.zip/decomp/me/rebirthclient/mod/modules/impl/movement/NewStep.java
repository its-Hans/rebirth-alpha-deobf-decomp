package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.events.impl.StepEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.exploit.Clip;
import me.rebirthclient.mod.modules.impl.player.Freecam;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityLlama;
import net.minecraft.entity.passive.EntityMule;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NewStep extends Module {
   public Setting<Boolean> useTimer;
   public Setting<Boolean> entityStep;
   public Setting<Integer> stepDelay;
   private final Timer stepTimer = new Timer();
   private final Setting<Boolean> onlyMoving;
   private final Setting<Boolean> pauseSneak;
   private final Setting<Boolean> pauseBurrow;
   public static boolean timer;
   private final Setting<NewStep.Mode> mode;
   private Entity entityRiding;
   public Setting<Float> height = this.register(new Setting<>("Height", 2.0F, 1.0F, 2.5F));
   private final Setting<Boolean> pauseWeb;
   public Setting<Boolean> strict;

   @SubscribeEvent
   public void onStep(StepEvent var1) {
      if (this.mode.getValue().equals(NewStep.Mode.NORMAL)) {
         double var2 = var1.getAxisAlignedBB().minY - mc.player.posY;
         if (var2 <= 0.0 || var2 > (double)this.height.getValue().floatValue()) {
            return;
         }

         double[] var4 = this.getOffset(var2);
         if (var4 != null && var4.length > 1) {
            if (this.useTimer.getValue()) {
               Managers.TIMER.timer = 1.0F / (float)var4.length;
               timer = true;
            }

            for(double var8 : var4) {
               mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + var8, mc.player.posZ, false));
               boolean var10000 = false;
            }
         }

         this.stepTimer.reset();
         boolean var10 = false;
      }
   }

   public double[] getOffset(double var1) {
      if (var1 == 0.75) {
         return this.strict.getValue() ? new double[]{0.42, 0.753, 0.75} : new double[]{0.42, 0.753};
      } else if (var1 == 0.8125) {
         return this.strict.getValue() ? new double[]{0.39, 0.7, 0.8125} : new double[]{0.39, 0.7};
      } else if (var1 == 0.875) {
         return this.strict.getValue() ? new double[]{0.39, 0.7, 0.875} : new double[]{0.39, 0.7};
      } else if (var1 == 1.0) {
         return this.strict.getValue() ? new double[]{0.42, 0.753, 1.0} : new double[]{0.42, 0.753};
      } else if (var1 == 1.5) {
         return new double[]{0.42, 0.75, 1.0, 1.16, 1.23, 1.2};
      } else if (var1 == 2.0) {
         return new double[]{0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43};
      } else {
         return var1 == 2.5 ? new double[]{0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.907} : null;
      }
   }

   public NewStep() {
      super("NewStep", "褏芯写懈褌褜 锌芯 斜谢芯泻邪屑 1 懈谢懈 2 斜谢芯泻邪", Category.MOVEMENT);
      this.entityStep = this.add(new Setting<>("EntityStep", false));
      this.useTimer = this.add(new Setting<>("Timer", true));
      this.strict = this.add(new Setting<>("Strict", false));
      this.pauseBurrow = this.add(new Setting<>("PauseBurrow", true));
      this.pauseSneak = this.add(new Setting<>("PauseSneak", true));
      this.pauseWeb = this.add(new Setting<>("PauseWeb", true));
      this.onlyMoving = this.add(new Setting<>("OnlyMoving", true));
      this.stepDelay = this.register(new Setting<>("StepDelay", 200, 0, 1000));
      this.mode = this.add(new Setting<>("Mode", NewStep.Mode.NORMAL));
   }

   @Override
   public void onUpdate() {
      if ((
            mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.PISTON_HEAD
               || mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.OBSIDIAN
               || mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.ENDER_CHEST
               || mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.BEDROCK
         )
         && this.pauseBurrow.getValue()) {
         mc.player.stepHeight = 0.6F;
      } else if ((
            mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.PISTON_HEAD
               || mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.OBSIDIAN
               || mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.ENDER_CHEST
               || mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.BEDROCK
         )
         && this.pauseBurrow.getValue()) {
         mc.player.stepHeight = 0.6F;
      } else if (this.pauseWeb.getValue() && mc.player.isInWeb) {
         mc.player.stepHeight = 0.6F;
      } else if (SneakManager.isSneaking && this.pauseSneak.getValue()) {
         mc.player.stepHeight = 0.6F;
      } else if (this.onlyMoving.getValue() && !MovementUtil.isMoving() && HoleSnap.INSTANCE.isOff()) {
         mc.player.stepHeight = 0.6F;
      } else if (Clip.INSTANCE.isOn()) {
         mc.player.stepHeight = 0.6F;
      } else if (mc.player.capabilities.isFlying || Freecam.INSTANCE.isOn()) {
         mc.player.stepHeight = 0.6F;
      } else if (EntityUtil.isInLiquid()) {
         mc.player.stepHeight = 0.6F;
      } else {
         if (timer && mc.player.onGround) {
            Managers.TIMER.timer = 1.0F;
            timer = false;
         }

         if (mc.player.onGround && this.stepTimer.passedMs((long)this.stepDelay.getValue().intValue())) {
            if (mc.player.isRiding() && mc.player.getRidingEntity() != null) {
               this.entityRiding = mc.player.getRidingEntity();
               if (this.entityStep.getValue()) {
                  mc.player.getRidingEntity().stepHeight = this.height.getValue();
                  boolean var3 = false;
               }
            } else {
               mc.player.stepHeight = this.height.getValue();
               boolean var2 = false;
            }
         } else if (mc.player.isRiding() && mc.player.getRidingEntity() != null) {
            this.entityRiding = mc.player.getRidingEntity();
            if (this.entityRiding != null) {
               if (!(this.entityRiding instanceof EntityHorse)
                  && !(this.entityRiding instanceof EntityLlama)
                  && !(this.entityRiding instanceof EntityMule)
                  && (!(this.entityRiding instanceof EntityPig) || !this.entityRiding.isBeingRidden() || !((EntityPig)this.entityRiding).canBeSteered())) {
                  this.entityRiding.stepHeight = 0.5F;
                  boolean var1 = false;
               } else {
                  this.entityRiding.stepHeight = 1.0F;
                  boolean var10000 = false;
               }
            }
         } else {
            mc.player.stepHeight = 0.6F;
         }
      }
   }

   @Override
   public void onDisable() {
      super.onDisable();
      mc.player.stepHeight = 0.6F;
      if (this.entityRiding != null) {
         if (!(this.entityRiding instanceof EntityHorse)
            && !(this.entityRiding instanceof EntityLlama)
            && !(this.entityRiding instanceof EntityMule)
            && (!(this.entityRiding instanceof EntityPig) || !this.entityRiding.isBeingRidden() || !((EntityPig)this.entityRiding).canBeSteered())) {
            this.entityRiding.stepHeight = 0.5F;
         } else {
            this.entityRiding.stepHeight = 1.0F;
            boolean var10000 = false;
         }
      }
   }

   public static enum Mode {
      VANILLA,
      NORMAL;
      private static final NewStep.Mode[] $VALUES = new NewStep.Mode[]{NewStep.Mode.NORMAL, VANILLA};
   }
}
