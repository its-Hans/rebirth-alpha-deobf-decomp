package me.rebirthclient.mod.modules.impl.movement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.exploit.Blink;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.Timer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HoleSnap extends Module {
   private BlockPos holePos;
   public static final List<BlockPos> holeBlocks = Arrays.asList(
      new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(-1, 0, 0), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1)
   );
   private static final BlockPos[] surroundOffset = new BlockPos[]{
      new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(-1, 0, 0)
   };
   private final Setting<Integer> timeoutTicks;
   private final Setting<Boolean> blink = this.add(new Setting<>("Blink", false));
   boolean resetMove;
   public static HoleSnap INSTANCE;
   private final Setting<Float> timer;
   private final Setting<Integer> range = this.add(new Setting<>("Range", 5, 1, 50));
   private int stuckTicks;
   private int enabledTicks;

   public HoleSnap() {
      super("HoleSnap", "IQ", Category.MOVEMENT);
      this.timer = this.add(new Setting<>("Timer", 1.6F, 1.0F, 8.0F));
      this.timeoutTicks = this.add(new Setting<>("TimeOutTicks", 10, 0, 30));
      this.resetMove = false;
      INSTANCE = this;
   }

   public static boolean isHole(BlockPos var0) {
      boolean var10000;
      if (getBlockResistance(var0.add(0, 1, 0)) != HoleSnap.BlockResistance.Blank
         || getBlockResistance(var0.add(0, 0, 0)) != HoleSnap.BlockResistance.Blank
         || getBlockResistance(var0.add(0, 2, 0)) != HoleSnap.BlockResistance.Blank
         || getBlockResistance(var0.add(0, 0, -1)) != HoleSnap.BlockResistance.Resistant
            && getBlockResistance(var0.add(0, 0, -1)) != HoleSnap.BlockResistance.Unbreakable
         || getBlockResistance(var0.add(1, 0, 0)) != HoleSnap.BlockResistance.Resistant
            && getBlockResistance(var0.add(1, 0, 0)) != HoleSnap.BlockResistance.Unbreakable
         || getBlockResistance(var0.add(-1, 0, 0)) != HoleSnap.BlockResistance.Resistant
            && getBlockResistance(var0.add(-1, 0, 0)) != HoleSnap.BlockResistance.Unbreakable
         || getBlockResistance(var0.add(0, 0, 1)) != HoleSnap.BlockResistance.Resistant
            && getBlockResistance(var0.add(0, 0, 1)) != HoleSnap.BlockResistance.Unbreakable
         || getBlockResistance(var0.add(0.5, 0.5, 0.5)) != HoleSnap.BlockResistance.Blank
         || getBlockResistance(var0.add(0, -1, 0)) != HoleSnap.BlockResistance.Resistant
            && getBlockResistance(var0.add(0, -1, 0)) != HoleSnap.BlockResistance.Unbreakable) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public double applySpeedPotionEffects(EntityLivingBase var1) {
      PotionEffect var2 = var1.getActivePotionEffect(MobEffects.SPEED);
      double var3;
      if (var2 == null) {
         var3 = 0.2873;
         boolean var10000 = false;
      } else {
         var3 = 0.2873 * this.getSpeedEffectMultiplier(var1);
      }

      return var3;
   }

   @SubscribeEvent
   public void onInput(InputUpdateEvent var1) {
      if (var1.getMovementInput() instanceof MovementInputFromOptions && this.holePos != null) {
         MovementInput var2 = var1.getMovementInput();
         this.resetMove(var2);
      }
   }

   private void resetMove(MovementInput var1) {
      var1.moveForward = 0.0F;
      var1.moveStrafe = 0.0F;
      var1.forwardKeyDown = false;
      var1.backKeyDown = false;
      var1.leftKeyDown = false;
      var1.rightKeyDown = false;
   }

   public List<BlockPos> getBlockPositionsInArea(BlockPos var1, BlockPos var2) {
      int var3 = Math.min(var1.getX(), var2.getX());
      int var4 = Math.max(var1.getX(), var2.getX());
      int var5 = Math.min(var1.getY(), var2.getY());
      int var6 = Math.max(var1.getY(), var2.getY());
      int var7 = Math.min(var1.getZ(), var2.getZ());
      int var8 = Math.max(var1.getZ(), var2.getZ());
      return this.getBlockPos(var3, var4, var5, var6, var7, var8);
   }

   public Vec3d toVec3dCenter(Vec3i var1) {
      return this.toVec3dCenter(var1, 0.0, 0.0, 0.0);
   }

   public Vec3d toVec3dCenter(Vec3i var1, double var2, double var4, double var6) {
      return new Vec3d((double)var1.getX() + 0.5 + var2, (double)var1.getY() + 0.5 + var4, (double)var1.getZ() + 0.5 + var6);
   }

   @Override
   public void onTick() {
      ++this.enabledTicks;
      if (this.enabledTicks > this.timeoutTicks.getValue() - 1) {
         this.disable();
      } else {
         if (mc.player.isEntityAlive()) {
            if (!this.isFlying(mc.player)) {
               EntityPlayerSP var1 = mc.player;
               double var2 = this.getSpeed(var1);
               if (this.shouldDisable(var2)) {
                  this.disable();
                  return;
               }

               BlockPos var4 = this.getHole();
               if (var4 != null) {
                  if (mc.player.posY - (double)var4.getY() < 0.5
                     && mc.player.posX - (double)var4.getX() <= 0.65
                     && mc.player.posX - (double)var4.getX() >= 0.35
                     && mc.player.posZ - (double)var4.getZ() <= 0.65
                     && mc.player.posZ - (double)var4.getZ() >= 0.35) {
                     this.disable();
                     return;
                  }

                  if (mc.player.posX - (double)var4.getX() <= 0.65
                     && mc.player.posX - (double)var4.getX() >= 0.35
                     && mc.player.posZ - (double)var4.getZ() <= 0.65
                     && mc.player.posZ - (double)var4.getZ() >= 0.35) {
                     mc.player.motionX = 0.0;
                     mc.player.motionZ = 0.0;
                     return;
                  }

                  this.resetMove = true;
                  Timer var5 = mc.timer;
                  Float var6 = this.timer.getValue();
                  var5.tickLength = 50.0F / var6;
                  if (!this.isCentered(mc.player, var4)) {
                     Vec3d var7 = mc.player.getPositionVector();
                     Vec3d var8 = new Vec3d((double)var4.getX() + 0.5, mc.player.posY, (double)var4.getZ() + 0.5);
                     float var9 = this.getRotationTo(var7, var8).x;
                     float var10 = var9 / 180.0F * (float) Math.PI;
                     double var11 = var7.distanceTo(var8);
                     EntityPlayerSP var13 = mc.player;
                     double var14 = this.applySpeedPotionEffects(var13);
                     double var10000;
                     if (mc.player.onGround) {
                        var10000 = var14;
                        boolean var10001 = false;
                     } else {
                        var10000 = Math.max(var2 + 0.02, var14);
                     }

                     double var16 = var10000;
                     double var18 = Math.min(var16, var11);
                     mc.player.motionX = (double)(-((float)Math.sin((double)var10))) * var18;
                     mc.player.motionZ = (double)((float)Math.cos((double)var10)) * var18;
                     if (mc.player.collidedHorizontally) {
                        ++this.stuckTicks;
                        boolean var20 = false;
                     } else {
                        this.stuckTicks = 0;
                     }
                  }

                  boolean var21 = false;
               } else {
                  this.disable();
               }

               boolean var22 = false;
            } else {
               this.disable();
               boolean var23 = false;
            }
         } else {
            this.disable();
         }
      }
   }

   private double normalizeAngle(double var1) {
      double var3 = var1 % 360.0;
      if (var3 >= 180.0) {
         var3 -= 360.0;
      }

      if (var3 < -180.0) {
         var3 += 360.0;
      }

      return var3;
   }

   private boolean isCentered(Entity var1, BlockPos var2) {
      double var3 = (double)var2.getX() + 0.31;
      double var5 = (double)var2.getX() + 0.69;
      double var7 = var1.posX;
      if (var3 > var7) {
         return false;
      } else if (var7 > var5) {
         return false;
      } else {
         var3 = (double)var2.getZ() + 0.31;
         var5 = (double)var2.getZ() + 0.69;
         var7 = var1.posZ;
         boolean var10000;
         if (var3 <= var7 && var7 <= var5) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private BlockPos getHole() {
      if (mc.player.ticksExisted % 10 == 0) {
         EntityPlayerSP var1 = mc.player;
         if (!this.getFlooredPosition(var1).equals(this.holePos)) {
            return this.findHole();
         }
      }

      BlockPos var3 = this.holePos;
      return var3 != null ? var3 : this.findHole();
   }

   private boolean isFlying(EntityPlayer var1) {
      boolean var10000;
      if (!var1.isElytraFlying() && !var1.capabilities.isFlying) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static HoleSnap.BlockResistance getBlockResistance(BlockPos var0) {
      if (mc.world.isAirBlock(var0)) {
         return HoleSnap.BlockResistance.Blank;
      } else if (mc.world.getBlockState(var0).getBlock().getBlockHardness(mc.world.getBlockState(var0), mc.world, var0) != -1.0F
         && !mc.world.getBlockState(var0).getBlock().equals(Blocks.OBSIDIAN)
         && !mc.world.getBlockState(var0).getBlock().equals(Blocks.ANVIL)
         && !mc.world.getBlockState(var0).getBlock().equals(Blocks.ENCHANTING_TABLE)
         && !mc.world.getBlockState(var0).getBlock().equals(Blocks.ENDER_CHEST)) {
         return HoleSnap.BlockResistance.Breakable;
      } else if (mc.world.getBlockState(var0).getBlock().equals(Blocks.OBSIDIAN)
         || mc.world.getBlockState(var0).getBlock().equals(Blocks.ANVIL)
         || mc.world.getBlockState(var0).getBlock().equals(Blocks.ENCHANTING_TABLE)
         || mc.world.getBlockState(var0).getBlock().equals(Blocks.ENDER_CHEST)) {
         return HoleSnap.BlockResistance.Resistant;
      } else {
         return mc.world.getBlockState(var0).getBlock().equals(Blocks.BEDROCK) ? HoleSnap.BlockResistance.Unbreakable : null;
      }
   }

   private BlockPos findHole() {
      HoleSnap.Pair var1 = new HoleSnap.Pair<>(69.69, BlockPos.ORIGIN);
      EntityPlayerSP var2 = mc.player;
      BlockPos var3 = this.getFlooredPosition(var2);
      Integer var4 = this.range.getValue();
      BlockPos var5 = var3.add(var4, -1, var4);
      BlockPos var6 = var3.add(-var4, -1, -var4);

      for(BlockPos var9 : this.getBlockPositionsInArea(var5, var6)) {
         EntityPlayerSP var10 = mc.player;
         double var11 = this.distanceTo(var10, var9);
         Integer var13 = this.range.getValue();
         if (var11 <= Double.valueOf((double)var13.intValue())) {
            if (var11 > var1.getLeft()) {
               boolean var21 = false;
               continue;
            }

            int var14 = 0;

            while(var14 < 6) {
               WorldClient var10000 = mc.world;
               BlockPos var15 = var9.add(0, -var14, 0);
               if (!var10000.isAirBlock(var15.up())) {
                  break;
               }

               if (!is2HoleB(var15) && this.checkHole(var15) == HoleSnap.HoleType.NONE) {
                  boolean var19 = false;
                  ++var14;
               } else {
                  var1 = new HoleSnap.Pair<>(var11, var15);
                  boolean var18 = false;
               }
            }
         }

         boolean var20 = false;
      }

      BlockPos var17;
      if (var1.getRight() != BlockPos.ORIGIN) {
         var6 = (BlockPos)var1.getRight();
         this.holePos = var6;
         var17 = var6;
         boolean var22 = false;
      } else {
         var17 = null;
      }

      return var17;
   }

   public BlockPos getFlooredPosition(Entity var1) {
      return new BlockPos((int)Math.floor(var1.posX), (int)Math.floor(var1.posY), (int)Math.floor(var1.posZ));
   }

   public static BlockPos is2Hole(BlockPos var0) {
      if (isHole(var0)) {
         return null;
      } else {
         BlockPos var1 = null;
         int var2 = 0;
         int var3 = 0;
         if (mc.world.getBlockState(var0).getBlock() != Blocks.AIR) {
            return null;
         } else {
            for(BlockPos var5 : holeBlocks) {
               if (mc.world.getBlockState(var0.add(var5)).getBlock() == Blocks.AIR) {
                  if (var0.add(var5).equals(new BlockPos(var5.getX(), var5.getY() - 1, var5.getZ()))) {
                     boolean var10 = false;
                     continue;
                  }

                  var1 = var0.add(var5);
                  ++var2;
               }

               boolean var10000 = false;
            }

            if (var2 == 1) {
               for(BlockPos var8 : holeBlocks) {
                  if (mc.world.getBlockState(var0.add(var8)).getBlock() != Blocks.BEDROCK
                     && mc.world.getBlockState(var0.add(var8)).getBlock() != Blocks.OBSIDIAN) {
                     boolean var12 = false;
                  } else {
                     ++var3;
                     boolean var11 = false;
                  }
               }

               for(BlockPos var9 : holeBlocks) {
                  if (mc.world.getBlockState(var1.add(var9)).getBlock() != Blocks.BEDROCK
                     && mc.world.getBlockState(var1.add(var9)).getBlock() != Blocks.OBSIDIAN) {
                     boolean var14 = false;
                  } else {
                     ++var3;
                     boolean var13 = false;
                  }
               }
            }

            return var3 == 8 ? var1 : null;
         }
      }
   }

   @Override
   public void onDisable() {
      if (this.blink.getValue() && Blink.INSTANCE.isOn()) {
         Blink.INSTANCE.disable();
      }

      if (this.resetMove) {
         mc.player.motionX = 0.0;
         mc.player.motionZ = 0.0;
      }

      this.holePos = null;
      this.stuckTicks = 0;
      this.enabledTicks = 0;
      mc.timer.tickLength = 50.0F;
   }

   public HoleSnap.HoleType checkHole(BlockPos var1) {
      if (mc.world.isAirBlock(var1) && mc.world.isAirBlock(var1.up()) && mc.world.isAirBlock(var1.up().up())) {
         HoleSnap.HoleType var2 = HoleSnap.HoleType.BEDROCK;

         for(BlockPos var6 : surroundOffset) {
            Block var7 = mc.world.getBlockState(var1.add(var6)).getBlock();
            if (!this.checkBlock(var7)) {
               var2 = HoleSnap.HoleType.NONE;
               boolean var8 = false;
               break;
            }

            boolean var10000 = false;
         }

         return var2;
      } else {
         return HoleSnap.HoleType.NONE;
      }
   }

   private double getSpeedEffectMultiplier(EntityLivingBase var1) {
      PotionEffect var2 = var1.getActivePotionEffect(MobEffects.SPEED);
      double var3;
      if (var2 == null) {
         var3 = 1.0;
         boolean var10000 = false;
      } else {
         var3 = 1.0 + ((double)var2.getAmplifier() + 1.0) * 0.2;
      }

      return var3;
   }

   public double getSpeed(Entity var1) {
      return Math.hypot(var1.motionX, var1.motionZ);
   }

   public static boolean is2HoleB(BlockPos var0) {
      boolean var10000;
      if (is2Hole(var0) != null) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private Vec2f getRotationTo(Vec3d var1, Vec3d var2) {
      Vec3d var3 = var2.subtract(var1);
      return this.getRotationFromVec(var3);
   }

   private Vec2f getRotationFromVec(Vec3d var1) {
      double var2 = var1.x;
      double var4 = var1.z;
      double var6 = Math.hypot(var2, var4);
      var4 = var1.z;
      double var8 = var1.x;
      double var10 = this.normalizeAngle(Math.toDegrees(Math.atan2(var4, var8)) - 90.0);
      double var12 = this.normalizeAngle(Math.toDegrees(-Math.atan2(var1.y, var6)));
      return new Vec2f((float)var10, (float)var12);
   }

   public double distanceTo(Entity var1, Vec3i var2) {
      double var3 = (double)var2.getX() + 0.5 - var1.posX;
      double var5 = (double)var2.getY() + 0.5 - var1.posY;
      double var7 = (double)var2.getZ() + 0.5 - var1.posZ;
      return Math.sqrt(var3 * var3 + var5 * var5 + var7 * var7);
   }

   private boolean shouldDisable(double var1) {
      BlockPos var3 = this.holePos;
      if (var3 != null) {
         if (mc.player.posY < (double)var3.getY()) {
            return true;
         }

         if (is2HoleB(var3)) {
            BlockPos var4 = mc.player.getPosition();
            if (this.toBlockPos(this.toVec3dCenter(var4)).equals(var3)) {
               return true;
            }
         }
      }

      if (this.stuckTicks > 5 && var1 < 0.1) {
         return true;
      } else if (var1 >= 0.01) {
         return false;
      } else {
         EntityPlayerSP var5 = mc.player;
         boolean var10000;
         if (this.checkHole(var5) != HoleSnap.HoleType.NONE) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public HoleSnap.HoleType checkHole(Entity var1) {
      return this.checkHole(this.getFlooredPosition(var1));
   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (var1.getPacket() instanceof SPacketPlayerPosLook) {
         this.disable();
      }
   }

   @Override
   public void onEnable() {
      if (this.blink.getValue() && Blink.INSTANCE.isOff()) {
         Blink.INSTANCE.enable();
      }

      this.resetMove = false;
   }

   private boolean checkBlock(Block var1) {
      boolean var10000;
      if (var1 != Blocks.BEDROCK && var1 != Blocks.OBSIDIAN && var1 != Blocks.ENDER_CHEST && var1 != Blocks.ANVIL) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public BlockPos toBlockPos(Vec3d var1) {
      int var2 = (int)Math.floor(var1.x);
      int var3 = (int)Math.floor(var1.y);
      return new BlockPos(var2, var3, (int)Math.floor(var1.z));
   }

   private List<BlockPos> getBlockPos(int var1, int var2, int var3, int var4, int var5, int var6) {
      ArrayList var7 = new ArrayList();
      int var8 = var1;
      int var9;
      if (var1 <= var2) {
         do {
            var9 = var8++;
            int var10 = var5;
            int var11;
            if (var5 > var6) {
               boolean var18 = false;
            } else {
               do {
                  var11 = var10++;
                  int var12 = var3;
                  if (var3 > var4) {
                     boolean var15 = false;
                  } else {
                     do {
                        var7.add(new BlockPos(var9, var12, var11));
                        boolean var16 = false;
                     } while(var12++ != var4);
                  }
               } while(var11 != var6);
            }
         } while(var9 != var2);
      }

      return var7;
   }

   public static enum BlockResistance {
      Unbreakable,
      Resistant,
      Blank,
      Breakable;

      private static final HoleSnap.BlockResistance[] $VALUES = new HoleSnap.BlockResistance[]{Blank, Breakable, Resistant, Unbreakable};
   }

   public static enum HoleType {
      OBBY,
      BEDROCK,
      NONE;
      private static final HoleSnap.HoleType[] $VALUES = new HoleSnap.HoleType[]{HoleSnap.HoleType.NONE, OBBY, BEDROCK};
   }

   public static class Pair<L, R> {
      R right;
      L left;

      public R getRight() {
         return this.right;
      }

      public Pair(L var1, R var2) {
         this.left = (L)var1;
         this.right = (R)var2;
      }

      public HoleSnap.Pair<L, R> setRight(R var1) {
         this.right = (R)var1;
         return this;
      }

      public HoleSnap.Pair<L, R> setLeft(L var1) {
         this.left = (L)var1;
         return this;
      }

      public L getLeft() {
         return this.left;
      }
   }
}
