package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.events.impl.ElytraEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.MoverType;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ElytraFly extends Module {
   public Setting<Float> maxSpeed;
   private final Setting<Float> timeout;
   private static boolean hasElytra = false;
   public Setting<Float> downFactor;
   public Setting<Float> upFactor;
   private final Timer instantFlyTimer;
   public final Setting<Boolean> boostTimer;
   private final Setting<Boolean> instantFly = this.register(new Setting<>("InstantFly", true));
   private boolean hasTouchedGround;
   public static ElytraFly INSTANCE = new ElytraFly();
   public Setting<Float> speed;
   private final Timer strictTimer;
   public Setting<Boolean> noDrag;
   private final Setting<Float> sneakDownSpeed;
   public Setting<Boolean> speedLimit;

   private boolean lambda$new$0(Float var1) {
      return this.speedLimit.getValue();
   }

   @SubscribeEvent
   public void onElytra(ElytraEvent var1) {
      if (!fullNullCheck() && hasElytra && mc.player.isElytraFlying()) {
         if (var1.getEntity() == mc.player && mc.player.isServerWorld()
            || mc.player.canPassengerSteer() && !mc.player.isInWater()
            || mc.player.capabilities.isFlying && !mc.player.isInLava()
            || mc.player.capabilities.isFlying && mc.player.isElytraFlying()) {
            var1.setCanceled(true);
            Vec3d var2 = mc.player.getLookVec();
            double var3 = Math.sqrt(var2.x * var2.x + var2.z * var2.z);
            double var5 = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
            if (mc.gameSettings.keyBindSneak.isKeyDown()) {
               mc.player.motionY = (double)(-this.sneakDownSpeed.getValue());
               boolean var10000 = false;
            } else if (!MovementUtil.isJumping()) {
               mc.player.motionY = -3.0E-14 * (double)this.downFactor.getValue().floatValue();
            }

            if (MovementUtil.isJumping()) {
               if (var5 > (double)(this.upFactor.getValue() / this.upFactor.getMaxValue())) {
                  double var7 = var5 * 0.01325;
                  mc.player.motionY += var7 * 3.2;
                  mc.player.motionX -= var2.x * var7 / var3;
                  mc.player.motionZ -= var2.z * var7 / var3;
                  boolean var12 = false;
               } else {
                  double[] var9 = directionSpeed((double)this.speed.getValue().floatValue());
                  mc.player.motionX = var9[0];
                  mc.player.motionZ = var9[1];
               }
            }

            if (var3 > 0.0) {
               mc.player.motionX += (var2.x / var3 * var5 - mc.player.motionX) * 0.1;
               mc.player.motionZ += (var2.z / var3 * var5 - mc.player.motionZ) * 0.1;
            }

            if (!MovementUtil.isJumping()) {
               double[] var10 = directionSpeed((double)this.speed.getValue().floatValue());
               mc.player.motionX = var10[0];
               mc.player.motionZ = var10[1];
            }

            if (!this.noDrag.getValue()) {
               mc.player.motionX *= 0.99F;
               mc.player.motionY *= 0.98F;
               mc.player.motionZ *= 0.99F;
            }

            double var11 = Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ);
            if (this.speedLimit.getValue() && var11 > (double)this.maxSpeed.getValue().floatValue()) {
               mc.player.motionX *= (double)this.maxSpeed.getValue().floatValue() / var11;
               mc.player.motionZ *= (double)this.maxSpeed.getValue().floatValue() / var11;
            }

            mc.player.move(MoverType.SELF, mc.player.motionX, mc.player.motionY, mc.player.motionZ);
         }
      }
   }

   @Override
   public void onEnable() {
      if (mc.player != null) {
         if (!mc.player.isCreative()) {
            mc.player.capabilities.allowFlying = false;
         }

         mc.player.capabilities.isFlying = false;
      }

      hasElytra = false;
   }

   public ElytraFly() {
      super("ElytraFly", "斜褍褋褌褘 写谢褟 2斜", Category.MOVEMENT);
      this.timeout = this.register(new Setting<>("Timeout", 0.5F, 0.1F, 1.0F));
      this.upFactor = this.register(new Setting<>("UpFactor", 1.0F, 0.0F, 10.0F));
      this.downFactor = this.register(new Setting<>("DownFactor", 1.0F, 0.0F, 10.0F));
      this.speed = this.register(new Setting<>("Speed", 1.0F, 0.1F, 10.0F));
      this.sneakDownSpeed = this.register(new Setting<>("DownSpeed", 1.0F, 0.1F, 10.0F));
      this.boostTimer = this.register(new Setting<>("Timer", true));
      this.speedLimit = this.register(new Setting<>("SpeedLimit", true));
      this.maxSpeed = this.register(new Setting<>("MaxSpeed", 2.5F, 0.1F, 10.0F, this::lambda$new$0));
      this.noDrag = new Setting<>("NoDrag", false);
      this.instantFlyTimer = new Timer();
      this.strictTimer = new Timer();
      this.hasTouchedGround = false;
      INSTANCE = this;
   }

   @Override
   public void onUpdate() {
      if (!fullNullCheck()) {
         if (mc.player.onGround) {
            this.hasTouchedGround = true;
         }

         for(ItemStack var2 : mc.player.getArmorInventoryList()) {
            if (var2.getItem() instanceof ItemElytra) {
               hasElytra = true;
               boolean var3 = false;
               break;
            }

            hasElytra = false;
            boolean var10000 = false;
         }

         if (this.strictTimer.passedMs(1500L) && !this.strictTimer.passedMs(2000L) || mc.player.isElytraFlying() && Managers.TIMER.get() == 0.3F) {
            Managers.TIMER.reset();
         }

         if (!mc.player.isElytraFlying()) {
            if (this.hasTouchedGround && this.boostTimer.getValue() && !mc.player.onGround) {
               Managers.TIMER.set(0.3F);
            }

            if (!mc.player.onGround && this.instantFly.getValue() && mc.player.motionY < 0.0) {
               if (!this.instantFlyTimer.passedMs((long)(1000.0F * this.timeout.getValue()))) {
                  return;
               }

               this.instantFlyTimer.reset();
               boolean var5 = false;
               mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_FALL_FLYING));
               this.hasTouchedGround = false;
               this.strictTimer.reset();
               var5 = false;
            }
         } else {
            mc.player.isElytraFlying();
            boolean var4 = false;
         }
      }
   }

   @Override
   public void onDisable() {
      if (mc.player != null) {
         if (!mc.player.isCreative()) {
            mc.player.capabilities.allowFlying = false;
         }

         mc.player.capabilities.isFlying = false;
      }

      Managers.TIMER.reset();
      hasElytra = false;
   }

   public static double[] directionSpeed(double var0) {
      float var2 = mc.player.movementInput.moveForward;
      float var3 = mc.player.movementInput.moveStrafe;
      float var4 = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
      if (var2 != 0.0F) {
         if (var3 > 0.0F) {
            byte var10001;
            if (var2 > 0.0F) {
               var10001 = -45;
               boolean var10002 = false;
            } else {
               var10001 = 45;
            }

            var4 += (float)var10001;
            boolean var10000 = false;
         } else if (var3 < 0.0F) {
            byte var14;
            if (var2 > 0.0F) {
               var14 = 45;
               boolean var15 = false;
            } else {
               var14 = -45;
            }

            var4 += (float)var14;
         }

         var3 = 0.0F;
         if (var2 > 0.0F) {
            var2 = 1.0F;
            boolean var13 = false;
         } else if (var2 < 0.0F) {
            var2 = -1.0F;
         }
      }

      double var5 = Math.sin(Math.toRadians((double)(var4 + 90.0F)));
      double var7 = Math.cos(Math.toRadians((double)(var4 + 90.0F)));
      double var9 = (double)var2 * var0 * var7 + (double)var3 * var0 * var5;
      double var11 = (double)var2 * var0 * var5 - (double)var3 * var0 * var7;
      return new double[]{var9, var11};
   }
}
