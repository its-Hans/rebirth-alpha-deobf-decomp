package me.rebirthclient.mod.modules.impl.movement;

import java.util.Objects;
import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Strafe extends Module {
   private final Setting<Float> multiplier;
   private final Setting<Float> Dist;
   private final Setting<Double> jumpMotion;
   private final Setting<Float> SPEEDH;
   private final Setting<Float> plier;
   private final Setting<Float> SPEEDY;
   public final Setting<Strafe.Mode> mode = this.add(new Setting<>("Mode", Strafe.Mode.Normal));
   private double lastDist;
   int stage;
   private final Setting<Float> StrafeH;
   private final Setting<Float> StrafeY;
   public static Strafe INSTANCE = new Strafe();
   private final Setting<Boolean> jump = this.add(new Setting<>("Jump", false));
   private double moveSpeed;
   private final Setting<Float> multiDist;

   public double getBaseMoveSpeed() {
      double var1 = 0.2873;
      if (mc.player.isPotionActive(MobEffects.SPEED)) {
         var1 *= 1.0 + 0.2 * (double)(((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SPEED))).getAmplifier() + 1);
      }

      return var1;
   }

   public Strafe() {
      super("Strafe", "Modifies sprinting", Category.MOVEMENT);
      this.jumpMotion = this.add(new Setting<>("JumpMotion", 0.40123128, 0.1, 1.0));
      this.multiplier = this.add(new Setting<>("Factor", 1.67F, 0.0F, 3.0F));
      this.plier = this.add(new Setting<>("Factor+", 2.149F, 0.0F, 3.0F));
      this.Dist = this.add(new Setting<>("Dist", 0.6896F, 0.1F, 1.0F));
      this.multiDist = this.add(new Setting<>("Dist+", 0.795F, 0.1F, 1.0F));
      this.SPEEDY = this.add(new Setting<>("SpeedY", 730.0F, 500.0F, 800.0F));
      this.SPEEDH = this.add(new Setting<>("SpeedH", 159.0F, 100.0F, 300.0F));
      this.StrafeH = this.add(new Setting<>("SpeedH", 0.993F, 0.1F, 1.0F));
      this.StrafeY = this.add(new Setting<>("SpeedY", 0.99F, 0.1F, 1.2F));
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayerEvent(UpdateWalkingPlayerEvent var1) {
      if (!fullNullCheck()) {
         this.lastDist = Math.sqrt(
            (mc.player.posX - mc.player.prevPosX) * (mc.player.posX - mc.player.prevPosX)
               + (mc.player.posZ - mc.player.prevPosZ) * (mc.player.posZ - mc.player.prevPosZ)
         );
      }
   }

   @SubscribeEvent
   public void onStrafe(MoveEvent var1) {
      if (!fullNullCheck()) {
         if (!HoleSnap.INSTANCE.isOn()) {
            if (!mc.player.isInWater() && !mc.player.isInLava()) {
               if (mc.player.onGround) {
                  this.stage = 2;
               }

               if (this.stage == 0) {
                  ++this.stage;
                  this.lastDist = 0.0;
                  boolean var12 = false;
               } else if (this.stage == 2) {
                  double var2 = this.jumpMotion.getValue();
                  if (mc.player.onGround && this.jump.getValue() || mc.gameSettings.keyBindJump.isKeyDown()) {
                     if (mc.player.isPotionActive(MobEffects.JUMP_BOOST)) {
                        var2 += (double)(
                           (float)(((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST))).getAmplifier() + 1) * 0.1F
                        );
                     }

                     mc.player.motionY = var2;
                     var1.setY(mc.player.motionY);
                     double var17 = this.moveSpeed;
                     Float var22;
                     if (this.mode.getValue() == Strafe.Mode.Normal) {
                        var22 = this.multiplier.getValue();
                        boolean var25 = false;
                     } else {
                        var22 = this.plier.getValue();
                     }

                     this.moveSpeed = var17 * (double)var22.floatValue();
                  }

                  boolean var11 = false;
               } else if (this.stage == 3) {
                  double var16 = this.lastDist;
                  Float var21;
                  if (this.mode.getValue() == Strafe.Mode.Normal) {
                     var21 = this.Dist.getValue();
                     boolean var24 = false;
                  } else {
                     var21 = this.multiDist.getValue();
                  }

                  this.moveSpeed = var16 - (double)var21.floatValue() * (this.lastDist - this.getBaseMoveSpeed());
                  boolean var10000 = false;
               } else {
                  if ((
                        mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(0.0, mc.player.motionY, 0.0)).size() > 0
                           || mc.player.collidedVertically
                     )
                     && this.stage > 0) {
                     byte var10001;
                     if (mc.player.moveForward == 0.0F && mc.player.moveStrafing == 0.0F) {
                        var10001 = 0;
                     } else {
                        var10001 = 1;
                        boolean var10002 = false;
                     }

                     this.stage = var10001;
                  }

                  double var15 = this.lastDist;
                  double var20 = this.lastDist;
                  Float var10003;
                  if (this.mode.getValue() == Strafe.Mode.Normal) {
                     var10003 = this.SPEEDY.getValue();
                     boolean var10004 = false;
                  } else {
                     var10003 = this.SPEEDH.getValue();
                  }

                  this.moveSpeed = var15 - var20 / (double)var10003.floatValue();
               }

               double var18;
               if (!mc.gameSettings.keyBindJump.isKeyDown()
                  && (!InventoryMove.INSTANCE.isOn() || !Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode()) || mc.currentScreen instanceof GuiChat)
                  && mc.player.onGround) {
                  var18 = this.getBaseMoveSpeed();
                  boolean var23 = false;
               } else {
                  var18 = Math.max(this.moveSpeed, this.getBaseMoveSpeed());
               }

               this.moveSpeed = var18;
               double var10 = (double)mc.player.movementInput.moveForward;
               double var4 = (double)mc.player.movementInput.moveStrafe;
               double var6 = (double)mc.player.rotationYaw;
               if (var10 == 0.0 && var4 == 0.0) {
                  var1.setX(0.0);
                  var1.setZ(0.0);
                  boolean var13 = false;
               } else if (var10 != 0.0 && var4 != 0.0) {
                  var10 *= Math.sin(Math.PI / 4);
                  var4 *= Math.cos(Math.PI / 4);
               }

               double var14;
               if (this.mode.getValue() == Strafe.Mode.Normal) {
                  var14 = (double)this.StrafeH.getValue().floatValue();
                  boolean var19 = false;
               } else {
                  var14 = (double)this.StrafeY.getValue().floatValue();
               }

               double var8 = var14;
               var1.setX((var10 * this.moveSpeed * -Math.sin(Math.toRadians(var6)) + var4 * this.moveSpeed * Math.cos(Math.toRadians(var6))) * var8);
               var1.setZ((var10 * this.moveSpeed * Math.cos(Math.toRadians(var6)) - var4 * this.moveSpeed * -Math.sin(Math.toRadians(var6))) * var8);
               ++this.stage;
               var1.setCanceled(false);
            }
         }
      }
   }

   @Override
   public String getInfo() {
      return this.mode.getValue().name();
   }

   public static enum Mode {
      Normal,
      Strict;

      private static final Strafe.Mode[] $VALUES = new Strafe.Mode[]{Normal, Strict};
   }
}
