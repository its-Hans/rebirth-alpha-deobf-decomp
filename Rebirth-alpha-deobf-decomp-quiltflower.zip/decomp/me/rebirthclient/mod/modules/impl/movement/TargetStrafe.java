package me.rebirthclient.mod.modules.impl.movement;

import java.awt.Color;
import java.util.Objects;
import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.combat.Aura;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.potion.Potion;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class TargetStrafe extends Module {
   EntityPlayer strafeTarget;
   private final Setting<Boolean> addddd;
   private final Setting<Float> reversedDistance = this.add(new Setting<>("ReversedDistance", 3.0F, 1.0F, 6.0F));
   private final Setting<Boolean> strafeBoost;
   private final Setting<Boolean> autoJump;
   private final Setting<Boolean> autoThirdPerson;
   private final Setting<Float> spd;
   int velocity;
   private final Setting<Boolean> drawRadius;
   private final Setting<Float> velocityUse;
   private final Setting<Integer> boostTicks;
   private final Setting<Float> speedIfUsing = this.add(new Setting<>("Speed if using", 0.1F, 0.1F, 2.0F));
   private final Setting<Boolean> speedIfPotion;
   private final Setting<Float> reduction;
   float speedy;
   private final Setting<Boolean> whenMoving;
   private final Setting<Float> potionSpeed;
   int boostticks;
   private final Setting<Boolean> smartStrafe;
   private final Setting<Float> targetRange;
   private final Setting<Float> range = this.add(new Setting<>("StrafeDistance", 2.4F, 0.1F, 6.0F));
   private final Setting<Boolean> reversed;
   private float wrap;
   private final Setting<Boolean> usingItemCheck;
   private final Setting<Integer> boostDecr;
   private boolean switchDir;

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onPacketReceive(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (var1.getPacket() instanceof SPacketEntityVelocity && ((SPacketEntityVelocity)var1.getPacket()).getEntityID() == mc.player.getEntityId()) {
            SPacketEntityVelocity var2 = var1.getPacket();
            int var3 = var2.getMotionX();
            int var4 = var2.getMotionZ();
            if (var3 < 0) {
               var3 *= -1;
            }

            if (var4 < 0) {
               var4 *= -1;
            }

            this.velocity = var3 + var4;
         }
      }
   }

   private float toDegree(double var1, double var3) {
      return (float)(Math.atan2(var3 - mc.player.posZ, var1 - mc.player.posX) * 180.0 / Math.PI) - 90.0F;
   }

   @Override
   public void onEnable() {
      this.wrap = 0.0F;
      this.switchDir = true;
      Managers.TIMER.set(1.0F);
      this.velocity = 0;
   }

   public boolean needToSwitch(double var1, double var3) {
      if (!mc.gameSettings.keyBindLeft.isPressed() && !mc.gameSettings.keyBindRight.isPressed()) {
         int var5 = (int)(mc.player.posY + 4.0);

         while(true) {
            if (var5 < 0) {
               return true;
            }

            BlockPos var6 = new BlockPos(var1, (double)var5, var3);
            if (mc.world.getBlockState(var6).getBlock().equals(Blocks.LAVA)) {
               boolean var9 = false;
               break;
            }

            if (mc.world.getBlockState(var6).getBlock().equals(Blocks.FIRE)) {
               break;
            }

            boolean var10000 = false;
            if (!mc.world.isAirBlock(var6)) {
               return false;
            }

            var10000 = false;
            var10000 = false;
            --var5;
         }

         return true;
      } else {
         return true;
      }
   }

   public TargetStrafe() {
      super("TargetStrafe", "袙褉邪褖邪褌褜褋褟 胁芯泻褉褍谐 褑械谢懈", Category.MOVEMENT);
      this.spd = this.add(new Setting<>("StrafeSpeed", 0.23F, 0.1F, 2.0F));
      this.reversed = this.add(new Setting<>("Reversed", false));
      this.whenMoving = this.add(new Setting<>("WhenMoving", true));
      this.autoJump = this.add(new Setting<>("AutoJump", true));
      this.smartStrafe = this.add(new Setting<>("SmartStrafe", true));
      this.usingItemCheck = this.add(new Setting<>("EatingSlowDown", false));
      this.speedIfPotion = this.add(new Setting<>("Speed if Potion ", true));
      this.potionSpeed = this.add(new Setting<>("PotionSpeed", 0.45F, 0.1F, 2.0F, this::lambda$new$0));
      this.autoThirdPerson = this.register(new Setting<>("AutoThirdPerson", Boolean.TRUE));
      this.targetRange = this.register(new Setting<>("TargetRange", 3.8F, 0.1F, 7.0F));
      this.drawRadius = this.add(new Setting<>("drawRadius", true));
      this.strafeBoost = this.add(new Setting<>("StrafeBoost", false));
      this.addddd = this.add(new Setting<>("add", false));
      this.reduction = this.add(new Setting<>("reduction", 2.0F, 1.0F, 5.0F));
      this.velocityUse = this.add(new Setting<>("velocityUse", 50000.0F, 0.1F, 100000.0F));
      this.boostTicks = this.register(new Setting<>("BoostTicks", 5, 0, 60));
      this.boostDecr = this.register(new Setting<>("BoostDecr", 5, 0, 5000));
      this.strafeTarget = null;
      this.boostticks = 0;
      this.speedy = 1.0F;
      this.velocity = 0;
      this.wrap = 0.0F;
      this.switchDir = true;
   }

   @SubscribeEvent
   @Override
   public void onRender3D(Render3DEvent var1) {
      if (Aura.target != null && this.drawRadius.getValue()) {
         RenderUtil.drawCircle(
            (float)Aura.target.posX - 0.5F,
            (float)(Aura.target.posY + 1.0),
            (float)Aura.target.posZ - 0.5F,
            this.range.getValue(),
            new Color(255, 255, 255, 255)
         );
      }
   }

   @Override
   public void onUpdate() {
      if (!this.whenMoving.getValue() || MovementUtil.isMoving()) {
         if (Aura.target != null) {
            if (!(Aura.target instanceof EntityPlayer)) {
               return;
            }

            this.strafeTarget = (EntityPlayer)Aura.target;
            boolean var10000 = false;
         } else {
            this.strafeTarget = null;
         }
      }
   }

   @Override
   public void onDisable() {
      if (this.autoThirdPerson.getValue()) {
         mc.gameSettings.thirdPersonView = 0;
      }
   }

   private boolean lambda$new$0(Float var1) {
      return this.speedIfPotion.getValue();
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayerPre(MotionEvent var1) {
      if (!this.whenMoving.getValue() || MovementUtil.isMoving()) {
         if (this.strafeTarget != null) {
            if (!(mc.player.getDistanceSq(this.strafeTarget) < 0.2)) {
               if (this.autoThirdPerson.getValue()) {
                  if (!(this.strafeTarget.getHealth() > 0.0F)
                     || !(mc.player.getDistance(this.strafeTarget) <= this.targetRange.getValue())
                     || !(mc.player.getHealth() > 0.0F)) {
                     mc.gameSettings.thirdPersonView = 0;
                  } else if (Aura.INSTANCE.isOn()) {
                     mc.gameSettings.thirdPersonView = 1;
                     boolean var10000 = false;
                  }
               }

               if (mc.player.getDistance(this.strafeTarget) <= this.targetRange.getValue()) {
                  if (EntityUtil.getHealth(this.strafeTarget) > 0.0F && this.autoJump.getValue() && Aura.INSTANCE.isOn() && mc.player.onGround) {
                     mc.player.jump();
                  }

                  if (EntityUtil.getHealth(this.strafeTarget) > 0.0F) {
                     EntityPlayer var2 = this.strafeTarget;
                     if (var2 == null || mc.player.ticksExisted < 20) {
                        return;
                     }

                     if (this.speedIfPotion.getValue()) {
                        if (mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionFromResourceLocation("speed")))) {
                           this.speedy = this.potionSpeed.getValue();
                           boolean var10 = false;
                        } else {
                           this.speedy = this.spd.getValue();
                           boolean var11 = false;
                        }
                     } else {
                        this.speedy = this.spd.getValue();
                     }

                     float var12;
                     if (mc.gameSettings.keyBindUseItem.isKeyDown() && this.usingItemCheck.getValue()) {
                        var12 = this.speedIfUsing.getValue();
                        boolean var10001 = false;
                     } else {
                        var12 = this.speedy;
                     }

                     float var3 = var12;
                     if ((float)this.velocity > this.velocityUse.getValue() && this.strafeBoost.getValue()) {
                        if (this.velocity < 0) {
                           this.velocity = 0;
                        }

                        if (this.addddd.getValue()) {
                           var3 += (float)this.velocity / 8000.0F / this.reduction.getValue();
                           boolean var13 = false;
                        } else {
                           var3 = (float)this.velocity / 8000.0F / this.reduction.getValue();
                        }

                        ++this.boostticks;
                        this.velocity -= this.boostDecr.getValue();
                     }

                     if (this.boostticks >= this.boostTicks.getValue()) {
                        this.boostticks = 0;
                        this.velocity = 0;
                     }

                     this.wrap = (float)Math.atan2(mc.player.posZ - var2.posZ, mc.player.posX - var2.posX);
                     float var16 = this.wrap;
                     float var10002;
                     if (this.switchDir) {
                        var10002 = var3 / mc.player.getDistance(var2);
                        boolean var10003 = false;
                     } else {
                        var10002 = -(var3 / mc.player.getDistance(var2));
                     }

                     this.wrap = var16 + var10002;
                     double var4 = var2.posX + (double)this.range.getValue().floatValue() * Math.cos((double)this.wrap);
                     double var6 = var2.posZ + (double)this.range.getValue().floatValue() * Math.sin((double)this.wrap);
                     if (this.smartStrafe.getValue() && this.needToSwitch(var4, var6)) {
                        boolean var17;
                        if (!this.switchDir) {
                           var17 = true;
                           boolean var21 = false;
                        } else {
                           var17 = false;
                        }

                        this.switchDir = var17;
                        var16 = this.wrap;
                        float var22;
                        if (this.switchDir) {
                           var22 = var3 / mc.player.getDistance(var2);
                           boolean var10004 = false;
                        } else {
                           var22 = -(var3 / mc.player.getDistance(var2));
                        }

                        this.wrap = var16 + 2.0F * var22;
                        var4 = var2.posX + (double)this.range.getValue().floatValue() * Math.cos((double)this.wrap);
                        var6 = var2.posZ + (double)this.range.getValue().floatValue() * Math.sin((double)this.wrap);
                     }

                     if (this.reversed.getValue() && mc.player.getDistance(this.strafeTarget) < this.reversedDistance.getValue()) {
                        var12 = -90.0F;
                        boolean var19 = false;
                     } else {
                        var12 = 0.0F;
                     }

                     float var8 = var12;
                     if (!mc.gameSettings.keyBindLeft.isKeyDown() && !mc.gameSettings.keyBindRight.isKeyDown()) {
                        var12 = var8;
                        boolean var20 = false;
                     } else {
                        var12 = 0.0F;
                     }

                     float var9 = var12;
                     mc.player.motionX = (double)var3
                        * -Math.sin((double)((float)Math.toRadians((double)this.toDegree(var4 + (double)var9, var6 + (double)var9))));
                     mc.player.motionZ = (double)var3
                        * Math.cos((double)((float)Math.toRadians((double)this.toDegree(var4 + (double)var9, var6 + (double)var9))));
                  }
               }
            }
         }
      }
   }
}
