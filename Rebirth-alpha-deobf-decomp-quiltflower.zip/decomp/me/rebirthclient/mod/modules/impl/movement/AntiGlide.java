package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.util.MovementInput;

public class AntiGlide extends Module {
   private final Setting<Boolean> ice;
   private final Setting<Boolean> onGround = this.add(new Setting<>("OnGround", true));

   @Override
   public void onUpdate() {
      if (!HoleSnap.INSTANCE.isOn() && !AutoCenter.INSTANCE.isOn()) {
         if (!this.onGround.getValue() || mc.player.onGround) {
            MovementInput var1 = mc.player.movementInput;
            if ((double)var1.moveForward == 0.0 && (double)var1.moveStrafe == 0.0) {
               mc.player.motionX = 0.0;
               mc.player.motionZ = 0.0;
            }

            if (this.ice.getValue() && mc.player.getRidingEntity() == null) {
               this.setIceSlipperiness(0.6F);
               boolean var10000 = false;
            } else {
               this.setIceSlipperiness(0.98F);
            }
         }
      }
   }

   @Override
   public void onDisable() {
      this.setIceSlipperiness(0.98F);
   }

   public AntiGlide() {
      super("AntiGlide", "Prevents inertial moving", Category.MOVEMENT);
      this.ice = this.add(new Setting<>("Ice", true));
   }

   private void setIceSlipperiness(float var1) {
      Blocks.ICE.setDefaultSlipperiness(var1);
      Blocks.FROSTED_ICE.setDefaultSlipperiness(var1);
      Blocks.PACKED_ICE.setDefaultSlipperiness(var1);
   }
}
