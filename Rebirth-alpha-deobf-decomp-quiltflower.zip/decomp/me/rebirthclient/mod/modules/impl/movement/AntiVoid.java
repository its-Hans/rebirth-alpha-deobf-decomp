package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class AntiVoid extends Module {
   private final Setting<Integer> height = this.add(new Setting<>("Height", 100, 0, 256));

   public AntiVoid() {
      super("AntiVoid", "Allows you to fly over void blocks", Category.MOVEMENT);
   }

   @Override
   public void onTick() {
      boolean var1 = true;

      for(int var2 = (int)mc.player.posY; var2 > -1; --var2) {
         if (BlockUtil.getBlock(new BlockPos(mc.player.posX, (double)var2, mc.player.posZ)) != Blocks.AIR) {
            var1 = false;
            boolean var3 = false;
            break;
         }

         boolean var10000 = false;
      }

      if (mc.player.posY < (double)this.height.getValue().intValue() && var1) {
         mc.player.motionY = 0.0;
      }
   }
}
