package me.rebirthclient.mod.modules.impl.movement;

import java.text.DecimalFormat;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.exploit.Clip;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayer.Position;

public class Step extends Module {
   private final Setting<Step.Mode> mode;
   private final Setting<Boolean> pauseSneak;
   public static Step INSTANCE;
   private final Setting<Boolean> pauseBurrow;
   private final Setting<Double> height = this.add(new Setting<>("Height", 2.5, 0.5, 3.5));
   private final Setting<Boolean> pauseWeb;
   private final Setting<Boolean> onlyMoving;

   @Override
   public void onUpdate() {
      if ((
            mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.PISTON_HEAD
               || mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.OBSIDIAN
               || mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.ENDER_CHEST
               || mc.world.getBlockState(EntityUtil.getPlayerPos()).getBlock() == Blocks.BEDROCK
         )
         && this.pauseBurrow.getValue()) {
         mc.player.stepHeight = 0.1F;
      } else if ((
            mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.PISTON_HEAD
               || mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.OBSIDIAN
               || mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.ENDER_CHEST
               || mc.world.getBlockState(EntityUtil.getPlayerPos().up()).getBlock() == Blocks.BEDROCK
         )
         && this.pauseBurrow.getValue()) {
         mc.player.stepHeight = 0.1F;
      } else if (this.pauseWeb.getValue() && mc.player.isInWeb) {
         mc.player.stepHeight = 0.1F;
      } else if (SneakManager.isSneaking && this.pauseSneak.getValue()) {
         mc.player.stepHeight = 0.1F;
      } else if (this.onlyMoving.getValue() && !MovementUtil.isMoving() && HoleSnap.INSTANCE.isOff()) {
         mc.player.stepHeight = 0.1F;
      } else if (Clip.INSTANCE.isOn()) {
         mc.player.stepHeight = 0.1F;
      } else if (!mc.player.isInWater() && !mc.player.isInLava() && !mc.player.isOnLadder() && !mc.gameSettings.keyBindJump.isKeyDown()) {
         if (this.mode.getValue() == Step.Mode.Normal) {
            mc.player.stepHeight = 0.6F;
            double[] var1 = forward(0.1);
            boolean var2 = false;
            boolean var3 = false;
            boolean var4 = false;
            boolean var5 = false;
            if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 2.6, var1[1])).isEmpty()
               && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 2.4, var1[1])).isEmpty()) {
               var2 = true;
            }

            if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 2.1, var1[1])).isEmpty()
               && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 1.9, var1[1])).isEmpty()) {
               var3 = true;
            }

            if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 1.6, var1[1])).isEmpty()
               && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 1.4, var1[1])).isEmpty()) {
               var4 = true;
            }

            if (mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 1.0, var1[1])).isEmpty()
               && !mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(var1[0], 0.6, var1[1])).isEmpty()) {
               var5 = true;
            }

            if (mc.player.collidedHorizontally && (mc.player.moveForward != 0.0F || mc.player.moveStrafing != 0.0F) && mc.player.onGround) {
               if (var5 && this.height.getValue() >= 1.0) {
                  double[] var7 = new double[]{0.42, 0.753};

                  for(int var6 = 0; var6 < var7.length; ++var6) {
                     mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + var7[var6], mc.player.posZ, mc.player.onGround));
                     boolean var10000 = false;
                  }

                  mc.player.setPosition(mc.player.posX, mc.player.posY + 1.0, mc.player.posZ);
               }

               if (var4 && this.height.getValue() >= 1.5) {
                  double[] var12 = new double[]{0.42, 0.75, 1.0, 1.16, 1.23, 1.2};

                  for(int var9 = 0; var9 < var12.length; ++var9) {
                     mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + var12[var9], mc.player.posZ, mc.player.onGround));
                     boolean var15 = false;
                  }

                  mc.player.setPosition(mc.player.posX, mc.player.posY + 1.5, mc.player.posZ);
               }

               if (var3 && this.height.getValue() >= 2.0) {
                  double[] var13 = new double[]{0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43};

                  for(int var10 = 0; var10 < var13.length; ++var10) {
                     mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + var13[var10], mc.player.posZ, mc.player.onGround));
                     boolean var16 = false;
                  }

                  mc.player.setPosition(mc.player.posX, mc.player.posY + 2.0, mc.player.posZ);
               }

               if (var2 && this.height.getValue() >= 2.5) {
                  double[] var14 = new double[]{0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.907};

                  for(int var11 = 0; var11 < var14.length; ++var11) {
                     mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + var14[var11], mc.player.posZ, mc.player.onGround));
                     boolean var17 = false;
                  }

                  mc.player.setPosition(mc.player.posX, mc.player.posY + 2.5, mc.player.posZ);
               }
            }
         }

         if (this.mode.getValue() == Step.Mode.Vanilla) {
            DecimalFormat var8 = new DecimalFormat("#");
            mc.player.stepHeight = Float.parseFloat(var8.format(this.height.getValue()));
         }
      } else {
         mc.player.stepHeight = 0.1F;
      }
   }

   @Override
   public void onDisable() {
      mc.player.stepHeight = 0.6F;
   }

   @Override
   public String getInfo() {
      return this.mode.getValue().name();
   }

   public Step() {
      super("Step", "step", Category.MOVEMENT);
      this.mode = this.add(new Setting<>("Mode", Step.Mode.Vanilla));
      this.pauseBurrow = this.add(new Setting<>("PauseBurrow", true));
      this.pauseSneak = this.add(new Setting<>("PauseSneak", true));
      this.pauseWeb = this.add(new Setting<>("PauseWeb", true));
      this.onlyMoving = this.add(new Setting<>("OnlyMoving", true));
      INSTANCE = this;
   }

   public static double[] forward(double var0) {
      float var2 = mc.player.movementInput.moveForward;
      float var3 = mc.player.movementInput.moveStrafe;
      float var4 = mc.player.prevRotationYaw + (mc.player.rotationYaw - mc.player.prevRotationYaw) * mc.getRenderPartialTicks();
      if (var2 != 0.0F) {
         if (var3 > 0.0F) {
            byte var10001;
            if (var2 > 0.0F) {
               var10001 = -45;
               boolean var10002 = false;
            } else {
               var10001 = 45;
            }

            var4 += (float)var10001;
            boolean var10000 = false;
         } else if (var3 < 0.0F) {
            byte var14;
            if (var2 > 0.0F) {
               var14 = 45;
               boolean var15 = false;
            } else {
               var14 = -45;
            }

            var4 += (float)var14;
         }

         var3 = 0.0F;
         if (var2 > 0.0F) {
            var2 = 1.0F;
            boolean var13 = false;
         } else if (var2 < 0.0F) {
            var2 = -1.0F;
         }
      }

      double var5 = Math.sin(Math.toRadians((double)(var4 + 90.0F)));
      double var7 = Math.cos(Math.toRadians((double)(var4 + 90.0F)));
      double var9 = (double)var2 * var0 * var7 + (double)var3 * var0 * var5;
      double var11 = (double)var2 * var0 * var5 - (double)var3 * var0 * var7;
      return new double[]{var9, var11};
   }

   public static enum Mode {
      Vanilla,
      Normal;

      private static final Step.Mode[] $VALUES = new Step.Mode[]{Vanilla, Normal};
   }
}
