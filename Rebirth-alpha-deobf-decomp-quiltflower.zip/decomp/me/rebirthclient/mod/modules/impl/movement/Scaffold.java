package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Scaffold extends Module {
   private final Setting<Boolean> airCheck;
   private float lastYaw;
   private final Setting<Boolean> down;
   private final Setting<Integer> placeDelay;
   private final Setting<Float> yCheck;
   private final Timer rotateTimer;
   private final Timer placeTimer;
   private final Setting<Boolean> allowUp;
   private final Setting<Boolean> tower;
   private final Setting<Boolean> search;
   private final Setting<Integer> rotateTimerSetting;
   private final Setting<Float> range;
   private float lastPitch;
   private final Setting<Boolean> rotate;
   private final Timer timer;
   private final Setting<Boolean> packet;
   private final Setting<Boolean> sameY;
   private final Setting<Scaffold.SwapMode> autoSwap;
   private final Setting<Boolean> safeWalk = this.add(new Setting<>("SafeWalk", false));
   private BlockPos PlacePos;

   @SubscribeEvent
   public final void onMotion(MotionEvent var1) {
      if (!this.rotateTimer.passedMs((long)this.rotateTimerSetting.getValue().intValue()) && this.rotate.getValue()) {
         var1.setYaw(this.lastYaw);
         var1.setPitch(this.lastPitch);
      }
   }

   @Override
   public void onTick() {
      if (this.placeTimer.passedMs((long)this.placeDelay.getValue().intValue())) {
         if (this.PlacePos == null) {
            this.PlacePos = new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ);
         }

         this.doScaffold();
      }
   }

   private boolean lambda$new$3(Float var1) {
      return this.sameY.isOpen();
   }

   public Scaffold() {
      super("Scaffold", "Places Blocks underneath you", Category.MOVEMENT);
      this.rotate = this.add(new Setting<>("Rotate", true).setParent());
      this.rotateTimerSetting = this.add(new Setting<>("RotateTimer", 800, 0, 1000, this::lambda$new$0));
      this.packet = this.add(new Setting<>("Packet", false));
      this.placeDelay = this.add(new Setting<>("PlaceDelay", 100, 0, 500));
      this.autoSwap = this.add(new Setting<>("AutoSwap", Scaffold.SwapMode.SILENT));
      this.search = this.add(new Setting<>("Search", true).setParent());
      this.allowUp = this.add(new Setting<>("AllowUp", false, this::lambda$new$1));
      this.range = this.add(new Setting<>("Range", 3.5F, 2.5F, 5.0F, this::lambda$new$2));
      this.timer = new Timer();
      this.placeTimer = new Timer();
      this.tower = this.add(new Setting<>("Tower", true));
      this.down = this.add(new Setting<>("Down", true));
      this.sameY = this.add(new Setting<>("SameY", false).setParent());
      this.yCheck = this.add(new Setting<>("YCheck", 2.5F, 2.5F, 12.0F, this::lambda$new$3));
      this.airCheck = this.add(new Setting<>("AirCheck", true, this::lambda$new$4));
      this.rotateTimer = new Timer();
      this.lastYaw = 0.0F;
      this.lastPitch = 0.0F;
   }

   @SubscribeEvent
   public void onMove(MoveEvent var1) {
      if (this.safeWalk.getValue()) {
         if (!this.down.getValue() || !mc.gameSettings.keyBindSprint.isKeyDown()) {
            double var2 = var1.getX();
            double var4 = var1.getY();
            double var6 = var1.getZ();
            if (mc.player.onGround) {
               double var8 = 0.05;

               while(var2 != 0.0 && this.isOffsetBBEmpty(var2, -1.0, 0.0)) {
                  if (var2 < var8 && var2 >= -var8) {
                     var2 = 0.0;
                     boolean var11 = false;
                  } else if (var2 > 0.0) {
                     var2 -= var8;
                     boolean var10000 = false;
                  } else {
                     var2 += var8;
                     boolean var10 = false;
                  }
               }

               while(var6 != 0.0 && this.isOffsetBBEmpty(0.0, -1.0, var6)) {
                  if (var6 < var8 && var6 >= -var8) {
                     var6 = 0.0;
                     boolean var14 = false;
                  } else if (var6 > 0.0) {
                     var6 -= var8;
                     boolean var12 = false;
                  } else {
                     var6 += var8;
                     boolean var13 = false;
                  }
               }

               while(var2 != 0.0 && var6 != 0.0 && this.isOffsetBBEmpty(var2, -1.0, var6)) {
                  double var15;
                  if (var2 < var8 && var2 >= -var8) {
                     var15 = 0.0;
                     boolean var19 = false;
                  } else if (var2 > 0.0) {
                     var15 = var2 - var8;
                     boolean var10001 = false;
                  } else {
                     var15 = var2 + var8;
                  }

                  var2 = var15;
                  if (var6 < var8 && var6 >= -var8) {
                     var6 = 0.0;
                     boolean var18 = false;
                  } else if (var6 > 0.0) {
                     var6 -= var8;
                     boolean var16 = false;
                  } else {
                     var6 += var8;
                     boolean var17 = false;
                  }
               }
            }

            var1.setX(var2);
            var1.setY(var4);
            var1.setZ(var6);
         }
      }
   }

   public void doScaffold() {
      if (!MovementUtil.isJumping()) {
         this.timer.reset();
         boolean var10000 = false;
      }

      if (this.sameY.getValue()
         && !(mc.player.posY - (double)this.PlacePos.getY() > (double)this.yCheck.getValue().floatValue())
         && (!this.airCheck.getValue() || BlockUtil.canReplace(new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ)))
         && (!MovementUtil.isJumping() || MovementUtil.isMoving())
         && new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ).getY() >= this.PlacePos.getY()) {
         this.PlacePos = new BlockPos(mc.player.posX, (double)this.PlacePos.getY(), mc.player.posZ);
      } else {
         this.PlacePos = new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ);
         boolean var1 = false;
      }

      if (this.down.getValue() && mc.gameSettings.keyBindSprint.isKeyDown()) {
         this.PlacePos = new BlockPos(mc.player.posX, mc.player.posY - 2.0, mc.player.posZ);
      }

      this.place(this.PlacePos);
   }

   public boolean isOffsetBBEmpty(double var1, double var3, double var5) {
      EntityPlayerSP var7 = mc.player;
      return mc.world.getCollisionBoxes(var7, var7.getEntityBoundingBox().offset(var1, var3, var5)).isEmpty();
   }

   private boolean lambda$new$0(Integer var1) {
      return this.rotate.isOpen();
   }

   public void place(BlockPos var1) {
      if (!(var1.getDistance((int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ) > 6.0)) {
         if (BlockUtil.canReplace(var1)) {
            if (this.search.getValue() && !BlockUtil.canBlockFacing(var1)) {
               BlockPos var2 = null;
               double var3 = 1000.0;
               boolean var10000;
               if (!this.allowUp.getValue()) {
                  var10000 = true;
                  boolean var10001 = false;
               } else {
                  var10000 = false;
               }

               boolean var5 = var10000;

               for(BlockPos var7 : BlockUtil.getBox(this.range.getValue(), var1)) {
                  if (!BlockUtil.canPlace(var7)) {
                     var10000 = false;
                  } else {
                     if ((var2 == null || var1.getDistance(var7.getX(), var7.getY(), var7.getZ()) < var3) && !var5) {
                        var2 = var7;
                        var3 = var1.getDistance(var7.getX(), var7.getY(), var7.getZ());
                     }

                     if ((var2 == null || var1.getDistance(var7.getX(), var7.getY(), var7.getZ()) < var3) && var1.getY() >= var7.getY()) {
                        var2 = var7;
                        var3 = var1.getDistance(var7.getX(), var7.getY(), var7.getZ());
                        var5 = true;
                     }

                     var10000 = false;
                  }
               }

               if (var2 == null) {
                  return;
               }

               var1 = var2;
            }

            if (BlockUtil.canPlace(var1)) {
               int var8 = mc.player.inventory.currentItem;
               int var9 = -1;

               for(int var4 = 0; var4 < 9; ++var4) {
                  ItemStack var11 = mc.player.inventory.getStackInSlot(var4);
                  if (!InventoryUtil.isNull(var11) && var11.getItem() instanceof ItemBlock) {
                     if (Block.getBlockFromItem(var11.getItem()).getDefaultState().isFullBlock()) {
                        var9 = var4;
                        boolean var19 = false;
                        break;
                     }

                     boolean var17 = false;
                  }

                  boolean var18 = false;
               }

               if (var9 != -1) {
                  EnumFacing var10 = BlockUtil.getFirstFacing(var1);
                  if (var10 != null) {
                     boolean var12 = false;
                     if (!(mc.player.getHeldItemMainhand().getItem() instanceof ItemBlock)) {
                        if (this.autoSwap.getValue() == Scaffold.SwapMode.OFF) {
                           return;
                        }

                        if (this.autoSwap.getValue() == Scaffold.SwapMode.SILENT) {
                           var12 = true;
                        }

                        InventoryUtil.doSwap(var9);
                     }

                     if (MovementUtil.isJumping() && !MovementUtil.isMoving() && this.tower.getValue()) {
                        mc.player.motionX = 0.0;
                        mc.player.motionZ = 0.0;
                        mc.player.jump();
                        if (this.timer.passedMs(1500L)) {
                           mc.player.motionY = -0.28;
                           this.timer.reset();
                           boolean var20 = false;
                        }
                     }

                     this.rotateTimer.reset();
                     boolean var21 = false;
                     BlockPos var13 = var1.offset(var10);
                     EnumFacing var14 = var10.getOpposite();
                     this.faceVector(new Vec3d(var13).add(0.5, 0.5, 0.5).add(new Vec3d(var14.getDirectionVec()).scale(0.5)));
                     this.placeTimer.reset();
                     var21 = false;
                     BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                     if (var12) {
                        InventoryUtil.doSwap(var8);
                     }
                  }
               }
            }
         }
      }
   }

   private void faceVector(Vec3d var1) {
      float[] var2 = EntityUtil.getLegitRotations(var1);
      this.lastYaw = var2[0];
      this.lastPitch = var2[1];
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.search.isOpen();
   }

   private boolean lambda$new$2(Float var1) {
      return this.search.isOpen();
   }

   private boolean lambda$new$4(Boolean var1) {
      return this.sameY.isOpen();
   }

   @Override
   public void onEnable() {
      this.PlacePos = new BlockPos(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ);
      this.timer.reset();
      boolean var10000 = false;
   }

   public static enum SwapMode {
      OFF,
      NORMAL,
      SILENT;
      private static final Scaffold.SwapMode[] $VALUES = new Scaffold.SwapMode[]{OFF, Scaffold.SwapMode.NORMAL, Scaffold.SwapMode.SILENT};
   }
}
