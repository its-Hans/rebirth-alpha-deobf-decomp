package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public final class FastSwim extends Module {
   private final Setting<Float> speed = this.add(new Setting<>("Speed", 5.0F, 1.0F, 10.0F));
   private final Setting<Float> verticalSpeed = this.add(new Setting<>("VerticalSpeed", 2.0F, 1.0F, 10.0F));
   public static FastSwim INSTANCE = new FastSwim();
   private final Setting<Float> glideSpeed;
   private final Setting<Boolean> glide = this.add(new Setting<>("Glide", true).setParent());

   private void setMoveSpeed(MoveEvent var1, double var2) {
      double var4 = (double)mc.player.movementInput.moveForward;
      double var6 = (double)mc.player.movementInput.moveStrafe;
      float var8 = mc.player.rotationYaw;
      if (var4 == 0.0 && var6 == 0.0) {
         var1.setX(0.0);
         var1.setZ(0.0);
         mc.player.motionX = 0.0;
         mc.player.motionZ = 0.0;
         boolean var14 = false;
      } else {
         if (var4 != 0.0) {
            if (var6 > 0.0) {
               byte var10001;
               if (var4 > 0.0) {
                  var10001 = -45;
                  boolean var10002 = false;
               } else {
                  var10001 = 45;
               }

               var8 += (float)var10001;
               boolean var10000 = false;
            } else if (var6 < 0.0) {
               byte var15;
               if (var4 > 0.0) {
                  var15 = 45;
                  boolean var16 = false;
               } else {
                  var15 = -45;
               }

               var8 += (float)var15;
            }

            var6 = 0.0;
            if (var4 > 0.0) {
               var4 = 1.0;
               boolean var13 = false;
            } else if (var4 < 0.0) {
               var4 = -1.0;
            }
         }

         double var9 = var4 * var2 * -Math.sin(Math.toRadians((double)var8)) + var6 * var2 * Math.cos(Math.toRadians((double)var8));
         double var11 = var4 * var2 * Math.cos(Math.toRadians((double)var8)) - var6 * var2 * -Math.sin(Math.toRadians((double)var8));
         var1.setX(var9);
         var1.setZ(var11);
         mc.player.motionX = var9;
         mc.player.motionZ = var11;
      }
   }

   public FastSwim() {
      super("FastSwim", "Allows you fast swim", Category.MOVEMENT);
      this.glideSpeed = this.add(new Setting<>("GlideSpeed", 2.0F, 1.0F, 10.0F, this::lambda$new$0));
      INSTANCE = this;
   }

   private boolean lambda$new$0(Float var1) {
      return this.glide.isOpen();
   }

   @SubscribeEvent
   public void onMove(MoveEvent var1) {
      if (!fullNullCheck()) {
         if (mc.player.isInLava() || mc.player.isInWater()) {
            mc.player.capabilities.isFlying = false;
            mc.player.motionY = 0.0;
            var1.setY(0.0);
            this.setMoveSpeed(var1, (double)(this.speed.getValue() / 20.0F));
            if (this.glide.getValue() && !mc.player.onGround) {
               var1.setY((double)(-0.007875F * this.glideSpeed.getValue()));
               mc.player.motionY = (double)(-0.007875F * this.glideSpeed.getValue());
            }

            if (MovementUtil.isJumping()) {
               var1.setY(mc.player.motionY + (double)this.verticalSpeed.getValue().floatValue() / 20.0);
               mc.player.motionY += (double)this.verticalSpeed.getValue().floatValue() / 20.0;
            }

            if (mc.gameSettings.keyBindSneak.isKeyDown()
               || InventoryMove.INSTANCE.isOn() && InventoryMove.INSTANCE.sneak.getValue() && Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.getKeyCode())) {
               var1.setY(mc.player.motionY - (double)this.verticalSpeed.getValue().floatValue() / 20.0);
               mc.player.motionY -= (double)this.verticalSpeed.getValue().floatValue() / 20.0;
            }
         }
      }
   }
}
