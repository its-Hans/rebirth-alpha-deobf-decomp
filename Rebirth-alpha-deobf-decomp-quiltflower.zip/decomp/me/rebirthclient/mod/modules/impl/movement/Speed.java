package me.rebirthclient.mod.modules.impl.movement;

import java.util.Objects;
import me.rebirthclient.api.events.impl.MoveEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.PushEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.PositionUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Speed extends Module {
   private final Setting<Integer> pauseTime;
   private final Setting<Float> multiplier;
   private final Setting<Double> cap;
   private double speed;
   private final Setting<Boolean> velocity;
   private final Setting<Boolean> inWater;
   private final Setting<Boolean> scaleCap;
   private double distance;
   private double lastExp;
   private final Setting<Integer> coolDown;
   private boolean stop;
   private boolean boost;
   private final Setting<Boolean> jump = this.add(new Setting<>("Jump", false));
   private final Setting<Double> yFactor;
   private final Setting<Boolean> directional;
   private final Setting<Boolean> explosions;
   private final Setting<Double> xzFactor;
   private final Setting<Boolean> debug;
   private final Setting<Float> vertical;
   private int stage;
   private final Timer expTimer;
   public static Speed INSTANCE = new Speed();
   private final Setting<Double> strafeSpeed;
   private final Setting<Boolean> modify;
   private final Setting<Boolean> slow;

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (var1.getPacket() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity var2 = var1.getPacket();
            if (var2.getEntityID() == mc.player.getEntityId() && !this.directional.getValue() && this.velocity.getValue()) {
               double var3 = Math.sqrt((double)(var2.getMotionX() * var2.getMotionX() + var2.getMotionZ() * var2.getMotionZ())) / 8000.0;
               double var10001;
               if (this.expTimer.passedMs((long)this.coolDown.getValue().intValue())) {
                  var10001 = var3;
                  boolean var10002 = false;
               } else {
                  var10001 = var3 - this.lastExp;
               }

               this.lastExp = var10001;
               if (this.lastExp > 0.0) {
                  if (this.debug.getValue()) {
                     this.sendMessage("boost");
                  }

                  this.expTimer.reset();
                  boolean var10000 = false;
                  this.speed += this.lastExp * (double)this.multiplier.getValue().floatValue();
                  this.distance += this.lastExp * (double)this.multiplier.getValue().floatValue();
                  if (mc.player.motionY > 0.0 && this.vertical.getValue() != 0.0F) {
                     mc.player.motionY *= (double)this.vertical.getValue().floatValue();
                  }
               }
            }

            boolean var8 = false;
         } else if (var1.getPacket() instanceof SPacketPlayerPosLook) {
            this.distance = 0.0;
            this.speed = 0.0;
            this.stage = 4;
            boolean var9 = false;
         } else if (var1.getPacket() instanceof SPacketExplosion && this.explosions.getValue() && MovementUtil.isMoving()) {
            SPacketExplosion var6 = var1.getPacket();
            BlockPos var7 = new BlockPos(var6.getX(), var6.getY(), var6.getZ());
            if (mc.player.getDistanceSq(var7) < 100.0
               && (!this.directional.getValue() || !MovementUtil.isInMovementDirection(var6.getX(), var6.getY(), var6.getZ()))) {
               double var4 = Math.sqrt((double)(var6.getMotionX() * var6.getMotionX() + var6.getMotionZ() * var6.getMotionZ()));
               double var11;
               if (this.expTimer.passedMs((long)this.coolDown.getValue().intValue())) {
                  var11 = var4;
                  boolean var12 = false;
               } else {
                  var11 = var4 - this.lastExp;
               }

               this.lastExp = var11;
               if (this.lastExp > 0.0) {
                  if (this.debug.getValue()) {
                     this.sendMessage("boost");
                  }

                  this.expTimer.reset();
                  boolean var10 = false;
                  this.speed += this.lastExp * (double)this.multiplier.getValue().floatValue();
                  this.distance += this.lastExp * (double)this.multiplier.getValue().floatValue();
                  if (mc.player.motionY > 0.0) {
                     mc.player.motionY *= (double)this.vertical.getValue().floatValue();
                  }
               }
            }
         }
      }
   }

   @Override
   public String getInfo() {
      return "3arthh4ck";
   }

   @Override
   public void onEnable() {
      this.speed = MovementUtil.getSpeed();
      this.distance = MovementUtil.getDistance2D();
      this.stage = 4;
   }

   @SubscribeEvent
   public void onPush(PushEvent var1) {
      if (var1.getStage() == 0 && var1.entity.equals(mc.player)) {
         var1.x = -var1.x * 0.0;
         var1.y = -var1.y * 0.0;
         var1.z = -var1.z * 0.0;
         boolean var2 = false;
      } else if (var1.getStage() == 1) {
         var1.setCanceled(true);
         boolean var10000 = false;
      } else if (var1.getStage() == 2 && mc.player != null && mc.player.equals(var1.entity)) {
         var1.setCanceled(true);
      }
   }

   private boolean isFlying(EntityPlayer var1) {
      boolean var10000;
      if (!var1.isElytraFlying() && !var1.capabilities.isFlying && !Flight.INSTANCE.isOn()) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Double var1) {
      return this.modify.getValue();
   }

   public void playerMove(MoveEvent var1) {
      if (MovementUtil.isMoving()) {
         if (!LongJump.INSTANCE.isOn()) {
            if (!Flight.INSTANCE.isOn()) {
               if (this.stage == 1) {
                  this.speed = 1.35 * MovementUtil.getSpeed(this.slow.getValue(), this.strafeSpeed.getValue() / 1000.0) - 0.01;
                  boolean var10000 = false;
               } else if (this.stage == 2) {
                  if (this.jump.getValue()
                     || mc.gameSettings.keyBindJump.isKeyDown()
                     || InventoryMove.INSTANCE.isOn() && Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode())) {
                     double var2 = 0.3999 + MovementUtil.getJumpSpeed();
                     mc.player.motionY = var2;
                     var1.setY(var2);
                     double var10001 = this.speed;
                     double var10002;
                     if (this.boost) {
                        var10002 = 1.6835;
                        boolean var10003 = false;
                     } else {
                        var10002 = 1.395;
                     }

                     this.speed = var10001 * var10002;
                     boolean var4 = false;
                  }
               } else if (this.stage == 3) {
                  this.speed = this.distance - 0.66 * (this.distance - MovementUtil.getSpeed(this.slow.getValue(), this.strafeSpeed.getValue() / 1000.0));
                  boolean var6;
                  if (!this.boost) {
                     var6 = true;
                     boolean var8 = false;
                  } else {
                     var6 = false;
                  }

                  this.boost = var6;
                  boolean var5 = false;
               } else {
                  if ((
                        mc.world.getCollisionBoxes(null, mc.player.getEntityBoundingBox().offset(0.0, mc.player.motionY, 0.0)).size() > 0
                           || mc.player.collidedVertically
                     )
                     && this.stage > 0) {
                     byte var7;
                     if (MovementUtil.isMoving()) {
                        var7 = 1;
                        boolean var9 = false;
                     } else {
                        var7 = 0;
                     }

                     this.stage = var7;
                  }

                  this.speed = this.distance - this.distance / 159.0;
               }

               this.speed = Math.min(this.speed, this.getCap());
               this.speed = Math.max(this.speed, MovementUtil.getSpeed(this.slow.getValue(), this.strafeSpeed.getValue() / 1000.0));
               MovementUtil.strafe(var1, this.speed);
               ++this.stage;
            }
         }
      }
   }

   @SubscribeEvent
   public void Update(UpdateWalkingPlayerEvent var1) {
      if (this.expTimer.passedMs((long)this.pauseTime.getValue().intValue())) {
         this.distance = MovementUtil.getDistance2D();
      }
   }

   public double getCap() {
      double var1 = this.cap.getValue();
      if (!this.scaleCap.getValue()) {
         return var1;
      } else {
         if (mc.player.isPotionActive(MobEffects.SPEED)) {
            int var3 = ((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SPEED))).getAmplifier();
            var1 *= 1.0 + 0.2 * (double)(var3 + 1);
         }

         if (this.slow.getValue() && mc.player.isPotionActive(MobEffects.SLOWNESS)) {
            int var4 = ((PotionEffect)Objects.requireNonNull(mc.player.getActivePotionEffect(MobEffects.SLOWNESS))).getAmplifier();
            var1 /= 1.0 + 0.2 * (double)(var4 + 1);
         }

         return var1;
      }
   }

   private boolean lambda$new$0(Double var1) {
      return this.modify.getValue();
   }

   @SubscribeEvent
   public void Move(MoveEvent var1) {
      if (!fullNullCheck()) {
         if (!this.isFlying(mc.player)) {
            if ((this.inWater.getValue() || !PositionUtil.inLiquid() && !PositionUtil.inLiquid(true))
               && !mc.player.isOnLadder()
               && !mc.player.isEntityInsideOpaqueBlock()) {
               if (this.stop) {
                  this.stop = false;
               } else {
                  if (!MovementUtil.isMoving()) {
                     mc.player.motionX = 0.0;
                     mc.player.motionZ = 0.0;
                  }

                  this.playerMove(var1);
                  if (this.modify.getValue()) {
                     var1.setX(var1.getX() * this.xzFactor.getValue());
                     var1.setY(var1.getY() * this.yFactor.getValue());
                     var1.setZ(var1.getZ() * this.xzFactor.getValue());
                  }
               }
            } else {
               this.stop = true;
            }
         }
      }
   }

   public Speed() {
      super("Speed", "3ar", Category.MOVEMENT);
      this.inWater = this.add(new Setting<>("InWater", false));
      this.strafeSpeed = this.add(new Setting<>("StrafeSpeed", 278.5, 100.0, 1000.0));
      this.explosions = this.add(new Setting<>("Explosions", true));
      this.velocity = this.add(new Setting<>("Velocity", true));
      this.multiplier = this.add(new Setting<>("H-Factor", 1.0F, 0.0F, 5.0F));
      this.vertical = this.add(new Setting<>("V-Factor", 1.0F, 0.0F, 5.0F));
      this.coolDown = this.add(new Setting<>("CoolDown", 400, 0, 5000));
      this.pauseTime = this.add(new Setting<>("PauseTime", 400, 0, 1000));
      this.directional = this.add(new Setting<>("Directional", false));
      this.cap = this.add(new Setting<>("Cap", 10.0, 0.0, 10.0));
      this.scaleCap = this.add(new Setting<>("ScaleCap", false));
      this.slow = this.add(new Setting<>("Slowness", true));
      this.modify = this.add(new Setting<>("Modify", false));
      this.xzFactor = this.add(new Setting<>("XZ-Factor", 1.0, 0.0, 5.0, this::lambda$new$0));
      this.yFactor = this.add(new Setting<>("Y-Factor", 1.0, 0.0, 5.0, this::lambda$new$1));
      this.debug = this.add(new Setting<>("Debug", false));
      this.expTimer = new Timer();
      INSTANCE = this;
   }
}
