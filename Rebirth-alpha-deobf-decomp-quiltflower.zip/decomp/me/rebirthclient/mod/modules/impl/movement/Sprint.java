package me.rebirthclient.mod.modules.impl.movement;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class Sprint extends Module {
   private final Setting<Sprint.Mode> mode = this.add(new Setting<>("Mode", Sprint.Mode.RAGE));

   @Override
   public void onTick() {
      if (this.mode.getValue() == Sprint.Mode.RAGE && isMoving()) {
         mc.player.setSprinting(true);
         boolean var10000 = false;
      } else if (this.mode.getValue() == Sprint.Mode.LEGIT && mc.player.moveForward > 0.1F && !mc.player.collidedHorizontally && !SneakManager.isSneaking) {
         mc.player.setSprinting(true);
      }
   }

   public Sprint() {
      super("Sprint", "Sprints", Category.MOVEMENT);
   }

   public static boolean isMoving() {
      boolean var10000;
      if (mc.player.moveForward == 0.0F && mc.player.moveStrafing == 0.0F) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      return Managers.TEXT.normalizeCases(this.mode.getValue());
   }

   private static enum Mode {
      LEGIT,
      RAGE;
      private static final Sprint.Mode[] $VALUES = new Sprint.Mode[]{Sprint.Mode.RAGE, LEGIT};
   }
}
