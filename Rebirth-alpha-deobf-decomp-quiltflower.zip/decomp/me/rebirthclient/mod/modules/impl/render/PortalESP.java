package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.ArrayList;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockEndPortalFrame;
import net.minecraft.block.BlockPortal;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class PortalESP extends Module {
   private final Setting<Integer> distance;
   private final Setting<Integer> boxAlpha;
   private final Setting<Boolean> outline;
   private final Setting<Integer> outlineAlpha;
   private final Setting<Integer> updateDelay;
   private final Setting<Color> color;
   private final Setting<Boolean> box;
   private final ArrayList<BlockPos> blockPosArrayList = new ArrayList();
   private final Timer timer;

   public PortalESP() {
      super("PortalESP", "Draws portals", Category.RENDER);
      this.distance = this.add(new Setting<>("Distance", 60, 10, 100));
      this.updateDelay = this.add(new Setting<>("UpdateDelay", 2000, 500, 5000));
      this.box = this.add(new Setting<>("Box", false).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 125, 0, 255, this::lambda$new$0));
      this.outline = this.add(new Setting<>("Outline", true).setParent());
      this.outlineAlpha = this.add(new Setting<>("outlineAlpha", 150, 0, 255, this::lambda$new$1));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255, 100)).hideAlpha());
      this.timer = new Timer();
   }

   private boolean lambda$new$1(Object var1) {
      return this.outline.isOpen();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      for(BlockPos var3 : this.blockPosArrayList) {
         this.drawBlock(var3);
         boolean var10000 = false;
      }
   }

   private boolean lambda$new$0(Object var1) {
      return this.box.isOpen();
   }

   private void updateBlocks() {
      for(BlockPos var2 : BlockUtil.getBox((float)this.distance.getValue().intValue())) {
         if (mc.world.getBlockState(var2).getBlock() instanceof BlockPortal || mc.world.getBlockState(var2).getBlock() instanceof BlockEndPortalFrame) {
            this.blockPosArrayList.add(var2);
            boolean var10000 = false;
         }

         boolean var3 = false;
      }
   }

   @Override
   public void onTick() {
      if (this.timer.passedMs((long)this.updateDelay.getValue().intValue())) {
         this.blockPosArrayList.clear();
         this.updateBlocks();
         this.timer.reset();
         boolean var10000 = false;
      }
   }

   private void drawBlock(BlockPos var1) {
      AxisAlignedBB var2 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
      if (this.outline.getValue()) {
         RenderUtil.drawBBBox(var2, this.color.getValue(), this.outlineAlpha.getValue());
      }

      if (this.box.getValue()) {
         RenderUtil.drawBoxESP(var1, this.color.getValue(), this.boxAlpha.getValue());
      }
   }
}
