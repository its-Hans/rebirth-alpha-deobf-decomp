package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.RenderFogColorEvent;
import me.rebirthclient.api.events.impl.RenderSkyEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogDensity;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Ambience extends Module {
   public final Setting<Color> lightMap;
   public static Ambience INSTANCE;
   public final Setting<Color> fogNether;
   public final Setting<Color> sky;
   public final Setting<Color> skyNether;
   public final Setting<Color> fog;
   private final Setting<Integer> time;
   public final Setting<Boolean> noFog;
   public final Setting<Boolean> customTime = this.add(new Setting<>("CustomTime", false).setParent());

   @SubscribeEvent
   public void setFogColor(RenderFogColorEvent var1) {
      if (this.fog.booleanValue && mc.player.dimension == 0) {
         var1.setColor(this.fog.getValue());
         var1.setCanceled(true);
         boolean var10000 = false;
      } else if (this.fogNether.booleanValue && mc.player.dimension == -1) {
         var1.setColor(this.fogNether.getValue());
         var1.setCanceled(true);
      }
   }

   public Ambience() {
      super("Ambience", "Custom ambience", Category.RENDER);
      this.time = this.add(new Setting<>("Time", 0, 0, 24000, this::lambda$new$0));
      this.noFog = this.add(new Setting<>("NoFog", false));
      this.lightMap = this.add(new Setting<>("LightMap", new Color(-557395713, true)).injectBoolean(false).hideAlpha());
      this.sky = this.add(new Setting<>("OverWorldSky", new Color(8224213)).injectBoolean(true).hideAlpha());
      this.skyNether = this.add(new Setting<>("NetherSky", new Color(8224213)).injectBoolean(true).hideAlpha());
      this.fog = this.add(new Setting<>("OverWorldFog", new Color(13401557)).injectBoolean(false).hideAlpha());
      this.fogNether = this.add(new Setting<>("NetherFog", new Color(13401557)).injectBoolean(false).hideAlpha());
      INSTANCE = this;
   }

   @SubscribeEvent
   public void setFogDensity(FogDensity var1) {
      if (this.noFog.getValue()) {
         var1.setDensity(0.0F);
         var1.setCanceled(true);
      }
   }

   @SubscribeEvent
   public void init(WorldEvent var1) {
      if (this.customTime.getValue()) {
         var1.getWorld().setWorldTime((long)this.time.getValue().intValue());
      }
   }

   private boolean lambda$new$0(Integer var1) {
      return this.customTime.isOpen();
   }

   @SubscribeEvent
   public void setSkyColor(RenderSkyEvent var1) {
      if (this.sky.booleanValue && mc.player.dimension == 0) {
         var1.setColor(this.sky.getValue());
         var1.setCanceled(true);
         boolean var10000 = false;
      } else if (this.skyNether.booleanValue && mc.player.dimension == -1) {
         var1.setColor(this.skyNether.getValue());
         var1.setCanceled(true);
      }
   }

   public Color getColor() {
      return new Color(
         this.lightMap.getValue().getRed(), this.lightMap.getValue().getGreen(), this.lightMap.getValue().getBlue(), this.lightMap.getValue().getAlpha()
      );
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled()) {
         if (var1.getPacket() instanceof SPacketTimeUpdate && this.customTime.getValue()) {
            var1.setCanceled(true);
         }
      }
   }
}
