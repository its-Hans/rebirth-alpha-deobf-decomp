package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class CrystalChams extends Module {
   public final Setting<Color> color;
   public final Setting<Boolean> changeSpeed;
   public final Setting<Boolean> wireframe;
   public final Setting<Color> modelColor;
   private final Setting<CrystalChams.Page> page = this.add(new Setting<>("Settings", CrystalChams.Page.GLOBAL));
   public final Setting<Float> lineWidth;
   public final Setting<Float> spinSpeed;
   public static CrystalChams INSTANCE;
   public final Setting<Float> floatFactor;
   public final Setting<Boolean> glint;
   public final Setting<Boolean> fill = this.add(new Setting<>("Fill", true, this::lambda$new$0).setParent());
   public final Setting<Color> lineColor;
   public final Setting<Float> scale;
   public final Setting<CrystalChams.Model> model;
   public final Setting<Boolean> xqz = this.add(new Setting<>("XQZ", true, this::lambda$new$1));

   public CrystalChams() {
      super("CrystalChams", "Draws a pretty ESP around end crystals", Category.RENDER);
      this.wireframe = this.add(new Setting<>("Wireframe", true, this::lambda$new$2));
      this.model = this.add(new Setting<>("Model", CrystalChams.Model.XQZ, this::lambda$new$3));
      this.glint = this.add(new Setting<>("Glint", false, this::lambda$new$4));
      this.scale = this.add(new Setting<>("Scale", 1.0F, 0.1F, 1.0F, this::lambda$new$5));
      this.changeSpeed = this.add(new Setting<>("ChangeSpeed", false, this::lambda$new$6).setParent());
      this.spinSpeed = this.add(new Setting<>("SpinSpeed", 1.0F, 0.0F, 10.0F, this::lambda$new$7));
      this.floatFactor = this.add(new Setting<>("FloatFactor", 1.0F, 0.0F, 1.0F, this::lambda$new$8));
      this.lineWidth = this.add(new Setting<>("LineWidth", 1.0F, 0.1F, 3.0F, this::lambda$new$9));
      this.color = this.add(new Setting<>("Color", new Color(132, 132, 241, 150), this::lambda$new$10));
      this.lineColor = this.add(new Setting<>("LineColor", new Color(255, 255, 255), this::lambda$new$11).injectBoolean(false));
      this.modelColor = this.add(new Setting<>("ModelColor", new Color(125, 125, 213, 150), this::lambda$new$12).injectBoolean(false));
      INSTANCE = this;
   }

   @Override
   public String getInfo() {
      String var1 = null;
      if (this.fill.getValue()) {
         var1 = "Fill";
         boolean var10000 = false;
      } else if (this.wireframe.getValue()) {
         var1 = "Wireframe";
      }

      if (this.wireframe.getValue() && this.fill.getValue()) {
         var1 = "Both";
      }

      return var1;
   }

   private boolean lambda$new$5(Float var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Float var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Color var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Color var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(CrystalChams.Model var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL && this.fill.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$12(Color var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Float var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL && this.changeSpeed.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Float var1) {
      boolean var10000;
      if (this.page.getValue() == CrystalChams.Page.GLOBAL && this.changeSpeed.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Model {
      XQZ,
      OFF,
      VANILLA;
      private static final CrystalChams.Model[] $VALUES = new CrystalChams.Model[]{XQZ, CrystalChams.Model.VANILLA, CrystalChams.Model.OFF};
   }

   public static enum Page {
      GLOBAL,
      COLORS;
      private static final CrystalChams.Page[] $VALUES = new CrystalChams.Page[]{CrystalChams.Page.COLORS, CrystalChams.Page.GLOBAL};
   }
}
