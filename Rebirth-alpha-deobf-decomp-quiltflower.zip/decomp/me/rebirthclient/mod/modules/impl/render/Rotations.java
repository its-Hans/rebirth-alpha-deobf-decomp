package me.rebirthclient.mod.modules.impl.render;

import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Rotations extends Module {
   private int ticksExisted;
   private static float prevRenderYawOffset;
   private static float prevPitch;
   private static float renderPitch;
   private static float renderYawOffset;
   private final Setting<Boolean> onlyThird = this.add(new Setting<>("OnlyThird", true));
   private static float prevRotationYawHead;
   public static Rotations INSTANCE;
   private static float rotationYawHead;

   public static float getPrevPitch() {
      return prevPitch;
   }

   private float getRenderYawOffset(float var1, float var2) {
      float var3 = var2;
      double var5 = mc.player.posX - mc.player.prevPosX;
      double var7 = mc.player.posZ - mc.player.prevPosZ;
      if (var5 * var5 + var7 * var7 > 0.0025000002F) {
         float var4 = (float)MathHelper.atan2(var7, var5) * (180.0F / (float)Math.PI) - 90.0F;
         float var9 = MathHelper.abs(MathHelper.wrapDegrees(var1) - var4);
         if (95.0F < var9 && var9 < 265.0F) {
            var3 = var4 - 180.0F;
            boolean var10000 = false;
         } else {
            var3 = var4;
         }
      }

      if (mc.player.swingProgress > 0.0F) {
         var3 = var1;
      }

      var3 = var2 + MathHelper.wrapDegrees(var3 - var2) * 0.3F;
      float var12 = MathHelper.wrapDegrees(var1 - var3);
      if (var12 < -75.0F) {
         var12 = -75.0F;
         boolean var13 = false;
      } else if (var12 >= 75.0F) {
         var12 = 75.0F;
      }

      var3 = var1 - var12;
      if (var12 * var12 > 2500.0F) {
         var3 += var12 * 0.2F;
      }

      return var3;
   }

   public boolean check() {
      boolean var10000;
      if (!this.isOn() || mc.gameSettings.thirdPersonView == 0 && this.onlyThird.getValue()) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public Rotations() {
      super("Rotations", "show rotation", Category.RENDER);
      INSTANCE = this;
   }

   public static float getRenderYawOffset() {
      return renderYawOffset;
   }

   private void set(float var1, float var2) {
      if (mc.player.ticksExisted != this.ticksExisted) {
         this.ticksExisted = mc.player.ticksExisted;
         prevPitch = renderPitch;
         prevRenderYawOffset = renderYawOffset;
         renderYawOffset = this.getRenderYawOffset(var1, prevRenderYawOffset);
         prevRotationYawHead = rotationYawHead;
         rotationYawHead = var1;
         renderPitch = var2;
      }
   }

   public static float getRotationYawHead() {
      return rotationYawHead;
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void invoke(MotionEvent var1) {
      this.set(var1.getYaw(), var1.getPitch());
   }

   public static float getRenderPitch() {
      return renderPitch;
   }

   public static float getPrevRenderYawOffset() {
      return prevRenderYawOffset;
   }

   public static float getPrevRotationYawHead() {
      return prevRotationYawHead;
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onPacketSend(PacketEvent.Send var1) {
      if (var1.getPacket() instanceof CPacketPlayer && var1.getPacket().rotating) {
         this.set(var1.getPacket().yaw, var1.getPacket().pitch);
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled() && !fullNullCheck()) {
         if (var1.getStage() == 0 && var1.getPacket() instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook var2 = var1.getPacket();
            this.set(var2.yaw, var2.pitch);
         }
      }
   }
}
