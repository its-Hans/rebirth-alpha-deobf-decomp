package me.rebirthclient.mod.modules.impl.render;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.icu.math.BigDecimal;
import java.awt.Color;
import java.util.List;
import java.util.Map;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class DMGParticles extends Module {
   private final Setting<Integer> deleteAfter;
   private final Map<Integer, Float> hpData = Maps.newHashMap();
   private final List<DMGParticles.Particle> particles = Lists.newArrayList();

   @Override
   public void onDisable() {
      this.particles.clear();
   }

   public DMGParticles() {
      super("DMGParticles", "show damage", Category.RENDER);
      this.deleteAfter = this.add(new Setting<>("Remove Ticks", 7, 1, 60));
   }

   @SubscribeEvent
   @Override
   public void onRender3D(Render3DEvent var1) {
      boolean var2 = true;
      if (!this.particles.isEmpty()) {
         for(DMGParticles.Particle var4 : this.particles) {
            if (var4 != null) {
               if (var4.ticks > this.deleteAfter.getValue()) {
                  boolean var9 = false;
                  continue;
               }

               var2 = false;
               GlStateManager.pushMatrix();
               GlStateManager.disableDepth();
               Tessellator var5 = Tessellator.getInstance();
               BufferBuilder var6 = var5.getBuffer();
               var6.begin(3, DefaultVertexFormats.POSITION_COLOR);
               var5.draw();
               GL11.glDisable(2848);
               GlStateManager.depthMask(true);
               GlStateManager.enableDepth();
               GlStateManager.enableTexture2D();
               GlStateManager.disableBlend();
               GlStateManager.popMatrix();
               GlStateManager.pushMatrix();
               GlStateManager.enablePolygonOffset();
               GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
               GlStateManager.translate(
                  var4.posX - mc.getRenderManager().renderPosX, var4.posY - mc.getRenderManager().renderPosY, var4.posZ - mc.getRenderManager().renderPosZ
               );
               GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
               float var10000 = mc.getRenderManager().playerViewX;
               float var10001;
               if (mc.gameSettings.thirdPersonView == 2) {
                  var10001 = -1.0F;
                  boolean var10002 = false;
               } else {
                  var10001 = 1.0F;
               }

               GlStateManager.rotate(var10000, var10001, 0.0F, 0.0F);
               GlStateManager.scale(-0.03, -0.03, 0.03);
               GL11.glDepthMask(false);
               mc.fontRenderer
                  .drawStringWithShadow(
                     var4.str,
                     (float)((double)(-mc.fontRenderer.getStringWidth(var4.str)) * 0.5),
                     (float)(-mc.fontRenderer.FONT_HEIGHT + 1),
                     var4.color.getRGB()
                  );
               boolean var7 = false;
               GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
               GL11.glDepthMask(true);
               GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
               GlStateManager.disablePolygonOffset();
               GlStateManager.resetColor();
               GlStateManager.popMatrix();
            }

            boolean var8 = false;
         }
      }

      if (var2) {
         this.particles.clear();
      }
   }

   @Override
   public void onUpdate() {
      if (!this.particles.isEmpty()) {
         for(DMGParticles.Particle var2 : this.particles) {
            if (var2 != null) {
               ++var2.ticks;
            }

            boolean var10000 = false;
         }
      }

      for(Entity var11 : mc.world.loadedEntityList) {
         if (var11 instanceof EntityLivingBase) {
            EntityLivingBase var3 = (EntityLivingBase)var11;
            double var4 = (double)this.hpData.getOrDefault(var3.getEntityId(), var3.getMaxHealth()).floatValue();
            this.hpData.remove(var11.getEntityId());
            boolean var12 = false;
            this.hpData.put(var11.getEntityId(), var3.getHealth());
            var12 = false;
            if (var4 == (double)var3.getHealth()) {
               var12 = false;
               continue;
            }

            Color var6 = Color.YELLOW;
            Vec3d var14 = new Vec3d;
            double var10002 = var11.posX;
            double var10003 = Math.random() * 0.5;
            byte var10004;
            if (Math.random() > 0.5) {
               var10004 = -1;
               boolean var10005 = false;
            } else {
               var10004 = 1;
            }

            var10002 += var10003 * (double)var10004;
            var10003 = var11.getEntityBoundingBox().minY + (var11.getEntityBoundingBox().maxY - var11.getEntityBoundingBox().minY) * 0.5;
            double var20 = var11.posZ;
            double var21 = Math.random() * 0.5;
            byte var10006;
            if (Math.random() > 0.5) {
               var10006 = -1;
               boolean var10007 = false;
            } else {
               var10006 = 1;
            }

            var14./* $QF: Unable to resugar constructor */<init>(var10002, var10003, var20 + var21 * (double)var10006);
            Vec3d var7 = var14;
            double var8 = new BigDecimal(Math.abs(var4 - (double)var3.getHealth())).setScale(1, 4).doubleValue();
            this.particles.add(new DMGParticles.Particle(String.valueOf(var8), var7.x, var7.y, var7.z, var6));
            var12 = false;
         }

         boolean var16 = false;
      }
   }

   static class Particle {
      public final double posZ;
      public final double posY;
      public final String str;
      public final double posX;
      public final Color color;
      public int ticks;

      public Particle(String var1, double var2, double var4, double var6, Color var8) {
         this.str = var1;
         this.posX = var2;
         this.posY = var4;
         this.posZ = var6;
         this.color = var8;
         this.ticks = 0;
      }
   }
}
