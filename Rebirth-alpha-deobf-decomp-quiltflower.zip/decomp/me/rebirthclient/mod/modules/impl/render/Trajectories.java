package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemLingeringPotion;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

public class Trajectories extends Module {
   private float getGravity(Item var1) {
      return !(var1 instanceof ItemBow) && !(var1 instanceof ItemSplashPotion) && !(var1 instanceof ItemLingeringPotion) && !(var1 instanceof ItemExpBottle)
         ? 0.03F
         : 0.05F;
   }

   public void drawTracer(double var1, double var3, double var5) {
      GL11.glVertex3d(var1, var3, var5);
   }

   public Trajectories() {
      super("Trajectories", "Draws trajectories", Category.RENDER);
   }

   private int getPitch(Item var1) {
      return !(var1 instanceof ItemSplashPotion) && !(var1 instanceof ItemLingeringPotion) && !(var1 instanceof ItemExpBottle) ? 0 : 20;
   }

   private float getVelocity(Item var1) {
      if (var1 instanceof ItemSplashPotion || var1 instanceof ItemLingeringPotion) {
         return 0.5F;
      } else {
         return var1 instanceof ItemExpBottle ? 0.59F : 1.5F;
      }
   }

   private List<Entity> getEntitiesWithinAABB(AxisAlignedBB var1) {
      ArrayList var2 = new ArrayList();
      int var3 = MathHelper.floor((var1.minX - 2.0) / 16.0);
      int var4 = MathHelper.floor((var1.maxX + 2.0) / 16.0);
      int var5 = MathHelper.floor((var1.minZ - 2.0) / 16.0);
      int var6 = MathHelper.floor((var1.maxZ + 2.0) / 16.0);

      for(int var7 = var3; var7 <= var4; ++var7) {
         for(int var8 = var5; var8 <= var6; ++var8) {
            if (mc.world.getChunkProvider().getLoadedChunk(var7, var8) != null) {
               mc.world.getChunk(var7, var8).getEntitiesWithinAABBForEntity(mc.player, var1, var2, EntitySelectors.NOT_SPECTATING);
            }

            boolean var10000 = false;
         }

         boolean var9 = false;
      }

      return var2;
   }

   private boolean isThrowable(Item var1) {
      boolean var10000;
      if (!(var1 instanceof ItemEnderPearl)
         && !(var1 instanceof ItemExpBottle)
         && !(var1 instanceof ItemSnowball)
         && !(var1 instanceof ItemEgg)
         && !(var1 instanceof ItemSplashPotion)
         && !(var1 instanceof ItemLingeringPotion)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (mc.player != null && mc.world != null && mc.gameSettings.thirdPersonView != 2) {
         if (mc.player.getHeldItemMainhand() != ItemStack.EMPTY && mc.player.getHeldItemMainhand().getItem() instanceof ItemBow
            || mc.player.getHeldItemMainhand() != ItemStack.EMPTY && this.isThrowable(mc.player.getHeldItemMainhand().getItem())
            || mc.player.getHeldItemOffhand() != ItemStack.EMPTY && this.isThrowable(mc.player.getHeldItemOffhand().getItem())
            || Mouse.isButtonDown(2)) {
            double var2 = mc.getRenderManager().renderPosX;
            double var4 = mc.getRenderManager().renderPosY;
            double var6 = mc.getRenderManager().renderPosZ;
            Item var8 = null;
            if (mc.player.getHeldItemMainhand() == ItemStack.EMPTY
               || !(mc.player.getHeldItemMainhand().getItem() instanceof ItemBow) && !this.isThrowable(mc.player.getHeldItemMainhand().getItem())) {
               if (mc.player.getHeldItemOffhand() != ItemStack.EMPTY && this.isThrowable(mc.player.getHeldItemOffhand().getItem())) {
                  var8 = mc.player.getHeldItemOffhand().getItem();
               }
            } else {
               var8 = mc.player.getHeldItemMainhand().getItem();
               boolean var10000 = false;
            }

            if (var8 == null && Mouse.isButtonDown(2)) {
               var8 = Items.ENDER_PEARL;
               boolean var51 = false;
            } else if (var8 == null) {
               return;
            }

            GL11.glPushAttrib(1048575);
            GL11.glPushMatrix();
            GL11.glDisable(3008);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glDisable(3553);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glEnable(2884);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4353);
            GL11.glDisable(2896);
            double var9 = var2 - (double)(MathHelper.cos(mc.player.rotationYaw / 180.0F * (float) Math.PI) * 0.16F);
            double var11 = var4 + (double)mc.player.getEyeHeight() - 0.1000000014901161;
            double var13 = var6 - (double)(MathHelper.sin(mc.player.rotationYaw / 180.0F * (float) Math.PI) * 0.16F);
            float var15 = this.getDistance(var8);
            double var16 = (double)(
               -MathHelper.sin(mc.player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(mc.player.rotationPitch / 180.0F * (float) Math.PI) * var15
            );
            double var18 = (double)(-MathHelper.sin((mc.player.rotationPitch - (float)this.getPitch(var8)) / 180.0F * 3.141593F) * var15);
            double var20 = (double)(
               MathHelper.cos(mc.player.rotationYaw / 180.0F * (float) Math.PI) * MathHelper.cos(mc.player.rotationPitch / 180.0F * (float) Math.PI) * var15
            );
            int var22 = 72000 - mc.player.getItemInUseCount();
            float var23 = (float)var22 / 20.0F;
            var23 = (var23 * var23 + var23 * 2.0F) / 3.0F;
            if (var23 > 1.0F) {
               var23 = 1.0F;
            }

            float var24 = MathHelper.sqrt(var16 * var16 + var18 * var18 + var20 * var20);
            var16 /= (double)var24;
            var18 /= (double)var24;
            var20 /= (double)var24;
            float var52;
            if (var8 instanceof ItemBow) {
               var52 = var23 * 2.0F;
               boolean var10001 = false;
            } else {
               var52 = 1.0F;
            }

            float var25 = var52 * this.getVelocity(var8);
            var16 *= (double)var25;
            var18 *= (double)var25;
            var20 *= (double)var25;
            if (!mc.player.onGround) {
               var18 += mc.player.motionY;
            }

            RenderUtil.glColor(Managers.COLORS.getCurrent());
            GL11.glEnable(2848);
            double var53;
            if (var8 instanceof ItemBow) {
               var53 = 0.3;
               boolean var60 = false;
            } else {
               var53 = 0.25;
            }

            float var26 = (float)var53;
            boolean var27 = false;
            Entity var28 = null;
            RayTraceResult var29 = null;
            GL11.glBegin(3);

            while(!var27 && var11 > 0.0) {
               Vec3d var30 = new Vec3d(var9, var11, var13);
               Vec3d var31 = new Vec3d(var9 + var16, var11 + var18, var13 + var20);
               RayTraceResult var32 = mc.world.rayTraceBlocks(var30, var31, false, true, false);
               if (var32 != null && var32.typeOfHit != Type.MISS) {
                  var29 = var32;
                  var27 = true;
               }

               AxisAlignedBB var33 = new AxisAlignedBB(
                  var9 - (double)var26, var11 - (double)var26, var13 - (double)var26, var9 + (double)var26, var11 + (double)var26, var13 + (double)var26
               );

               for(Entity var36 : this.getEntitiesWithinAABB(var33.offset(var16, var18, var20).expand(1.0, 1.0, 1.0))) {
                  if (var36.canBeCollidedWith() && var36 != mc.player) {
                     float var37 = 0.3F;
                     AxisAlignedBB var38 = var36.getEntityBoundingBox().expand((double)var37, (double)var37, (double)var37);
                     RayTraceResult var39 = var38.calculateIntercept(var30, var31);
                     if (var39 == null) {
                        boolean var55 = false;
                        continue;
                     }

                     var27 = true;
                     var28 = var36;
                     var29 = var39;
                  }

                  boolean var54 = false;
               }

               var9 += var16;
               var11 += var18;
               var13 += var20;
               float var50 = 0.99F;
               var16 *= 0.99F;
               var18 *= 0.99F;
               var20 *= 0.99F;
               var18 -= (double)this.getGravity(var8);
               this.drawTracer(var9 - var2, var11 - var4, var13 - var6);
               boolean var56 = false;
            }

            GL11.glEnd();
            if (var29 != null && var29.typeOfHit == Type.BLOCK) {
               GlStateManager.translate(var9 - var2, var11 - var4, var13 - var6);
               int var48 = var29.sideHit.getIndex();
               if (var48 == 2) {
                  GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
                  boolean var57 = false;
               } else if (var48 == 3) {
                  GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
                  boolean var58 = false;
               } else if (var48 == 4) {
                  GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
                  boolean var59 = false;
               } else if (var48 == 5) {
                  GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
               }

               Cylinder var49 = new Cylinder();
               GlStateManager.rotate(-90.0F, 1.0F, 0.0F, 0.0F);
               var49.setDrawStyle(100011);
               var49.draw(0.5F, 0.2F, 0.0F, 4, 1);
               var49.setDrawStyle(100012);
               RenderUtil.glColor(ColorUtil.injectAlpha(Managers.COLORS.getCurrent(), 100));
               var49.draw(0.5F, 0.2F, 0.0F, 4, 1);
            }

            GL11.glEnable(2896);
            GL11.glDisable(2848);
            GL11.glEnable(3553);
            GL11.glEnable(2929);
            GL11.glDisable(3042);
            GL11.glEnable(3008);
            GL11.glDepthMask(true);
            GL11.glCullFace(1029);
            GL11.glPopMatrix();
            GL11.glPopAttrib();
            if (var28 != null) {
               RenderUtil.drawEntityBoxESP(var28, Managers.COLORS.getCurrent(), false, new Color(-1), 1.0F, false, true, 100);
            }
         }
      }
   }

   private float getDistance(Item var1) {
      float var10000;
      if (var1 instanceof ItemBow) {
         var10000 = 1.0F;
         boolean var10001 = false;
      } else {
         var10000 = 0.4F;
      }

      return var10000;
   }
}
