package me.rebirthclient.mod.modules.impl.render;

import com.mojang.authlib.GameProfile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.entity.StaticModelPlayer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

public class EarthPopChams extends Module {
   private final Setting<Color> selfColor;
   private final Setting<Integer> fadeTime;
   private final Setting<Color> outline;
   private final Setting<Boolean> friendPop;
   private final Setting<Color> color;
   private final Setting<Boolean> copyAnimations;
   private final Setting<Color> friendColor;
   public static EarthPopChams INSTANCE;
   private final Setting<Float> lineWidth = this.add(new Setting<>("LineWidth", 1.0F, 0.1F, 3.0F));
   private final Setting<Color> friendOutline;
   private final List<EarthPopChams.PopData> popDataList;
   private final Setting<Double> yAnimations;
   private final Setting<Color> selfOutline;
   private final Setting<Boolean> selfPop;

   @Override
   public void onTotemPop(EntityPlayer var1) {
      if (this.isValidEntity(var1)) {
         List var10000 = this.popDataList;
         EarthPopChams.PopData var10001 = new EarthPopChams.PopData;
         EntityPlayer var10003 = this.copyPlayer(var1, this.copyAnimations.getValue());
         long var10004 = System.currentTimeMillis();
         double var10005 = var1.posX;
         double var10006 = var1.posY;
         double var10007 = var1.posZ;
         boolean var10008;
         if (var1 instanceof AbstractClientPlayer && Integer.valueOf("slim".hashCode()).equals(((AbstractClientPlayer)var1).getSkinType().hashCode())) {
            var10008 = true;
            boolean var10009 = false;
         } else {
            var10008 = false;
         }

         var10001./* $QF: Unable to resugar constructor */<init>(var10003, var10004, var10005, var10006, var10007, var10008);
         var10000.add(var10001);
         boolean var2 = false;
      }
   }

   private void color(Color var1) {
      GL11.glColor4f((float)var1.getRed() / 255.0F, (float)var1.getGreen() / 255.0F, (float)var1.getBlue() / 255.0F, (float)var1.getAlpha() / 255.0F);
   }

   private boolean lambda$new$1(Color var1) {
      return this.selfPop.isOpen();
   }

   private boolean lambda$new$0(Color var1) {
      return this.selfPop.isOpen();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!this.popDataList.isEmpty()) {
         for(EarthPopChams.PopData var3 : this.popDataList) {
            EntityPlayer var4 = var3.getPlayer();
            StaticModelPlayer var5 = var3.getModel();
            double var6 = var3.getX() - mc.getRenderManager().viewerPosX;
            double var8 = var3.getY() - mc.getRenderManager().viewerPosY;
            var8 += this.yAnimations.getValue() * (double)(System.currentTimeMillis() - var3.getTime()) / this.fadeTime.getValue().doubleValue();
            double var10 = var3.getZ() - mc.getRenderManager().viewerPosZ;
            GlStateManager.pushMatrix();
            this.startRender();
            GlStateManager.translate(var6, var8, var10);
            GlStateManager.rotate(180.0F - var5.getYaw(), 0.0F, 1.0F, 0.0F);
            Color var12 = this.getColor(var3.getPlayer());
            Color var13 = this.getOutlineColor(var3.getPlayer());
            float var14 = (float)var12.getAlpha();
            float var15 = (float)var13.getAlpha();
            float var16 = var14 / (float)this.fadeTime.getValue().intValue();
            float var17 = var15 / (float)this.fadeTime.getValue().intValue();
            int var18 = MathHelper.clamp(
               (int)(var16 * (float)(var3.getTime() + (long)this.fadeTime.getValue().intValue() - System.currentTimeMillis())), 0, (int)var14
            );
            int var19 = MathHelper.clamp(
               (int)(var17 * (float)(var3.getTime() + (long)this.fadeTime.getValue().intValue() - System.currentTimeMillis())), 0, (int)var15
            );
            Color var20 = new Color(var12.getRed(), var12.getGreen(), var12.getBlue(), var18);
            Color var21 = new Color(var13.getRed(), var13.getGreen(), var13.getBlue(), var19);
            GlStateManager.enableRescaleNormal();
            GlStateManager.scale(-1.0F, -1.0F, 1.0F);
            double var22 = var4.getEntityBoundingBox().maxX - var4.getRenderBoundingBox().minX + 1.0;
            double var24 = var4.getEntityBoundingBox().maxZ - var4.getEntityBoundingBox().minZ + 1.0;
            GlStateManager.scale(var22, (double)var4.height, var24);
            GlStateManager.translate(0.0F, -1.501F, 0.0F);
            this.color(var20);
            GL11.glPolygonMode(1032, 6914);
            var5.render(0.0625F);
            this.color(var21);
            GL11.glLineWidth(this.lineWidth.getValue());
            GL11.glPolygonMode(1032, 6913);
            var5.render(0.0625F);
            this.endRender();
            GlStateManager.popMatrix();
            boolean var10000 = false;
         }

         this.popDataList.removeIf(this::lambda$onRender3D$4);
         boolean var27 = false;
      }
   }

   private boolean lambda$onRender3D$4(EarthPopChams.PopData var1) {
      boolean var10000;
      if (var1.getTime() + (long)this.fadeTime.getValue().intValue() < System.currentTimeMillis()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private Color getColor(EntityPlayer var1) {
      if (var1.equals(mc.player)) {
         return this.selfColor.getValue();
      } else {
         return Managers.FRIENDS.isFriend(var1) ? this.friendColor.getValue() : this.color.getValue();
      }
   }

   private boolean isValidEntity(EntityPlayer var1) {
      boolean var10000;
      if (var1 == mc.player && !this.selfPop.getValue() || Managers.FRIENDS.isFriend(var1) && var1 != mc.player && !this.friendPop.getValue()) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public EarthPopChams() {
      super("3arPopChams", "Pop rendering", Category.RENDER);
      this.color = this.add(new Setting<>("Color", new Color(80, 80, 255, 80)));
      this.outline = this.add(new Setting<>("Outline", new Color(80, 80, 255, 255)));
      this.copyAnimations = this.add(new Setting<>("Copy-Animations", true));
      this.yAnimations = this.add(new Setting<>("Y-Animation", 0.0, -7.0, 7.0));
      this.fadeTime = this.add(new Setting<>("Fade-Time", 1500, 0, 5000));
      this.selfPop = this.add(new Setting<>("Self-Pop", false).setParent());
      this.selfColor = this.add(new Setting<>("Self-Color", new Color(80, 80, 255, 80), this::lambda$new$0));
      this.selfOutline = this.add(new Setting<>("Self-Outline", new Color(80, 80, 255, 255), this::lambda$new$1));
      this.friendPop = this.add(new Setting<>("Friend-Pop", false).setParent());
      this.friendColor = this.add(new Setting<>("Friend-Color", new Color(45, 255, 45, 80), this::lambda$new$2));
      this.friendOutline = this.add(new Setting<>("Friend-Outline", new Color(45, 255, 45, 255), this::lambda$new$3));
      this.popDataList = new ArrayList<>();
      INSTANCE = this;
   }

   private void startRender() {
      GL11.glPushAttrib(1048575);
      GL11.glPushMatrix();
      GL11.glDisable(3008);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glDisable(3553);
      GL11.glDisable(2929);
      GL11.glDepthMask(false);
      GL11.glEnable(2884);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4353);
      GL11.glDisable(2896);
   }

   private void endRender() {
      GL11.glEnable(2896);
      GL11.glDisable(2848);
      GL11.glEnable(3553);
      GL11.glEnable(2929);
      GL11.glDisable(3042);
      GL11.glEnable(3008);
      GL11.glDepthMask(true);
      GL11.glCullFace(1029);
      GL11.glPopMatrix();
      GL11.glPopAttrib();
   }

   private EntityPlayer copyPlayer(EntityPlayer var1, boolean var2) {
      int var3 = var1.getItemInUseCount();
      EntityPlayer var4 = new EntityPlayer(this, mc.world, new GameProfile(UUID.randomUUID(), var1.getName()), var3) {
         final EarthPopChams this$0;
         final int val$count;

         public int getItemInUseCount() {
            return this.val$count;
         }

         public boolean isSpectator() {
            return false;
         }

         {
            this.this$0 = var1;
            this.val$count = var4;
         }

         public boolean isCreative() {
            return false;
         }
      };
      if (var2) {
         var4.setSneaking(var1.isSneaking());
         var4.swingProgress = var1.swingProgress;
         var4.limbSwing = var1.limbSwing;
         var4.limbSwingAmount = var1.prevLimbSwingAmount;
         var4.inventory.copyInventory(var1.inventory);
      }

      var4.setPrimaryHand(var1.getPrimaryHand());
      var4.ticksExisted = var1.ticksExisted;
      var4.setEntityId(var1.getEntityId());
      var4.copyLocationAndAnglesFrom(var1);
      return var4;
   }

   private Color getOutlineColor(EntityPlayer var1) {
      if (var1.equals(mc.player)) {
         return this.selfOutline.getValue();
      } else {
         return Managers.FRIENDS.isFriend(var1) ? this.friendOutline.getValue() : this.outline.getValue();
      }
   }

   private boolean lambda$new$3(Color var1) {
      return this.friendPop.isOpen();
   }

   private boolean lambda$new$2(Color var1) {
      return this.friendPop.isOpen();
   }

   public static class PopData {
      private final long time;
      private final EntityPlayer player;
      private final StaticModelPlayer model;
      private final double z;
      private final double x;
      private final double y;

      public PopData(EntityPlayer var1, long var2, double var4, double var6, double var8, boolean var10) {
         this.player = var1;
         this.time = var2;
         this.x = var4;
         double var10002;
         if (var1.isSneaking()) {
            var10002 = 0.125;
            boolean var10003 = false;
         } else {
            var10002 = 0.0;
         }

         this.y = var6 - var10002;
         this.z = var8;
         this.model = new StaticModelPlayer(var1, var10, 0.0F);
         this.model.disableArmorLayers();
      }

      public double getX() {
         return this.x;
      }

      public StaticModelPlayer getModel() {
         return this.model;
      }

      public double getZ() {
         return this.z;
      }

      public double getY() {
         return this.y;
      }

      public EntityPlayer getPlayer() {
         return this.player;
      }

      public long getTime() {
         return this.time;
      }
   }
}
