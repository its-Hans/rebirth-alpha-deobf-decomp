package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class BreadCrumbs extends Module {
   private final Setting<Float> lineWidth;
   private final Setting<Color> secondColor;
   private final Setting<Integer> timeExisted;
   protected final Map trails = new HashMap();
   private final Setting<Boolean> xp;
   private final Setting<Color> color;
   private final Setting<Boolean> self;
   private final Setting<Boolean> arrow;

   public void drawTrail(BreadCrumbs.ItemTrail var1) {
      double var2 = MathUtil.normalize((double)(System.currentTimeMillis() - var1.timer.getStartTime()), 0.0, (double)this.timeExisted.getValue().intValue());
      int var4 = (int)(var2 * 255.0);
      var4 = MathHelper.clamp(var4, 0, 255);
      var4 = 255 - var4;
      int var10000;
      if (var1.timer.isPaused()) {
         var10000 = 255;
         boolean var10001 = false;
      } else {
         var10000 = var4;
      }

      var4 = var10000;
      Color var5 = new Color(this.secondColor.getValue().getRed(), this.secondColor.getValue().getGreen(), this.secondColor.getValue().getBlue(), var4);
      GlStateManager.pushMatrix();
      GlStateManager.disableDepth();
      GlStateManager.disableLighting();
      GlStateManager.depthMask(false);
      GlStateManager.disableAlpha();
      GlStateManager.disableCull();
      GlStateManager.enableBlend();
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glBlendFunc(770, 771);
      GL11.glLineWidth(this.lineWidth.getValue().floatValue());
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      Tessellator var6 = Tessellator.getInstance();
      BufferBuilder var7 = var6.getBuffer();
      var7.begin(3, DefaultVertexFormats.POSITION_COLOR);
      Color var10003 = new Color(this.color.getValue().getRGB());
      Color var10004;
      if (this.secondColor.booleanValue) {
         var10004 = var5;
         boolean var10005 = false;
      } else {
         var10004 = new Color(this.color.getValue().getRGB());
      }

      this.buildBuffer(var7, var1, var10003, var10004);
      var6.draw();
      GlStateManager.depthMask(true);
      GlStateManager.enableLighting();
      GlStateManager.enableDepth();
      GlStateManager.enableAlpha();
      GlStateManager.popMatrix();
      GL11.glEnable(3553);
      GL11.glPolygonMode(1032, 6914);
   }

   public static void addBuilderVertex(BufferBuilder var0, double var1, double var3, double var5, Color var7) {
      var0.pos(var1, var3, var5)
         .color((float)var7.getRed() / 255.0F, (float)var7.getGreen() / 255.0F, (float)var7.getBlue() / 255.0F, (float)var7.getAlpha() / 255.0F)
         .endVertex();
   }

   public BreadCrumbs() {
      super("BreadCrumbs", "Draws trails behind projectiles and you (bread crumbs)", Category.RENDER);
      this.lineWidth = this.add(new Setting<>("Width", 0.8F, 0.1F, 3.0F));
      this.timeExisted = this.add(new Setting<>("Delay", 1000, 100, 3000));
      this.xp = this.add(new Setting<>("Exp", true));
      this.arrow = this.add(new Setting<>("Arrows", true));
      this.self = this.add(new Setting<>("Self", true));
      this.color = this.add(new Setting<>("Color", new Color(125, 125, 213)).hideAlpha());
      this.secondColor = this.add(new Setting<>("SecondColor", new Color(12550399)).injectBoolean(false).hideAlpha());
   }

   public void buildBuffer(BufferBuilder var1, BreadCrumbs.ItemTrail var2, Color var3, Color var4) {
      for(Object var6 : var2.positions) {
         BreadCrumbs.Position var7 = (BreadCrumbs.Position)var6;
         Vec3d var8 = updateToCamera(var7.pos);
         double var9 = MathUtil.normalize((double)var2.positions.indexOf(var7), 0.0, (double)var2.positions.size());
         addBuilderVertex(var1, var8.x, var8.y, var8.z, ColorUtil.interpolate((float)var9, var3, var4));
         boolean var10000 = false;
      }
   }

   boolean isValid(Entity var1) {
      boolean var10000;
      if (!(var1 instanceof EntityEnderPearl)
         && (!(var1 instanceof EntityExpBottle) || !this.xp.getValue())
         && (!(var1 instanceof EntityArrow) || !this.arrow.getValue() || var1.ticksExisted > this.timeExisted.getValue())) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static Vec3d updateToCamera(Vec3d var0) {
      return new Vec3d(var0.x - mc.getRenderManager().viewerPosX, var0.y - mc.getRenderManager().viewerPosY, var0.z - mc.getRenderManager().viewerPosZ);
   }

   static Setting access$000(BreadCrumbs var0) {
      return var0.timeExisted;
   }

   @Override
   public void onTick() {
      for(Entity var2 : mc.world.loadedEntityList) {
         if (this.isValid(var2)) {
            if (this.trails.containsKey(var2.getUniqueID())) {
               if (var2.isDead) {
                  if (((BreadCrumbs.ItemTrail)this.trails.get(var2.getUniqueID())).timer.isPaused()) {
                     ((BreadCrumbs.ItemTrail)this.trails.get(var2.getUniqueID())).timer.resetDelay();
                  }

                  ((BreadCrumbs.ItemTrail)this.trails.get(var2.getUniqueID())).timer.setPaused(false);
                  boolean var10000 = false;
               } else {
                  ((BreadCrumbs.ItemTrail)this.trails.get(var2.getUniqueID())).positions.add(new BreadCrumbs.Position(var2.getPositionVector()));
                  boolean var8 = false;
                  var8 = false;
               }
            } else {
               this.trails.put(var2.getUniqueID(), new BreadCrumbs.ItemTrail(this, var2));
               boolean var10 = false;
            }
         }

         boolean var11 = false;
      }

      if (this.self.getValue()) {
         if (this.trails.containsKey(mc.player.getUniqueID())) {
            BreadCrumbs.ItemTrail var6 = (BreadCrumbs.ItemTrail)this.trails.get(mc.player.getUniqueID());
            var6.timer.resetDelay();
            ArrayList var7 = new ArrayList();

            for(Object var4 : var6.positions) {
               BreadCrumbs.Position var5 = (BreadCrumbs.Position)var4;
               if (System.currentTimeMillis() - var5.time > (long)this.timeExisted.getValue().intValue()) {
                  var7.add(var5);
                  boolean var12 = false;
               }

               boolean var13 = false;
            }

            var6.positions.removeAll(var7);
            boolean var14 = false;
            var6.positions.add(new BreadCrumbs.Position(mc.player.getPositionVector()));
            var14 = false;
            var14 = false;
         } else {
            this.trails.put(mc.player.getUniqueID(), new BreadCrumbs.ItemTrail(this, mc.player));
            boolean var17 = false;
            var17 = false;
         }
      } else {
         this.trails.remove(mc.player.getUniqueID());
         boolean var19 = false;
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent var1) {
      if (!nullCheck()) {
         for(Object var3 : this.trails.entrySet()) {
            Entry var4 = (Entry)var3;
            if (((BreadCrumbs.ItemTrail)var4.getValue()).entity.isDead
               || mc.world.getEntityByID(((BreadCrumbs.ItemTrail)var4.getValue()).entity.getEntityId()) == null) {
               if (((BreadCrumbs.ItemTrail)var4.getValue()).timer.isPaused()) {
                  ((BreadCrumbs.ItemTrail)var4.getValue()).timer.resetDelay();
               }

               ((BreadCrumbs.ItemTrail)var4.getValue()).timer.setPaused(false);
            }

            if (!((BreadCrumbs.ItemTrail)var4.getValue()).timer.isPassed()) {
               this.drawTrail((BreadCrumbs.ItemTrail)var4.getValue());
            }

            boolean var10000 = false;
         }
      }
   }

   public class ItemTrail {
      public final List positions;
      public final Entity entity;
      final BreadCrumbs this$0;
      public final BreadCrumbs.Timer timer;

      public ItemTrail(BreadCrumbs var1, Entity var2) {
         this.this$0 = var1;
         this.entity = var2;
         this.positions = new ArrayList();
         this.timer = new BreadCrumbs.Timer();
         this.timer.setDelay((long)((Integer)BreadCrumbs.access$000(var1).getValue()).intValue());
         this.timer.setPaused(true);
      }
   }

   public static class Position {
      public final long time;
      public final Vec3d pos;

      @Override
      public int hashCode() {
         return Objects.hash(this.pos, this.time);
      }

      public Position(Vec3d var1) {
         this.pos = var1;
         this.time = System.currentTimeMillis();
      }

      @Override
      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (var1 != null && this.getClass() == var1.getClass()) {
            BreadCrumbs.Position var2 = (BreadCrumbs.Position)var1;
            boolean var10000;
            if (this.time == var2.time && Objects.equals(this.pos, var2.pos)) {
               var10000 = true;
               boolean var10001 = false;
            } else {
               var10000 = false;
            }

            return var10000;
         } else {
            return false;
         }
      }
   }

   public static class Timer {
      long delay;
      long startTime = System.currentTimeMillis();
      boolean paused;

      public void setPaused(boolean var1) {
         this.paused = var1;
      }

      public long getTime() {
         return System.currentTimeMillis() - this.startTime;
      }

      public void setDelay(long var1) {
         this.delay = var1;
      }

      public void resetDelay() {
         this.startTime = System.currentTimeMillis();
      }

      public boolean isPaused() {
         return this.paused;
      }

      public boolean isPassed() {
         boolean var10000;
         if (!this.paused && System.currentTimeMillis() - this.startTime >= this.delay) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }

      public long getStartTime() {
         return this.startTime;
      }
   }
}
