package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class VoidESP extends Module {
   private final Setting<Integer> rangeY;
   private final Setting<Boolean> line;
   private final Setting<Color> color;
   private final Setting<Integer> rangeX = this.add(new Setting<>("RangeX", 10, 0, 25));
   private final Setting<VoidESP.Mode> mode;
   private final Setting<Integer> height;
   private final Setting<Boolean> fill;
   static final boolean $assertionsDisabled;
   private final Setting<Boolean> wireframe;

   static {
      boolean var10000;
      if (!VoidESP.class.desiredAssertionStatus()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      $assertionsDisabled = var10000;
   }

   private boolean isVoid(BlockPos var1) {
      if (var1.getY() != 0) {
         return false;
      } else {
         boolean var10000;
         if (BlockUtil.getBlock(var1) != Blocks.BEDROCK) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public VoidESP() {
      super("VoidESP", "Highlights void blocks", Category.RENDER);
      this.rangeY = this.add(new Setting<>("RangeY", 5, 0, 25));
      this.mode = this.add(new Setting<>("Mode", VoidESP.Mode.FULL));
      this.height = this.add(new Setting<>("Height", 1, 0, 4, this::lambda$new$0));
      this.fill = this.add(new Setting<>("Fill", true));
      this.line = this.add(new Setting<>("Outline", true));
      this.wireframe = this.add(new Setting<>("Wireframe", true));
      this.color = this.add(new Setting<>("Color", new Color(1692929536, true)));
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!fullNullCheck()) {
         if (!$assertionsDisabled && mc.renderViewEntity == null) {
            throw new AssertionError();
         }

         Vec3i var2 = new Vec3i(mc.renderViewEntity.posX, mc.renderViewEntity.posY, mc.renderViewEntity.posZ);

         for(int var4 = var2.getX() - this.rangeX.getValue(); var4 < var2.getX() + this.rangeX.getValue(); ++var4) {
            for(int var5 = var2.getZ() - this.rangeX.getValue(); var5 < var2.getZ() + this.rangeX.getValue(); ++var5) {
               for(int var6 = var2.getY() + this.rangeY.getValue(); var6 > var2.getY() - this.rangeY.getValue(); --var6) {
                  BlockPos var3 = new BlockPos(var4, var6, var5);
                  double var7 = 0.0;
                  if (this.mode.getValue() == VoidESP.Mode.FLAT) {
                     var7 = -1.0;
                     boolean var10000 = false;
                  } else if (this.mode.getValue() == VoidESP.Mode.SLAB) {
                     var7 = -0.8;
                  }

                  if (this.isVoid(var3)) {
                     if (this.mode.getValue() == VoidESP.Mode.FULL) {
                        if (this.height.getValue() != 1 && isAir(var3.up())) {
                           if (this.height.getValue() == 2 && isAir(var3.up())) {
                              this.drawVoidESP(
                                 var3,
                                 this.color.getValue(),
                                 new Color(-1),
                                 this.line.getValue(),
                                 this.fill.getValue(),
                                 this.color.getValue().getAlpha(),
                                 1.0,
                                 this.wireframe.getValue()
                              );
                              boolean var12 = false;
                           } else if (this.height.getValue() == 3 && isAir(var3.up()) && isAir(var3.up().up())) {
                              this.drawVoidESP(
                                 var3,
                                 this.color.getValue(),
                                 new Color(-1),
                                 this.line.getValue(),
                                 this.fill.getValue(),
                                 this.color.getValue().getAlpha(),
                                 2.0,
                                 this.wireframe.getValue()
                              );
                              boolean var11 = false;
                           } else if (this.height.getValue() == 4 && isAir(var3.up()) && isAir(var3.up().up()) && isAir(var3.up().up().up())) {
                              this.drawVoidESP(
                                 var3,
                                 this.color.getValue(),
                                 new Color(-1),
                                 this.line.getValue(),
                                 this.fill.getValue(),
                                 this.color.getValue().getAlpha(),
                                 3.0,
                                 this.wireframe.getValue()
                              );
                              boolean var10 = false;
                           }
                        } else {
                           this.drawVoidESP(
                              var3,
                              this.color.getValue(),
                              new Color(-1),
                              this.line.getValue(),
                              this.fill.getValue(),
                              this.color.getValue().getAlpha(),
                              0.0,
                              this.wireframe.getValue()
                           );
                           boolean var9 = false;
                        }
                     } else {
                        this.drawVoidESP(
                           var3,
                           this.color.getValue(),
                           new Color(-1),
                           this.line.getValue(),
                           this.fill.getValue(),
                           this.color.getValue().getAlpha(),
                           var7,
                           this.wireframe.getValue()
                        );
                     }
                  }

                  boolean var13 = false;
               }

               boolean var14 = false;
            }

            boolean var15 = false;
         }
      }
   }

   @Override
   public String getInfo() {
      return Managers.TEXT.normalizeCases(this.mode.getValue());
   }

   public static boolean isAir(BlockPos var0) {
      boolean var10000;
      if (BlockUtil.getBlock(var0) == Blocks.AIR) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawVoidESP(BlockPos var1, Color var2, Color var3, boolean var4, boolean var5, int var6, double var7, boolean var9) {
      if (var5) {
         RenderUtil.drawBox(var1, new Color(var2.getRed(), var2.getGreen(), var2.getBlue(), var6), var7, false, false, 0);
      }

      if (var4) {
         RenderUtil.drawBlockOutline(var1, var2, 0.8F, true, var7, false, false, 0, false);
      }

      if (var9) {
         RenderUtil.drawBlockWireframe(var1, var2, 0.8F, var7, true);
      }
   }

   private boolean lambda$new$0(Integer var1) {
      boolean var10000;
      if (this.mode.getValue() == VoidESP.Mode.FULL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static enum Mode {
      FLAT,
      SLAB,
      FULL;
      private static final VoidESP.Mode[] $VALUES = new VoidESP.Mode[]{VoidESP.Mode.FLAT, VoidESP.Mode.SLAB, VoidESP.Mode.FULL};
   }
}
