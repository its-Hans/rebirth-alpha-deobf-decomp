package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

public class HoleESP extends Module {
   private final Setting<Integer> range;
   private final Setting<Boolean> fov;
   private final Setting<Boolean> box;
   private final Setting<Boolean> customOutline;
   private final Setting<Boolean> renderOwn;
   private final Setting<Float> lineWidth;
   static final boolean $assertionsDisabled;
   private final Setting<Color> brockLineColor;
   private final Setting<HoleESP.Page> page = this.add(new Setting<>("Settings", HoleESP.Page.GLOBAL));
   private final Setting<Boolean> invertGradientBox;
   private final Setting<Color> obbyColor;
   private final Setting<Double> lineHeight;
   private final Setting<Boolean> outline;
   private final Setting<Color> brockColor;
   private final Setting<HoleESP.WireframeMode> wireframeMode;
   private final Setting<Integer> boxAlpha;
   private final Setting<Color> obbyLineColor;
   private final Setting<Boolean> separateHeight;
   private final Setting<Boolean> gradientBox;
   private final Setting<Boolean> invertGradientOutline;
   private final Setting<Boolean> wireframe;
   private final Setting<Double> height;
   private final Setting<Boolean> gradientOutline;

   private boolean lambda$new$14(Float var1) {
      boolean var10000;
      if ((this.outline.getValue() || this.wireframe.getValue()) && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$18(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Boolean var1) {
      boolean var10000;
      if (this.box.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Integer var1) {
      boolean var10000;
      if (this.box.getValue() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$19(Color var1) {
      boolean var10000;
      if (this.customOutline.isOpen() && this.page.getValue() == HoleESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void drawHoleESP(
      BlockPos var1,
      Color var2,
      boolean var3,
      Color var4,
      float var5,
      boolean var6,
      boolean var7,
      int var8,
      boolean var9,
      double var10,
      double var12,
      boolean var14,
      boolean var15,
      boolean var16,
      boolean var17,
      int var18,
      boolean var19,
      boolean var20
   ) {
      if (var7) {
         RenderUtil.drawBox(var1, ColorUtil.injectAlpha(var2, var8), var10, var14, var16, var18);
      }

      if (var6) {
         Color var10001;
         if (var3) {
            var10001 = var4;
            boolean var10002 = false;
         } else {
            var10001 = var2;
         }

         RenderUtil.drawBlockOutline(var1, var10001, var5, var9, var12, var15, var17, var18, false);
      }

      if (var19) {
         Color var21;
         if (var3) {
            var21 = var4;
            boolean var22 = false;
         } else {
            var21 = var2;
         }

         RenderUtil.drawBlockWireframe(var1, var21, var5, var10, var20);
      }
   }

   private boolean lambda$new$7(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$20(Color var1) {
      boolean var10000;
      if (this.customOutline.isOpen() && this.page.getValue() == HoleESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public void drawDoubles(
      boolean var1,
      BlockPos var2,
      Color var3,
      boolean var4,
      Color var5,
      float var6,
      boolean var7,
      boolean var8,
      int var9,
      boolean var10,
      double var11,
      double var13,
      boolean var15,
      boolean var16,
      boolean var17,
      boolean var18,
      int var19,
      boolean var20,
      boolean var21
   ) {
      this.drawHoleESP(var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var13, var15, var16, var17, var18, var19, var20, var21);
      BlockPos var10001;
      if (var1) {
         var10001 = var2.north();
         boolean var10002 = false;
      } else {
         var10001 = var2.east();
      }

      this.drawHoleESP(var10001, var3, var4, var5, var6, var7, var8, var9, var10, var11, var13, var15, var16, var17, var18, var19, var20, var21);
   }

   public HoleESP() {
      super("HoleESP", "Shows safe spots near you", Category.RENDER);
      this.renderOwn = this.add(new Setting<>("RenderOwn", true, this::lambda$new$0));
      this.fov = this.add(new Setting<>("FovOnly", true, this::lambda$new$1));
      this.range = this.add(new Setting<>("Range", 5, 0, 25, this::lambda$new$2));
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$3).setParent());
      this.gradientBox = this.add(new Setting<>("FadeBox", false, this::lambda$new$4));
      this.invertGradientBox = this.add(new Setting<>("InvertBoxFade", false, this::lambda$new$5));
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 80, 0, 255, this::lambda$new$6));
      this.outline = this.add(new Setting<>("Outline", true, this::lambda$new$7).setParent());
      this.gradientOutline = this.add(new Setting<>("FadeLine", false, this::lambda$new$8));
      this.invertGradientOutline = this.add(new Setting<>("InvertLineFade", false, this::lambda$new$9));
      this.separateHeight = this.add(new Setting<>("SeparateHeight", false, this::lambda$new$10));
      this.lineHeight = this.add(new Setting<>("LineHeight", -1.1, -2.0, 2.0, this::lambda$new$11));
      this.wireframe = this.add(new Setting<>("Wireframe", true, this::lambda$new$12).setParent());
      this.wireframeMode = this.add(new Setting<>("Mode", HoleESP.WireframeMode.FULL, this::lambda$new$13));
      this.lineWidth = this.add(new Setting<>("LineWidth", 0.5F, 0.1F, 5.0F, this::lambda$new$14));
      this.height = this.add(new Setting<>("Height", -1.1, -2.0, 2.0, this::lambda$new$15));
      this.obbyColor = this.add(new Setting<>("Obby", new Color(12721437), this::lambda$new$16));
      this.brockColor = this.add(new Setting<>("Bedrock", new Color(2595403), this::lambda$new$17));
      this.customOutline = this.add(new Setting<>("LineColor", false, this::lambda$new$18).setParent());
      this.obbyLineColor = this.add(new Setting<>("ObbyLine", new Color(-1), this::lambda$new$19));
      this.brockLineColor = this.add(new Setting<>("BedrockLine", new Color(-1), this::lambda$new$20));
   }

   private boolean lambda$new$15(Double var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Boolean var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!$assertionsDisabled && mc.renderViewEntity == null) {
         throw new AssertionError();
      } else {
         Vec3i var2 = new Vec3i(mc.renderViewEntity.posX, mc.renderViewEntity.posY, mc.renderViewEntity.posZ);

         for(int var3 = var2.getX() - this.range.getValue(); var3 < var2.getX() + this.range.getValue(); ++var3) {
            for(int var4 = var2.getZ() - this.range.getValue(); var4 < var2.getZ() + this.range.getValue(); ++var4) {
               byte var5 = 5;

               for(int var6 = var2.getY() + var5; var6 > var2.getY() - var5; --var6) {
                  BlockPos var7 = new BlockPos(var3, var6, var4);
                  Color var8 = this.brockColor.getValue();
                  Color var9 = this.obbyColor.getValue();
                  Color var10 = this.brockLineColor.getValue();
                  Color var11 = this.obbyLineColor.getValue();
                  if (mc.world.getBlockState(var7).getBlock().equals(Blocks.AIR)
                     && mc.world.getBlockState(var7.add(0, 1, 0)).getBlock().equals(Blocks.AIR)
                     && mc.world.getBlockState(var7.add(0, 2, 0)).getBlock().equals(Blocks.AIR)
                     && (!var7.equals(EntityUtil.getPlayerPos()) || this.renderOwn.getValue())) {
                     if (!Managers.ROTATIONS.isInFov(var7) && this.fov.getValue()) {
                        boolean var15 = false;
                     } else {
                        if (mc.world.getBlockState(var7.north()).getBlock() == Blocks.AIR
                           && mc.world.getBlockState(var7.north().up()).getBlock() == Blocks.AIR
                           && mc.world.getBlockState(var7.north().down()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.north(2)).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.east()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.north().east()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.west()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.north().west()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.south()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.down()).getBlock() == Blocks.BEDROCK) {
                           boolean var20 = this.customOutline.getValue();
                           float var24 = this.lineWidth.getValue();
                           boolean var29 = this.outline.getValue();
                           boolean var34 = this.box.getValue();
                           int var39 = this.boxAlpha.getValue();
                           double var43 = this.height.getValue();
                           double var48;
                           if (this.separateHeight.getValue()) {
                              var48 = this.lineHeight.getValue();
                              boolean var56 = false;
                           } else {
                              var48 = this.height.getValue();
                           }

                           boolean var57 = this.gradientBox.getValue();
                           boolean var64 = this.gradientOutline.getValue();
                           boolean var69 = this.invertGradientBox.getValue();
                           boolean var74 = this.invertGradientOutline.getValue();
                           boolean var78 = this.wireframe.getValue();
                           boolean var83;
                           if (this.wireframeMode.getValue() == HoleESP.WireframeMode.FLAT) {
                              var83 = true;
                              boolean var88 = false;
                           } else {
                              var83 = false;
                           }

                           this.drawDoubles(
                              true, var7, var8, var20, var10, var24, var29, var34, var39, true, var43, var48, var57, var64, var69, var74, 0, var78, var83
                           );
                           boolean var10000 = false;
                        } else if (mc.world.getBlockState(var7.north()).getBlock() == Blocks.AIR
                           && mc.world.getBlockState(var7.north().up()).getBlock() == Blocks.AIR
                           && (
                              mc.world.getBlockState(var7.north().down()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.north().down()).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.north(2)).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.north(2)).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.east()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.east()).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.north().east()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.north().east()).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.west()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.west()).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.north().west()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.north().west()).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.south()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.south()).getBlock() == Blocks.BEDROCK
                           )
                           && (
                              mc.world.getBlockState(var7.down()).getBlock() == Blocks.OBSIDIAN
                                 || mc.world.getBlockState(var7.down()).getBlock() == Blocks.BEDROCK
                           )) {
                           boolean var10004 = this.customOutline.getValue();
                           float var10006 = this.lineWidth.getValue();
                           boolean var10007 = this.outline.getValue();
                           boolean var10008 = this.box.getValue();
                           int var10009 = this.boxAlpha.getValue();
                           double var10011 = this.height.getValue();
                           double var10012;
                           if (this.separateHeight.getValue()) {
                              var10012 = this.lineHeight.getValue();
                              boolean var10013 = false;
                           } else {
                              var10012 = this.height.getValue();
                           }

                           boolean var55 = this.gradientBox.getValue();
                           boolean var10014 = this.gradientOutline.getValue();
                           boolean var10015 = this.invertGradientBox.getValue();
                           boolean var10016 = this.invertGradientOutline.getValue();
                           boolean var10018 = this.wireframe.getValue();
                           boolean var10019;
                           if (this.wireframeMode.getValue() == HoleESP.WireframeMode.FLAT) {
                              var10019 = true;
                              boolean var10020 = false;
                           } else {
                              var10019 = false;
                           }

                           this.drawDoubles(
                              true,
                              var7,
                              var9,
                              var10004,
                              var11,
                              var10006,
                              var10007,
                              var10008,
                              var10009,
                              true,
                              var10011,
                              var10012,
                              var55,
                              var10014,
                              var10015,
                              var10016,
                              0,
                              var10018,
                              var10019
                           );
                        }

                        if (mc.world.getBlockState(var7.east()).getBlock() == Blocks.AIR
                           && mc.world.getBlockState(var7.east().up()).getBlock() == Blocks.AIR
                           && mc.world.getBlockState(var7.east().down()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.east(2)).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.east(2).down()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.north()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.east().north()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.west()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.east().south()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.south()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.down()).getBlock() == Blocks.BEDROCK) {
                           boolean var22 = this.customOutline.getValue();
                           float var26 = this.lineWidth.getValue();
                           boolean var31 = this.outline.getValue();
                           boolean var36 = this.box.getValue();
                           int var41 = this.boxAlpha.getValue();
                           double var45 = this.height.getValue();
                           double var50;
                           if (this.separateHeight.getValue()) {
                              var50 = this.lineHeight.getValue();
                              boolean var60 = false;
                           } else {
                              var50 = this.height.getValue();
                           }

                           boolean var61 = this.gradientBox.getValue();
                           boolean var66 = this.gradientOutline.getValue();
                           boolean var71 = this.invertGradientBox.getValue();
                           boolean var76 = this.invertGradientOutline.getValue();
                           boolean var80 = this.wireframe.getValue();
                           boolean var85;
                           if (this.wireframeMode.getValue() == HoleESP.WireframeMode.FLAT) {
                              var85 = true;
                              boolean var90 = false;
                           } else {
                              var85 = false;
                           }

                           this.drawDoubles(
                              false, var7, var8, var22, var10, var26, var31, var36, var41, true, var45, var50, var61, var66, var71, var76, 0, var80, var85
                           );
                           boolean var12 = false;
                        } else if (mc.world.getBlockState(var7.east()).getBlock() == Blocks.AIR
                           && mc.world.getBlockState(var7.east().up()).getBlock() == Blocks.AIR
                           && (
                              mc.world.getBlockState(var7.east().down()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.east().down()).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.east(2)).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.east(2)).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.north()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.north()).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.east().north()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.east().north()).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.west()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.west()).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.east().south()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.east().south()).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.south()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.south()).getBlock() == Blocks.OBSIDIAN
                           )
                           && (
                              mc.world.getBlockState(var7.down()).getBlock() == Blocks.BEDROCK
                                 || mc.world.getBlockState(var7.down()).getBlock() == Blocks.OBSIDIAN
                           )) {
                           boolean var21 = this.customOutline.getValue();
                           float var25 = this.lineWidth.getValue();
                           boolean var30 = this.outline.getValue();
                           boolean var35 = this.box.getValue();
                           int var40 = this.boxAlpha.getValue();
                           double var44 = this.height.getValue();
                           double var49;
                           if (this.separateHeight.getValue()) {
                              var49 = this.lineHeight.getValue();
                              boolean var58 = false;
                           } else {
                              var49 = this.height.getValue();
                           }

                           boolean var59 = this.gradientBox.getValue();
                           boolean var65 = this.gradientOutline.getValue();
                           boolean var70 = this.invertGradientBox.getValue();
                           boolean var75 = this.invertGradientOutline.getValue();
                           boolean var79 = this.wireframe.getValue();
                           boolean var84;
                           if (this.wireframeMode.getValue() == HoleESP.WireframeMode.FLAT) {
                              var84 = true;
                              boolean var89 = false;
                           } else {
                              var84 = false;
                           }

                           this.drawDoubles(
                              false, var7, var9, var21, var11, var25, var30, var35, var40, true, var44, var49, var59, var65, var70, var75, 0, var79, var84
                           );
                        }

                        if (mc.world.getBlockState(var7.north()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.east()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.west()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.south()).getBlock() == Blocks.BEDROCK
                           && mc.world.getBlockState(var7.down()).getBlock() == Blocks.BEDROCK) {
                           boolean var19 = this.customOutline.getValue();
                           float var23 = this.lineWidth.getValue();
                           boolean var28 = this.outline.getValue();
                           boolean var33 = this.box.getValue();
                           int var38 = this.boxAlpha.getValue();
                           double var42 = this.height.getValue();
                           double var47;
                           if (this.separateHeight.getValue()) {
                              var47 = this.lineHeight.getValue();
                              boolean var53 = false;
                           } else {
                              var47 = this.height.getValue();
                           }

                           boolean var54 = this.gradientBox.getValue();
                           boolean var63 = this.gradientOutline.getValue();
                           boolean var68 = this.invertGradientBox.getValue();
                           boolean var73 = this.invertGradientOutline.getValue();
                           boolean var77 = this.wireframe.getValue();
                           boolean var82;
                           if (this.wireframeMode.getValue() == HoleESP.WireframeMode.FLAT) {
                              var82 = true;
                              boolean var87 = false;
                           } else {
                              var82 = false;
                           }

                           this.drawHoleESP(
                              var7, var8, var19, var10, var23, var28, var33, var38, true, var42, var47, var54, var63, var68, var73, 0, var77, var82
                           );
                           boolean var14 = false;
                        } else if (!BlockUtil.isSafe(mc.world.getBlockState(var7.down()).getBlock())
                           && !BlockUtil.isSafe(mc.world.getBlockState(var7.east()).getBlock())
                           && !BlockUtil.isSafe(mc.world.getBlockState(var7.west()).getBlock())
                           && !BlockUtil.isSafe(mc.world.getBlockState(var7.south()).getBlock())) {
                           if (BlockUtil.isSafe(mc.world.getBlockState(var7.north()).getBlock())) {
                              boolean var13 = false;
                           } else {
                              boolean var10003 = this.customOutline.getValue();
                              float var10005 = this.lineWidth.getValue();
                              boolean var27 = this.outline.getValue();
                              boolean var32 = this.box.getValue();
                              int var37 = this.boxAlpha.getValue();
                              double var10010 = this.height.getValue();
                              double var46;
                              if (this.separateHeight.getValue()) {
                                 var46 = this.lineHeight.getValue();
                                 boolean var51 = false;
                              } else {
                                 var46 = this.height.getValue();
                              }

                              boolean var52 = this.gradientBox.getValue();
                              boolean var62 = this.gradientOutline.getValue();
                              boolean var67 = this.invertGradientBox.getValue();
                              boolean var72 = this.invertGradientOutline.getValue();
                              boolean var10017 = this.wireframe.getValue();
                              boolean var81;
                              if (this.wireframeMode.getValue() == HoleESP.WireframeMode.FLAT) {
                                 var81 = true;
                                 boolean var86 = false;
                              } else {
                                 var81 = false;
                              }

                              this.drawHoleESP(
                                 var7,
                                 var9,
                                 var10003,
                                 var11,
                                 var10005,
                                 var27,
                                 var32,
                                 var37,
                                 true,
                                 var10010,
                                 var46,
                                 var52,
                                 var62,
                                 var67,
                                 var72,
                                 0,
                                 var10017,
                                 var81
                              );
                           }
                        }
                     }
                  }

                  boolean var16 = false;
               }

               boolean var17 = false;
            }

            boolean var18 = false;
         }
      }
   }

   private boolean lambda$new$12(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$17(Color var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Color var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Boolean var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   static {
      boolean var10000;
      if (!HoleESP.class.desiredAssertionStatus()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      $assertionsDisabled = var10000;
   }

   private boolean lambda$new$2(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Boolean var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(HoleESP.WireframeMode var1) {
      boolean var10000;
      if (this.wireframe.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Double var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL && this.separateHeight.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.box.isOpen() && this.page.getValue() == HoleESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static enum Page {
      COLORS,
      GLOBAL;

      private static final HoleESP.Page[] $VALUES = new HoleESP.Page[]{COLORS, GLOBAL};
   }

   private static enum WireframeMode {
      FULL,
      FLAT;
      private static final HoleESP.WireframeMode[] $VALUES = new HoleESP.WireframeMode[]{HoleESP.WireframeMode.FLAT, HoleESP.WireframeMode.FULL};
   }
}
