package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.asm.accessors.IEntityRenderer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public final class ESP2D extends Module {
   public final Setting<Boolean> armorItems;
   public final Setting<Boolean> droppedItems;
   private final int black;
   public final Setting<Boolean> animals;
   public final Setting<Color> color;
   public final Setting<Boolean> tagsBGValue;
   private final Setting<Integer> mixerSecondsValue;
   public final Setting<Boolean> friendColor;
   private static final int[] DISPLAY_LISTS_2D = new int[4];
   public final Setting<Boolean> itemValue;
   private final FloatBuffer modelview;
   public final Setting<Boolean> clearNameValue;
   private final FloatBuffer projection;
   public final Setting<Boolean> outline;
   public final Setting<Boolean> bbtt = this.add(new Setting<>("2B2T Mode", true));
   private static final Pattern COLOR_PATTERN = Pattern.compile("(?i)§[0-9A-FK-OR]");
   public final Setting<Boolean> armorBar;
   private final Setting<Float> brightnessValue;
   public final Setting<Boolean> healthBar;
   private final Setting<Float> fontScaleValue;
   public final Setting<Boolean> tagsValue;
   public final Setting<Boolean> itemTagsValue;
   public final Setting<ESP2D.Mode> boxMode;
   public final Setting<ESP2D.Mode5> colorModeValue;
   public final Setting<Boolean> hoverValue;
   private final IntBuffer viewport;
   public final Setting<Boolean> localPlayer;
   public final Setting<ESP2D.Mode4> hpMode;
   private final FloatBuffer vector;
   private final Setting<Float> saturationValue;
   public final Setting<Boolean> armorDur;
   public final Setting<Boolean> mobs;
   public final Setting<Boolean> healthNumber;
   private static final Frustum frustrum = new Frustum();
   public final Setting<Boolean> outlineFont;
   private final DecimalFormat dFormat;
   public final Setting<ESP2D.Mode2> hpBarMode;
   public static final List collectedEntities = new ArrayList();
   private final int backgroundColor;
   public static ESP2D INSTANCE = new ESP2D();

   private void drawScaledCenteredString(String var1, double var2, double var4, double var6) {
      this.drawScaledString(var1, var2 - (double)((float)mc.fontRenderer.getStringWidth(var1) / 2.0F) * var6, var4, var6);
   }

   private void drawScaledString(String var1, double var2, double var4, double var6, int var8) {
      GlStateManager.pushMatrix();
      GlStateManager.translate(var2, var4, var2);
      GlStateManager.scale(var6, var6, var6);
      if (this.outlineFont.getValue()) {
         this.drawOutlineStringWithoutGL(var1, 0.0F, 0.0F, var8, mc.fontRenderer);
         boolean var10000 = false;
      } else {
         mc.fontRenderer.drawStringWithShadow(var1, 0.0F, 0.0F, var8);
         boolean var9 = false;
      }

      GlStateManager.popMatrix();
   }

   public static void setColor(Color var0) {
      float var1 = (float)(var0.getRGB() >> 24 & 0xFF) / 255.0F;
      float var2 = (float)(var0.getRGB() >> 16 & 0xFF) / 255.0F;
      float var3 = (float)(var0.getRGB() >> 8 & 0xFF) / 255.0F;
      float var4 = (float)(var0.getRGB() & 0xFF) / 255.0F;
      GL11.glColor4f(var2, var3, var4, var1);
   }

   private void drawScaledString(String var1, double var2, double var4, double var6) {
      GlStateManager.pushMatrix();
      GlStateManager.translate(var2, var4, var2);
      GlStateManager.scale(var6, var6, var6);
      if (this.outlineFont.getValue()) {
         this.drawOutlineStringWithoutGL(var1, 0.0F, 0.0F, -1, mc.fontRenderer);
         boolean var10000 = false;
      } else {
         mc.fontRenderer.drawStringWithShadow(var1, 0.0F, 0.0F, -1);
         boolean var8 = false;
      }

      GlStateManager.popMatrix();
   }

   public static Color slowlyRainbow(long var0, int var2, float var3, float var4) {
      Color var5 = new Color(Color.HSBtoRGB(((float)var0 + (float)var2 * -3000000.0F) / 2.0F / 1.0E9F, var3, var4));
      return new Color((float)var5.getRed() / 255.0F, (float)var5.getGreen() / 255.0F, (float)var5.getBlue() / 255.0F, (float)var5.getAlpha() / 255.0F);
   }

   private boolean lambda$new$2(Color var1) {
      boolean var10000;
      if (this.colorModeValue.getValue() == ESP2D.Mode5.Custom && this.outline.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean isInViewFrustrum(AxisAlignedBB var0) {
      Entity var1 = mc.getRenderViewEntity();
      frustrum.setPosition(var1.posX, var1.posY, var1.posZ);
      return frustrum.isBoundingBoxInFrustum(var0);
   }

   private boolean lambda$new$3(Float var1) {
      boolean var10000;
      if (this.colorModeValue.getValue() != ESP2D.Mode5.Custom && this.outline.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static int[] getFractionIndices(float[] var0, float var1) {
      int[] var3 = new int[2];

      int var2;
      for(var2 = 0; var2 < var0.length && var0[var2] <= var1; ++var2) {
         boolean var10000 = false;
      }

      if (var2 >= var0.length) {
         var2 = var0.length - 1;
      }

      var3[0] = var2 - 1;
      var3[1] = var2;
      return var3;
   }

   public boolean isMob(Entity var1) {
      boolean var10000;
      if (!(var1 instanceof EntityMob) && !(var1 instanceof EntitySlime) && !(var1 instanceof EntityGhast) && !(var1 instanceof EntityDragon)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(ESP2D.Mode4 var1) {
      boolean var10000;
      if (this.healthNumber.isOpen() && this.healthBar.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   @Override
   public void onRender2D(Render2DEvent var1) {
      GL11.glPushMatrix();
      this.collectEntities();
      float var2 = var1.partialTicks;
      ScaledResolution var3 = new ScaledResolution(mc);
      int var4 = var3.getScaleFactor();
      double var5 = (double)var4 / Math.pow((double)var4, 2.0);
      GL11.glScaled(var5, var5, var5);
      int var7 = this.black;
      RenderManager var8 = mc.getRenderManager();
      EntityRenderer var9 = mc.entityRenderer;
      boolean var10 = this.outline.getValue();
      boolean var11 = this.healthBar.getValue();
      int var12 = 0;

      for(int var13 = collectedEntities.size(); var12 < var13; ++var12) {
         Entity var14 = (Entity)collectedEntities.get(var12);
         int var15 = this.getColor(var14).getRGB();
         if (isInViewFrustrum(var14)) {
            double var16 = interpolate(var14.posX, var14.lastTickPosX, (double)var2);
            double var18 = interpolate(var14.posY, var14.lastTickPosY, (double)var2);
            double var20 = interpolate(var14.posZ, var14.lastTickPosZ, (double)var2);
            double var22 = (double)var14.width / 1.5;
            double var10000 = (double)var14.height;
            double var10001;
            if (var14.isSneaking()) {
               var10001 = -0.3;
               boolean var10002 = false;
            } else {
               var10001 = 0.2;
            }

            double var24 = var10000 + var10001;
            AxisAlignedBB var26 = new AxisAlignedBB(var16 - var22, var18, var20 - var22, var16 + var22, var18 + var24, var20 + var22);
            List var27 = Arrays.asList(
               new Vector3d(var26.minX, var26.minY, var26.minZ),
               new Vector3d(var26.minX, var26.maxY, var26.minZ),
               new Vector3d(var26.maxX, var26.minY, var26.minZ),
               new Vector3d(var26.maxX, var26.maxY, var26.minZ),
               new Vector3d(var26.minX, var26.minY, var26.maxZ),
               new Vector3d(var26.minX, var26.maxY, var26.maxZ),
               new Vector3d(var26.maxX, var26.minY, var26.maxZ),
               new Vector3d(var26.maxX, var26.maxY, var26.maxZ)
            );
            ((IEntityRenderer)mc.entityRenderer).invokeSetupCameraTransform(var2, 0);
            Vector4d var28 = null;

            for(Object var30 : var27) {
               Vector3d var31 = (Vector3d)var30;
               var31 = this.project2D(var4, var31.x - var8.viewerPosX, var31.y - var8.viewerPosY, var31.z - var8.viewerPosZ);
               if (var31 != null && var31.z >= 0.0 && var31.z < 1.0) {
                  if (var28 == null) {
                     var28 = new Vector4d(var31.x, var31.y, var31.z, 0.0);
                  }

                  var28.x = Math.min(var31.x, var28.x);
                  var28.y = Math.min(var31.y, var28.y);
                  var28.z = Math.max(var31.x, var28.z);
                  var28.w = Math.max(var31.y, var28.w);
               }

               boolean var69 = false;
            }

            if (var28 != null) {
               var9.setupOverlayRendering();
               double var56 = var28.x;
               double var58 = var28.y;
               double var33 = var28.z;
               double var35 = var28.w;
               if (var10) {
                  if (this.boxMode.getValue() == ESP2D.Mode.Box) {
                     newDrawRect(var56 - 1.0, var58, var56 + 0.5, var35 + 0.5, var7);
                     newDrawRect(var56 - 1.0, var58 - 0.5, var33 + 0.5, var58 + 0.5 + 0.5, var7);
                     newDrawRect(var33 - 0.5 - 0.5, var58, var33 + 0.5, var35 + 0.5, var7);
                     newDrawRect(var56 - 1.0, var35 - 0.5 - 0.5, var33 + 0.5, var35 + 0.5, var7);
                     newDrawRect(var56 - 0.5, var58, var56 + 0.5 - 0.5, var35, var15);
                     newDrawRect(var56, var35 - 0.5, var33, var35, var15);
                     newDrawRect(var56 - 0.5, var58, var33, var58 + 0.5, var15);
                     newDrawRect(var33 - 0.5, var58, var33, var35, var15);
                     boolean var70 = false;
                  } else {
                     newDrawRect(var56 + 0.5, var58, var56 - 1.0, var58 + (var35 - var58) / 4.0 + 0.5, var7);
                     newDrawRect(var56 - 1.0, var35, var56 + 0.5, var35 - (var35 - var58) / 4.0 - 0.5, var7);
                     newDrawRect(var56 - 1.0, var58 - 0.5, var56 + (var33 - var56) / 3.0 + 0.5, var58 + 1.0, var7);
                     newDrawRect(var33 - (var33 - var56) / 3.0 - 0.5, var58 - 0.5, var33, var58 + 1.0, var7);
                     newDrawRect(var33 - 1.0, var58, var33 + 0.5, var58 + (var35 - var58) / 4.0 + 0.5, var7);
                     newDrawRect(var33 - 1.0, var35, var33 + 0.5, var35 - (var35 - var58) / 4.0 - 0.5, var7);
                     newDrawRect(var56 - 1.0, var35 - 1.0, var56 + (var33 - var56) / 3.0 + 0.5, var35 + 0.5, var7);
                     newDrawRect(var33 - (var33 - var56) / 3.0 - 0.5, var35 - 1.0, var33 + 0.5, var35 + 0.5, var7);
                     newDrawRect(var56, var58, var56 - 0.5, var58 + (var35 - var58) / 4.0, var15);
                     newDrawRect(var56, var35, var56 - 0.5, var35 - (var35 - var58) / 4.0, var15);
                     newDrawRect(var56 - 0.5, var58, var56 + (var33 - var56) / 3.0, var58 + 0.5, var15);
                     newDrawRect(var33 - (var33 - var56) / 3.0, var58, var33, var58 + 0.5, var15);
                     newDrawRect(var33 - 0.5, var58, var33, var58 + (var35 - var58) / 4.0, var15);
                     newDrawRect(var33 - 0.5, var35, var33, var35 - (var35 - var58) / 4.0, var15);
                     newDrawRect(var56, var35 - 0.5, var56 + (var33 - var56) / 3.0, var35, var15);
                     newDrawRect(var33 - (var33 - var56) / 3.0, var35 - 0.5, var33 - 0.5, var35, var15);
                  }
               }

               boolean var37 = var14 instanceof EntityLivingBase;
               if (!var37) {
                  boolean var77 = false;
               } else {
                  EntityLivingBase var38 = (EntityLivingBase)var14;
                  if (var11) {
                     float var39 = var38.getHealth();
                     float var40 = var38.getMaxHealth();
                     if (this.bbtt.getValue() && var38 instanceof EntityPlayer) {
                        var39 = var38.getHealth() + var38.getAbsorptionAmount();
                        var40 = var38.getMaxHealth() + 16.0F;
                     }

                     if (var39 > var40) {
                        var39 = var40;
                     }

                     double var41 = (double)(var39 / var40);
                     double var43 = (var35 - var58) * var41;
                     String var45 = String.valueOf(
                        new StringBuilder().append(this.dFormat.format((double)(var38.getHealth() + var38.getAbsorptionAmount()))).append(" §c❤")
                     );
                     String var46 = String.valueOf(new StringBuilder().append((int)(var38.getHealth() / var40 * 100.0F)).append("%"));
                     if (this.healthNumber.getValue()
                        && (!this.hoverValue.getValue() || var14 == mc.player || this.isHovering(var56, var33, var58, var35, var3))) {
                        String var79;
                        if (this.hpMode.getValue() == ESP2D.Mode4.Health) {
                           var79 = var45;
                           boolean var83 = false;
                        } else {
                           var79 = var46;
                        }

                        double var84 = var56 - 4.0;
                        TextManager var10003 = Managers.TEXT;
                        String var10004;
                        if (this.hpMode.getValue() == ESP2D.Mode4.Health) {
                           var10004 = var45;
                           boolean var10005 = false;
                        } else {
                           var10004 = var46;
                        }

                        this.drawScaledString(
                           var79,
                           var84 - (double)((float)var10003.getStringWidth(var10004) * this.fontScaleValue.getValue()),
                           var35 - var43 - (double)((float)mc.fontRenderer.FONT_HEIGHT / 2.0F * this.fontScaleValue.getValue()),
                           (double)this.fontScaleValue.getValue().floatValue()
                        );
                     }

                     newDrawRect(var56 - 3.5, var58 - 0.5, var56 - 1.5, var35 + 0.5, this.backgroundColor);
                     if (var39 > 0.0F) {
                        int var47 = getHealthColor(var39, var40).getRGB();
                        double var48 = var35 - var58;
                        if (this.hpBarMode.getValue() == ESP2D.Mode2.Dot && var48 >= 60.0) {
                           for(double var50 = 0.0; var50 < 10.0; var71 = false) {
                              double var52 = MathHelper.clamp((double)var39 - var50 * ((double)var40 / 10.0), 0.0, (double)var40 / 10.0)
                                 / ((double)var40 / 10.0);
                              double var54 = (var48 / 10.0 - 0.5) * var52;
                              newDrawRect(var56 - 3.0, var35 - (var48 + 0.5) / 10.0 * var50, var56 - 2.0, var35 - (var48 + 0.5) / 10.0 * var50 - var54, var47);
                              ++var50;
                           }

                           boolean var72 = false;
                        } else {
                           newDrawRect(var56 - 3.0, var35, var56 - 2.0, var35 - var43, var47);
                        }
                     }
                  }

                  if (this.tagsValue.getValue()) {
                     String var73;
                     if (this.clearNameValue.getValue()) {
                        var73 = var38.getName();
                        boolean var80 = false;
                     } else {
                        var73 = var38.getDisplayName().getFormattedText();
                     }

                     String var59 = var73;
                     if (this.friendColor.getValue() && Managers.FRIENDS.isFriend(var38.getName())) {
                        var59 = String.valueOf(new StringBuilder().append("§b").append(var59));
                     }

                     if (this.tagsBGValue.getValue()) {
                        newDrawRect(
                           var56
                              + (var33 - var56) / 2.0
                              - (double)(((float)mc.fontRenderer.getStringWidth(var59) / 2.0F + 2.0F) * this.fontScaleValue.getValue()),
                           var58 - 1.0 - (double)(((float)mc.fontRenderer.FONT_HEIGHT + 2.0F) * this.fontScaleValue.getValue()),
                           var56
                              + (var33 - var56) / 2.0
                              + (double)(((float)mc.fontRenderer.getStringWidth(var59) / 2.0F + 2.0F) * this.fontScaleValue.getValue()),
                           var58 - 1.0 + (double)(2.0F * this.fontScaleValue.getValue()),
                           -1610612736
                        );
                     }

                     this.drawScaledCenteredString(
                        var59,
                        var56 + (var33 - var56) / 2.0,
                        var58 - 1.0 - (double)((float)mc.fontRenderer.FONT_HEIGHT * this.fontScaleValue.getValue()),
                        (double)this.fontScaleValue.getValue().floatValue()
                     );
                  }

                  if (this.armorBar.getValue() && var14 instanceof EntityPlayer) {
                     double var60 = (var35 - var58) / 4.0;

                     for(int var65 = 4; var65 > 0; --var65) {
                        ItemStack var67 = var38.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
                        if (var65 == 3) {
                           var67 = var38.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
                        }

                        if (var65 == 2) {
                           var67 = var38.getItemStackFromSlot(EntityEquipmentSlot.LEGS);
                        }

                        if (var65 == 1) {
                           var67 = var38.getItemStackFromSlot(EntityEquipmentSlot.FEET);
                        }

                        double var49 = var60 + 0.25;
                        newDrawRect(
                           var33 + 1.5,
                           var35 + 0.5 - var49 * (double)var65,
                           var33 + 3.5,
                           var35 + 0.5 - var49 * (double)(var65 - 1),
                           new Color(0, 0, 0, 120).getRGB()
                        );
                        newDrawRect(
                           var33 + 2.0,
                           var35 + 0.5 - var49 * (double)(var65 - 1) - 0.25,
                           var33 + 3.0,
                           var35
                              + 0.5
                              - var49 * (double)(var65 - 1)
                              - 0.25
                              - (var60 - 0.25) * MathHelper.clamp((double)InventoryUtil.getItemDurability(var67) / (double)var67.getMaxDamage(), 0.0, 1.0),
                           new Color(0, 255, 255).getRGB()
                        );
                        boolean var74 = false;
                     }
                  }

                  if (this.armorItems.getValue() && (!this.hoverValue.getValue() || var14 == mc.player || this.isHovering(var56, var33, var58, var35, var3))) {
                     double var61 = (var35 - var58) / 4.0;

                     for(int var66 = 4; var66 > 0; --var66) {
                        ItemStack var68 = var38.getItemStackFromSlot(EntityEquipmentSlot.HEAD);
                        if (var66 == 3) {
                           var68 = var38.getItemStackFromSlot(EntityEquipmentSlot.CHEST);
                        }

                        if (var66 == 2) {
                           var68 = var38.getItemStackFromSlot(EntityEquipmentSlot.LEGS);
                        }

                        if (var66 == 1) {
                           var68 = var38.getItemStackFromSlot(EntityEquipmentSlot.FEET);
                        }

                        double var85;
                        if (this.armorBar.getValue()) {
                           var85 = 4.0;
                           boolean var88 = false;
                        } else {
                           var85 = 2.0;
                        }

                        this.renderItemStack(var68, var33 + var85, var58 + var61 * (double)(4 - var66) + var61 / 2.0 - 5.0);
                        if (this.armorDur.getValue()) {
                           String var81 = String.valueOf(new StringBuilder().append(InventoryUtil.getItemDurability(var68)).append(""));
                           if (this.armorBar.getValue()) {
                              var85 = 4.0;
                              boolean var89 = false;
                           } else {
                              var85 = 2.0;
                           }

                           this.drawScaledCenteredString(
                              var81,
                              var33 + var85 + 4.5,
                              var58 + var61 * (double)(4 - var66) + var61 / 2.0 + 4.0,
                              (double)this.fontScaleValue.getValue().floatValue(),
                              -1
                           );
                        }

                        boolean var75 = false;
                     }
                  }

                  if (this.itemTagsValue.getValue()) {
                     if (!this.itemValue.getValue()) {
                        String var62 = var38.getHeldItem(EnumHand.MAIN_HAND).getDisplayName();
                        if (this.tagsBGValue.getValue()) {
                           newDrawRect(
                              var56
                                 + (var33 - var56) / 2.0
                                 - (double)(((float)mc.fontRenderer.getStringWidth(var62) / 2.0F + 2.0F) * this.fontScaleValue.getValue()),
                              var35 + 1.0 - (double)(2.0F * this.fontScaleValue.getValue()),
                              var56
                                 + (var33 - var56) / 2.0
                                 + (double)(((float)mc.fontRenderer.getStringWidth(var62) / 2.0F + 2.0F) * this.fontScaleValue.getValue()),
                              var35 + 1.0 + (double)(((float)mc.fontRenderer.FONT_HEIGHT + 2.0F) * this.fontScaleValue.getValue()),
                              -1610612736
                           );
                        }

                        this.drawScaledCenteredString(
                           var62, var56 + (var33 - var56) / 2.0, var35 + 1.0, (double)this.fontScaleValue.getValue().floatValue(), -1
                        );
                        var62 = var38.getHeldItem(EnumHand.OFF_HAND).getDisplayName();
                        float var64 = 7.5F;
                        if (this.tagsBGValue.getValue()) {
                           newDrawRect(
                              var56
                                 + (var33 - var56) / 2.0
                                 - (double)(((float)mc.fontRenderer.getStringWidth(var62) / 2.0F + 2.0F) * this.fontScaleValue.getValue()),
                              var35 + (double)var64 - (double)(2.0F * this.fontScaleValue.getValue()),
                              var56
                                 + (var33 - var56) / 2.0
                                 + (double)(((float)mc.fontRenderer.getStringWidth(var62) / 2.0F + 2.0F) * this.fontScaleValue.getValue()),
                              var35 + (double)var64 + (double)(((float)mc.fontRenderer.FONT_HEIGHT + 2.0F) * this.fontScaleValue.getValue()),
                              -1610612736
                           );
                        }

                        this.drawScaledCenteredString(
                           var62, var56 + (var33 - var56) / 2.0, var35 + (double)var64, (double)this.fontScaleValue.getValue().floatValue(), -1
                        );
                        boolean var76 = false;
                     } else {
                        this.renderItemStack(var38.getHeldItemMainhand(), var56, var35);
                        ItemStack var82 = var38.getHeldItemOffhand();
                        float var87;
                        if (var38.getHeldItemMainhand().getItem() == Items.AIR) {
                           var87 = 0.0F;
                           boolean var90 = false;
                        } else {
                           var87 = 8.0F;
                        }

                        this.renderItemStack(var82, var56 + (double)var87, var35);
                     }
                  }
               }
            }
         }

         boolean var78 = false;
      }

      GL11.glPopMatrix();
      GlStateManager.enableBlend();
      GlStateManager.resetColor();
      var9.setupOverlayRendering();
   }

   public static void color(double var0, double var2, double var4, double var6) {
      GL11.glColor4d(var0, var2, var4, var6);
   }

   public static void render(int var0, Runnable var1) {
      GL11.glBegin(var0);
      var1.run();
      GL11.glEnd();
   }

   public static boolean isInViewFrustrum(Entity var0) {
      boolean var10000;
      if (!isInViewFrustrum(var0.getEntityBoundingBox()) && !var0.ignoreFrustumCheck) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Boolean var1) {
      return this.healthBar.isOpen();
   }

   public static void glColor(int var0) {
      float var1 = (float)(var0 >> 24 & 0xFF) / 255.0F;
      float var2 = (float)(var0 >> 16 & 0xFF) / 255.0F;
      float var3 = (float)(var0 >> 8 & 0xFF) / 255.0F;
      float var4 = (float)(var0 & 0xFF) / 255.0F;
      GlStateManager.color(var2, var3, var4, var1);
   }

   private boolean lambda$new$1(ESP2D.Mode5 var1) {
      return this.outline.isOpen();
   }

   private void collectEntities() {
      collectedEntities.clear();
      List var1 = mc.world.loadedEntityList;
      int var2 = 0;

      for(int var3 = var1.size(); var2 < var3; ++var2) {
         Entity var4 = (Entity)var1.get(var2);
         if (this.isSelected(var4, false)
            || this.localPlayer.getValue() && var4 instanceof EntityPlayerSP && mc.gameSettings.thirdPersonView != 0
            || this.droppedItems.getValue() && var4 instanceof EntityItem) {
            collectedEntities.add(var4);
            boolean var10000 = false;
         }

         boolean var5 = false;
      }
   }

   private Vector3d project2D(int var1, double var2, double var4, double var6) {
      GL11.glGetFloat(2982, this.modelview);
      GL11.glGetFloat(2983, this.projection);
      GL11.glGetInteger(2978, this.viewport);
      Vector3d var10000;
      if (GLU.gluProject((float)var2, (float)var4, (float)var6, this.modelview, this.projection, this.viewport, this.vector)) {
         var10000 = new Vector3d(
            (double)(this.vector.get(0) / (float)var1), (double)(((float)Display.getHeight() - this.vector.get(1)) / (float)var1), (double)this.vector.get(2)
         );
         boolean var10001 = false;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   private boolean lambda$new$5(Integer var1) {
      boolean var10000;
      if (this.colorModeValue.getValue() != ESP2D.Mode5.Custom && this.outline.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public ESP2D() {
      super("ESP2D", "fixed", Category.RENDER);
      this.outline = this.add(new Setting<>("Outline", true).setParent());
      this.boxMode = this.add(new Setting<>("Mode", ESP2D.Mode.Corners, this::lambda$new$0));
      this.colorModeValue = this.add(new Setting<>("ColorMode", ESP2D.Mode5.Custom, this::lambda$new$1));
      this.color = this.add(new Setting<>("Color", new Color(200, 200, 200), this::lambda$new$2));
      this.saturationValue = this.add(new Setting<>("Saturation", 1.0F, 0.0F, 1.0F, this::lambda$new$3));
      this.brightnessValue = this.add(new Setting<>("Brightness", 1.0F, 0.0F, 1.0F, this::lambda$new$4));
      this.mixerSecondsValue = this.add(new Setting<>("Seconds", 2, 1, 10, this::lambda$new$5));
      this.outlineFont = this.add(new Setting<>("OutlineFont", true));
      this.healthBar = this.add(new Setting<>("Health-bar", true).setParent());
      this.hpBarMode = this.add(new Setting<>("HBar-Mode", ESP2D.Mode2.Dot, this::lambda$new$6));
      this.healthNumber = this.add(new Setting<>("Health-Number", true, this::lambda$new$7).setParent());
      this.hpMode = this.add(new Setting<>("HP-Mode", ESP2D.Mode4.Health, this::lambda$new$8));
      this.hoverValue = this.add(new Setting<>("Details-HoverOnly", false));
      this.itemTagsValue = this.add(new Setting<>("ItemTags", true).setParent());
      this.itemValue = this.add(new Setting<>("Item", true, this::lambda$new$9));
      this.tagsValue = this.add(new Setting<>("Tags", true));
      this.tagsBGValue = this.add(new Setting<>("Tags-Background", true, this::lambda$new$10));
      this.clearNameValue = this.add(new Setting<>("Use-Clear-Name", false, this::lambda$new$11));
      this.armorBar = this.add(new Setting<>("ArmorBar", true));
      this.armorItems = this.add(new Setting<>("ArmorItems", true).setParent());
      this.armorDur = this.add(new Setting<>("ArmorDur", true, this::lambda$new$12));
      this.friendColor = this.add(new Setting<>("FriendColor", true));
      this.localPlayer = this.add(new Setting<>("Local-Player", true));
      this.mobs = this.add(new Setting<>("Mobs", false));
      this.animals = this.add(new Setting<>("Animasl", false));
      this.droppedItems = this.add(new Setting<>("Dropped-Items", false));
      this.fontScaleValue = this.add(new Setting<>("Font-Scale", 0.5F, 0.0F, 1.0F));
      this.dFormat = new DecimalFormat("0.0");
      this.viewport = GLAllocation.createDirectIntBuffer(16);
      this.modelview = GLAllocation.createDirectFloatBuffer(16);
      this.projection = GLAllocation.createDirectFloatBuffer(16);
      this.vector = GLAllocation.createDirectFloatBuffer(4);
      this.backgroundColor = new Color(0, 0, 0, 120).getRGB();
      this.black = Color.BLACK.getRGB();
      INSTANCE = this;
   }

   public static double interpolate(double var0, double var2, double var4) {
      return var2 + (var0 - var2) * var4;
   }

   private boolean lambda$new$6(ESP2D.Mode2 var1) {
      return this.healthBar.isOpen();
   }

   private void drawScaledCenteredString(String var1, double var2, double var4, double var6, int var8) {
      this.drawScaledString(var1, var2 - (double)((float)mc.fontRenderer.getStringWidth(var1) / 2.0F) * var6, var4, var6, var8);
   }

   public void drawOutlineStringWithoutGL(String var1, float var2, float var3, int var4, FontRenderer var5) {
      var5.drawString(stripColor(var1), (int)(var2 * 2.0F - 1.0F), (int)(var3 * 2.0F), Color.BLACK.getRGB());
      boolean var10000 = false;
      var5.drawString(stripColor(var1), (int)(var2 * 2.0F + 1.0F), (int)(var3 * 2.0F), Color.BLACK.getRGB());
      var10000 = false;
      var5.drawString(stripColor(var1), (int)(var2 * 2.0F), (int)(var3 * 2.0F - 1.0F), Color.BLACK.getRGB());
      var10000 = false;
      var5.drawString(stripColor(var1), (int)(var2 * 2.0F), (int)(var3 * 2.0F + 1.0F), Color.BLACK.getRGB());
      var10000 = false;
      var5.drawString(var1, (int)(var2 * 2.0F), (int)(var3 * 2.0F), var4);
      var10000 = false;
   }

   static {
      for(int var0 = 0; var0 < DISPLAY_LISTS_2D.length; ++var0) {
         DISPLAY_LISTS_2D[var0] = GL11.glGenLists(1);
         boolean var10000 = false;
      }

      GL11.glNewList(DISPLAY_LISTS_2D[0], 4864);
      quickDrawRect(-7.0F, 2.0F, -4.0F, 3.0F);
      quickDrawRect(4.0F, 2.0F, 7.0F, 3.0F);
      quickDrawRect(-7.0F, 0.5F, -6.0F, 3.0F);
      quickDrawRect(6.0F, 0.5F, 7.0F, 3.0F);
      GL11.glEndList();
      GL11.glNewList(DISPLAY_LISTS_2D[1], 4864);
      quickDrawRect(-7.0F, 3.0F, -4.0F, 3.3F);
      quickDrawRect(4.0F, 3.0F, 7.0F, 3.3F);
      quickDrawRect(-7.3F, 0.5F, -7.0F, 3.3F);
      quickDrawRect(7.0F, 0.5F, 7.3F, 3.3F);
      GL11.glEndList();
      GL11.glNewList(DISPLAY_LISTS_2D[2], 4864);
      quickDrawRect(4.0F, -20.0F, 7.0F, -19.0F);
      quickDrawRect(-7.0F, -20.0F, -4.0F, -19.0F);
      quickDrawRect(6.0F, -20.0F, 7.0F, -17.5F);
      quickDrawRect(-7.0F, -20.0F, -6.0F, -17.5F);
      GL11.glEndList();
      GL11.glNewList(DISPLAY_LISTS_2D[3], 4864);
      quickDrawRect(7.0F, -20.0F, 7.3F, -17.5F);
      quickDrawRect(-7.3F, -20.0F, -7.0F, -17.5F);
      quickDrawRect(4.0F, -20.3F, 7.3F, -20.0F);
      quickDrawRect(-7.3F, -20.3F, -4.0F, -20.0F);
      GL11.glEndList();
   }

   @Override
   public void onDisable() {
      collectedEntities.clear();
   }

   public static void quickDrawRect(float var0, float var1, float var2, float var3) {
      GL11.glBegin(7);
      GL11.glVertex2d((double)var2, (double)var1);
      GL11.glVertex2d((double)var0, (double)var1);
      GL11.glVertex2d((double)var0, (double)var3);
      GL11.glVertex2d((double)var2, (double)var3);
      GL11.glEnd();
   }

   public boolean isAnimal(Entity var1) {
      boolean var10000;
      if (!(var1 instanceof EntityAnimal)
         && !(var1 instanceof EntitySquid)
         && !(var1 instanceof EntityGolem)
         && !(var1 instanceof EntityVillager)
         && !(var1 instanceof EntityBat)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static void newDrawRect(double var0, double var2, double var4, double var6, int var8) {
      if (var0 < var4) {
         double var9 = var0;
         var0 = var4;
         var4 = var9;
      }

      if (var2 < var6) {
         double var15 = var2;
         var2 = var6;
         var6 = var15;
      }

      float var16 = (float)(var8 >> 24 & 0xFF) / 255.0F;
      float var10 = (float)(var8 >> 16 & 0xFF) / 255.0F;
      float var11 = (float)(var8 >> 8 & 0xFF) / 255.0F;
      float var12 = (float)(var8 & 0xFF) / 255.0F;
      Tessellator var13 = Tessellator.getInstance();
      BufferBuilder var14 = var13.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      GlStateManager.color(var10, var11, var12, var16);
      var14.begin(7, DefaultVertexFormats.POSITION);
      var14.pos(var0, var6, 0.0).endVertex();
      var14.pos(var4, var6, 0.0).endVertex();
      var14.pos(var4, var2, 0.0).endVertex();
      var14.pos(var0, var2, 0.0).endVertex();
      var13.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }

   public static Color getHealthColor(float var0, float var1) {
      float[] var2 = new float[]{0.0F, 0.5F, 1.0F};
      Color[] var3 = new Color[]{new Color(108, 0, 0), new Color(255, 51, 0), Color.GREEN};
      float var4 = var0 / var1;
      return blendColors(var2, var3, var4).brighter();
   }

   private boolean lambda$new$9(Boolean var1) {
      return this.itemTagsValue.isOpen();
   }

   private void renderItemStack(ItemStack var1, double var2, double var4) {
      GlStateManager.pushMatrix();
      GlStateManager.translate(var2, var4, var2);
      GlStateManager.scale(0.5, 0.5, 0.5);
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      RenderHelper.enableGUIStandardItemLighting();
      mc.getRenderItem().renderItemAndEffectIntoGUI(var1, 0, 0);
      mc.getRenderItem().renderItemOverlays(mc.fontRenderer, var1, 0, 0);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableBlend();
      GlStateManager.popMatrix();
   }

   public static void drawRect(double var0, double var2, double var4, double var6, int var8) {
      GL11.glEnable(3042);
      GL11.glDisable(3553);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2848);
      glColor(var8);
      GL11.glBegin(7);
      GL11.glVertex2d(var4, var2);
      GL11.glVertex2d(var0, var2);
      GL11.glVertex2d(var0, var6);
      GL11.glVertex2d(var4, var6);
      GL11.glEnd();
      GL11.glEnable(3553);
      GL11.glDisable(3042);
      GL11.glDisable(2848);
   }

   private boolean lambda$new$4(Float var1) {
      boolean var10000;
      if (this.colorModeValue.getValue() != ESP2D.Mode5.Custom && this.outline.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public Color getColor(Entity var1) {
      if (var1 instanceof EntityLivingBase && var1 instanceof EntityPlayer && this.friendColor.getValue() && Managers.FRIENDS.isFriend((EntityPlayer)var1)) {
         return Color.cyan;
      } else {
         switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$render$ESP2D$Mode5[this.colorModeValue.getValue().ordinal()]) {
            case 1:
               return this.color.getValue();
            case 2:
               return new Color(getRainbowOpaque(this.mixerSecondsValue.getValue(), this.saturationValue.getValue(), this.brightnessValue.getValue(), 0));
            case 3:
               return slowlyRainbow(System.nanoTime(), 0, this.saturationValue.getValue(), this.brightnessValue.getValue());
            default:
               return fade(this.color.getValue(), 0, 100);
         }
      }
   }

   public static Color blend(Color var0, Color var1, double var2) {
      float var4 = (float)var2;
      float var5 = 1.0F - var4;
      float[] var6 = var0.getColorComponents(new float[3]);
      float[] var7 = var1.getColorComponents(new float[3]);
      float var8 = var6[0] * var4 + var7[0] * var5;
      float var9 = var6[1] * var4 + var7[1] * var5;
      float var10 = var6[2] * var4 + var7[2] * var5;
      if (var8 < 0.0F) {
         var8 = 0.0F;
         boolean var10000 = false;
      } else if (var8 > 255.0F) {
         var8 = 255.0F;
      }

      if (var9 < 0.0F) {
         var9 = 0.0F;
         boolean var14 = false;
      } else if (var9 > 255.0F) {
         var9 = 255.0F;
      }

      if (var10 < 0.0F) {
         var10 = 0.0F;
         boolean var15 = false;
      } else if (var10 > 255.0F) {
         var10 = 255.0F;
      }

      Color var11 = null;
      Color var16 = new Color;
      Color var10001 = var16;
      float var10002 = var8;
      float var10003 = var9;
      float var10004 = var10;

      try {
         var10001./* $QF: Unable to resugar constructor */<init>(var10002, var10003, var10004);
         var11 = var16;
      } catch (IllegalArgumentException var13) {
         return var11;
      }

      boolean var17 = false;
      return var11;
   }

   private boolean lambda$new$0(ESP2D.Mode var1) {
      return this.outline.isOpen();
   }

   public static String stripColor(String var0) {
      return COLOR_PATTERN.matcher(var0).replaceAll("");
   }

   private boolean lambda$new$11(Boolean var1) {
      return this.tagsValue.isOpen();
   }

   public static Color blendColors(float[] var0, Color[] var1, float var2) {
      if (var0.length == var1.length) {
         int[] var3 = getFractionIndices(var0, var2);
         float[] var4 = new float[]{var0[var3[0]], var0[var3[1]]};
         Color[] var5 = new Color[]{var1[var3[0]], var1[var3[1]]};
         float var6 = var4[1] - var4[0];
         float var7 = var2 - var4[0];
         float var8 = var7 / var6;
         return blend(var5[0], var5[1], (double)(1.0F - var8));
      } else {
         throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
      }
   }

   public boolean isSelected(Entity var1, boolean var2) {
      if (!(var1 instanceof EntityLivingBase) || !var1.isEntityAlive() || var1 == mc.player) {
         return false;
      } else if (!(var1 instanceof EntityPlayer)) {
         boolean var3;
         if ((!this.isMob(var1) || !this.mobs.getValue()) && (!this.isAnimal(var1) || !this.animals.getValue())) {
            var3 = false;
         } else {
            var3 = true;
            boolean var4 = false;
         }

         return var3;
      } else if (!var2) {
         return true;
      } else if (Managers.FRIENDS.isFriend((EntityPlayer)var1)) {
         return false;
      } else if (((EntityPlayer)var1).isSpectator()) {
         return false;
      } else {
         boolean var10000;
         if (!((EntityPlayer)var1).isPlayerSleeping()) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private boolean isHovering(double var1, double var3, double var5, double var7, ScaledResolution var9) {
      boolean var10000;
      if ((double)var9.getScaledWidth() / 2.0 >= var1
         && (double)var9.getScaledWidth() / 2.0 < var3
         && (double)var9.getScaledHeight() / 2.0 >= var5
         && (double)var9.getScaledHeight() / 2.0 < var7) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static void color(Color var0) {
      if (var0 == null) {
         var0 = Color.white;
      }

      color(
         (double)((float)var0.getRed() / 255.0F),
         (double)((float)var0.getGreen() / 255.0F),
         (double)((float)var0.getBlue() / 255.0F),
         (double)((float)var0.getAlpha() / 255.0F)
      );
   }

   public static Color fade(Color var0, int var1, int var2) {
      float[] var3 = new float[3];
      Color.RGBtoHSB(var0.getRed(), var0.getGreen(), var0.getBlue(), var3);
      boolean var10000 = false;
      float var4 = Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0F + (float)var1 / (float)var2 * 2.0F) % 2.0F - 1.0F);
      var4 = 0.5F + 0.5F * var4;
      var3[2] = var4 % 2.0F;
      return new Color(Color.HSBtoRGB(var3[0], var3[1], var3[2]));
   }

   private boolean lambda$new$12(Boolean var1) {
      return this.armorItems.isOpen();
   }

   public static int getRainbowOpaque(int var0, float var1, float var2, int var3) {
      float var4 = (float)((System.currentTimeMillis() + (long)var3) % (long)(var0 * 1000)) / (float)(var0 * 1000);
      return Color.HSBtoRGB(var4, var1, var2);
   }

   private boolean lambda$new$10(Boolean var1) {
      boolean var10000;
      if (!this.tagsValue.getValue() && !this.itemTagsValue.getValue()) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static enum Mode {
      Box,
      Corners;
      private static final ESP2D.Mode[] $VALUES = new ESP2D.Mode[]{ESP2D.Mode.Box, ESP2D.Mode.Corners};
   }

   public static enum Mode2 {
      Line,
      Dot;
      private static final ESP2D.Mode2[] $VALUES = new ESP2D.Mode2[]{ESP2D.Mode2.Dot, ESP2D.Mode2.Line};
   }

   public static enum Mode4 {
      Health,
      Percent;
      private static final ESP2D.Mode4[] $VALUES = new ESP2D.Mode4[]{Health, ESP2D.Mode4.Percent};
   }

   public static enum Mode5 {
      Slowly,
      AnotherRainbow,
      Custom;
      private static final ESP2D.Mode5[] $VALUES = new ESP2D.Mode5[]{ESP2D.Mode5.Custom, Slowly, ESP2D.Mode5.AnotherRainbow};
   }
}
