package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderPlayerEvent.Pre;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Chams extends Module {
   public final Setting<Chams.Model> model;
   public final Setting<Boolean> sneak;
   public final Setting<Color> modelColor;
   public final Setting<Boolean> self;
   public final Setting<Boolean> noInterp;
   public final Setting<Color> color;
   public final Setting<Boolean> glint;
   public final Setting<Boolean> wireframe;
   private final Setting<Chams.Page> page = this.add(new Setting<>("Settings", Chams.Page.GLOBAL));
   public static Chams INSTANCE;
   public final Setting<Boolean> xqz;
   private final Setting<Float> range;
   public final Setting<Color> lineColor;
   public final Setting<Boolean> fill = this.add(new Setting<>("Fill", true, this::lambda$new$0).setParent());
   public final Setting<Float> lineWidth;
   private final Setting<Boolean> hide;

   private boolean lambda$new$12(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Color var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public Chams() {
      super("Chams", "Draws a pretty ESP around other players", Category.RENDER);
      this.xqz = this.add(new Setting<>("XQZ", true, this::lambda$new$1));
      this.wireframe = this.add(new Setting<>("Wireframe", true, this::lambda$new$2));
      this.model = this.add(new Setting<>("Model", Chams.Model.XQZ, this::lambda$new$3));
      this.self = this.add(new Setting<>("Self", true, this::lambda$new$4));
      this.noInterp = this.add(new Setting<>("NoInterp", false, this::lambda$new$5));
      this.sneak = this.add(new Setting<>("Sneak", false, this::lambda$new$6));
      this.glint = this.add(new Setting<>("Glint", false, this::lambda$new$7));
      this.lineWidth = this.add(new Setting<>("LineWidth", 1.0F, 0.1F, 3.0F, this::lambda$new$8));
      this.color = this.add(new Setting<>("Color", new Color(132, 132, 241, 150), this::lambda$new$9));
      this.lineColor = this.add(new Setting<>("LineColor", new Color(255, 255, 255), this::lambda$new$10).injectBoolean(false));
      this.modelColor = this.add(new Setting<>("ModelColor", new Color(125, 125, 213, 150), this::lambda$new$11).injectBoolean(false));
      this.hide = this.add(new Setting<>("Hide", false, this::lambda$new$12).setParent());
      this.range = this.add(new Setting<>("Range", 1.5F, 1.0F, 12.0F, this::lambda$new$13));
      INSTANCE = this;
   }

   @Override
   public String getInfo() {
      String var1 = null;
      if (this.fill.getValue()) {
         var1 = "Fill";
         boolean var10000 = false;
      } else if (this.wireframe.getValue()) {
         var1 = "Wireframe";
      }

      if (this.wireframe.getValue() && this.fill.getValue()) {
         var1 = "Both";
      }

      return var1;
   }

   private boolean lambda$new$3(Chams.Model var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Color var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Color var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onRenderPlayerEvent(Pre var1) {
      var1.getEntityPlayer().hurtTime = 0;
   }

   private boolean lambda$new$8(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL && this.fill.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(Float var1) {
      boolean var10000;
      if (this.hide.isOpen() && this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onRenderLiving(net.minecraftforge.client.event.RenderLivingEvent.Pre<EntityLivingBase> var1) {
      if (var1.getEntity() instanceof EntityPlayer && var1.getEntity() != mc.player && this.hide.getValue()) {
         double var2 = (double)var1.getEntity().getDistance(mc.player);
         if (var2 < (double)this.range.getValue().floatValue()) {
            var1.setCanceled(true);
         }
      }
   }

   private boolean lambda$new$5(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Chams.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Model {
      VANILLA,
      OFF,
      XQZ;

      private static final Chams.Model[] $VALUES = new Chams.Model[]{XQZ, VANILLA, OFF};
   }

   public static enum Page {
      GLOBAL,
      COLORS;

      private static final Chams.Page[] $VALUES = new Chams.Page[]{COLORS, GLOBAL};
   }
}
