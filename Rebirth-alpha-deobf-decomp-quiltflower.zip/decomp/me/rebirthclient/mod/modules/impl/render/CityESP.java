package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class CityESP extends Module {
   private final Setting<Boolean> onlyBurrow = this.add(new Setting<>("OnlyBurrow", false));
   private final Setting<Boolean> outline = this.add(new Setting<>("Outline", true).setParent());
   private final Setting<Boolean> box;
   private final Setting<Integer> boxAlpha;
   private final Setting<Color> canAttackColor;
   private final Setting<Color> burrowColor;
   private final List<BlockPos> burrowPos;
   private final Setting<Float> range;
   private final Setting<Color> breakColor;
   private final Setting<Integer> outlineAlpha = this.add(new Setting<>("OutlineAlpha", 150, 0, 255, this::lambda$new$0));

   private void drawBurrow(BlockPos var1) {
      if (!this.burrowPos.contains(var1)) {
         this.burrowPos.add(var1);
         boolean var10000 = false;
         if (this.getBlock(var1).getBlock() != Blocks.AIR && this.getBlock(var1).getBlock() != Blocks.BEDROCK) {
            AxisAlignedBB var2 = mc.world.getBlockState(new BlockPos(var1)).getSelectedBoundingBox(mc.world, new BlockPos(var1));
            if (this.box.getValue()) {
               RenderUtil.drawBBFill(var2, this.burrowColor.getValue(), this.boxAlpha.getValue());
            }

            if (this.outline.getValue()) {
               RenderUtil.drawBBBox(var2, this.burrowColor.getValue(), this.outlineAlpha.getValue());
            }
         }
      }
   }

   private void doRender(EntityPlayer var1) {
      BlockPos var2 = EntityUtil.getEntityPos(var1);
      this.drawBurrow(new BlockPos(var1.posX + 0.1, var1.posY + 0.5, var1.posZ + 0.1));
      this.drawBurrow(new BlockPos(var1.posX - 0.1, var1.posY + 0.5, var1.posZ + 0.1));
      this.drawBurrow(new BlockPos(var1.posX + 0.1, var1.posY + 0.5, var1.posZ - 0.1));
      this.drawBurrow(new BlockPos(var1.posX - 0.1, var1.posY + 0.5, var1.posZ - 0.1));
      if (!this.onlyBurrow.getValue()) {
         if (this.getBlock(var2.add(-1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(var2.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK) {
            if (this.getBlock(var2.add(-2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(var2.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
               this.drawBlock(var2, -1.0, 0.0, 0.0, true);
               boolean var10000 = false;
            } else if (this.getBlock(var2.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(var2.add(-2, 1, 0)).getBlock() != Blocks.BEDROCK) {
               this.drawBlock(var2, -1.0, 0.0, 0.0, false);
            }
         }

         if (this.getBlock(var2.add(1, 0, 0)).getBlock() != Blocks.AIR && this.getBlock(var2.add(1, 0, 0)).getBlock() != Blocks.BEDROCK) {
            if (this.getBlock(var2.add(2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(var2.add(2, 1, 0)).getBlock() == Blocks.AIR) {
               this.drawBlock(var2, 1.0, 0.0, 0.0, true);
               boolean var3 = false;
            } else if (this.getBlock(var2.add(2, 0, 0)).getBlock() != Blocks.BEDROCK && this.getBlock(var2.add(2, 1, 0)).getBlock() != Blocks.BEDROCK) {
               this.drawBlock(var2, 1.0, 0.0, 0.0, false);
            }
         }

         if (this.getBlock(var2.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(-2, 1, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(-2, 0, 0)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK) {
            boolean var10005;
            if (this.getBlock(var2.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(var2.add(-2, 1, 0)).getBlock() == Blocks.AIR) {
               var10005 = true;
               boolean var10006 = false;
            } else {
               var10005 = false;
            }

            this.drawBlock(var2, -2.0, 0.0, 0.0, var10005);
         }

         if (this.getBlock(var2.add(-1, 0, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(-2, 0, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(-2, 1, 0)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(-2, 1, 0)).getBlock() != Blocks.BEDROCK) {
            boolean var6;
            if (this.getBlock(var2.add(-1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(var2.add(-2, 0, 0)).getBlock() == Blocks.AIR) {
               var6 = true;
               boolean var13 = false;
            } else {
               var6 = false;
            }

            this.drawBlock(var2, -2.0, 1.0, 0.0, var6);
         }

         if (this.getBlock(var2.add(1, 0, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(2, 1, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(2, 0, 0)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(2, 0, 0)).getBlock() != Blocks.BEDROCK) {
            boolean var7;
            if (this.getBlock(var2.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(var2.add(2, 1, 0)).getBlock() == Blocks.AIR) {
               var7 = true;
               boolean var14 = false;
            } else {
               var7 = false;
            }

            this.drawBlock(var2, 2.0, 0.0, 0.0, var7);
         }

         if (this.getBlock(var2.add(1, 0, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(2, 0, 0)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(2, 1, 0)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(2, 1, 0)).getBlock() != Blocks.BEDROCK) {
            boolean var8;
            if (this.getBlock(var2.add(1, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(var2.add(2, 0, 0)).getBlock() == Blocks.AIR) {
               var8 = true;
               boolean var15 = false;
            } else {
               var8 = false;
            }

            this.drawBlock(var2, 2.0, 1.0, 0.0, var8);
         }

         if (this.getBlock(var2.add(0, 0, 1)).getBlock() != Blocks.AIR && this.getBlock(var2.add(0, 0, 1)).getBlock() != Blocks.BEDROCK) {
            if (this.getBlock(var2.add(0, 0, 2)).getBlock() == Blocks.AIR && this.getBlock(var2.add(0, 1, 2)).getBlock() == Blocks.AIR) {
               this.drawBlock(var2, 0.0, 0.0, 1.0, true);
               boolean var4 = false;
            } else if (this.getBlock(var2.add(0, 0, 2)).getBlock() != Blocks.BEDROCK && this.getBlock(var2.add(0, 1, 2)).getBlock() != Blocks.BEDROCK) {
               this.drawBlock(var2, 0.0, 0.0, 1.0, false);
            }
         }

         if (this.getBlock(var2.add(0, 0, -1)).getBlock() != Blocks.AIR && this.getBlock(var2.add(0, 0, -1)).getBlock() != Blocks.BEDROCK) {
            if (this.getBlock(var2.add(0, 0, -2)).getBlock() == Blocks.AIR && this.getBlock(var2.add(0, 1, -2)).getBlock() == Blocks.AIR) {
               this.drawBlock(var2, 0.0, 0.0, -1.0, true);
               boolean var5 = false;
            } else if (this.getBlock(var2.add(0, 0, -2)).getBlock() != Blocks.BEDROCK && this.getBlock(var2.add(0, 1, -2)).getBlock() != Blocks.BEDROCK) {
               this.drawBlock(var2, 0.0, 0.0, -1.0, false);
            }
         }

         if (this.getBlock(var2.add(0, 0, 1)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 1, 2)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 0, 2)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(0, 0, 2)).getBlock() != Blocks.BEDROCK) {
            boolean var9;
            if (this.getBlock(var2.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(var2.add(0, 1, 2)).getBlock() == Blocks.AIR) {
               var9 = true;
               boolean var16 = false;
            } else {
               var9 = false;
            }

            this.drawBlock(var2, 0.0, 0.0, 2.0, var9);
         }

         if (this.getBlock(var2.add(0, 0, 1)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 0, 2)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 1, 2)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(0, 1, 2)).getBlock() != Blocks.BEDROCK) {
            boolean var10;
            if (this.getBlock(var2.add(0, 0, 1)).getBlock() == Blocks.AIR && this.getBlock(var2.add(0, 0, 2)).getBlock() == Blocks.AIR) {
               var10 = true;
               boolean var17 = false;
            } else {
               var10 = false;
            }

            this.drawBlock(var2, 0.0, 1.0, 2.0, var10);
         }

         if (this.getBlock(var2.add(0, 0, -1)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 1, -2)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 0, -2)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(0, 0, -2)).getBlock() != Blocks.BEDROCK) {
            boolean var11;
            if (this.getBlock(var2.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(var2.add(0, 1, -2)).getBlock() == Blocks.AIR) {
               var11 = true;
               boolean var18 = false;
            } else {
               var11 = false;
            }

            this.drawBlock(var2, 0.0, 0.0, -2.0, var11);
         }

         if (this.getBlock(var2.add(0, 0, -1)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 0, -2)).getBlock() != Blocks.BEDROCK
            && this.getBlock(var2.add(0, 1, -2)).getBlock() != Blocks.AIR
            && this.getBlock(var2.add(0, 1, -2)).getBlock() != Blocks.BEDROCK) {
            boolean var12;
            if (this.getBlock(var2.add(0, 0, -1)).getBlock() == Blocks.AIR && this.getBlock(var2.add(0, 0, -2)).getBlock() == Blocks.AIR) {
               var12 = true;
               boolean var19 = false;
            } else {
               var12 = false;
            }

            this.drawBlock(var2, 0.0, 1.0, -2.0, var12);
         }
      }
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      this.burrowPos.clear();

      for(EntityPlayer var3 : mc.world.playerEntities) {
         if (EntityUtil.invalid(var3, (double)this.range.getValue().floatValue())) {
            boolean var10000 = false;
         } else {
            this.doRender(var3);
            boolean var4 = false;
         }
      }
   }

   private void drawBlock(BlockPos var1, double var2, double var4, double var6, boolean var8) {
      var1 = var1.add(var2, var4, var6);
      if (mc.world.getBlockState(var1).getBlock() != Blocks.AIR) {
         if (mc.world.getBlockState(var1).getBlock() != Blocks.FIRE) {
            AxisAlignedBB var9 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            if (var8) {
               if (this.outline.getValue()) {
                  RenderUtil.drawBBBox(var9, this.canAttackColor.getValue(), this.outlineAlpha.getValue());
               }

               if (this.box.getValue()) {
                  RenderUtil.drawBBFill(var9, this.canAttackColor.getValue(), this.boxAlpha.getValue());
               }
            } else {
               if (this.outline.getValue()) {
                  RenderUtil.drawBBBox(var9, this.breakColor.getValue(), this.outlineAlpha.getValue());
               }

               if (this.box.getValue()) {
                  RenderUtil.drawBBFill(var9, this.breakColor.getValue(), this.boxAlpha.getValue());
               }
            }
         }
      }
   }

   private boolean lambda$new$1(Integer var1) {
      return this.box.isOpen();
   }

   private boolean lambda$new$0(Integer var1) {
      return this.outline.isOpen();
   }

   public CityESP() {
      super("CityESP", "CityESP", Category.RENDER);
      this.box = this.add(new Setting<>("Box", true).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 70, 0, 255, this::lambda$new$1));
      this.range = this.add(new Setting<>("Range", 7.0F, 1.0F, 12.0F));
      this.canAttackColor = this.add(new Setting<>("AttackColor", new Color(255, 147, 147)).hideAlpha());
      this.breakColor = this.add(new Setting<>("Color", new Color(118, 118, 255)).hideAlpha());
      this.burrowColor = this.add(new Setting<>("BurrowColor", new Color(255, 255, 255)).hideAlpha());
      this.burrowPos = new ArrayList();
   }

   private IBlockState getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1);
   }
}
