package me.rebirthclient.mod.modules.impl.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.rebirthclient.api.events.impl.ConnectionEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InterpolationUtil;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.api.util.render.entity.StaticModelPlayer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.client.FontMod;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class LogOutSpots extends Module {
   private final Setting<Boolean> outline;
   private final Setting<Boolean> rect;
   private final Setting<Color> lineColor;
   private final Setting<Boolean> coords;
   static final boolean $assertionsDisabled;
   private final Setting<Boolean> chams;
   private final Setting<Color> color;
   private final Setting<Float> range;
   private final Setting<Boolean> box;
   private final Setting<Boolean> text;
   private final Setting<Color> fillColor;
   protected final Map<UUID, LogOutSpots.LogOutSpot> spots = new ConcurrentHashMap<>();
   private final Setting<Boolean> time;
   final Date date = new Date();

   private boolean lambda$new$0(Color var1) {
      return this.chams.isOpen();
   }

   private String getLogOutTime() {
      SimpleDateFormat var1 = new SimpleDateFormat("HH:mm:ss");
      return var1.format(this.date);
   }

   @Override
   public void onDisable() {
      this.spots.clear();
   }

   public LogOutSpots() {
      super("LogOutSpots", "Displays logout spots for players", Category.RENDER);
      this.text = this.add(new Setting<>("Text", true));
      this.range = this.add(new Setting<>("Range", 150.0F, 50.0F, 500.0F));
      this.rect = this.add(new Setting<>("Rectangle", true));
      this.outline = this.add(new Setting<>("Outline", true));
      this.time = this.add(new Setting<>("Time", true));
      this.coords = this.add(new Setting<>("Coords", true));
      this.box = this.add(new Setting<>("Box", true));
      this.color = this.add(new Setting<>("Color", new Color(-1766449377, true)));
      this.chams = this.add(new Setting<>("Chams", true).setParent());
      this.fillColor = this.add(new Setting<>("ChamsColor", new Color(190, 0, 0, 100), this::lambda$new$0));
      this.lineColor = this.add(new Setting<>("LineColor", new Color(255, 255, 255, 120), this::lambda$new$1).injectBoolean(false));
   }

   private void drawNameTag(String var1, double var2, double var4, double var6, double var8, double var10, double var12) {
      var4 += 0.7;
      Entity var14 = mc.getRenderViewEntity();
      if (!$assertionsDisabled && var14 == null) {
         throw new AssertionError();
      } else {
         double var15 = var14.posX;
         double var17 = var14.posY;
         double var19 = var14.posZ;
         var14.posX = InterpolationUtil.getInterpolatedDouble(var14.prevPosX, var14.posX, mc.getRenderPartialTicks());
         var14.posY = InterpolationUtil.getInterpolatedDouble(var14.prevPosY, var14.posY, mc.getRenderPartialTicks());
         var14.posZ = InterpolationUtil.getInterpolatedDouble(var14.prevPosZ, var14.posZ, mc.getRenderPartialTicks());
         StringBuilder var10000 = new StringBuilder().append(var1);
         String var10001;
         if (this.coords.getValue()) {
            var10001 = String.valueOf(new StringBuilder().append(" XYZ: ").append((int)var8).append(", ").append((int)var10).append(", ").append((int)var12));
            boolean var10002 = false;
         } else {
            var10001 = "";
         }

         var10000 = var10000.append(var10001);
         if (this.time.getValue()) {
            var10001 = String.valueOf(new StringBuilder().append(" ").append(ChatFormatting.GRAY).append("(").append(this.getLogOutTime()).append(")"));
            boolean var33 = false;
         } else {
            var10001 = "";
         }

         String var21 = String.valueOf(var10000.append(var10001));
         double var22 = var14.getDistance(
            var2 + mc.getRenderManager().viewerPosX, var4 + mc.getRenderManager().viewerPosY, var6 + mc.getRenderManager().viewerPosZ
         );
         int var24 = Managers.TEXT.getStringWidth(var21) / 2;
         double var25 = (0.0018 + 5.0 * var22 * 0.6F) / 1000.0;
         if (var22 <= 8.0) {
            var25 = 0.0245;
         }

         GlStateManager.pushMatrix();
         RenderHelper.enableStandardItemLighting();
         GlStateManager.enablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
         GlStateManager.disableLighting();
         GlStateManager.translate((float)var2, (float)var4 + 1.4F, (float)var6);
         GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
         float var29 = mc.getRenderManager().playerViewX;
         float var32;
         if (mc.gameSettings.thirdPersonView == 2) {
            var32 = -1.0F;
            boolean var34 = false;
         } else {
            var32 = 1.0F;
         }

         GlStateManager.rotate(var29, var32, 0.0F, 0.0F);
         GlStateManager.scale(-var25, -var25, var25);
         GlStateManager.disableDepth();
         GlStateManager.enableBlend();
         GlStateManager.enableBlend();
         if (this.rect.getValue()) {
            RenderUtil.drawRect((float)(-var24 - 2), (float)(-(mc.fontRenderer.FONT_HEIGHT + 1)), (float)var24 + 2.0F, 1.5F, 1426063360);
         }

         if (this.outline.getValue()) {
            RenderUtil.drawNameTagOutline(
               (float)(-var24 - 2),
               (float)(-(mc.fontRenderer.FONT_HEIGHT + 1)),
               (float)var24 + 2.0F,
               1.5F,
               0.8F,
               this.color.getValue().getRGB(),
               this.color.getValue().darker().getRGB(),
               false
            );
         }

         GlStateManager.disableBlend();
         TextManager var30 = Managers.TEXT;
         float var35 = (float)(-var24);
         float var10003;
         if (FontMod.INSTANCE.isOn()) {
            var10003 = (float)(-(mc.fontRenderer.FONT_HEIGHT + 1));
            boolean var10004 = false;
         } else {
            var10003 = (float)(-(mc.fontRenderer.FONT_HEIGHT - 1));
         }

         var30.drawMCString(var21, var35, var10003, this.color.getValue().getRGB(), true);
         var14.posX = var15;
         var14.posY = var17;
         var14.posZ = var19;
         GlStateManager.enableDepth();
         GlStateManager.disableBlend();
         GlStateManager.disablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
         GlStateManager.popMatrix();
      }
   }

   static {
      boolean var10000;
      if (!LogOutSpots.class.desiredAssertionStatus()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      $assertionsDisabled = var10000;
   }

   private boolean lambda$new$1(Color var1) {
      return this.chams.isOpen();
   }

   @Override
   public void onTick() {
      for(LogOutSpots.LogOutSpot var2 : this.spots.values()) {
         if (mc.player.getDistanceSq(var2.getPlayer()) >= (double)this.range.getValue().floatValue()) {
            this.spots.remove(var2.getPlayer().getUniqueID());
            boolean var10000 = false;
         }

         boolean var3 = false;
      }
   }

   @Override
   public void onLogout() {
      this.spots.clear();
   }

   @SubscribeEvent
   public void onConnection(ConnectionEvent var1) {
      if (mc.world.getPlayerEntityByUUID(var1.getUuid()) == null
         || !Integer.valueOf("§a§l[赞助本服]".hashCode()).equals(mc.world.getPlayerEntityByUUID(var1.getUuid()).getName().hashCode())) {
         if (var1.getStage() == 0) {
            UUID var2 = var1.getUuid();
            EntityPlayer var3 = mc.world.getPlayerEntityByUUID(var2);
            if (var3 != null && this.text.getValue()) {
               StringBuilder var10001 = new StringBuilder().append("§a").append(var3.getName()).append(" just logged in");
               String var10002;
               if (this.coords.getValue()) {
                  var10002 = String.valueOf(
                     new StringBuilder()
                        .append(" at (")
                        .append((int)var3.posX)
                        .append(", ")
                        .append((int)var3.posY)
                        .append(", ")
                        .append((int)var3.posZ)
                        .append(")!")
                  );
                  boolean var10003 = false;
               } else {
                  var10002 = "!";
               }

               this.sendMessage(String.valueOf(var10001.append(var10002)));
            }

            this.spots.remove(var1.getUuid());
            boolean var10000 = false;
            var10000 = false;
         } else if (var1.getStage() == 1) {
            EntityPlayer var4 = var1.getPlayer();
            if (var4 == null || this.spots.containsKey(var4.getUniqueID())) {
               return;
            }

            if (this.text.getValue()) {
               StringBuilder var8 = new StringBuilder().append("§c").append(var1.getName()).append(" just logged out");
               String var9;
               if (this.coords.getValue()) {
                  var9 = String.valueOf(
                     new StringBuilder()
                        .append(" at (")
                        .append((int)var4.posX)
                        .append(", ")
                        .append((int)var4.posY)
                        .append(", ")
                        .append((int)var4.posZ)
                        .append(")!")
                  );
                  boolean var10 = false;
               } else {
                  var9 = "!";
               }

               this.sendMessage(String.valueOf(var8.append(var9)));
            }

            LogOutSpots.LogOutSpot var5 = new LogOutSpots.LogOutSpot(var4);
            this.spots.put(var4.getUniqueID(), var5);
            boolean var7 = false;
         }
      }
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      for(LogOutSpots.LogOutSpot var3 : this.spots.values()) {
         AxisAlignedBB var4 = InterpolationUtil.getInterpolatedAxis(var3.getBoundingBox());
         if (this.chams.getValue()) {
            StaticModelPlayer var5 = var3.getModel();
            double var6 = var3.getX() - mc.getRenderManager().viewerPosX;
            double var8 = var3.getY() - mc.getRenderManager().viewerPosY;
            double var10 = var3.getZ() - mc.getRenderManager().viewerPosZ;
            GL11.glPushMatrix();
            GL11.glPushAttrib(1048575);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glEnable(2848);
            GL11.glEnable(3042);
            GlStateManager.blendFunc(770, 771);
            GlStateManager.translate(var6, var8, var10);
            GlStateManager.rotate(180.0F - var5.getYaw(), 0.0F, 1.0F, 0.0F);
            GlStateManager.enableRescaleNormal();
            GlStateManager.scale(-1.0F, -1.0F, 1.0F);
            double var12 = var4.maxX - var4.minX + 1.0;
            double var14 = var4.maxZ - var4.minZ + 1.0;
            GlStateManager.scale(var12, var4.maxY - var4.minY, var14);
            GlStateManager.translate(0.0F, -1.501F, 0.0F);
            Color var16 = this.fillColor.getValue();
            Color var10000;
            if (this.lineColor.booleanValue) {
               var10000 = this.lineColor.getValue();
               boolean var10001 = false;
            } else {
               var10000 = this.fillColor.getValue();
            }

            Color var17 = var10000;
            RenderUtil.glColor(var16);
            GL11.glPolygonMode(1032, 6914);
            var5.render(0.0625F);
            RenderUtil.glColor(var17);
            GL11.glLineWidth(1.0F);
            GL11.glPolygonMode(1032, 6913);
            var5.render(0.0625F);
            GL11.glPopAttrib();
            GL11.glPopMatrix();
         }

         if (this.box.getValue()) {
            RenderUtil.drawBlockOutline(var4, this.color.getValue(), 1.0F, false);
         }

         double var18 = InterpolationUtil.getInterpolatedDouble(var3.getPlayer().lastTickPosX, var3.getPlayer().posX, var1.getPartialTicks())
            - mc.getRenderManager().renderPosX;
         double var7 = InterpolationUtil.getInterpolatedDouble(var3.getPlayer().lastTickPosY, var3.getPlayer().posY, var1.getPartialTicks())
            - mc.getRenderManager().renderPosY;
         double var9 = InterpolationUtil.getInterpolatedDouble(var3.getPlayer().lastTickPosZ, var3.getPlayer().posZ, var1.getPartialTicks())
            - mc.getRenderManager().renderPosZ;
         this.drawNameTag(var3.getName(), var18, var7, var9, var3.getX(), var3.getY(), var3.getZ());
         boolean var19 = false;
      }
   }

   @Override
   public void onEnable() {
      this.spots.clear();
   }

   protected static class LogOutSpot implements Wrapper {
      private final AxisAlignedBB boundingBox;
      private final StaticModelPlayer model;
      private final String name;
      private final double y;
      private final double z;
      private final EntityPlayer player;
      private final double x;

      public double getDistance() {
         return mc.player.getDistance(this.x, this.y, this.z);
      }

      public String getName() {
         return this.name;
      }

      public AxisAlignedBB getBoundingBox() {
         return this.boundingBox;
      }

      public StaticModelPlayer getModel() {
         return this.model;
      }

      public LogOutSpot(EntityPlayer var1) {
         this.name = var1.getName();
         StaticModelPlayer var10001 = new StaticModelPlayer;
         EntityPlayer var10003 = EntityUtil.getCopiedPlayer(var1);
         boolean var10004;
         if (var1 instanceof AbstractClientPlayer && Integer.valueOf("slim".hashCode()).equals(((AbstractClientPlayer)var1).getSkinType().hashCode())) {
            var10004 = true;
            boolean var10005 = false;
         } else {
            var10004 = false;
         }

         var10001./* $QF: Unable to resugar constructor */<init>(var10003, var10004, 0.0F);
         this.model = var10001;
         this.model.disableArmorLayers();
         this.boundingBox = var1.getEntityBoundingBox();
         this.x = var1.posX;
         this.y = var1.posY;
         this.z = var1.posZ;
         this.player = var1;
      }

      public double getX() {
         return this.x;
      }

      public EntityPlayer getPlayer() {
         return this.player;
      }

      public double getZ() {
         return this.z;
      }

      public double getY() {
         return this.y;
      }
   }
}
