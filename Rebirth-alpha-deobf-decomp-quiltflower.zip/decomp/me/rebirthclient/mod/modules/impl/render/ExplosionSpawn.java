package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.ArrayList;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ExplosionSpawn extends Module {
   public final Setting<Color> color = this.add(new Setting<>("Color", new Color(-557395713, true)));
   private final Setting<Integer> time;
   private final Setting<Integer> animationTime;
   public static final ArrayList<ExplosionSpawn.Pos> spawnList = new ArrayList<>();
   public final Setting<Double> minSize;
   public final Setting<Double> up;
   private final Setting<Boolean> extra;
   public final Setting<Float> size = this.add(new Setting<>("Max Size", 0.5F, 0.1F, 5.0F));
   public final Setting<Double> height;

   public ExplosionSpawn() {
      super("ExplosionSpawn", "Draws a circle when a crystal spawn", Category.RENDER);
      this.minSize = this.add(new Setting<>("Min Size", 0.1, 0.0, 1.0));
      this.up = this.add(new Setting<>("Up", 0.1, 0.0, 1.0));
      this.height = this.add(new Setting<>("Height", 0.5, -1.0, 1.0));
      this.extra = this.add(new Setting<>("Extra", true));
      this.time = this.add(new Setting<>("Time", 500, 0, 5000));
      this.animationTime = this.add(new Setting<>("animationTime", 500, 0, 5000));
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (spawnList.size() != 0) {
         Color var2 = this.color.getValue();
         boolean var3 = true;

         for(ExplosionSpawn.Pos var5 : spawnList) {
            if (var5.time.easeOutQuad() >= 1.0) {
               boolean var10000 = false;
            } else {
               float var6 = (float)var5.pos.getX();
               float var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
               float var10002 = (float)var5.pos.getZ();
               double var10003;
               if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                  var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                  boolean var10004 = false;
               } else {
                  var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
               }

               RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003, var2);
               var3 = false;
               if (this.extra.getValue()) {
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var36 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.01F, var2);
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var37 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.015F, var2);
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var38 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.02F, var2);
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var39 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.025F, var2);
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var40 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.03F, var2);
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var41 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.035F, var2);
                  var6 = (float)var5.pos.getX();
                  var10001 = (float)((double)(var5.pos.getY() + 1) + 1.0 * var5.firstFade.easeOutQuad() * this.up.getValue() + this.height.getValue());
                  var10002 = (float)var5.pos.getZ();
                  if (var5.firstFade.easeOutQuad() > this.minSize.getValue()) {
                     var10003 = (double)this.size.getValue().floatValue() * var5.firstFade.easeOutQuad();
                     boolean var42 = false;
                  } else {
                     var10003 = (double)this.size.getValue().floatValue() * this.minSize.getValue();
                  }

                  RenderUtil.drawCircle(var6, var10001, var10002, (float)var10003 - 0.005F, var2);
               }

               boolean var14 = false;
            }
         }

         if (var3) {
            spawnList.clear();
         }
      }
   }

   @SubscribeEvent
   public void onPacketReceive(PacketEvent.Send var1) {
      if (var1.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
         spawnList.add(
            new ExplosionSpawn.Pos(((CPacketPlayerTryUseItemOnBlock)var1.getPacket()).getPos(), this.animationTime.getValue(), this.time.getValue())
         );
         boolean var10000 = false;
      }
   }

   @Override
   public void onEnable() {
      spawnList.clear();
   }

   private static class Pos {
      public final BlockPos pos;
      public final FadeUtils firstFade;
      public final FadeUtils time;

      public Pos(BlockPos var1, int var2, int var3) {
         this.firstFade = new FadeUtils((long)var2);
         this.time = new FadeUtils((long)var3);
         this.pos = var1;
      }
   }
}
