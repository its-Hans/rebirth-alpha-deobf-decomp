package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class Models extends Module {
   public Setting<Color> legsColor;
   public Setting<Boolean> onlySelf;
   public Setting<Color> eyeColor;
   public Setting<Color> bodyColor;
   public static Models INSTANCE;
   public Setting<Models.mode> Mode = this.add(new Setting<>("Mode", Models.mode.AmongUs));
   public Setting<Boolean> friendHighlight;
   public Setting<Boolean> friends;

   private boolean lambda$new$3(Color var1) {
      boolean var10000;
      if (this.Mode.getValue() == Models.mode.AmongUs) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.friends.isOpen() && this.onlySelf.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.onlySelf.isOpen();
   }

   public Models() {
      super("Models", "something", Category.RENDER);
      this.onlySelf = this.add(new Setting<>("OnlySelf", false).setParent());
      this.friends = this.add(new Setting<>("Friends", false, this::lambda$new$0).setParent());
      this.friendHighlight = this.add(new Setting<>("friendHighLight", false, this::lambda$new$1));
      this.eyeColor = this.add(new Setting<>("eyeColor", new Color(255, 255, 255), this::lambda$new$2));
      this.bodyColor = this.add(new Setting<>("bodyColor", new Color(255, 0, 0), this::lambda$new$3));
      this.legsColor = this.add(new Setting<>("legsColor", new Color(255, 0, 0), this::lambda$new$4));
      INSTANCE = this;
   }

   private boolean lambda$new$4(Color var1) {
      boolean var10000;
      if (this.Mode.getValue() == Models.mode.AmongUs) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Color var1) {
      boolean var10000;
      if (this.Mode.getValue() == Models.mode.AmongUs) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum mode {
      Rabbit,
      AmongUs,
      Freddy;
      private static final Models.mode[] $VALUES = new Models.mode[]{AmongUs, Rabbit, Models.mode.Freddy};
   }
}
