package me.rebirthclient.mod.modules.impl.render;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.asm.accessors.IGuiBossOverlay;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.BossInfoClient;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogDensity;
import net.minecraftforge.client.event.RenderBlockOverlayEvent.OverlayType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class NoRender extends Module {
   public final Setting<Boolean> noWeather;
   boolean gamma;
   public final Setting<Boolean> explosion;
   public final Setting<Boolean> fire;
   public final Setting<Boolean> totemPops;
   public final Setting<Boolean> nausea;
   public final Setting<Boolean> blocks;
   public final Setting<Boolean> hurtCam;
   public final Setting<Boolean> exp;
   public final Setting<Boolean> blind;
   public Setting<Boolean> skyLight;
   public Setting<Boolean> advancements;
   float oldBright;
   public static NoRender INSTANCE = new NoRender();
   private static final ResourceLocation GUI_BARS_TEXTURES = new ResourceLocation("textures/gui/bars.png");
   public Setting<NoRender.Boss> boss;
   public final Setting<Boolean> armor;
   public final Setting<Boolean> fog;
   public Setting<Float> scale;
   public final Setting<Boolean> night = this.add(new Setting<>("Night", true));

   private boolean lambda$new$0(Float var1) {
      boolean var10000;
      if (this.boss.getValue() != NoRender.Boss.MINIMIZE && this.boss.getValue() != NoRender.Boss.STACK) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onRenderPost(Post var1) {
      if (var1.getType() == ElementType.BOSSINFO && this.boss.getValue() != NoRender.Boss.NONE) {
         if (this.boss.getValue() == NoRender.Boss.MINIMIZE) {
            Map var2 = ((IGuiBossOverlay)mc.ingameGUI.getBossOverlay()).getMapBossInfos();
            if (var2 == null) {
               return;
            }

            ScaledResolution var3 = new ScaledResolution(mc);
            int var4 = var3.getScaledWidth();
            int var5 = 12;

            for(Entry var7 : var2.entrySet()) {
               BossInfoClient var8 = (BossInfoClient)var7.getValue();
               String var9 = var8.getName().getFormattedText();
               int var10 = (int)((float)var4 / this.scale.getValue() / 2.0F - 91.0F);
               GL11.glScaled((double)this.scale.getValue().floatValue(), (double)this.scale.getValue().floatValue(), 1.0);
               if (!var1.isCanceled()) {
                  GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
                  mc.getTextureManager().bindTexture(GUI_BARS_TEXTURES);
                  ((IGuiBossOverlay)mc.ingameGUI.getBossOverlay()).invokeRender(var10, var5, var8);
                  mc.fontRenderer
                     .drawStringWithShadow(
                        var9, (float)var4 / this.scale.getValue() / 2.0F - (float)mc.fontRenderer.getStringWidth(var9) / 2.0F, (float)(var5 - 9), 16777215
                     );
                  boolean var10000 = false;
               }

               GL11.glScaled(1.0 / (double)this.scale.getValue().floatValue(), 1.0 / (double)this.scale.getValue().floatValue(), 1.0);
               var5 += 10 + mc.fontRenderer.FONT_HEIGHT;
               boolean var29 = false;
            }

            boolean var30 = false;
         } else if (this.boss.getValue() == NoRender.Boss.STACK) {
            Map var13 = ((IGuiBossOverlay)mc.ingameGUI.getBossOverlay()).getMapBossInfos();
            HashMap var14 = new HashMap();

            for(Entry var17 : var13.entrySet()) {
               String var19 = ((BossInfoClient)var17.getValue()).getName().getFormattedText();
               if (var14.containsKey(var19)) {
                  NoRender.Pair var21 = (NoRender.Pair)var14.get(var19);
                  var21 = new NoRender.Pair<>(var21.getKey(), var21.getValue() + 1);
                  var14.put(var19, var21);
                  boolean var31 = false;
                  var31 = false;
               } else {
                  NoRender.Pair var23 = new NoRender.Pair<>(var17.getValue(), 1);
                  var14.put(var19, var23);
                  boolean var33 = false;
               }

               boolean var34 = false;
            }

            ScaledResolution var16 = new ScaledResolution(mc);
            int var18 = var16.getScaledWidth();
            int var20 = 12;

            for(Entry var25 : var14.entrySet()) {
               String var26 = (String)var25.getKey();
               BossInfoClient var28 = (BossInfoClient)((NoRender.Pair)var25.getValue()).getKey();
               int var11 = ((NoRender.Pair)var25.getValue()).getValue();
               var26 = String.valueOf(new StringBuilder().append(var26).append(" x").append(var11));
               int var12 = (int)((float)var18 / this.scale.getValue() / 2.0F - 91.0F);
               GL11.glScaled((double)this.scale.getValue().floatValue(), (double)this.scale.getValue().floatValue(), 1.0);
               if (!var1.isCanceled()) {
                  GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
                  mc.getTextureManager().bindTexture(GUI_BARS_TEXTURES);
                  ((IGuiBossOverlay)mc.ingameGUI.getBossOverlay()).invokeRender(var12, var20, var28);
                  mc.fontRenderer
                     .drawStringWithShadow(
                        var26, (float)var18 / this.scale.getValue() / 2.0F - (float)mc.fontRenderer.getStringWidth(var26) / 2.0F, (float)(var20 - 9), 16777215
                     );
                  boolean var35 = false;
               }

               GL11.glScaled(1.0 / (double)this.scale.getValue().floatValue(), 1.0 / (double)this.scale.getValue().floatValue(), 1.0);
               var20 += 10 + mc.fontRenderer.FONT_HEIGHT;
               boolean var36 = false;
            }
         }
      }
   }

   @SubscribeEvent
   public void fog_density(FogDensity var1) {
      if (!this.fog.getValue()) {
         var1.setDensity(0.0F);
         var1.setCanceled(true);
      }
   }

   @Override
   public void onUpdate() {
      if (this.blind.getValue() && mc.player.isPotionActive(MobEffects.BLINDNESS)) {
         mc.player.removePotionEffect(MobEffects.BLINDNESS);
      }

      if (this.noWeather.getValue() && mc.world.isRaining()) {
         mc.world.setRainStrength(0.0F);
      }

      if (mc.player.isPotionActive(MobEffects.NAUSEA) && this.nausea.getValue()) {
         mc.player.removePotionEffect(MobEffects.NAUSEA);
      }

      if (this.night.getValue()) {
         this.gamma = true;
         mc.gameSettings.gammaSetting = 100.0F;
         boolean var10000 = false;
      } else if (this.gamma) {
         mc.gameSettings.gammaSetting = this.oldBright;
         this.gamma = false;
      }
   }

   @Override
   public void onEnable() {
      this.oldBright = mc.gameSettings.gammaSetting;
   }

   @Override
   public void onDisable() {
      mc.gameSettings.gammaSetting = this.oldBright;
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled()) {
         if (this.explosion.getValue() && var1.getPacket() instanceof SPacketExplosion) {
            var1.setCanceled(true);
         } else {
            if (this.exp.getValue() && var1.getPacket() instanceof SPacketSoundEffect) {
               SPacketSoundEffect var2 = var1.getPacket();
               if (var2.getCategory() == SoundCategory.NEUTRAL && var2.getSound() == SoundEvents.ENTITY_EXPERIENCE_BOTTLE_THROW) {
                  var1.setCanceled(true);
                  return;
               }
            }
         }
      }
   }

   public NoRender() {
      super("NoRender", "Prevent some animation", Category.RENDER);
      this.armor = this.add(new Setting<>("Armor", true));
      this.fire = this.add(new Setting<>("Fire", true));
      this.blind = this.add(new Setting<>("Blind", true));
      this.nausea = this.add(new Setting<>("Nausea", true));
      this.fog = this.add(new Setting<>("Fog", true));
      this.noWeather = this.add(new Setting<>("Weather", true));
      this.hurtCam = this.add(new Setting<>("HurtCam", true));
      this.totemPops = this.add(new Setting<>("TotemPop", true));
      this.blocks = this.add(new Setting<>("Block", true));
      this.exp = this.add(new Setting<>("Exp", true));
      this.explosion = this.add(new Setting<>("Explosion[!]", false));
      this.skyLight = this.add(new Setting<>("SkyLight", false));
      this.advancements = this.add(new Setting<>("Advancements", false));
      this.boss = this.add(new Setting<>("BossBars", NoRender.Boss.NONE));
      this.scale = this.add(new Setting<>("Scale", 0.5F, 0.5F, 1.0F, this::lambda$new$0));
      this.gamma = false;
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onRenderPre(Pre var1) {
      if (var1.getType() == ElementType.BOSSINFO && this.boss.getValue() != NoRender.Boss.NONE) {
         var1.setCanceled(true);
      }
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if (this.exp.getValue()) {
         for(Entity var3 : mc.world.getLoadedEntityList()) {
            if (var3 instanceof EntityExpBottle) {
               mc.world.removeEntity(var3);
            }

            boolean var10000 = false;
         }
      }
   }

   @SubscribeEvent
   public void blockOverlayEventListener(RenderBlockOverlayEvent var1) {
      if (!fullNullCheck()) {
         if (this.fire.getValue() || this.blocks.getValue()) {
            if (var1.getOverlayType() == OverlayType.FIRE || this.blocks.getValue()) {
               var1.setCanceled(true);
            }
         }
      }
   }

   public static enum Boss {
      STACK,
      NONE,
      REMOVE,
      MINIMIZE;
      private static final NoRender.Boss[] $VALUES = new NoRender.Boss[]{NONE, REMOVE, STACK, NoRender.Boss.MINIMIZE};
   }

   public static class Pair<T, S> {
      S value;
      T key;

      public void setKey(T var1) {
         this.key = (T)var1;
      }

      public S getValue() {
         return this.value;
      }

      public Pair(T var1, S var2) {
         this.key = (T)var1;
         this.value = (S)var2;
      }

      public T getKey() {
         return this.key;
      }

      public void setValue(S var1) {
         this.value = (S)var1;
      }
   }
}
