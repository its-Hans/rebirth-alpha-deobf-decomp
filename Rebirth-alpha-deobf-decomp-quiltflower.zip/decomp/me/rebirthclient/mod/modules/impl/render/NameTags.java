package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.Objects;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.DamageUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.TextUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;

public class NameTags extends Module {
   private final Setting<Boolean> rect;
   private final Setting<Boolean> health;
   private final Setting<Boolean> reversed;
   private final Setting<Boolean> heldStackName;
   private final Setting<Float> outLineWidth;
   static final boolean $assertionsDisabled;
   private final Setting<Float> size;
   public final Setting<Color> outLine;
   private final Setting<Boolean> noMaxText;
   private final Setting<Boolean> gamemode;
   private final Setting<Boolean> ping;
   private final Setting<Boolean> armor;
   public final Setting<Color> sneak;
   public final Setting<Color> color;
   public final Setting<Color> friend;
   private final Setting<Float> factor;
   private final Setting<Boolean> scale;
   private final Setting<Boolean> entityID;
   public final Setting<Color> invisible;
   public static NameTags INSTANCE;
   private final Setting<Boolean> smartScale;
   public final Setting<Color> max = this.add(new Setting<>("Max", new Color(255, 255, 255)).injectBoolean(true).setParent());

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!fullNullCheck()) {
         for(EntityPlayer var3 : mc.world.playerEntities) {
            if (var3 != null && !var3.equals(mc.player) && var3.isEntityAlive()) {
               if (var3.isInvisible() && !this.invisible.booleanValue) {
                  boolean var10 = false;
               } else {
                  double var4 = this.interpolate(var3.lastTickPosX, var3.posX, var1.getPartialTicks()) - mc.getRenderManager().renderPosX;
                  double var6 = this.interpolate(var3.lastTickPosY, var3.posY, var1.getPartialTicks()) - mc.getRenderManager().renderPosY;
                  double var8 = this.interpolate(var3.lastTickPosZ, var3.posZ, var1.getPartialTicks()) - mc.getRenderManager().renderPosZ;
                  this.renderNameTag(var3, var4, var6, var8, var1.getPartialTicks());
                  boolean var10000 = false;
               }
            }
         }
      }
   }

   private String getDisplayTag(EntityPlayer var1) {
      String var2 = var1.getDisplayName().getFormattedText();
      if (var2.contains(mc.getSession().getUsername())) {
         var2 = "You";
      }

      float var3 = EntityUtil.getHealth(var1);
      String var10000;
      if (var3 > 18.0F) {
         var10000 = TextUtil.GREEN;
         boolean var10001 = false;
      } else if (var3 > 16.0F) {
         var10000 = TextUtil.DARK_GREEN;
         boolean var16 = false;
      } else if (var3 > 12.0F) {
         var10000 = TextUtil.YELLOW;
         boolean var17 = false;
      } else if (var3 > 8.0F) {
         var10000 = TextUtil.RED;
         boolean var18 = false;
      } else {
         var10000 = TextUtil.DARK_RED;
      }

      String var4;
      String var5;
      var4 = var10000;
      var5 = "";
      label71:
      if (this.ping.getValue()) {
         Minecraft var10 = mc;

         try {
            int var6 = ((NetHandlerPlayClient)Objects.requireNonNull(var10.getConnection())).getPlayerInfo(var1.getUniqueID()).getResponseTime();
            var5 = String.valueOf(new StringBuilder().append(var5).append(var6).append("ms "));
         } catch (Exception var8) {
            break label71;
         }

         boolean var11 = false;
      }

      String var9 = "";
      if (this.entityID.getValue()) {
         var9 = String.valueOf(new StringBuilder().append(var9).append("ID: ").append(var1.getEntityId()).append(" "));
      }

      String var7 = "";
      if (this.gamemode.getValue()) {
         if (var1.isCreative()) {
            var10000 = String.valueOf(new StringBuilder().append(var7).append("[C] "));
            boolean var20 = false;
         } else if (!var1.isSpectator() && !var1.isInvisible()) {
            var10000 = String.valueOf(new StringBuilder().append(var7).append("[S] "));
         } else {
            var10000 = String.valueOf(new StringBuilder().append(var7).append("[I] "));
            boolean var19 = false;
         }

         var7 = var10000;
      }

      if (this.health.getValue()) {
         if (Math.floor((double)var3) == (double)var3) {
            StringBuilder var13 = new StringBuilder().append(var2).append(var4).append(" ");
            Object var21;
            if (var3 > 0.0F) {
               var21 = (int)Math.floor((double)var3);
               boolean var10002 = false;
            } else {
               var21 = "dead";
            }

            var10000 = String.valueOf(var13.append(var21));
            boolean var22 = false;
         } else {
            StringBuilder var15 = new StringBuilder().append(var2).append(var4).append(" ");
            Object var23;
            if (var3 > 0.0F) {
               var23 = (int)var3;
               boolean var24 = false;
            } else {
               var23 = "dead";
            }

            var10000 = String.valueOf(var15.append(var23));
         }

         var2 = var10000;
      }

      return String.valueOf(new StringBuilder().append(" ").append(var5).append(var9).append(var7).append(var2).append(" "));
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.armor.isOpen();
   }

   public void drawOutlineRect(float var1, float var2, float var3, float var4, int var5) {
      float var6 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var7 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var8 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var9 = (float)(var5 & 0xFF) / 255.0F;
      Tessellator var10 = Tessellator.getInstance();
      BufferBuilder var11 = var10.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.glLineWidth(this.outLineWidth.getValue());
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      var11.begin(2, DefaultVertexFormats.POSITION_COLOR);
      var11.pos((double)var1, (double)var4, 0.0).color(var7, var8, var9, var6).endVertex();
      var11.pos((double)var3, (double)var4, 0.0).color(var7, var8, var9, var6).endVertex();
      var11.pos((double)var3, (double)var2, 0.0).color(var7, var8, var9, var6).endVertex();
      var11.pos((double)var1, (double)var2, 0.0).color(var7, var8, var9, var6).endVertex();
      var10.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }

   private boolean lambda$new$4(Float var1) {
      return this.outLine.isOpen();
   }

   public void drawRect(float var1, float var2, float var3, float var4, int var5) {
      float var6 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var7 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var8 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var9 = (float)(var5 & 0xFF) / 255.0F;
      Tessellator var10 = Tessellator.getInstance();
      BufferBuilder var11 = var10.getBuffer();
      GlStateManager.enableBlend();
      GlStateManager.disableTexture2D();
      GlStateManager.glLineWidth(this.outLineWidth.getValue());
      GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
      var11.begin(7, DefaultVertexFormats.POSITION_COLOR);
      var11.pos((double)var1, (double)var4, 0.0).color(var7, var8, var9, var6).endVertex();
      var11.pos((double)var3, (double)var4, 0.0).color(var7, var8, var9, var6).endVertex();
      var11.pos((double)var3, (double)var2, 0.0).color(var7, var8, var9, var6).endVertex();
      var11.pos((double)var1, (double)var2, 0.0).color(var7, var8, var9, var6).endVertex();
      var10.draw();
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
   }

   public NameTags() {
      super("NameTags", "Renders info about the player on a NameTag", Category.RENDER);
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255)));
      this.outLine = this.add(new Setting<>("outLine", new Color(255, 255, 255)).injectBoolean(false).setParent());
      this.friend = this.add(new Setting<>("Friend", new Color(155, 155, 255)).injectBoolean(true));
      this.invisible = this.add(new Setting<>("Invisible", new Color(200, 200, 200)).injectBoolean(true));
      this.sneak = this.add(new Setting<>("Sneaking", new Color(200, 200, 0)).injectBoolean(true));
      this.rect = this.add(new Setting<>("Rectangle", true));
      this.armor = this.add(new Setting<>("Armor", true).setParent());
      this.reversed = this.add(new Setting<>("ArmorReversed", false, this::lambda$new$0));
      this.health = this.add(new Setting<>("Health", true));
      this.ping = this.add(new Setting<>("Ping", true));
      this.gamemode = this.add(new Setting<>("Gamemode", true));
      this.entityID = this.add(new Setting<>("EntityID", false));
      this.heldStackName = this.add(new Setting<>("StackName", false));
      this.size = this.add(new Setting<>("Size", 2.5F, 0.1F, 15.0F));
      this.scale = this.add(new Setting<>("Scale", true).setParent());
      this.smartScale = this.add(new Setting<>("SmartScale", true, this::lambda$new$1));
      this.factor = this.add(new Setting<>("Factor", 0.3F, 0.1F, 1.0F, this::lambda$new$2));
      this.noMaxText = this.add(new Setting<>("NoMaxText", true, this::lambda$new$3));
      this.outLineWidth = this.add(new Setting<>("Width", 1.3F, 0.0F, 5.0F, this::lambda$new$4));
      INSTANCE = this;
   }

   private void renderEnchantmentText(ItemStack var1, int var2) {
      int var4 = -34;
      if (var1.getItem() == Items.GOLDEN_APPLE && var1.hasEffect()) {
         Managers.TEXT.drawMCString("god", (float)(var2 * 2), (float)var4, -3977919, true);
         var4 -= 8;
      }

      NBTTagList var3 = var1.getEnchantmentTagList();
      if (var3.tagCount() > 2 && this.max.booleanValue) {
         if (this.noMaxText.getValue()) {
            Managers.TEXT.drawMCString("", (float)(var2 * 2), (float)var4, ColorUtil.toRGBA(this.max.getValue()), true);
            boolean var17 = false;
         } else {
            Managers.TEXT.drawMCString("max", (float)(var2 * 2), (float)var4, ColorUtil.toRGBA(this.max.getValue()), true);
         }

         var4 -= 8;
         boolean var18 = false;
      } else {
         for(int var5 = 0; var5 < var3.tagCount(); ++var5) {
            short var6 = var3.getCompoundTagAt(var5).getShort("id");
            short var7 = var3.getCompoundTagAt(var5).getShort("lvl");
            Enchantment var8 = Enchantment.getEnchantmentByID(var6);
            if (var8 == null) {
               boolean var10000 = false;
            } else {
               String var15;
               if (var8.isCurse()) {
                  var15 = String.valueOf(new StringBuilder().append(TextFormatting.RED).append(var8.getTranslatedName(var7).substring(0, 4).toLowerCase()));
                  boolean var10001 = false;
               } else {
                  var15 = var8.getTranslatedName(var7).substring(0, 2).toLowerCase();
               }

               String var9 = var15;
               var9 = String.valueOf(new StringBuilder().append(var9).append((int)var7));
               Managers.TEXT.drawMCString(var9, (float)(var2 * 2), (float)var4, -1, true);
               var4 -= 8;
            }

            boolean var16 = false;
         }
      }

      if (DamageUtil.hasDurability(var1)) {
         float var11 = ((float)var1.getMaxDamage() - (float)var1.getItemDamage()) / (float)var1.getMaxDamage();
         float var12 = 1.0F - var11;
         int var10 = 100 - (int)(var12 * 100.0F);
         String var19;
         if (var10 >= 60) {
            var19 = TextUtil.GREEN;
            boolean var20 = false;
         } else if (var10 >= 25) {
            var19 = TextUtil.YELLOW;
            boolean var21 = false;
         } else {
            var19 = TextUtil.RED;
         }

         String var13 = var19;
         Managers.TEXT.drawMCString(String.valueOf(new StringBuilder().append(var13).append(var10).append("%")), (float)(var2 * 2), (float)var4, -1, true);
      }
   }

   static {
      boolean var10000;
      if (!NameTags.class.desiredAssertionStatus()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      $assertionsDisabled = var10000;
      INSTANCE = new NameTags();
   }

   private float getBiggestArmorTag(EntityPlayer var1) {
      float var5 = 0.0F;
      boolean var6 = false;

      for(ItemStack var8 : var1.inventory.armorInventory) {
         float var9 = 0.0F;
         if (var8 != null) {
            NBTTagList var10 = var8.getEnchantmentTagList();

            for(int var4 = 0; var4 < var10.tagCount(); ++var4) {
               short var11 = var10.getCompoundTagAt(var4).getShort("id");
               Enchantment var3 = Enchantment.getEnchantmentByID(var11);
               if (var3 == null) {
                  boolean var10000 = false;
               } else {
                  var9 += 8.0F;
                  var6 = true;
               }

               boolean var23 = false;
            }
         }

         if (!(var9 > var5)) {
            boolean var24 = false;
         } else {
            var5 = var9;
            boolean var25 = false;
         }
      }

      ItemStack var15 = var1.getHeldItemMainhand().copy();
      if (var15.hasEffect()) {
         float var16 = 0.0F;
         NBTTagList var18 = var15.getEnchantmentTagList();

         for(int var20 = 0; var20 < var18.tagCount(); ++var20) {
            short var22 = var18.getCompoundTagAt(var20).getShort("id");
            Enchantment var12 = Enchantment.getEnchantmentByID(var22);
            if (var12 == null) {
               boolean var26 = false;
            } else {
               var16 += 8.0F;
               var6 = true;
            }

            boolean var27 = false;
         }

         if (var16 > var5) {
            var5 = var16;
         }
      }

      ItemStack var2 = var1.getHeldItemOffhand().copy();
      if (var2.hasEffect()) {
         float var17 = 0.0F;
         NBTTagList var19 = var2.getEnchantmentTagList();

         for(int var14 = 0; var14 < var19.tagCount(); ++var14) {
            short var21 = var19.getCompoundTagAt(var14).getShort("id");
            Enchantment var13 = Enchantment.getEnchantmentByID(var21);
            if (var13 == null) {
               boolean var28 = false;
            } else {
               var17 += 8.0F;
               var6 = true;
            }

            boolean var29 = false;
         }

         if (var17 > var5) {
            var5 = var17;
         }
      }

      byte var30;
      if (var6) {
         var30 = 0;
         boolean var10001 = false;
      } else {
         var30 = 20;
      }

      return (float)var30 + var5;
   }

   private int getDisplayColor(EntityPlayer var1) {
      int var2 = ColorUtil.toRGBA(this.color.getValue());
      if (Managers.FRIENDS.isFriend(var1) && this.friend.booleanValue) {
         return ColorUtil.toRGBA(this.friend.getValue());
      } else {
         if (var1.isInvisible() && this.invisible.booleanValue) {
            var2 = ColorUtil.toRGBA(this.invisible.getValue());
            boolean var10000 = false;
         } else if (var1.isSneaking() && this.sneak.booleanValue) {
            var2 = ColorUtil.toRGBA(this.sneak.getValue());
         }

         return var2;
      }
   }

   private boolean lambda$new$3(Boolean var1) {
      return this.max.isOpen();
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.scale.isOpen();
   }

   private void renderNameTag(EntityPlayer var1, double var2, double var4, double var6, float var8) {
      double var10001;
      if (var1.isSneaking()) {
         var10001 = 0.5;
         boolean var10002 = false;
      } else {
         var10001 = 0.7;
      }

      double var9 = var4 + var10001;
      Entity var11 = mc.getRenderViewEntity();
      if (!$assertionsDisabled && var11 == null) {
         throw new AssertionError();
      } else {
         double var12 = var11.posX;
         double var14 = var11.posY;
         double var16 = var11.posZ;
         var11.posX = this.interpolate(var11.prevPosX, var11.posX, var8);
         var11.posY = this.interpolate(var11.prevPosY, var11.posY, var8);
         var11.posZ = this.interpolate(var11.prevPosZ, var11.posZ, var8);
         String var18 = this.getDisplayTag(var1);
         double var19 = var11.getDistance(
            var2 + mc.getRenderManager().viewerPosX, var4 + mc.getRenderManager().viewerPosY, var6 + mc.getRenderManager().viewerPosZ
         );
         int var21 = Managers.TEXT.getMCStringWidth(var18) / 2;
         double var22 = (0.0018 + (double)this.size.getValue().floatValue() * var19 * (double)this.factor.getValue().floatValue()) / 1000.0;
         if (var19 <= 6.0 && this.smartScale.getValue()) {
            var22 = (0.0018 + (double)(this.size.getValue() + 2.0F) * var19 * (double)this.factor.getValue().floatValue()) / 1000.0;
         }

         if (var19 <= 4.0 && this.smartScale.getValue()) {
            var22 = (0.0018 + (double)(this.size.getValue() + 4.0F) * var19 * (double)this.factor.getValue().floatValue()) / 1000.0;
         }

         if (!this.scale.getValue()) {
            var22 = (double)this.size.getValue().floatValue() / 100.0;
         }

         GlStateManager.pushMatrix();
         RenderHelper.enableStandardItemLighting();
         GlStateManager.enablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
         GlStateManager.disableLighting();
         GlStateManager.translate((float)var2, (float)var9 + 1.4F, (float)var6);
         GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
         float var10000 = mc.getRenderManager().playerViewX;
         float var47;
         if (mc.gameSettings.thirdPersonView == 2) {
            var47 = -1.0F;
            boolean var48 = false;
         } else {
            var47 = 1.0F;
         }

         GlStateManager.rotate(var10000, var47, 0.0F, 0.0F);
         GlStateManager.scale(-var22, -var22, var22);
         GlStateManager.disableDepth();
         GlStateManager.enableBlend();
         GlStateManager.enableBlend();
         if (this.rect.getValue()) {
            this.drawRect((float)(-var21 - 2), (float)(-(mc.fontRenderer.FONT_HEIGHT + 1)), (float)var21 + 2.0F, 1.5F, 1426063360);
            boolean var37 = false;
         } else if (!this.outLine.booleanValue) {
            this.drawRect(0.0F, 0.0F, 0.0F, 0.0F, 1426063360);
         }

         if (this.outLine.booleanValue) {
            this.drawOutlineRect((float)(-var21 - 2), (float)(-(mc.fontRenderer.FONT_HEIGHT + 1)), (float)var21 + 2.0F, 1.5F, this.getOutlineColor());
         }

         GlStateManager.disableBlend();
         ItemStack var24 = var1.getHeldItemMainhand().copy();
         if (var24.hasEffect() && (var24.getItem() instanceof ItemTool || var24.getItem() instanceof ItemArmor)) {
            var24.stackSize = 1;
         }

         if (this.heldStackName.getValue() && !var24.isEmpty && var24.getItem() != Items.AIR) {
            String var25 = var24.getDisplayName();
            int var26 = Managers.TEXT.getMCStringWidth(var25) / 2;
            GL11.glPushMatrix();
            GL11.glScalef(0.75F, 0.75F, 0.0F);
            Managers.TEXT.drawMCString(var25, (float)(-var26), -(this.getBiggestArmorTag(var1) + 20.0F), -1, true);
            GL11.glScalef(1.5F, 1.5F, 1.0F);
            GL11.glPopMatrix();
         }

         if (this.armor.getValue()) {
            GlStateManager.pushMatrix();
            int var29 = -6;

            for(ItemStack var27 : var1.inventory.armorInventory) {
               if (var27 == null) {
                  boolean var38 = false;
               } else {
                  var29 -= 8;
                  boolean var39 = false;
               }
            }

            var29 -= 8;
            ItemStack var33 = var1.getHeldItemOffhand().copy();
            if (var33.hasEffect() && (var33.getItem() instanceof ItemTool || var33.getItem() instanceof ItemArmor)) {
               var33.stackSize = 1;
            }

            this.renderItemStack(var33, var29);
            var29 += 16;
            if (!this.reversed.getValue()) {
               for(int var35 = 3; var35 >= 0; --var35) {
                  ItemStack var36 = (ItemStack)var1.inventory.armorInventory.get(var35);
                  if (var36.getItem() == Items.AIR) {
                     boolean var44 = false;
                  } else {
                     var36.copy();
                     boolean var45 = false;
                     this.renderItemStack(var36, var29);
                     var29 += 16;
                  }

                  boolean var46 = false;
               }
            } else {
               for(int var34 = 0; var34 <= 3; ++var34) {
                  ItemStack var28 = (ItemStack)var1.inventory.armorInventory.get(var34);
                  if (var28.getItem() == Items.AIR) {
                     boolean var40 = false;
                  } else {
                     var28.copy();
                     boolean var41 = false;
                     this.renderItemStack(var28, var29);
                     var29 += 16;
                  }

                  boolean var42 = false;
               }

               boolean var43 = false;
            }

            this.renderItemStack(var24, var29);
            GlStateManager.popMatrix();
         }

         Managers.TEXT.drawMCString(var18, (float)(-var21), (float)(-(Managers.TEXT.getFontHeight() - 1)), this.getDisplayColor(var1), true);
         var11.posX = var12;
         var11.posY = var14;
         var11.posZ = var16;
         GlStateManager.enableDepth();
         GlStateManager.disableBlend();
         GlStateManager.disablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
         GlStateManager.popMatrix();
      }
   }

   private void renderItemStack(ItemStack var1, int var2) {
      GlStateManager.pushMatrix();
      GlStateManager.depthMask(true);
      GlStateManager.clear(256);
      RenderHelper.enableStandardItemLighting();
      mc.getRenderItem().zLevel = -150.0F;
      GlStateManager.disableAlpha();
      GlStateManager.enableDepth();
      GlStateManager.disableCull();
      mc.getRenderItem().renderItemAndEffectIntoGUI(var1, var2, -26);
      mc.getRenderItem().renderItemOverlays(mc.fontRenderer, var1, var2, -26);
      mc.getRenderItem().zLevel = 0.0F;
      RenderHelper.disableStandardItemLighting();
      GlStateManager.enableCull();
      GlStateManager.enableAlpha();
      GlStateManager.scale(0.5F, 0.5F, 0.5F);
      GlStateManager.disableDepth();
      this.renderEnchantmentText(var1, var2);
      GlStateManager.enableDepth();
      GlStateManager.scale(2.0F, 2.0F, 2.0F);
      GlStateManager.popMatrix();
   }

   private double interpolate(double var1, double var3, float var5) {
      return var1 + (var3 - var1) * (double)var5;
   }

   private boolean lambda$new$2(Float var1) {
      return this.scale.isOpen();
   }

   private int getOutlineColor() {
      return ColorUtil.toRGBA(this.outLine.getValue());
   }
}
