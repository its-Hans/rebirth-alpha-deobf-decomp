package me.rebirthclient.mod.modules.impl.render;

import com.mojang.authlib.GameProfile;
import java.awt.Color;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class PopChams extends Module {
   private final Setting<Color> fillColor;
   public static Setting<Boolean> self;
   double alphaFill;
   ModelPlayer playerModel;
   EntityOtherPlayerMP player;
   private final Setting<Color> outlineColor = this.add(new Setting<>("Outline Color", new Color(255, 255, 255, 100)));
   public static Setting<Boolean> onlyOneEsp;
   public static PopChams INSTANCE;
   double alphaLine;
   public static Setting<Float> fadetime;
   public static Setting<Integer> fadestart;
   public static Setting<PopChams.ElevatorMode> elevatorMode;
   public static Setting<Boolean> elevator;
   Long startTime;

   public static float handleRotationFloat() {
      return 0.0F;
   }

   public static void glColor(Color var0) {
      GL11.glColor4f((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F);
   }

   private static boolean lambda$new$0(Object var0) {
      return elevator.isOpen();
   }

   public static float prepareScale(EntityLivingBase var0, float var1) {
      GlStateManager.enableRescaleNormal();
      GlStateManager.scale(-1.0F, -1.0F, 1.0F);
      double var2 = var0.getRenderBoundingBox().maxX - var0.getRenderBoundingBox().minX;
      double var4 = var0.getRenderBoundingBox().maxZ - var0.getRenderBoundingBox().minZ;
      GlStateManager.scale((double)var1 + var2, (double)(var1 * var0.height), (double)var1 + var4);
      GlStateManager.translate(0.0F, -1.501F, 0.0F);
      return 0.0625F;
   }

   public static void renderLivingAt(double var0, double var2, double var4) {
      GlStateManager.translate(var0, var2, var4);
   }

   public static void prepareGL() {
      GL11.glBlendFunc(770, 771);
      GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
      GlStateManager.glLineWidth(1.5F);
      GlStateManager.disableTexture2D();
      GlStateManager.depthMask(false);
      GlStateManager.enableBlend();
      GlStateManager.disableDepth();
      GlStateManager.disableLighting();
      GlStateManager.disableCull();
      GlStateManager.enableAlpha();
      GlStateManager.color(1.0F, 1.0F, 1.0F);
   }

   static Setting access$000(PopChams var0) {
      return var0.outlineColor;
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent var1) {
      if (!fullNullCheck()) {
         if (EarthPopChams.INSTANCE.isOn()) {
            this.disable();
         } else {
            if (onlyOneEsp.getValue()) {
               if (this.player == null || mc.world == null || mc.player == null) {
                  return;
               }

               if (elevator.getValue()) {
                  if (elevatorMode.getValue() == PopChams.ElevatorMode.UP) {
                     this.player.posY += (double)(0.05F * var1.getPartialTicks());
                     boolean var10000 = false;
                  } else if (elevatorMode.getValue() == PopChams.ElevatorMode.DOWN) {
                     this.player.posY -= (double)(0.05F * var1.getPartialTicks());
                  }
               }

               GL11.glLineWidth(1.0F);
               Color var2 = this.outlineColor.getValue();
               Color var3 = this.fillColor.getValue();
               int var4 = var2.getAlpha();
               int var5 = var3.getAlpha();
               long var6 = System.currentTimeMillis() - this.startTime - fadestart.getValue().longValue();
               if (System.currentTimeMillis() - this.startTime > fadestart.getValue().longValue()) {
                  double var8 = this.normalize((double)var6, fadetime.getValue().doubleValue());
                  var8 = MathHelper.clamp(var8, 0.0, 1.0);
                  var8 = -var8 + 1.0;
                  var4 *= (int)var8;
                  var5 *= (int)var8;
               }

               Color var14 = newAlpha(var2, var4);
               Color var9 = newAlpha(var3, var5);
               if (this.player != null && this.playerModel != null) {
                  prepareGL();
                  GL11.glPushAttrib(1048575);
                  GL11.glEnable(2881);
                  GL11.glEnable(2848);
                  if (this.alphaFill > 1.0) {
                     this.alphaFill -= (double)fadetime.getValue().floatValue();
                  }

                  Color var10 = new Color(var9.getRed(), var9.getGreen(), var9.getBlue(), (int)this.alphaFill);
                  if (this.alphaLine > 1.0) {
                     this.alphaLine -= (double)fadetime.getValue().floatValue();
                  }

                  Color var11 = new Color(var14.getRed(), var14.getGreen(), var14.getBlue(), (int)this.alphaLine);
                  glColor(var10);
                  GL11.glPolygonMode(1032, 6914);
                  renderEntity(this.player, this.playerModel, this.player.limbSwing, this.player.limbSwingAmount, 1);
                  glColor(var11);
                  GL11.glPolygonMode(1032, 6913);
                  renderEntity(this.player, this.playerModel, this.player.limbSwing, this.player.limbSwingAmount, 1);
                  GL11.glPolygonMode(1032, 6914);
                  GL11.glPopAttrib();
                  releaseGL();
               }
            }
         }
      }
   }

   public PopChams() {
      super("PopChams", "Pop rendering", Category.RENDER);
      this.fillColor = this.add(new Setting<>("Fill Color", new Color(255, 255, 255, 100)));
      INSTANCE = this;
      self = this.add(new Setting<>("Self", true));
      elevator = this.add(new Setting<>("Travel", true).setParent());
      elevatorMode = this.add(new Setting<>("Elevator", PopChams.ElevatorMode.UP, PopChams::lambda$new$0));
      fadestart = this.add(new Setting<>("Fade Start", 0, 0, 255));
      fadetime = this.add(new Setting<>("Fade Time", 0.5F, 0.0F, 2.0F));
      onlyOneEsp = this.add(new Setting<>("Only Render One", true));
   }

   public static Color newAlpha(Color var0, int var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var1);
   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled() && !fullNullCheck()) {
         if (EarthPopChams.INSTANCE.isOn()) {
            this.disable();
         } else {
            if (var1.getPacket() instanceof SPacketEntityStatus) {
               SPacketEntityStatus var2 = var1.getPacket();
               if (var2.getOpCode() == 35) {
                  var2.getEntity(mc.world);
                  boolean var10000 = false;
                  if (self.getValue() || var2.getEntity(mc.world).getEntityId() != mc.player.getEntityId()) {
                     GameProfile var3 = new GameProfile(mc.player.getUniqueID(), "");
                     this.player = new EntityOtherPlayerMP(mc.world, var3);
                     this.player.copyLocationAndAnglesFrom(var2.getEntity(mc.world));
                     this.playerModel = new ModelPlayer(0.0F, false);
                     this.startTime = System.currentTimeMillis();
                     this.playerModel.bipedHead.showModel = false;
                     this.playerModel.bipedBody.showModel = false;
                     this.playerModel.bipedLeftArmwear.showModel = false;
                     this.playerModel.bipedLeftLegwear.showModel = false;
                     this.playerModel.bipedRightArmwear.showModel = false;
                     this.playerModel.bipedRightLegwear.showModel = false;
                     this.alphaFill = (double)this.fillColor.getValue().getAlpha();
                     this.alphaLine = (double)this.outlineColor.getValue().getAlpha();
                     if (!onlyOneEsp.getValue()) {
                        new PopChams.TotemPopChams(this.player, this.playerModel, this.startTime, this.alphaFill);
                        var10000 = false;
                     }
                  }
               }
            }
         }
      }
   }

   static Setting access$100(PopChams var0) {
      return var0.fillColor;
   }

   double normalize(double var1, double var3) {
      return (var1 - 0.0) / (var3 - 0.0);
   }

   public static void renderEntity(EntityLivingBase var0, ModelBase var1, float var2, float var3, int var4) {
      float var5 = mc.getRenderPartialTicks();
      double var6 = var0.posX - mc.getRenderManager().viewerPosX;
      double var8 = var0.posY - mc.getRenderManager().viewerPosY;
      double var10 = var0.posZ - mc.getRenderManager().viewerPosZ;
      GlStateManager.pushMatrix();
      if (var0.isSneaking()) {
         var8 -= 0.125;
      }

      renderLivingAt(var6, var8, var10);
      float var12 = handleRotationFloat();
      prepareRotations(var0);
      float var13 = prepareScale(var0, (float)var4);
      GlStateManager.enableAlpha();
      var1.setLivingAnimations(var0, var2, var3, var5);
      var1.setRotationAngles(var2, var3, var12, var0.rotationYaw, var0.rotationPitch, var13, var0);
      var1.render(var0, var2, var3, var12, var0.rotationYaw, var0.rotationPitch, var13);
      GlStateManager.popMatrix();
   }

   public static void releaseGL() {
      GlStateManager.enableCull();
      GlStateManager.depthMask(true);
      GlStateManager.enableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.enableDepth();
   }

   public static void prepareRotations(EntityLivingBase var0) {
      GlStateManager.rotate(180.0F - var0.rotationYaw, 0.0F, 1.0F, 0.0F);
   }

   public static enum ElevatorMode {
      DOWN,
      UP;
      private static final PopChams.ElevatorMode[] $VALUES = new PopChams.ElevatorMode[]{PopChams.ElevatorMode.UP, PopChams.ElevatorMode.DOWN};
   }

   public static class TotemPopChams {
      double alphaLine;
      final EntityOtherPlayerMP player;
      double alphaFill;
      final Long startTime;
      final ModelPlayer playerModel;

      public static float prepareScale(EntityLivingBase var0, float var1) {
         GlStateManager.enableRescaleNormal();
         GlStateManager.scale(-1.0F, -1.0F, 1.0F);
         double var2 = var0.getRenderBoundingBox().maxX - var0.getRenderBoundingBox().minX;
         double var4 = var0.getRenderBoundingBox().maxZ - var0.getRenderBoundingBox().minZ;
         GlStateManager.scale((double)var1 + var2, (double)(var1 * var0.height), (double)var1 + var4);
         GlStateManager.translate(0.0F, -1.501F, 0.0F);
         return 0.0625F;
      }

      public static void glColor(Color var0) {
         GL11.glColor4f((float)var0.getRed() / 255.0F, (float)var0.getGreen() / 255.0F, (float)var0.getBlue() / 255.0F, (float)var0.getAlpha() / 255.0F);
      }

      public static void renderLivingAt(double var0, double var2, double var4) {
         GlStateManager.translate((float)var0, (float)var2, (float)var4);
      }

      public static float handleRotationFloat() {
         return 0.0F;
      }

      public static void prepareRotations(EntityLivingBase var0) {
         GlStateManager.rotate(180.0F - var0.rotationYaw, 0.0F, 1.0F, 0.0F);
      }

      double normalize(double var1, double var3) {
         return (var1 - 0.0) / (var3 - 0.0);
      }

      public static Color newAlpha(Color var0, int var1) {
         return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), var1);
      }

      @SubscribeEvent
      public void onRenderWorld(RenderWorldLastEvent var1) {
         if (this.player != null && Wrapper.mc.world != null && Wrapper.mc.player != null) {
            GL11.glLineWidth(1.0F);
            Color var2 = (Color)PopChams.access$000(PopChams.INSTANCE).getValue();
            Color var3 = (Color)PopChams.access$100(PopChams.INSTANCE).getValue();
            int var4 = var2.getAlpha();
            int var5 = var3.getAlpha();
            long var6 = System.currentTimeMillis() - this.startTime - PopChams.fadestart.getValue().longValue();
            if (System.currentTimeMillis() - this.startTime > PopChams.fadestart.getValue().longValue()) {
               double var8 = this.normalize((double)var6, PopChams.fadetime.getValue().doubleValue());
               var8 = MathHelper.clamp(var8, 0.0, 1.0);
               var8 = -var8 + 1.0;
               var4 *= (int)var8;
               var5 *= (int)var8;
            }

            Color var14 = newAlpha(var2, var4);
            Color var9 = newAlpha(var3, var5);
            if (this.playerModel != null) {
               PopChams.prepareGL();
               GL11.glPushAttrib(1048575);
               GL11.glEnable(2881);
               GL11.glEnable(2848);
               if (this.alphaFill > 1.0) {
                  this.alphaFill -= (double)PopChams.fadetime.getValue().floatValue();
               }

               Color var10 = new Color(var9.getRed(), var9.getGreen(), var9.getBlue(), (int)this.alphaFill);
               if (this.alphaLine > 1.0) {
                  this.alphaLine -= (double)PopChams.fadetime.getValue().floatValue();
               }

               Color var11 = new Color(var14.getRed(), var14.getGreen(), var14.getBlue(), (int)this.alphaLine);
               glColor(var10);
               GL11.glPolygonMode(1032, 6914);
               renderEntity(this.player, this.playerModel, this.player.limbSwing, this.player.limbSwingAmount, 1.0F);
               glColor(var11);
               GL11.glPolygonMode(1032, 6913);
               renderEntity(this.player, this.playerModel, this.player.limbSwing, this.player.limbSwingAmount, 1.0F);
               GL11.glPolygonMode(1032, 6914);
               GL11.glPopAttrib();
               PopChams.releaseGL();
            }
         }
      }

      public TotemPopChams(EntityOtherPlayerMP var1, ModelPlayer var2, Long var3, double var4) {
         MinecraftForge.EVENT_BUS.register(this);
         this.player = var1;
         this.playerModel = var2;
         this.startTime = var3;
         this.alphaFill = var4;
         this.alphaLine = var4;
      }

      public static void renderEntity(EntityLivingBase var0, ModelBase var1, float var2, float var3, float var4) {
         float var5 = Wrapper.mc.getRenderPartialTicks();
         double var6 = var0.posX - Wrapper.mc.getRenderManager().viewerPosX;
         double var8 = var0.posY - Wrapper.mc.getRenderManager().viewerPosY;
         double var10 = var0.posZ - Wrapper.mc.getRenderManager().viewerPosZ;
         GlStateManager.pushMatrix();
         if (var0.isSneaking()) {
            var8 -= 0.125;
         }

         renderLivingAt(var6, var8, var10);
         float var12 = handleRotationFloat();
         prepareRotations(var0);
         float var13 = prepareScale(var0, var4);
         GlStateManager.enableAlpha();
         var1.setLivingAnimations(var0, var2, var3, var5);
         var1.setRotationAngles(var2, var3, var12, var0.rotationYawHead, var0.rotationPitch, var13, var0);
         var1.render(var0, var2, var3, var12, var0.rotationYawHead, var0.rotationPitch, var13);
         GlStateManager.popMatrix();
      }
   }
}
