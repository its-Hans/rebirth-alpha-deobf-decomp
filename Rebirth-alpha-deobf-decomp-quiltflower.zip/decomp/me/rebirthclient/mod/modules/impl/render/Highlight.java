package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;

public class Highlight extends Module {
   private final Setting<Color> color;
   AxisAlignedBB renderBB;
   private final Setting<Boolean> box;
   private final Setting<Boolean> depth;
   BlockPos lastPos;
   FadeUtils fade;
   private final Setting<Boolean> line;
   private final Setting<Float> lineWidth;
   private final Setting<Integer> animationTime = this.add(new Setting<>("AnimationTime", 1000, 0, 6000));

   public Highlight() {
      super("Highlight", "Highlights the block u look at", Category.RENDER);
      this.line = this.add(new Setting<>("Line", true));
      this.box = this.add(new Setting<>("Box", false));
      this.depth = this.add(new Setting<>("Depth", true));
      this.lineWidth = this.add(new Setting<>("LineWidth", 3.0F, 0.1F, 3.0F));
      this.color = this.add(new Setting<>("Color", new Color(125, 125, 213, 150)));
      this.fade = new FadeUtils((long)this.animationTime.getValue().intValue());
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      RayTraceResult var2 = mc.objectMouseOver;
      if (var2 != null && var2.typeOfHit == Type.BLOCK) {
         BlockPos var3 = var2.getBlockPos();
         if (this.lastPos == null) {
            this.lastPos = var3;
            this.renderBB = mc.world.getBlockState(var3).getSelectedBoundingBox(mc.world, var3).grow(0.002);
         }

         if (!this.lastPos.equals(var2.getBlockPos())) {
            this.lastPos = var2.getBlockPos();
            this.fade = new FadeUtils((long)this.animationTime.getValue().intValue());
         }

         AxisAlignedBB var4 = mc.world.getBlockState(var3).getSelectedBoundingBox(mc.world, var3).grow(0.002);
         this.renderBB = new AxisAlignedBB(
            this.renderBB.minX - (this.renderBB.minX - var4.minX) * this.fade.easeOutQuad(),
            this.renderBB.minY - (this.renderBB.minY - var4.minY) * this.fade.easeOutQuad(),
            this.renderBB.minZ - (this.renderBB.minZ - var4.minZ) * this.fade.easeOutQuad(),
            this.renderBB.maxX - (this.renderBB.maxX - var4.maxX) * this.fade.easeOutQuad(),
            this.renderBB.maxY - (this.renderBB.maxY - var4.maxY) * this.fade.easeOutQuad(),
            this.renderBB.maxZ - (this.renderBB.maxZ - var4.maxZ) * this.fade.easeOutQuad()
         );
         RenderUtil.testESP(
            this.renderBB,
            this.color.getValue(),
            false,
            new Color(-1),
            this.lineWidth.getValue(),
            this.line.getValue(),
            this.box.getValue(),
            this.color.getValue().getAlpha(),
            this.depth.getValue()
         );
      }
   }
}
