package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import org.lwjgl.opengl.GL11;

public class ChinaHat extends Module {
   public final Setting<Integer> points;
   public final Setting<Boolean> firstPerson;
   public final Setting<Color> color = this.add(new Setting<>("Color", new Color(-557395713, true)).hideAlpha());
   public final Setting<Color> color2 = this.add(new Setting<>("SecondColor", new Color(-557395713, true)).hideAlpha());

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (mc.gameSettings.thirdPersonView != 0 || this.firstPerson.getValue()) {
         for(int var3 = 0; var3 < 400; ++var3) {
            float var2 = (float)ColorUtil.getGradientOffset(
                  this.color2.getValue(), this.color.getValue(), (double)Math.abs(System.currentTimeMillis() / 7L - (long)(var3 / 2)) / 120.0
               )
               .getRGB();
            if (mc.player.isElytraFlying()) {
               EntityPlayerSP var10000 = mc.player;
               double var10001 = 0.009 + (double)var3 * 0.0014;
               float var10002 = var1.getPartialTicks();
               int var10003 = this.points.getValue();
               float var10005 = 1.1F - (float)var3 * 7.85E-4F;
               float var10006;
               if (SneakManager.isSneaking) {
                  var10006 = 0.07F;
                  boolean var10007 = false;
               } else {
                  var10006 = 0.03F;
               }

               drawHat(var10000, var10001, var10002, var10003, 2.0F, var10005 - var10006, (int)var2);
               boolean var4 = false;
            } else if (SneakManager.isSneaking) {
               EntityPlayerSP var5 = mc.player;
               double var9 = 0.009 + (double)var3 * 0.0014;
               float var11 = var1.getPartialTicks();
               int var13 = this.points.getValue();
               float var15 = 1.1F - (float)var3 * 7.85E-4F;
               float var17;
               if (SneakManager.isSneaking) {
                  var17 = 0.07F;
                  boolean var19 = false;
               } else {
                  var17 = 0.03F;
               }

               drawHat(var5, var9, var11, var13, 2.0F, var15 - var17, (int)var2);
               boolean var6 = false;
            } else {
               EntityPlayerSP var7 = mc.player;
               double var10 = 0.009 + (double)var3 * 0.0014;
               float var12 = var1.getPartialTicks();
               int var14 = this.points.getValue();
               float var16 = 2.2F - (float)var3 * 7.85E-4F;
               float var18;
               if (SneakManager.isSneaking) {
                  var18 = 0.07F;
                  boolean var20 = false;
               } else {
                  var18 = 0.03F;
               }

               drawHat(var7, var10, var12, var14, 2.0F, var16 - var18, (int)var2);
            }

            boolean var8 = false;
         }
      }
   }

   public static void drawHat(Entity var0, double var1, float var3, int var4, float var5, float var6, int var7) {
      GL11.glPushMatrix();
      GL11.glDisable(3553);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      GL11.glDepthMask(false);
      GL11.glLineWidth(var5);
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      GL11.glEnable(2929);
      GL11.glBegin(3);
      double var8 = interpolate(var0.prevPosX, var0.posX, (double)var3) - mc.getRenderManager().viewerPosX;
      double var10 = interpolate(var0.prevPosY + (double)var6, var0.posY + (double)var6, (double)var3) - mc.getRenderManager().viewerPosY;
      double var12 = interpolate(var0.prevPosZ, var0.posZ, (double)var3) - mc.getRenderManager().viewerPosZ;
      GL11.glColor4f((float)new Color(var7).getRed() / 255.0F, (float)new Color(var7).getGreen() / 255.0F, (float)new Color(var7).getBlue() / 255.0F, 0.15F);

      for(int var14 = 0; var14 <= var4; ++var14) {
         GL11.glVertex3d(
            var8 + var1 * Math.cos((double)var14 * Math.PI * 2.0 / (double)var4), var10, var12 + var1 * Math.sin((double)var14 * Math.PI * 2.0 / (double)var4)
         );
         boolean var10000 = false;
      }

      GL11.glEnd();
      GL11.glDepthMask(true);
      GL11.glDisable(3042);
      GL11.glEnable(2929);
      GL11.glDisable(2848);
      GL11.glEnable(2929);
      GL11.glEnable(3553);
      GL11.glPopMatrix();
   }

   public static double interpolate(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * var4;
   }

   public ChinaHat() {
      super("ChinaHat", "ChinaHat", Category.RENDER);
      this.points = this.add(new Setting<>("Points", 12, 4, 64));
      this.firstPerson = this.add(new Setting<>("FirstPerson", false));
   }
}
