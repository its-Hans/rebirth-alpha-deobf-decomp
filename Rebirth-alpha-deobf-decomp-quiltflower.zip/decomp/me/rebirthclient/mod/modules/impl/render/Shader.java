package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.events.impl.RenderItemInFirstPersonEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.InterpolationUtil;
import me.rebirthclient.api.util.render.shader.framebuffer.impl.ItemShader;
import me.rebirthclient.asm.accessors.IEntityRenderer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;

public class Shader extends Module {
   private boolean forceRender;
   private final Setting<Boolean> model;
   private final Setting<Boolean> crystals;
   private final Setting<Integer> range;
   private final Setting<Boolean> fovOnly;
   private final Setting<Float> smoothness;
   private final Setting<Boolean> items;
   private final Setting<Integer> alpha;
   private final Setting<Color> color;
   private final Setting<Boolean> players = this.add(new Setting<>("Players", false));
   public static Shader INSTANCE;
   private final Setting<Boolean> self;
   private final Setting<Float> radius;
   private final Setting<Boolean> glow;
   private final Setting<Boolean> xp;
   public static boolean crystalRender;

   private void lambda$onRenderWorldLastEvent$4(RenderWorldLastEvent var1, Entity var2) {
      if (!(var2.getDistance(mc.player) > (float)this.range.getValue().intValue())
         && (!this.fovOnly.getValue() || Managers.ROTATIONS.isInFov(var2.getPosition()))) {
         if (!Integer.valueOf(mc.player.getName().hashCode()).equals(var2.getName().hashCode()) || mc.gameSettings.thirdPersonView != 0) {
            Vec3d var3 = InterpolationUtil.getInterpolatedRenderPos(var2, var1.getPartialTicks());
            if (var2 instanceof EntityPlayer) {
               ((EntityPlayer)var2).hurtTime = 0;
            }

            Render var4 = mc.getRenderManager().getEntityRenderObject(var2);
            if (var4 != null) {
               Render var10000 = var4;
               Entity var10001 = var2;
               Vec3d var10002 = var3;

               try {
                  var10000.doRender(var10001, var10002.x, var3.y, var3.z, var2.rotationYaw, var1.getPartialTicks());
               } catch (Exception var6) {
                  return;
               }

               boolean var7 = false;
            }
         }
      }
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if ((Display.isActive() || Display.isVisible()) && !(mc.currentScreen instanceof GuiDownloadTerrain)) {
         GlStateManager.pushMatrix();
         GlStateManager.pushAttrib();
         GlStateManager.enableBlend();
         GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
         GlStateManager.enableDepth();
         GlStateManager.depthMask(true);
         GlStateManager.enableAlpha();
         ItemShader var2 = ItemShader.INSTANCE;
         var2.mix = (float)this.color.getValue().getAlpha() / 255.0F;
         var2.alpha = (float)(205 + this.alpha.getValue()) / 255.0F;
         var2.model = this.model.getValue();
         var2.startDraw(mc.getRenderPartialTicks());
         this.forceRender = true;
         if (this.self.getValue()) {
            ((IEntityRenderer)mc.entityRenderer).invokeRenderHand(mc.getRenderPartialTicks(), 2);
         }

         this.forceRender = false;
         Color var10001 = this.color.getValue();
         float var10002;
         if (this.glow.getValue()) {
            var10002 = this.radius.getValue();
            boolean var10003 = false;
         } else {
            var10002 = 0.0F;
         }

         var2.stopDraw(var10001, var10002, this.smoothness.getValue());
         GlStateManager.disableBlend();
         GlStateManager.disableAlpha();
         GlStateManager.disableDepth();
         GlStateManager.popAttrib();
         GlStateManager.popMatrix();
      }
   }

   private boolean lambda$new$1(Float var1) {
      return this.glow.isOpen();
   }

   private boolean lambda$onRenderWorldLastEvent$3(Entity var1) {
      boolean var10000;
      if (var1 == null
         || var1 == mc.player && var1 == mc.getRenderViewEntity()
         || mc.getRenderManager().getEntityRenderObject(var1) == null
         || (!(var1 instanceof EntityPlayer) || !this.players.getValue() || ((EntityPlayer)var1).isSpectator())
            && (!(var1 instanceof EntityEnderCrystal) || !this.crystals.getValue())
            && (!(var1 instanceof EntityExpBottle) || !this.xp.getValue())
            && (!(var1 instanceof EntityItem) || !this.items.getValue())) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onRenderWorldLastEvent(RenderWorldLastEvent var1) {
      if (!fullNullCheck() && this.isOn()) {
         if ((Display.isActive() || Display.isVisible()) && !(mc.currentScreen instanceof GuiDownloadTerrain)) {
            GlStateManager.pushMatrix();
            GlStateManager.pushAttrib();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.enableAlpha();
            ItemShader var2 = ItemShader.INSTANCE;
            var2.mix = (float)this.color.getValue().getAlpha() / 255.0F;
            var2.alpha = (float)(205 + this.alpha.getValue()) / 255.0F;
            var2.model = false;
            var2.startDraw(mc.getRenderPartialTicks());
            crystalRender = true;
            mc.world.loadedEntityList.stream().filter(this::lambda$onRenderWorldLastEvent$3).forEach(this::lambda$onRenderWorldLastEvent$4);
            crystalRender = false;
            Color var10001 = this.color.getValue();
            float var10002;
            if (this.glow.getValue()) {
               var10002 = this.radius.getValue();
               boolean var10003 = false;
            } else {
               var10002 = 0.0F;
            }

            var2.stopDraw(var10001, var10002, this.smoothness.getValue());
            GlStateManager.disableBlend();
            GlStateManager.disableAlpha();
            GlStateManager.disableDepth();
            GlStateManager.popAttrib();
            GlStateManager.popMatrix();
         }
      }
   }

   @Override
   public void onLogin() {
      if (this.isOn()) {
         this.disable();
         this.enable();
      }
   }

   private boolean lambda$new$2(Integer var1) {
      return this.glow.isOpen();
   }

   private boolean lambda$new$0(Float var1) {
      return this.glow.isOpen();
   }

   public Shader() {
      super("Shader", "Is in beta test stage", Category.RENDER);
      this.crystals = this.add(new Setting<>("Crystals", false));
      this.xp = this.add(new Setting<>("Exp", false));
      this.items = this.add(new Setting<>("Items", false));
      this.self = this.add(new Setting<>("Self", true));
      this.color = this.add(new Setting<>("Color", new Color(-8553003, true)));
      this.glow = this.add(new Setting<>("Glow", true).setParent());
      this.radius = this.add(new Setting<>("Radius", 4.0F, 0.1F, 6.0F, this::lambda$new$0));
      this.smoothness = this.add(new Setting<>("Smoothness", 1.0F, 0.1F, 1.0F, this::lambda$new$1));
      this.alpha = this.add(new Setting<>("Alpha", 50, 1, 50, this::lambda$new$2));
      this.model = this.add(new Setting<>("Model", true));
      this.range = this.add(new Setting<>("Range", 75, 5, 250));
      this.fovOnly = this.add(new Setting<>("FOVOnly", false));
      INSTANCE = this;
   }

   @SubscribeEvent
   public void renderItemInFirstPerson(RenderItemInFirstPersonEvent var1) {
      if (!fullNullCheck() && this.isOn() && var1.getStage() == 0 && !this.forceRender && this.self.getValue()) {
         var1.setCanceled(true);
      }
   }
}
