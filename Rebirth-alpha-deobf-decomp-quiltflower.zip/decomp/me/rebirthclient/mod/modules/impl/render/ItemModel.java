package me.rebirthclient.mod.modules.impl.render;

import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ItemModel extends Module {
   public final Setting<Boolean> noSway;
   public final Setting<Double> mainY;
   public float angle;
   public final Setting<Boolean> noEatAnimation;
   public final Setting<Double> mainZ;
   public final Setting<Double> offY;
   public final Setting<Boolean> doBob;
   public final Setting<Double> offZ;
   public final Setting<Double> eatY;
   public final Setting<Boolean> slowSwing;
   public final Setting<Boolean> spinY;
   public final Setting<Double> mainX;
   public final Setting<Integer> delay;
   public final Setting<Double> offX;
   final Timer timer;
   public final Setting<Integer> angleSpeed;
   public final Setting<ItemModel.Swing> swing;
   public final Setting<Boolean> customSwing;
   public final Setting<Boolean> spinX;
   public final Setting<ItemModel.Settings> settings = this.add(new Setting<>("Settings", ItemModel.Settings.TRANSLATE));
   public final Setting<Double> eatX;
   public static ItemModel INSTANCE = new ItemModel();
   public final Setting<Integer> swingSpeed;

   @Override
   public void onUpdate() {
      if (this.swing.getValue() == ItemModel.Swing.OFFHAND && this.customSwing.getValue()) {
         mc.player.swingingHand = EnumHand.OFF_HAND;
         boolean var10000 = false;
      } else if (this.swing.getValue() == ItemModel.Swing.MAINHAND && this.customSwing.getValue()) {
         mc.player.swingingHand = EnumHand.MAIN_HAND;
      }

      this.doAngle();
   }

   private boolean lambda$new$4(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TWEAKS && !this.noEatAnimation.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$14(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.OTHERS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$15(ItemModel.Swing var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.OTHERS && this.customSwing.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.OTHERS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$17(Integer var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.OTHERS && this.slowSwing.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void doAngle() {
      if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         this.angle += (float)this.angleSpeed.getValue().intValue();
         this.timer.reset();
         boolean var10000 = false;
      }
   }

   private boolean lambda$new$18(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.OTHERS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TWEAKS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public ItemModel() {
      super("ItemModel", "Change the position of the arm", Category.RENDER);
      this.noEatAnimation = this.add(new Setting<>("NoEatAnimation", false, this::lambda$new$0));
      this.eatX = this.add(new Setting<>("EatX", 1.4, -5.0, 15.0, this::lambda$new$1));
      this.eatY = this.add(new Setting<>("EatY", 1.3, -5.0, 15.0, this::lambda$new$2));
      this.doBob = this.add(new Setting<>("ItemBob", true, this::lambda$new$3));
      this.mainX = this.add(new Setting<>("MainX", 0.2, -4.0, 4.0, this::lambda$new$4));
      this.mainY = this.add(new Setting<>("MainY", -0.2, -3.0, 3.0, this::lambda$new$5));
      this.mainZ = this.add(new Setting<>("MainZ", -0.3, -5.0, 5.0, this::lambda$new$6));
      this.offX = this.add(new Setting<>("OffX", -0.2, -4.0, 4.0, this::lambda$new$7));
      this.offY = this.add(new Setting<>("OffY", -0.2, -3.0, 3.0, this::lambda$new$8));
      this.offZ = this.add(new Setting<>("OffZ", -0.3, -5.0, 5.0, this::lambda$new$9));
      this.spinY = this.add(new Setting<>("SpinX", false, this::lambda$new$10));
      this.spinX = this.add(new Setting<>("SpinY", false, this::lambda$new$11));
      this.delay = this.add(new Setting<>("Delay", 50, 0, 500, this::lambda$new$12));
      this.angleSpeed = this.add(new Setting<>("AngleSpeed", 5, 0, 10, this::lambda$new$13));
      this.customSwing = this.add(new Setting<>("CustomSwing", false, this::lambda$new$14).setParent());
      this.swing = this.add(new Setting<>("Swing", ItemModel.Swing.MAINHAND, this::lambda$new$15));
      this.slowSwing = this.add(new Setting<>("SwingSpeed", false, this::lambda$new$16).setParent());
      this.swingSpeed = this.add(new Setting<>("swingSpeed", 15, 0, 30, this::lambda$new$17));
      this.noSway = this.add(new Setting<>("NoSway", false, this::lambda$new$18));
      this.timer = new Timer();
      this.angle = 0.0F;
      INSTANCE = this;
   }

   private boolean lambda$new$1(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TWEAKS && !this.noEatAnimation.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$12(Integer var1) {
      boolean var10000;
      if (this.settings.getValue() != ItemModel.Settings.TRANSLATE || !this.spinX.getValue() && !this.spinY.getValue()) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void Update(UpdateWalkingPlayerEvent var1) {
      this.doAngle();
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      this.doAngle();
   }

   private boolean lambda$new$5(Double var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TRANSLATE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      this.doAngle();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      this.doAngle();
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.settings.getValue() == ItemModel.Settings.TWEAKS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(Integer var1) {
      boolean var10000;
      if (this.settings.getValue() != ItemModel.Settings.TRANSLATE || !this.spinX.getValue() && !this.spinY.getValue()) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private static enum Settings {
      TRANSLATE,
      TWEAKS,
      OTHERS;

      private static final ItemModel.Settings[] $VALUES = new ItemModel.Settings[]{TRANSLATE, TWEAKS, OTHERS};
   }

   public static enum Swing {
      SERVER,
      OFFHAND,
      MAINHAND;

      private static final ItemModel.Swing[] $VALUES = new ItemModel.Swing[]{MAINHAND, OFFHAND, SERVER};
   }
}
