package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.concurrent.atomic.AtomicInteger;
import me.rebirthclient.api.util.shaders.impl.fill.AquaShader;
import me.rebirthclient.api.util.shaders.impl.fill.CircleShader;
import me.rebirthclient.api.util.shaders.impl.fill.FillShader;
import me.rebirthclient.api.util.shaders.impl.fill.FlowShader;
import me.rebirthclient.api.util.shaders.impl.fill.GradientShader;
import me.rebirthclient.api.util.shaders.impl.fill.PhobosShader;
import me.rebirthclient.api.util.shaders.impl.fill.RainbowCubeShader;
import me.rebirthclient.api.util.shaders.impl.fill.SmokeShader;
import me.rebirthclient.api.util.shaders.impl.outline.AquaOutlineShader;
import me.rebirthclient.api.util.shaders.impl.outline.AstralOutlineShader;
import me.rebirthclient.api.util.shaders.impl.outline.CircleOutlineShader;
import me.rebirthclient.api.util.shaders.impl.outline.GlowShader;
import me.rebirthclient.api.util.shaders.impl.outline.GradientOutlineShader;
import me.rebirthclient.api.util.shaders.impl.outline.RainbowCubeOutlineShader;
import me.rebirthclient.api.util.shaders.impl.outline.SmokeOutlineShader;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Shaders extends Module {
   public Setting<Integer> WaveLenghtFIll;
   public Setting<Float> PI;
   public Setting<Float> alphaFill;
   public Setting<Color> colorESP;
   public Setting<Float> saturationOutline;
   public Setting<Float> stepSizeFill;
   public Setting<Float> volumStepsFill;
   public Setting<Integer> maxEntities;
   public Setting<Integer> MaxIterFill;
   public Setting<Float> radOutline;
   public Setting<Integer> GSTARTOutline;
   public Setting<Integer> NUM_OCTAVESFill;
   private final Setting<Shaders.fillShadermode> fillShader = this.add(new Setting<>("Fill Shader", Shaders.fillShadermode.None));
   private final Setting<Shaders.Player1> player;
   private final Setting<Boolean> fadeOutline;
   public final Setting<Shaders.Crystal1> crystal;
   public Setting<Float> greenFill;
   private final Setting<Shaders.XPl> xpOrb;
   public Setting<Float> stepSizeOutline;
   private final Setting<Shaders.glowESPmode> glowESP = this.add(new Setting<>("Glow ESP", Shaders.glowESPmode.None));
   public Setting<Float> moreGradientFill;
   private final Setting<Boolean> default1;
   private final Setting<Boolean> fadeFill;
   public Setting<Float> duplicateFill;
   public Setting<Float> formuparam2Outline;
   public Setting<Float> zoomOutline;
   public Setting<Float> tauOutline;
   public Setting<Integer> WaveLenghtOutline;
   public Setting<Color> colorImgFill;
   public Setting<Integer> RSTARTOutline;
   public Setting<Integer> NUM_OCTAVESOutline;
   public Setting<Integer> MaxIterOutline;
   public Setting<Float> titleOutline;
   private final Setting<Shaders.EPl> enderPearl;
   public static Shaders INSTANCE;
   public Setting<Float> zoomFill;
   public Setting<Float> blueFill;
   public Setting<Float> PIOutline;
   public Setting<Float> duplicateOutline;
   public Setting<Float> speedFill;
   public Setting<Color> thirdColorImgFIll;
   private final Setting<Shaders.XPBl> xpBottle;
   public Setting<Float> greenOutline;
   public Setting<Integer> GSTARTFill;
   public Setting<Integer> BSTARTOutline;
   private final Setting<Shaders.Itemsl> items;
   public Setting<Color> secondColorImgFill;
   private final Setting<Shaders.Mob1> mob;
   public Setting<Float> creepyFill;
   public Setting<Integer> RSTARTFill;
   public Setting<Color> thirdColorImgOutline;
   public Setting<Float> tauFill;
   public Setting<Integer> redFill;
   public Setting<Float> speedOutline;
   public Setting<Integer> volumStepsOutline;
   public Setting<Integer> BSTARTFIll;
   public Setting<Integer> iterationsFill;
   public Setting<Float> blueOutline;
   public Setting<Integer> redOutline;
   public boolean notShader;
   public Setting<Float> moreGradientOutline;
   public Setting<Float> distfadingFill;
   public Setting<Integer> iterationsOutline;
   public Setting<Float> titleFill;
   public Setting<Color> colorImgOutline;
   public Setting<Float> minRange;
   public Setting<Integer> alphaValue;
   public Setting<Float> saturationFill;
   public Setting<Float> formuparam2Fill;
   public Setting<Float> quality;
   public Setting<Float> radius;
   public Setting<Float> alphaOutline;
   public Setting<Float> distfadingOutline;
   public Setting<Float> maxRange;
   private final Setting<Boolean> Fpreset;
   public Setting<Float> rad;
   private final Setting<Boolean> rangeCheck;
   public Setting<Float> creepyOutline;

   private boolean lambda$new$44(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Circle) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$25(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Smoke) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$31(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.Astral && this.fillShader.getValue() != Shaders.fillShadermode.Smoke) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$38(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$42(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() != Shaders.glowESPmode.Astral && this.glowESP.getValue() != Shaders.glowESPmode.Gradient) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.Astral && this.glowESP.getValue() != Shaders.glowESPmode.Astral) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$26(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$30(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$29(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$22(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$15(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static void lambda$renderPlayersFill$56(float var0, Entity var1) {
      mc.getRenderManager().renderEntityStatic(var1, var0, true);
   }

   private boolean lambda$new$32(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$34(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Aqua) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$43(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$53(Color var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.Smoke && this.glowESP.getValue() != Shaders.glowESPmode.Smoke) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$36(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Smoke) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   void getFill() {
      switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$render$Shaders$fillShadermode[this.fillShader.getValue().ordinal()]) {
         case 1:
            FlowShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var6 = false;
            break;
         case 2:
            AquaShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var5 = false;
            break;
         case 3:
            SmokeShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var4 = false;
            break;
         case 4:
            RainbowCubeShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var3 = false;
            break;
         case 5:
            GradientShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var2 = false;
            break;
         case 6:
            FillShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var1 = false;
            break;
         case 7:
            CircleShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
            boolean var10000 = false;
            break;
         case 8:
            PhobosShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
      }
   }

   @Override
   public void onTick() {
      if (this.Fpreset.getValue()) {
         this.fillShader.setValue(Shaders.fillShadermode.None);
         this.glowESP.setValue(Shaders.glowESPmode.Gradient);
         this.player.setValue(Shaders.Player1.Outline);
         this.crystal.setValue(Shaders.Crystal1.Outline);
         this.duplicateOutline.setValue(2.0F);
         this.speedOutline.setValue(30.0F);
         this.quality.setValue(0.6F);
         this.radius.setValue(1.7F);
         this.creepyOutline.setValue(1.0F);
         this.moreGradientOutline.setValue(1.0F);
         this.Fpreset.setValue(false);
      }

      if (this.default1.getValue()) {
         this.fillShader.setValue(Shaders.fillShadermode.None);
         this.glowESP.setValue(Shaders.glowESPmode.None);
         this.rangeCheck.setValue(true);
         this.maxRange.setValue(35.0F);
         this.minRange.setValue(0.0F);
         this.crystal.setValue(Shaders.Crystal1.None);
         this.player.setValue(Shaders.Player1.None);
         this.mob.setValue(Shaders.Mob1.None);
         this.items.setValue(Shaders.Itemsl.None);
         this.fadeFill.setValue(false);
         this.fadeOutline.setValue(false);
         this.duplicateOutline.setValue(1.0F);
         this.duplicateFill.setValue(1.0F);
         this.speedOutline.setValue(10.0F);
         this.speedFill.setValue(10.0F);
         this.quality.setValue(1.0F);
         this.radius.setValue(1.0F);
         this.rad.setValue(0.75F);
         this.PI.setValue((float) Math.PI);
         this.saturationFill.setValue(0.4F);
         this.distfadingFill.setValue(0.56F);
         this.titleFill.setValue(0.45F);
         this.stepSizeFill.setValue(0.2F);
         this.volumStepsFill.setValue(10.0F);
         this.zoomFill.setValue(3.9F);
         this.formuparam2Fill.setValue(0.89F);
         this.saturationOutline.setValue(0.4F);
         this.maxEntities.setValue(100);
         this.iterationsFill.setValue(4);
         this.redFill.setValue(0);
         this.MaxIterFill.setValue(5);
         this.NUM_OCTAVESFill.setValue(5);
         this.BSTARTFIll.setValue(0);
         this.GSTARTFill.setValue(0);
         this.RSTARTFill.setValue(0);
         this.WaveLenghtFIll.setValue(555);
         this.volumStepsOutline.setValue(10);
         this.iterationsOutline.setValue(4);
         this.MaxIterOutline.setValue(5);
         this.NUM_OCTAVESOutline.setValue(5);
         this.BSTARTOutline.setValue(0);
         this.GSTARTOutline.setValue(0);
         this.RSTARTOutline.setValue(0);
         this.alphaValue.setValue(255);
         this.WaveLenghtOutline.setValue(555);
         this.redOutline.setValue(0);
         this.alphaFill.setValue(1.0F);
         this.blueFill.setValue(0.0F);
         this.greenFill.setValue(0.0F);
         this.tauFill.setValue((float) (Math.PI * 2));
         this.creepyFill.setValue(1.0F);
         this.moreGradientFill.setValue(1.0F);
         this.distfadingOutline.setValue(0.56F);
         this.titleOutline.setValue(0.45F);
         this.stepSizeOutline.setValue(0.19F);
         this.zoomOutline.setValue(3.9F);
         this.formuparam2Outline.setValue(0.89F);
         this.alphaOutline.setValue(1.0F);
         this.blueOutline.setValue(0.0F);
         this.greenOutline.setValue(0.0F);
         this.tauOutline.setValue(0.0F);
         this.creepyOutline.setValue(1.0F);
         this.moreGradientOutline.setValue(1.0F);
         this.radOutline.setValue(0.75F);
         this.PIOutline.setValue((float) Math.PI);
         this.default1.setValue(false);
      }
   }

   private boolean lambda$new$12(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean lambda$renderPlayersFill$55(boolean var0, double var1, double var3, Entity var5) {
      if (!var0) {
         return true;
      } else {
         double var6 = mc.player.getDistanceSq(var5);
         boolean var10000;
         if (var6 > var1 && var6 < var3) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   @SubscribeEvent
   public void onRenderGameOverlay(RenderGameOverlayEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getType() == ElementType.HOTBAR) {
            if (mc.world == null || mc.player == null) {
               return;
            }

            GlStateManager.pushMatrix();
            this.notShader = false;
            Color var2 = new Color(
               this.colorImgFill.getValue().getRed(),
               this.colorImgFill.getValue().getGreen(),
               this.colorImgFill.getValue().getBlue(),
               this.colorImgFill.getValue().getAlpha()
            );
            Color var3 = new Color(
               this.colorESP.getValue().getRed(), this.colorESP.getValue().getGreen(), this.colorESP.getValue().getBlue(), this.colorESP.getValue().getAlpha()
            );
            Color var4 = new Color(
               this.secondColorImgFill.getValue().getRed(),
               this.secondColorImgFill.getValue().getGreen(),
               this.secondColorImgFill.getValue().getBlue(),
               this.secondColorImgFill.getValue().getAlpha()
            );
            Color var5 = new Color(
               this.thirdColorImgOutline.getValue().getRed(),
               this.thirdColorImgOutline.getValue().getGreen(),
               this.thirdColorImgOutline.getValue().getBlue(),
               this.thirdColorImgOutline.getValue().getAlpha()
            );
            Color var6 = new Color(
               this.thirdColorImgFIll.getValue().getRed(),
               this.thirdColorImgFIll.getValue().getGreen(),
               this.thirdColorImgFIll.getValue().getBlue(),
               this.thirdColorImgFIll.getValue().getAlpha()
            );
            Color var7 = new Color(
               this.colorImgOutline.getValue().getRed(),
               this.colorImgOutline.getValue().getGreen(),
               this.colorImgOutline.getValue().getBlue(),
               this.colorImgOutline.getValue().getAlpha()
            );
            if (this.glowESP.getValue() != Shaders.glowESPmode.None && this.fillShader.getValue() != Shaders.fillShadermode.None) {
               this.getFill();
               switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$render$Shaders$fillShadermode[this.fillShader.getValue().ordinal()]) {
                  case 1:
                     FlowShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     FlowShader var28 = FlowShader.INSTANCE;
                     Color var38 = Color.WHITE;
                     float var41 = this.duplicateFill.getValue();
                     float var43 = this.redFill.getValue().floatValue();
                     float var46 = this.greenFill.getValue();
                     float var49 = this.blueFill.getValue();
                     float var52 = this.alphaFill.getValue();
                     int var55 = this.iterationsFill.getValue();
                     float var58 = this.formuparam2Fill.getValue();
                     float var61 = this.zoomFill.getValue();
                     float var64 = this.volumStepsFill.getValue();
                     float var67 = this.stepSizeFill.getValue();
                     float var70 = this.titleFill.getValue();
                     float var73 = this.distfadingFill.getValue();
                     float var76 = this.saturationFill.getValue();
                     byte var80;
                     if (this.fadeFill.getValue()) {
                        var80 = 1;
                        boolean var82 = false;
                     } else {
                        var80 = 0;
                     }

                     var28.stopDraw(var38, 1.0F, 1.0F, var41, var43, var46, var49, var52, var55, var58, var61, var64, var67, var70, var73, var76, 0.0F, var80);
                     FlowShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var29 = false;
                     break;
                  case 2:
                     AquaShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     AquaShader.INSTANCE
                        .stopDraw(var2, 1.0F, 1.0F, this.duplicateFill.getValue(), this.MaxIterFill.getValue(), (double)this.tauFill.getValue().floatValue());
                     AquaShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var27 = false;
                     break;
                  case 3:
                     SmokeShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     SmokeShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, this.duplicateFill.getValue(), var2, var4, var6, this.NUM_OCTAVESFill.getValue());
                     SmokeShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var26 = false;
                     break;
                  case 4:
                     RainbowCubeShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     RainbowCubeShader.INSTANCE
                        .stopDraw(
                           Color.WHITE,
                           1.0F,
                           1.0F,
                           this.duplicateFill.getValue(),
                           var2,
                           this.WaveLenghtFIll.getValue(),
                           this.RSTARTFill.getValue(),
                           this.GSTARTFill.getValue(),
                           this.BSTARTFIll.getValue()
                        );
                     RainbowCubeShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var25 = false;
                     break;
                  case 5:
                     GradientShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     GradientShader.INSTANCE
                        .stopDraw(
                           var3,
                           1.0F,
                           1.0F,
                           this.duplicateFill.getValue(),
                           this.moreGradientFill.getValue(),
                           this.creepyFill.getValue(),
                           this.alphaFill.getValue(),
                           this.NUM_OCTAVESFill.getValue()
                        );
                     GradientShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var24 = false;
                     break;
                  case 6:
                     FillShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     FillShader.INSTANCE.stopDraw(var2);
                     FillShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var23 = false;
                     break;
                  case 7:
                     CircleShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     CircleShader.INSTANCE.stopDraw(this.duplicateFill.getValue(), var2, this.PI.getValue(), this.rad.getValue());
                     CircleShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var22 = false;
                     break;
                  case 8:
                     PhobosShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     PhobosShader.INSTANCE
                        .stopDraw(var2, 1.0F, 1.0F, this.duplicateFill.getValue(), this.MaxIterFill.getValue(), (double)this.tauFill.getValue().floatValue());
                     PhobosShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
               }

               switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$render$Shaders$glowESPmode[this.glowESP.getValue().ordinal()]) {
                  case 1:
                     GlowShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     GlowShader.INSTANCE.stopDraw(var3, this.radius.getValue(), this.quality.getValue(), false, this.alphaValue.getValue());
                     boolean var36 = false;
                     break;
                  case 2:
                     RainbowCubeOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     RainbowCubeOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           var7,
                           this.WaveLenghtOutline.getValue(),
                           this.RSTARTOutline.getValue(),
                           this.GSTARTOutline.getValue(),
                           this.BSTARTOutline.getValue()
                        );
                     RainbowCubeOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var35 = false;
                     break;
                  case 3:
                     GradientOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     GradientOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           this.moreGradientOutline.getValue(),
                           this.creepyOutline.getValue(),
                           this.alphaOutline.getValue(),
                           this.NUM_OCTAVESOutline.getValue()
                        );
                     GradientOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var34 = false;
                     break;
                  case 4:
                     AstralOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     AstralOutlineShader var32 = AstralOutlineShader.INSTANCE;
                     float var39 = this.radius.getValue();
                     float var40 = this.quality.getValue();
                     int var44 = this.alphaValue.getValue();
                     float var47 = this.duplicateOutline.getValue();
                     float var50 = this.redOutline.getValue().floatValue();
                     float var53 = this.greenOutline.getValue();
                     float var56 = this.blueOutline.getValue();
                     float var59 = this.alphaOutline.getValue();
                     int var62 = this.iterationsOutline.getValue();
                     float var65 = this.formuparam2Outline.getValue();
                     float var68 = this.zoomOutline.getValue();
                     float var71 = (float)this.volumStepsOutline.getValue().intValue();
                     float var74 = this.stepSizeOutline.getValue();
                     float var77 = this.titleOutline.getValue();
                     float var78 = this.distfadingOutline.getValue();
                     float var81 = this.saturationOutline.getValue();
                     byte var83;
                     if (this.fadeOutline.getValue()) {
                        var83 = 1;
                        boolean var84 = false;
                     } else {
                        var83 = 0;
                     }

                     var32.stopDraw(
                        var3,
                        var39,
                        var40,
                        false,
                        var44,
                        var47,
                        var50,
                        var53,
                        var56,
                        var59,
                        var62,
                        var65,
                        var68,
                        var71,
                        var74,
                        var77,
                        var78,
                        var81,
                        0.0F,
                        var83
                     );
                     AstralOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var33 = false;
                     break;
                  case 5:
                     AquaOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     AquaOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           this.MaxIterOutline.getValue(),
                           (double)this.tauOutline.getValue().floatValue()
                        );
                     AquaOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var31 = false;
                     break;
                  case 6:
                     CircleOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     CircleOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           this.PIOutline.getValue(),
                           this.radOutline.getValue()
                        );
                     CircleOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var30 = false;
                     break;
                  case 7:
                     SmokeOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     SmokeOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           var4,
                           var5,
                           this.NUM_OCTAVESOutline.getValue()
                        );
                     SmokeOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
               }

               boolean var37 = false;
            } else {
               switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$render$Shaders$glowESPmode[this.glowESP.getValue().ordinal()]) {
                  case 1:
                     GlowShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     GlowShader.INSTANCE.stopDraw(var3, this.radius.getValue(), this.quality.getValue(), false, this.alphaValue.getValue());
                     boolean var13 = false;
                     break;
                  case 2:
                     RainbowCubeOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     RainbowCubeOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           var7,
                           this.WaveLenghtOutline.getValue(),
                           this.RSTARTOutline.getValue(),
                           this.GSTARTOutline.getValue(),
                           this.BSTARTOutline.getValue()
                        );
                     RainbowCubeOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var12 = false;
                     break;
                  case 3:
                     GradientOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     GradientOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           this.moreGradientOutline.getValue(),
                           this.creepyOutline.getValue(),
                           this.alphaOutline.getValue(),
                           this.NUM_OCTAVESOutline.getValue()
                        );
                     GradientOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var11 = false;
                     break;
                  case 4:
                     AstralOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     AstralOutlineShader var9 = AstralOutlineShader.INSTANCE;
                     float var10002 = this.radius.getValue();
                     float var10003 = this.quality.getValue();
                     int var10005 = this.alphaValue.getValue();
                     float var10006 = this.duplicateOutline.getValue();
                     float var10007 = this.redOutline.getValue().floatValue();
                     float var10008 = this.greenOutline.getValue();
                     float var10009 = this.blueOutline.getValue();
                     float var10010 = this.alphaOutline.getValue();
                     int var10011 = this.iterationsOutline.getValue();
                     float var10012 = this.formuparam2Outline.getValue();
                     float var10013 = this.zoomOutline.getValue();
                     float var10014 = (float)this.volumStepsOutline.getValue().intValue();
                     float var10015 = this.stepSizeOutline.getValue();
                     float var10016 = this.titleOutline.getValue();
                     float var10017 = this.distfadingOutline.getValue();
                     float var10018 = this.saturationOutline.getValue();
                     byte var10020;
                     if (this.fadeOutline.getValue()) {
                        var10020 = 1;
                        boolean var10021 = false;
                     } else {
                        var10020 = 0;
                     }

                     var9.stopDraw(
                        var3,
                        var10002,
                        var10003,
                        false,
                        var10005,
                        var10006,
                        var10007,
                        var10008,
                        var10009,
                        var10010,
                        var10011,
                        var10012,
                        var10013,
                        var10014,
                        var10015,
                        var10016,
                        var10017,
                        var10018,
                        0.0F,
                        var10020
                     );
                     AstralOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var10 = false;
                     break;
                  case 5:
                     AquaOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     AquaOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           this.MaxIterOutline.getValue(),
                           (double)this.tauOutline.getValue().floatValue()
                        );
                     AquaOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var8 = false;
                     break;
                  case 6:
                     CircleOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     CircleOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           this.PIOutline.getValue(),
                           this.radOutline.getValue()
                        );
                     CircleOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
                     boolean var10000 = false;
                     break;
                  case 7:
                     SmokeOutlineShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersOutline(var1.getPartialTicks());
                     SmokeOutlineShader.INSTANCE
                        .stopDraw(
                           var3,
                           this.radius.getValue(),
                           this.quality.getValue(),
                           false,
                           this.alphaValue.getValue(),
                           this.duplicateOutline.getValue(),
                           var4,
                           var5,
                           this.NUM_OCTAVESOutline.getValue()
                        );
                     SmokeOutlineShader.INSTANCE.update((double)(this.speedOutline.getValue() / 1000.0F));
               }

               switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$render$Shaders$fillShadermode[this.fillShader.getValue().ordinal()]) {
                  case 1:
                     FlowShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     FlowShader var20 = FlowShader.INSTANCE;
                     Color var10001 = Color.WHITE;
                     float var10004 = this.duplicateFill.getValue();
                     float var42 = this.redFill.getValue().floatValue();
                     float var45 = this.greenFill.getValue();
                     float var48 = this.blueFill.getValue();
                     float var51 = this.alphaFill.getValue();
                     int var54 = this.iterationsFill.getValue();
                     float var57 = this.formuparam2Fill.getValue();
                     float var60 = this.zoomFill.getValue();
                     float var63 = this.volumStepsFill.getValue();
                     float var66 = this.stepSizeFill.getValue();
                     float var69 = this.titleFill.getValue();
                     float var72 = this.distfadingFill.getValue();
                     float var75 = this.saturationFill.getValue();
                     byte var79;
                     if (this.fadeFill.getValue()) {
                        var79 = 1;
                        boolean var10019 = false;
                     } else {
                        var79 = 0;
                     }

                     var20.stopDraw(
                        var10001, 1.0F, 1.0F, var10004, var42, var45, var48, var51, var54, var57, var60, var63, var66, var69, var72, var75, 0.0F, var79
                     );
                     FlowShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var21 = false;
                     break;
                  case 2:
                     AquaShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     AquaShader.INSTANCE
                        .stopDraw(var2, 1.0F, 1.0F, this.duplicateFill.getValue(), this.MaxIterFill.getValue(), (double)this.tauFill.getValue().floatValue());
                     AquaShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var19 = false;
                     break;
                  case 3:
                     SmokeShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     SmokeShader.INSTANCE.stopDraw(Color.WHITE, 1.0F, 1.0F, this.duplicateFill.getValue(), var2, var4, var6, this.NUM_OCTAVESFill.getValue());
                     SmokeShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var18 = false;
                     break;
                  case 4:
                     RainbowCubeShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     RainbowCubeShader.INSTANCE
                        .stopDraw(
                           Color.WHITE,
                           1.0F,
                           1.0F,
                           this.duplicateFill.getValue(),
                           var2,
                           this.WaveLenghtFIll.getValue(),
                           this.RSTARTFill.getValue(),
                           this.GSTARTFill.getValue(),
                           this.BSTARTFIll.getValue()
                        );
                     RainbowCubeShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var17 = false;
                     break;
                  case 5:
                     GradientShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     GradientShader.INSTANCE
                        .stopDraw(
                           var3,
                           1.0F,
                           1.0F,
                           this.duplicateFill.getValue(),
                           this.moreGradientFill.getValue(),
                           this.creepyFill.getValue(),
                           this.alphaFill.getValue(),
                           this.NUM_OCTAVESFill.getValue()
                        );
                     GradientShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var16 = false;
                     break;
                  case 6:
                     FillShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     FillShader.INSTANCE.stopDraw(var2);
                     FillShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var15 = false;
                     break;
                  case 7:
                     CircleShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     CircleShader.INSTANCE.stopDraw(this.duplicateFill.getValue(), var2, this.PI.getValue(), this.rad.getValue());
                     CircleShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
                     boolean var14 = false;
                     break;
                  case 8:
                     PhobosShader.INSTANCE.startDraw(var1.getPartialTicks());
                     this.renderPlayersFill(var1.getPartialTicks());
                     PhobosShader.INSTANCE
                        .stopDraw(var2, 1.0F, 1.0F, this.duplicateFill.getValue(), this.MaxIterFill.getValue(), (double)this.tauFill.getValue().floatValue());
                     PhobosShader.INSTANCE.update((double)(this.speedFill.getValue() / 1000.0F));
               }
            }

            this.notShader = true;
            GlStateManager.popMatrix();
         }
      }
   }

   private boolean lambda$new$52(Color var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.Smoke && this.glowESP.getValue() != Shaders.glowESPmode.Smoke) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$47(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Gradient) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$37(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Aqua) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$18(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.Astral && this.glowESP.getValue() != Shaders.glowESPmode.Astral) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public Shaders() {
      super("Shaders", "test", Category.RENDER);
      this.crystal = this.add(new Setting<>("Crystals", Shaders.Crystal1.None));
      this.player = this.add(new Setting<>("Players", Shaders.Player1.None));
      this.mob = this.add(new Setting<>("Mobs", Shaders.Mob1.None));
      this.items = this.add(new Setting<>("Items", Shaders.Itemsl.None));
      this.xpOrb = this.add(new Setting<>("XP", Shaders.XPl.None));
      this.xpBottle = this.add(new Setting<>("XPBottle", Shaders.XPBl.None));
      this.enderPearl = this.add(new Setting<>("EnderPearl", Shaders.EPl.None));
      this.rangeCheck = this.add(new Setting<>("Range Check", true));
      this.maxRange = this.add(new Setting<>("Max Range", 35.0F, 10.0F, 100.0F, this::lambda$new$0));
      this.minRange = this.add(new Setting<>("Min range", 0.0F, 0.0F, 5.0F, this::lambda$new$1));
      this.default1 = this.add(new Setting<>("Reset Setting", false));
      this.Fpreset = this.add(new Setting<>("FutureRainbow Preset", false));
      this.fadeFill = this.add(new Setting<>("Fade Fill", Boolean.FALSE, this::lambda$new$2));
      this.fadeOutline = this.add(new Setting<>("FadeOL Fill", Boolean.FALSE, this::lambda$new$3));
      this.duplicateOutline = this.add(new Setting<>("duplicateOutline", 1.0F, 0.0F, 20.0F));
      this.duplicateFill = this.add(new Setting<>("Duplicate Fill", 1.0F, 0.0F, 5.0F));
      this.speedOutline = this.add(new Setting<>("Speed Outline", 10.0F, 1.0F, 100.0F));
      this.speedFill = this.add(new Setting<>("Speed Fill", 10.0F, 1.0F, 100.0F));
      this.quality = this.add(new Setting<>("Shader Quality", 1.0F, 0.0F, 20.0F));
      this.radius = this.add(new Setting<>("Shader Radius", 1.0F, 0.0F, 5.0F));
      this.rad = this.add(new Setting<>("RAD Fill", 0.75F, 0.0F, 5.0F, this::lambda$new$4));
      this.PI = this.add(new Setting<>("PI Fill", (float) Math.PI, 0.0F, 10.0F, this::lambda$new$5));
      this.saturationFill = this.add(new Setting<>("saturation", 0.4F, 0.0F, 3.0F, this::lambda$new$6));
      this.distfadingFill = this.add(new Setting<>("distfading", 0.56F, 0.0F, 1.0F, this::lambda$new$7));
      this.titleFill = this.add(new Setting<>("Tile", 0.45F, 0.0F, 1.3F, this::lambda$new$8));
      this.stepSizeFill = this.add(new Setting<>("Step Size", 0.2F, 0.0F, 0.7F, this::lambda$new$9));
      this.volumStepsFill = this.add(new Setting<>("Volum Steps", 10.0F, 0.0F, 10.0F, this::lambda$new$10));
      this.zoomFill = this.add(new Setting<>("Zoom", 3.9F, 0.0F, 20.0F, this::lambda$new$11));
      this.formuparam2Fill = this.add(new Setting<>("formuparam2", 0.89F, 0.0F, 1.5F, this::lambda$new$12));
      this.saturationOutline = this.add(new Setting<>("saturation", 0.4F, 0.0F, 3.0F, this::lambda$new$13));
      this.maxEntities = this.add(new Setting<>("Max Entities", 100, 10, 500));
      this.iterationsFill = this.add(new Setting<>("Iteration", 4, 3, 20, this::lambda$new$14));
      this.redFill = this.add(new Setting<>("Tick Regen", 0, 0, 100, this::lambda$new$15));
      this.MaxIterFill = this.add(new Setting<>("Max Iter", 5, 0, 30, this::lambda$new$16));
      this.NUM_OCTAVESFill = this.add(new Setting<>("NUM_OCTAVES", 5, 1, 30, this::lambda$new$17));
      this.BSTARTFIll = this.add(new Setting<>("BSTART", 0, 0, 1000, this::lambda$new$18));
      this.GSTARTFill = this.add(new Setting<>("GSTART", 0, 0, 1000, this::lambda$new$19));
      this.RSTARTFill = this.add(new Setting<>("RSTART", 0, 0, 1000, this::lambda$new$20));
      this.WaveLenghtFIll = this.add(new Setting<>("Wave Lenght", 555, 0, 2000, this::lambda$new$21));
      this.volumStepsOutline = this.add(new Setting<>("Volum Steps", 10, 0, 10, this::lambda$new$22));
      this.iterationsOutline = this.add(new Setting<>("Iteration", 4, 3, 20, this::lambda$new$23));
      this.MaxIterOutline = this.add(new Setting<>("Max Iter", 5, 0, 30, this::lambda$new$24));
      this.NUM_OCTAVESOutline = this.add(new Setting<>("NUM_OCTAVES", 5, 1, 30, this::lambda$new$25));
      this.BSTARTOutline = this.add(new Setting<>("BSTART", 0, 0, 1000, this::lambda$new$26));
      this.GSTARTOutline = this.add(new Setting<>("GSTART", 0, 0, 1000, this::lambda$new$27));
      this.RSTARTOutline = this.add(new Setting<>("RSTART", 0, 0, 1000, this::lambda$new$28));
      this.alphaValue = this.add(new Setting<>("Alpha Outline", 255, 0, 255));
      this.WaveLenghtOutline = this.add(new Setting<>("Wave Lenght", 555, 0, 2000, this::lambda$new$29));
      this.redOutline = this.add(new Setting<>("Red", 0, 0, 100, this::lambda$new$30));
      this.alphaFill = this.add(new Setting<>("AlphaF", 1.0F, 0.0F, 1.0F, this::lambda$new$31));
      this.blueFill = this.add(new Setting<>("BlueF", 0.0F, 0.0F, 5.0F, this::lambda$new$32));
      this.greenFill = this.add(new Setting<>("GreenF", 0.0F, 0.0F, 5.0F, this::lambda$new$33));
      this.tauFill = this.add(new Setting<>("TAU", (float) (Math.PI * 2), 0.0F, 20.0F, this::lambda$new$34));
      this.creepyFill = this.add(new Setting<>("Creepy", 1.0F, 0.0F, 20.0F, this::lambda$new$35));
      this.moreGradientFill = this.add(new Setting<>("More Gradient", 1.0F, 0.0F, 10.0, this::lambda$new$36));
      this.distfadingOutline = this.add(new Setting<>("distfading", 0.56F, 0.0F, 1.0F, this::lambda$new$37));
      this.titleOutline = this.add(new Setting<>("Tile", 0.45F, 0.0F, 1.3F, this::lambda$new$38));
      this.stepSizeOutline = this.add(new Setting<>("Step Size", 0.19F, 0.0F, 0.7F, this::lambda$new$39));
      this.zoomOutline = this.add(new Setting<>("Zoom", 3.9F, 0.0F, 20.0F, this::lambda$new$40));
      this.formuparam2Outline = this.add(new Setting<>("formuparam2", 0.89F, 0.0F, 1.5F, this::lambda$new$41));
      this.alphaOutline = this.add(new Setting<>("Alpha", 1.0F, 0.0F, 1.0F, this::lambda$new$42));
      this.blueOutline = this.add(new Setting<>("Blue", 0.0F, 0.0F, 5.0F, this::lambda$new$43));
      this.greenOutline = this.add(new Setting<>("Green", 0.0F, 0.0F, 5.0F, this::lambda$new$44));
      this.tauOutline = this.add(new Setting<>("TAU", (float) (Math.PI * 2), 0.0F, 20.0F, this::lambda$new$45));
      this.creepyOutline = this.add(new Setting<>("Gradient Creepy", 1.0F, 0.0F, 20.0F, this::lambda$new$46));
      this.moreGradientOutline = this.add(new Setting<>("More Gradient", 1.0F, 0.0F, 10.0F, this::lambda$new$47));
      this.radOutline = this.add(new Setting<>("RAD Outline", 0.75F, 0.0F, 5.0F, this::lambda$new$48));
      this.PIOutline = this.add(new Setting<>("PI Outline", (float) Math.PI, 0.0F, 10.0F, this::lambda$new$49));
      this.colorImgOutline = this.add(new Setting<>("ColorImgOutline", new Color(0, 0, 0, 255), this::lambda$new$50));
      this.thirdColorImgOutline = this.add(new Setting<>("ThirdColorImg", new Color(0, 0, 0, 255), this::lambda$new$51));
      this.colorESP = this.add(new Setting<>("ColorESP", new Color(0, 0, 0, 255)));
      this.colorImgFill = this.add(new Setting<>("ColorImgFill", new Color(0, 0, 0, 255)));
      this.thirdColorImgFIll = this.add(new Setting<>("SmokeImgFill", new Color(0, 0, 0, 255), this::lambda$new$52));
      this.secondColorImgFill = this.add(new Setting<>("SmokeFill", new Color(0, 0, 0, 255), this::lambda$new$53));
      this.notShader = true;
      INSTANCE = this;
   }

   private static void lambda$renderPlayersOutline$59(float var0, Entity var1) {
      mc.getRenderManager().renderEntityStatic(var1, var0, true);
   }

   private boolean lambda$new$6(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$28(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$17(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Smoke) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Object var1) {
      return this.rangeCheck.getValue();
   }

   private static boolean lambda$renderPlayersOutline$58(boolean var0, double var1, double var3, Entity var5) {
      if (!var0) {
         return true;
      } else {
         double var6 = mc.player.getDistanceSq(var5);
         boolean var10000;
         if ((!(var6 > var1) || !(var6 < var3)) && var5.getEntityId() != -1000) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var10001 = false;
         }

         return var10000;
      }
   }

   void renderPlayersFill(float var1) {
      boolean var2 = this.rangeCheck.getValue();
      double var3 = (double)(this.minRange.getValue() * this.minRange.getValue());
      double var5 = (double)(this.maxRange.getValue() * this.maxRange.getValue());
      AtomicInteger var7 = new AtomicInteger();
      int var8 = this.maxEntities.getValue();
      Minecraft var10000 = mc;

      try {
         var10000.world
            .loadedEntityList
            .stream()
            .filter(this::lambda$renderPlayersFill$54)
            .filter(Shaders::lambda$renderPlayersFill$55)
            .forEach(Shaders::lambda$renderPlayersFill$56);
      } catch (Exception var10) {
         return;
      }

      boolean var11 = false;
   }

   private boolean lambda$new$13(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$46(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Gradient) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$39(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$49(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Circle) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$33(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$45(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Aqua) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$renderPlayersFill$54(AtomicInteger var1, int var2, Entity var3) {
      if (var1.getAndIncrement() > var2) {
         return false;
      } else {
         boolean var10000;
         if (var3 instanceof EntityPlayer) {
            if (this.player.getValue() != Shaders.Player1.Fill && this.player.getValue() != Shaders.Player1.Both
               || var3 == mc.player && mc.gameSettings.thirdPersonView == 0) {
               var10000 = false;
               boolean var4 = false;
            } else {
               var10000 = true;
               boolean var10001 = false;
            }
         } else if (var3 instanceof EntityEnderPearl) {
            if (this.enderPearl.getValue() != Shaders.EPl.Fill && this.enderPearl.getValue() != Shaders.EPl.Both) {
               var10000 = false;
               boolean var6 = false;
            } else {
               var10000 = true;
               boolean var5 = false;
            }
         } else if (var3 instanceof EntityExpBottle) {
            if (this.xpBottle.getValue() != Shaders.XPBl.Fill && this.xpBottle.getValue() != Shaders.XPBl.Both) {
               var10000 = false;
               boolean var8 = false;
            } else {
               var10000 = true;
               boolean var7 = false;
            }
         } else if (var3 instanceof EntityXPOrb) {
            if (this.xpOrb.getValue() != Shaders.XPl.Fill && this.xpOrb.getValue() != Shaders.XPl.Both) {
               var10000 = false;
               boolean var10 = false;
            } else {
               var10000 = true;
               boolean var9 = false;
            }
         } else if (var3 instanceof EntityItem) {
            if (this.items.getValue() != Shaders.Itemsl.Fill && this.items.getValue() != Shaders.Itemsl.Both) {
               var10000 = false;
               boolean var12 = false;
            } else {
               var10000 = true;
               boolean var11 = false;
            }
         } else if (var3 instanceof EntityCreature) {
            if (this.mob.getValue() != Shaders.Mob1.Fill && this.mob.getValue() != Shaders.Mob1.Both) {
               var10000 = false;
               boolean var14 = false;
            } else {
               var10000 = true;
               boolean var13 = false;
            }
         } else if (!(var3 instanceof EntityEnderCrystal)
            || this.crystal.getValue() != Shaders.Crystal1.Fill && this.crystal.getValue() != Shaders.Crystal1.Both) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var15 = false;
         }

         return var10000;
      }
   }

   private boolean lambda$new$4(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Circle) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$14(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$19(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$21(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Object var1) {
      return this.rangeCheck.getValue();
   }

   private boolean lambda$new$51(Color var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.Smoke && this.glowESP.getValue() != Shaders.glowESPmode.Smoke) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   void renderPlayersOutline(float var1) {
      boolean var2 = this.rangeCheck.getValue();
      double var3 = (double)(this.minRange.getValue() * this.minRange.getValue());
      double var5 = (double)(this.maxRange.getValue() * this.maxRange.getValue());
      AtomicInteger var7 = new AtomicInteger();
      int var8 = this.maxEntities.getValue();
      mc.world.addEntityToWorld(-1000, new EntityXPOrb(mc.world, mc.player.posX, mc.player.posY + 1000000.0, mc.player.posZ, 1));
      mc.world
         .loadedEntityList
         .stream()
         .filter(this::lambda$renderPlayersOutline$57)
         .filter(Shaders::lambda$renderPlayersOutline$58)
         .forEach(Shaders::lambda$renderPlayersOutline$59);
      mc.world.removeEntityFromWorld(-1000);
      boolean var10000 = false;
   }

   private boolean lambda$new$41(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$27(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$35(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Smoke) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$48(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Circle) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$23(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$24(Integer var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Aqua) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$20(Integer var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.RainbowCube) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$50(Color var1) {
      boolean var10000;
      if (this.fillShader.getValue() != Shaders.fillShadermode.RainbowCube && this.glowESP.getValue() != Shaders.glowESPmode.RainbowCube) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$40(Object var1) {
      boolean var10000;
      if (this.glowESP.getValue() == Shaders.glowESPmode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$renderPlayersOutline$57(AtomicInteger var1, int var2, Entity var3) {
      if (var1.getAndIncrement() > var2) {
         return false;
      } else {
         boolean var10000;
         if (var3 instanceof EntityPlayer) {
            if (this.player.getValue() != Shaders.Player1.Outline && this.player.getValue() != Shaders.Player1.Both
               || var3 == mc.player && mc.gameSettings.thirdPersonView == 0) {
               var10000 = false;
               boolean var4 = false;
            } else {
               var10000 = true;
               boolean var10001 = false;
            }
         } else if (var3 instanceof EntityEnderPearl) {
            if (this.enderPearl.getValue() != Shaders.EPl.Outline && this.enderPearl.getValue() != Shaders.EPl.Both) {
               var10000 = false;
               boolean var6 = false;
            } else {
               var10000 = true;
               boolean var5 = false;
            }
         } else if (var3 instanceof EntityExpBottle) {
            if (this.xpBottle.getValue() != Shaders.XPBl.Outline && this.xpBottle.getValue() != Shaders.XPBl.Both) {
               var10000 = false;
               boolean var8 = false;
            } else {
               var10000 = true;
               boolean var7 = false;
            }
         } else if (var3 instanceof EntityXPOrb) {
            if (this.xpOrb.getValue() != Shaders.XPl.Outline && this.xpOrb.getValue() != Shaders.XPl.Both) {
               var10000 = false;
               boolean var10 = false;
            } else {
               var10000 = true;
               boolean var9 = false;
            }
         } else if (var3 instanceof EntityItem) {
            if (this.items.getValue() != Shaders.Itemsl.Outline && this.items.getValue() != Shaders.Itemsl.Both) {
               var10000 = false;
               boolean var12 = false;
            } else {
               var10000 = true;
               boolean var11 = false;
            }
         } else if (var3 instanceof EntityCreature) {
            if (this.mob.getValue() != Shaders.Mob1.Outline && this.mob.getValue() != Shaders.Mob1.Both) {
               var10000 = false;
               boolean var14 = false;
            } else {
               var10000 = true;
               boolean var13 = false;
            }
         } else if (!(var3 instanceof EntityEnderCrystal)
            || this.crystal.getValue() != Shaders.Crystal1.Outline && this.crystal.getValue() != Shaders.Crystal1.Both) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var15 = false;
         }

         return var10000;
      }
   }

   private boolean lambda$new$7(Object var1) {
      boolean var10000;
      if (this.fillShader.getValue() == Shaders.fillShadermode.Astral) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Crystal1 {
      None,
      Outline,
      Both,
      Fill;
      private static final Shaders.Crystal1[] $VALUES = new Shaders.Crystal1[]{None, Shaders.Crystal1.Fill, Shaders.Crystal1.Outline, Shaders.Crystal1.Both};
   }

   public static enum EPl {
      Outline,
      None,
      Fill,
      Both;
      private static final Shaders.EPl[] $VALUES = new Shaders.EPl[]{Shaders.EPl.None, Shaders.EPl.Fill, Outline, Shaders.EPl.Both};
   }

   public static enum Itemsl {
      None,
      Fill,
      Outline,
      Both;
      private static final Shaders.Itemsl[] $VALUES = new Shaders.Itemsl[]{None, Shaders.Itemsl.Fill, Shaders.Itemsl.Outline, Shaders.Itemsl.Both};
   }

   public static enum Mob1 {
      Outline,
      Both,
      Fill,
      None;
      private static final Shaders.Mob1[] $VALUES = new Shaders.Mob1[]{Shaders.Mob1.None, Fill, Outline, Both};
   }

   public static enum Player1 {
      Outline,
      Both,
      None,
      Fill;
      private static final Shaders.Player1[] $VALUES = new Shaders.Player1[]{None, Shaders.Player1.Fill, Outline, Both};
   }

   public static enum XPBl {
      Outline,
      Both,
      None,
      Fill;
      private static final Shaders.XPBl[] $VALUES = new Shaders.XPBl[]{Shaders.XPBl.None, Shaders.XPBl.Fill, Shaders.XPBl.Outline, Shaders.XPBl.Both};
   }

   public static enum XPl {
      Fill,
      Outline,
      Both,
      None;
      private static final Shaders.XPl[] $VALUES = new Shaders.XPl[]{Shaders.XPl.None, Fill, Shaders.XPl.Outline, Shaders.XPl.Both};
   }

   public static enum fillShadermode {
      Fill,
      Gradient,
      Aqua,
      None,
      RainbowCube,
      Smoke,
      Circle,
      Phobos,
      Astral;
      private static final Shaders.fillShadermode[] $VALUES = new Shaders.fillShadermode[]{
         Shaders.fillShadermode.Astral,
         Shaders.fillShadermode.Aqua,
         Shaders.fillShadermode.Smoke,
         Shaders.fillShadermode.RainbowCube,
         Shaders.fillShadermode.Gradient,
         Fill,
         Shaders.fillShadermode.Circle,
         Shaders.fillShadermode.Phobos,
         Shaders.fillShadermode.None
      };
   }

   public static enum glowESPmode {
      Color,
      Astral,
      Gradient,
      None,
      Smoke,
      RainbowCube,
      Aqua,
      Circle;
      private static final Shaders.glowESPmode[] $VALUES = new Shaders.glowESPmode[]{
         Shaders.glowESPmode.None,
         Shaders.glowESPmode.Color,
         Shaders.glowESPmode.Astral,
         Shaders.glowESPmode.RainbowCube,
         Shaders.glowESPmode.Gradient,
         Shaders.glowESPmode.Circle,
         Shaders.glowESPmode.Smoke,
         Shaders.glowESPmode.Aqua
      };
   }
}
