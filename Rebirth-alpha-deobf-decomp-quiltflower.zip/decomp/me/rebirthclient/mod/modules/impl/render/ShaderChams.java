package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.render.shaders.FramebufferShader;
import me.rebirthclient.api.util.render.shaders.ShaderMode;
import me.rebirthclient.asm.accessors.IEntityRenderer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

public class ShaderChams extends Module {
   private final Setting<Boolean> items;
   private final Setting<Boolean> crystals;
   private final Setting<Color> color;
   private final Setting<ShaderMode> shader = this.add(new Setting<>("Shader Mode", ShaderMode.Aqua));
   private final Setting<Boolean> fovOnly;
   public static ShaderChams INSTANCE;
   private final Setting<Float> radius;
   private final Setting<Float> maxSample;
   private final Setting<Float> divider;
   private final Setting<Boolean> xp;
   private final Setting<Boolean> self;
   private Boolean criticalSection;
   private final Setting<Integer> animationSpeed;
   private final Setting<Boolean> animation = this.add(new Setting<>("Animation", true));
   private final Setting<Boolean> players;
   private final Setting<Integer> range;

   private void lambda$onRenderWorldLastEvent$1(RenderWorldLastEvent var1, Entity var2) {
      if (!(var2.getDistance(mc.player) > (float)this.range.getValue().intValue())
         && (!this.fovOnly.getValue() || Managers.ROTATIONS.isInFov(var2.getPosition()))) {
         Vec3d var3 = EntityUtil.getInterpolatedRenderPos(var2, var1.getPartialTicks());
         if (var2 instanceof EntityPlayer) {
            ((EntityPlayer)var2).hurtTime = 0;
         }

         Render var4 = mc.getRenderManager().getEntityRenderObject(var2);
         if (var4 != null) {
            Render var10000 = var4;
            Entity var10001 = var2;
            Vec3d var10002 = var3;

            try {
               var10000.doRender(var10001, var10002.x, var3.y, var3.z, var2.rotationYaw, var1.getPartialTicks());
            } catch (Exception var6) {
               return;
            }

            boolean var7 = false;
         }
      }
   }

   private boolean lambda$onRenderWorldLastEvent$0(Entity var1) {
      boolean var10000;
      if (var1 == null
         || var1 == mc.player && var1 == mc.getRenderViewEntity()
         || mc.getRenderManager().getEntityRenderObject(var1) == null
         || (!(var1 instanceof EntityPlayer) || !this.players.getValue() || ((EntityPlayer)var1).isSpectator())
            && (!(var1 instanceof EntityEnderCrystal) || !this.crystals.getValue())
            && (!(var1 instanceof EntityExpBottle) || !this.xp.getValue())
            && (!(var1 instanceof EntityItem) || !this.items.getValue())) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public ShaderChams() {
      super("ShaderChams", "good render", Category.RENDER);
      this.animationSpeed = this.add(new Setting<>("Animation Speed", 1, 1, 10));
      this.radius = this.add(new Setting<>("Glow Radius", 3.3F, 1.0F, 10.0F));
      this.divider = this.add(new Setting<>("Glow Divider", 158.6F, 1.0F, 1000.0F));
      this.maxSample = this.add(new Setting<>("Glow MaxSample", 10.0F, 1.0F, 20.0F));
      this.players = this.add(new Setting<>("Player", false));
      this.crystals = this.add(new Setting<>("Crystal", false));
      this.xp = this.add(new Setting<>("Exp", false));
      this.items = this.add(new Setting<>("DroppedItem", false));
      this.self = this.add(new Setting<>("ItemShaderChams", true));
      this.fovOnly = this.add(new Setting<>("FOVOnly", false));
      this.color = this.add(new Setting<>("Color", new Color(-8553003, true)));
      this.range = this.add(new Setting<>("Range", 50, 5, 250));
      this.criticalSection = false;
      INSTANCE = this;
   }

   @Override
   public String getInfo() {
      return this.shader.getValue().getName();
   }

   @Override
   public void onLogin() {
      if (this.isOn()) {
         this.disable();
         this.enable();
      }
   }

   @SubscribeEvent
   public void onRenderWorldLastEvent(RenderWorldLastEvent var1) {
      if (!fullNullCheck()) {
         if (Display.isActive() || Display.isVisible()) {
            FramebufferShader var2 = this.shader.getValue().getShader();
            if (var2 == null) {
               return;
            }

            GL11.glBlendFunc(770, 771);
            var2.setShaderParams(
               this.animation.getValue(),
               this.animationSpeed.getValue(),
               this.color.getValue(),
               this.radius.getValue(),
               this.divider.getValue(),
               this.maxSample.getValue()
            );
            this.criticalSection = true;
            var2.startDraw(mc.getRenderPartialTicks());
            mc.world.loadedEntityList.stream().filter(this::lambda$onRenderWorldLastEvent$0).forEach(this::lambda$onRenderWorldLastEvent$1);
            if (this.self.getValue() && !BlockUtil.getBlock(EntityUtil.getPlayerPos().up()).equals(Blocks.WATER)) {
               ((IEntityRenderer)mc.entityRenderer).invokeRenderHand(mc.getRenderPartialTicks(), 2);
            }

            var2.stopDraw();
            this.criticalSection = false;
         }
      }
   }

   @SubscribeEvent
   public void onRenderHand(RenderHandEvent var1) {
      if (!fullNullCheck()) {
         if (!this.criticalSection && this.self.getValue()) {
            var1.setCanceled(true);
         }
      }
   }
}
