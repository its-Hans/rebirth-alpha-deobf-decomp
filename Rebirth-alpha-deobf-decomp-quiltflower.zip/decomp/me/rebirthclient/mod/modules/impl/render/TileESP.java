package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.tileentity.TileEntitySign;

public class TileESP extends Module {
   private int count;
   private final Setting<Boolean> signs;
   private final Setting<Boolean> eChests;
   private final Setting<Boolean> beds = this.add(new Setting<>("Beds", true));
   private final Setting<Boolean> shulkers;
   private final Setting<Boolean> dispensers;
   private final Setting<Boolean> hoppers;
   private final Setting<Boolean> chests = this.add(new Setting<>("Chests", true));
   private final Setting<Boolean> furnaces;

   public TileESP() {
      super("TileESP", "Highlights tile entities such as storages and signs", Category.RENDER);
      this.eChests = this.add(new Setting<>("EChests", true));
      this.shulkers = this.add(new Setting<>("Shulkers", true));
      this.signs = this.add(new Setting<>("Signs", true));
      this.dispensers = this.add(new Setting<>("Dispensers", true));
      this.hoppers = this.add(new Setting<>("Hoppers", true));
      this.furnaces = this.add(new Setting<>("Furnaces", true));
   }

   private Color getColor(TileEntity var1) {
      if (var1 instanceof TileEntityChest) {
         return new Color(155, 127, 77, 100);
      } else if (var1 instanceof TileEntityBed) {
         return new Color(190, 49, 49, 100);
      } else if (var1 instanceof TileEntityEnderChest) {
         return new Color(124, 37, 196, 100);
      } else if (var1 instanceof TileEntityShulkerBox) {
         return new Color(255, 1, 175, 100);
      } else {
         return !(var1 instanceof TileEntityFurnace) && !(var1 instanceof TileEntityDispenser) && !(var1 instanceof TileEntityHopper)
            ? new Color(255, 255, 255, 100)
            : new Color(150, 150, 150, 100);
      }
   }

   private boolean isValid(TileEntity var1) {
      boolean var10000;
      if ((!(var1 instanceof TileEntityChest) || !this.chests.getValue())
         && (!(var1 instanceof TileEntityBed) || !this.beds.getValue())
         && (!(var1 instanceof TileEntityEnderChest) || !this.eChests.getValue())
         && (!(var1 instanceof TileEntityShulkerBox) || !this.shulkers.getValue())
         && (!(var1 instanceof TileEntityFurnace) || !this.furnaces.getValue())
         && (!(var1 instanceof TileEntityDispenser) || !this.dispensers.getValue())
         && (!(var1 instanceof TileEntityHopper) || !this.hoppers.getValue())
         && (!(var1 instanceof TileEntitySign) || !this.signs.getValue())) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      return String.valueOf(this.count);
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      this.count = 0;

      for(TileEntity var3 : mc.world.loadedTileEntityList) {
         if (this.isValid(var3)) {
            RenderUtil.drawSelectionBoxESP(var3.getPos(), this.getColor(var3), false, new Color(-1), 1.0F, true, true, 100, false);
            ++this.count;
         }

         boolean var10000 = false;
      }
   }
}
