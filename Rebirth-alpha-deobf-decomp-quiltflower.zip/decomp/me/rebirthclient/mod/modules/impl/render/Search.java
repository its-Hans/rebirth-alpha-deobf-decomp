package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map.Entry;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityEndPortal;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.math.BlockPos;

public class Search extends Module {
   private final Setting<Boolean> shulker;
   private final Setting<Boolean> frame;
   private final Setting<Float> lineWidth;
   private final Setting<Boolean> hopper;
   private final Setting<Boolean> chest;
   private final Setting<Boolean> cart;
   private final Setting<Boolean> outline;
   private final Setting<Integer> boxAlpha;
   private final Setting<Boolean> dispenser;
   private final Setting<Boolean> portal;
   private final Setting<Boolean> box;
   private final Setting<Float> range = this.add(new Setting<>("Range", 50.0F, 1.0F, 300.0F));
   private final Setting<Boolean> echest;

   private boolean lambda$new$0(Integer var1) {
      return this.box.getValue();
   }

   private int getEntityColor(Entity var1) {
      if (var1 instanceof EntityMinecartChest) {
         return ColorUtil.Colors.ORANGE;
      } else {
         return var1 instanceof EntityItemFrame && ((EntityItemFrame)var1).getDisplayedItem().getItem() instanceof ItemShulkerBox
            ? ColorUtil.Colors.WHITE
            : -1;
      }
   }

   private int getTileEntityColor(TileEntity var1) {
      if (var1 instanceof TileEntityChest) {
         return ColorUtil.Colors.ORANGE;
      } else if (var1 instanceof TileEntityShulkerBox) {
         return ColorUtil.Colors.WHITE;
      } else if (var1 instanceof TileEntityEndPortal) {
         return ColorUtil.Colors.GRAY;
      } else if (var1 instanceof TileEntityEnderChest) {
         return ColorUtil.Colors.PURPLE;
      } else if (var1 instanceof TileEntityHopper) {
         return ColorUtil.Colors.DARK_RED;
      } else {
         return var1 instanceof TileEntityDispenser ? ColorUtil.Colors.ORANGE : -1;
      }
   }

   private boolean lambda$new$1(Float var1) {
      return this.outline.getValue();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      HashMap var4 = new HashMap();

      for(TileEntity var6 : mc.world.loadedTileEntityList) {
         if (var6 instanceof TileEntityEndPortal && this.portal.getValue()
            || var6 instanceof TileEntityChest && this.chest.getValue()
            || var6 instanceof TileEntityDispenser && this.dispenser.getValue()
            || var6 instanceof TileEntityShulkerBox && this.shulker.getValue()
            || var6 instanceof TileEntityEnderChest && this.echest.getValue()
            || var6 instanceof TileEntityHopper && this.hopper.getValue()) {
            EntityPlayerSP var10000 = mc.player;
            BlockPos var3 = var6.getPos();
            if (var10000.getDistanceSq(var3) <= MathUtil.square((double)this.range.getValue().floatValue())) {
               int var2 = this.getTileEntityColor(var6);
               if (var2 == -1) {
                  boolean var15 = false;
               } else {
                  var4.put(var3, var2);
                  boolean var16 = false;
                  boolean var17 = false;
               }
            }
         }
      }

      for(Entity var13 : mc.world.loadedEntityList) {
         if (var13 instanceof EntityItemFrame && this.frame.getValue() || var13 instanceof EntityMinecartChest && this.cart.getValue()) {
            EntityPlayerSP var18 = mc.player;
            BlockPos var10 = var13.getPosition();
            if (var18.getDistanceSq(var10) <= MathUtil.square((double)this.range.getValue().floatValue())) {
               int var8 = this.getEntityColor(var13);
               if (var8 == -1) {
                  boolean var19 = false;
               } else {
                  var4.put(var10, var8);
                  boolean var20 = false;
                  boolean var21 = false;
               }
            }
         }
      }

      for(Entry var14 : var4.entrySet()) {
         BlockPos var7 = (BlockPos)var14.getKey();
         int var9 = var14.getValue();
         RenderUtil.drawBoxESP(
            var7,
            new Color(var9),
            false,
            new Color(var9),
            this.lineWidth.getValue(),
            this.outline.getValue(),
            this.box.getValue(),
            this.boxAlpha.getValue(),
            false
         );
         boolean var22 = false;
      }
   }

   public Search() {
      super("Search", "Highlights Containers", Category.RENDER);
      this.portal = this.add(new Setting<>("Portal", true));
      this.chest = this.add(new Setting<>("Chest", true));
      this.dispenser = this.add(new Setting<>("Dispenser", false));
      this.shulker = this.add(new Setting<>("Shulker", true));
      this.echest = this.add(new Setting<>("Ender Chest", false));
      this.hopper = this.add(new Setting<>("Hopper", false));
      this.cart = this.add(new Setting<>("Minecart", false));
      this.frame = this.add(new Setting<>("Item Frame", false));
      this.box = this.add(new Setting<>("Box", false));
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 125, 0, 255, this::lambda$new$0));
      this.outline = this.add(new Setting<>("Outline", true));
      this.lineWidth = this.add(new Setting<>("LineWidth", 1.0F, 0.1F, 5.0F, this::lambda$new$1));
   }
}
