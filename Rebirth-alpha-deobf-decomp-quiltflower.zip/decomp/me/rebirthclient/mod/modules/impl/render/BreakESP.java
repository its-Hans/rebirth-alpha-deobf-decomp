package me.rebirthclient.mod.modules.impl.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.events.impl.DamageBlockEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.misc.TabFriends;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BreakESP extends Module {
   private final Setting<Color> doubleRender;
   private final Setting<Boolean> outline;
   private final Setting<Integer> outlineAlpha;
   private final Setting<Integer> boxAlpha;
   private final Setting<Boolean> renderProgress;
   private final Setting<BreakESP.Mode> animationMode;
   static final HashMap<EntityPlayer, BreakESP.MinePosition> MineMap = new HashMap<>();
   private final Setting<Color> color;
   private final Setting<Double> range;
   public static BreakESP INSTANCE = new BreakESP();
   private final Setting<Boolean> box;
   private final Setting<Integer> animationTime;
   private final Setting<Boolean> renderName;
   private final Setting<TabFriends.FriendColor> nameColor;
   private final Setting<Boolean> renderAir = this.add(new Setting<>("RenderAir", true));
   private final Setting<Boolean> renderUnknown;
   private final Setting<Boolean> renderSelf = this.add(new Setting<>("OneSelf", true));

   public String getColor() {
      switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$misc$TabFriends$FriendColor[this.nameColor.getValue().ordinal()]) {
         case 1:
            return "§f";
         case 2:
            return "§4";
         case 3:
            return "§c";
         case 4:
            return "§6";
         case 5:
            return "§e";
         case 6:
            return "§2";
         case 7:
            return "§a";
         case 8:
            return "§b";
         case 9:
            return "§3";
         case 10:
            return "§1";
         case 11:
            return "§9";
         case 12:
            return "§d";
         case 13:
            return "§5";
         case 14:
            return "§7";
         case 15:
            return "§8";
         case 16:
            return "§0";
         default:
            return "";
      }
   }

   static Setting access$000(BreakESP var0) {
      return var0.animationTime;
   }

   private boolean lambda$new$2(Integer var1) {
      return this.box.isOpen();
   }

   @SubscribeEvent
   public void BlockBreak(DamageBlockEvent var1) {
      if (var1.getPosition().getY() != -1) {
         EntityPlayer var2 = (EntityPlayer)mc.world.getEntityByID(var1.getBreakerId());
         if (var2 != null
            && !(var2.getDistance((double)var1.getPosition().getX() + 0.5, (double)var1.getPosition().getY(), (double)var1.getPosition().getZ() + 0.5) > 7.0)) {
            if (!MineMap.containsKey(var2)) {
               MineMap.put(var2, new BreakESP.MinePosition(var2));
               boolean var10000 = false;
            }

            MineMap.get(var2).update(var1.getPosition());
         }
      }
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      EntityPlayer[] var2 = MineMap.keySet().toArray(new EntityPlayer[0]);

      for(EntityPlayer var6 : var2) {
         if (var6 != null && !var6.isEntityAlive()) {
            MineMap.remove(var6);
            boolean var10000 = false;
         }

         boolean var7 = false;
      }

      MineMap.values().forEach(this::lambda$onRender3D$4);
   }

   static Setting access$100(BreakESP var0) {
      return var0.renderAir;
   }

   private boolean lambda$new$3(Integer var1) {
      return this.outline.isOpen();
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.renderName.isOpen();
   }

   public void draw(BlockPos var1, double var2, Color var4) {
      if (this.animationMode.getValue() != BreakESP.Mode.Both) {
         AxisAlignedBB var5;
         if (this.animationMode.getValue() == BreakESP.Mode.InToOut) {
            var5 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
            boolean var10000 = false;
         } else if (this.animationMode.getValue() == BreakESP.Mode.Up) {
            AxisAlignedBB var6 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            var5 = new AxisAlignedBB(var6.minX, var6.minY, var6.minZ, var6.maxX, var6.minY + (var6.maxY - var6.minY) * var2, var6.maxZ);
            boolean var12 = false;
         } else if (this.animationMode.getValue() == BreakESP.Mode.Down) {
            AxisAlignedBB var10 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            var5 = new AxisAlignedBB(var10.minX, var10.maxY - (var10.maxY - var10.minY) * var2, var10.minZ, var10.maxX, var10.maxY, var10.maxZ);
            boolean var13 = false;
         } else if (this.animationMode.getValue() == BreakESP.Mode.None) {
            var5 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            boolean var14 = false;
         } else {
            AxisAlignedBB var11 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
            AxisAlignedBB var7 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            if (this.animationMode.getValue() == BreakESP.Mode.Horizontal) {
               var5 = new AxisAlignedBB(var7.minX, var11.minY, var7.minZ, var7.maxX, var11.maxY, var7.maxZ);
               boolean var15 = false;
            } else {
               var5 = new AxisAlignedBB(var11.minX, var7.minY, var11.minZ, var11.maxX, var7.maxY, var11.maxZ);
            }
         }

         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var5, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var5, var4, this.boxAlpha.getValue());
            boolean var16 = false;
         }
      } else {
         AxisAlignedBB var8 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var8, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var8, var4, this.boxAlpha.getValue());
         }

         var8 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(-Math.abs(var2 / 2.0 - 1.0));
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var8, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var8, var4, this.boxAlpha.getValue());
         }
      }
   }

   private boolean lambda$new$0(TabFriends.FriendColor var1) {
      return this.renderName.isOpen();
   }

   private void lambda$onRender3D$4(BreakESP.MinePosition var1) {
      if (!this.renderAir.getValue() && mc.world.isAirBlock(var1.first)) {
         var1.finishFirst();
      }

      if ((!var1.firstFinished || this.renderAir.getValue())
         && (var1.miner != mc.player || this.renderSelf.getValue())
         && var1.first.getDistance((int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ) < this.range.getValue()
         && (var1.miner != null || this.renderUnknown.getValue())) {
         this.draw(var1.first, var1.firstFade.easeOutQuad(), this.color.getValue());
         if (this.renderName.getValue()) {
            double var2 = (double)var1.first.getX() - mc.getRenderManager().renderPosX + 0.5;
            double var4 = (double)var1.first.getY() - mc.getRenderManager().renderPosY - 1.0;
            double var6 = (double)var1.first.getZ() - mc.getRenderManager().renderPosZ + 0.5;
            StringBuilder var10000 = new StringBuilder().append(ChatFormatting.GRAY);
            String var10001;
            if (var1.miner == null) {
               var10001 = String.valueOf(new StringBuilder().append(this.getColor()).append("Unknown"));
               boolean var10002 = false;
            } else {
               var10001 = String.valueOf(new StringBuilder().append(this.getColor()).append(var1.miner.getName()));
            }

            String var11 = String.valueOf(var10000.append(var10001));
            double var16;
            if (this.renderProgress.getValue()) {
               var16 = var4 + 0.15;
               boolean var10003 = false;
            } else {
               var16 = var4;
            }

            RenderUtil.drawText(var11, var2, var16, var6, new Color(255, 255, 255, 255));
            if (this.renderProgress.getValue()) {
               if (mc.world.isAirBlock(var1.first)) {
                  RenderUtil.drawText(
                     String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append("Broke")), var2, var4 - 0.15, var6, new Color(255, 255, 255, 255)
                  );
                  boolean var12 = false;
               } else {
                  RenderUtil.drawText(
                     String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append("Breaking")),
                     var2,
                     var4 - 0.15,
                     var6,
                     new Color(255, 255, 255, 255)
                  );
               }
            }
         }
      }

      if ((var1.miner != mc.player || this.renderSelf.getValue()) && !var1.secondFinished && var1.second != null) {
         if (mc.world.isAirBlock(var1.second)) {
            var1.finishSecond();
            boolean var13 = false;
         } else if (!var1.second.equals(var1.first)
            && var1.second.getDistance((int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ) < this.range.getValue()
            && (var1.miner != null || this.renderUnknown.getValue())
            && this.doubleRender.booleanValue) {
            this.draw(var1.second, var1.secondFade.easeOutQuad(), this.doubleRender.getValue());
            if (this.renderName.getValue()) {
               double var8 = (double)var1.second.getX() - mc.getRenderManager().renderPosX + 0.5;
               double var9 = (double)var1.second.getY() - mc.getRenderManager().renderPosY - 1.0;
               double var10 = (double)var1.second.getZ() - mc.getRenderManager().renderPosZ + 0.5;
               StringBuilder var14 = new StringBuilder().append(ChatFormatting.GRAY);
               String var15;
               if (var1.miner == null) {
                  var15 = String.valueOf(new StringBuilder().append(this.getColor()).append("Unknown"));
                  boolean var17 = false;
               } else {
                  var15 = String.valueOf(new StringBuilder().append(this.getColor()).append(var1.miner.getName()));
               }

               RenderUtil.drawText(String.valueOf(var14.append(var15)), var8, var9 + 0.15, var10, new Color(255, 255, 255, 255));
               RenderUtil.drawText(
                  String.valueOf(new StringBuilder().append(ChatFormatting.GOLD).append("Double")), var8, var9 - 0.15, var10, new Color(255, 255, 255, 255)
               );
            }
         }
      }
   }

   @Override
   public void onDisable() {
      MineMap.clear();
   }

   public BreakESP() {
      super("BreakESP", "Show mine postion", Category.RENDER);
      this.renderUnknown = this.add(new Setting<>("RenderUnknown", true));
      this.range = this.add(new Setting<>("Range", 15.0, 0.0, 50.0));
      this.renderName = this.add(new Setting<>("RenderName", true).setParent());
      this.nameColor = this.add(new Setting<>("Color", TabFriends.FriendColor.Gray, this::lambda$new$0));
      this.renderProgress = this.add(new Setting<>("Progress", true, this::lambda$new$1).setParent());
      this.animationMode = this.add(new Setting<>("AnimationMode", BreakESP.Mode.Up));
      this.animationTime = this.add(new Setting<>("AnimationTime", 1000, 0, 5000));
      this.box = this.add(new Setting<>("Box", true).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 30, 0, 255, this::lambda$new$2));
      this.outline = this.add(new Setting<>("Outline", true).setParent());
      this.outlineAlpha = this.add(new Setting<>("OutlineAlpha", 100, 0, 255, this::lambda$new$3));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255, 100)).hideAlpha());
      this.doubleRender = this.add(new Setting<>("Double", new Color(255, 255, 255, 100)).injectBoolean(true).hideAlpha());
      INSTANCE = this;
   }

   private static class MinePosition {
      public FadeUtils secondFade;
      public boolean firstFinished;
      public boolean secondFinished;
      public BlockPos second;
      public FadeUtils firstFade = new FadeUtils((long)((Integer)BreakESP.access$000(BreakESP.INSTANCE).getValue()).intValue());
      public final EntityPlayer miner;
      public BlockPos first;

      public void finishFirst() {
         this.firstFinished = true;
      }

      public void update(BlockPos var1) {
         if (this.first == null || !this.first.equals(var1) || !BreakESP.access$100(BreakESP.INSTANCE).getValue()) {
            if (this.secondFinished || this.second == null) {
               this.second = var1;
               this.secondFinished = false;
               this.secondFade = new FadeUtils((long)((Integer)BreakESP.access$000(BreakESP.INSTANCE).getValue()).intValue());
            }

            if (this.first == null || !this.first.equals(var1) || this.firstFinished) {
               this.firstFade = new FadeUtils((long)((Integer)BreakESP.access$000(BreakESP.INSTANCE).getValue()).intValue());
            }

            this.firstFinished = false;
            this.first = var1;
         }
      }

      public void finishSecond() {
         this.secondFinished = true;
      }

      public MinePosition(EntityPlayer var1) {
         this.secondFade = new FadeUtils((long)((Integer)BreakESP.access$000(BreakESP.INSTANCE).getValue()).intValue());
         this.miner = var1;
         this.secondFinished = true;
      }
   }

   public static enum Mode {
      Vertical,
      Horizontal,
      InToOut,
      None,
      Down,
      Both,
      Up;
      private static final BreakESP.Mode[] $VALUES = new BreakESP.Mode[]{
         BreakESP.Mode.Down, BreakESP.Mode.Up, InToOut, BreakESP.Mode.Both, Vertical, Horizontal, None
      };
   }
}
