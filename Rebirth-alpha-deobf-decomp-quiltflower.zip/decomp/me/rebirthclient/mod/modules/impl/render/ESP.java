package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.InterpolationUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class ESP extends Module {
   private final Setting<ESP.Burrow> burrow;
   private final Setting<Color> color;
   private final Setting<Color> lineColor;
   static final boolean $assertionsDisabled;
   private final Setting<ESP.Items> items;
   private final Setting<ESP.Players> players;
   private final Setting<Color> textColor;
   private final Setting<Boolean> xp;
   private final Setting<ESP.Page> page = this.add(new Setting<>("Settings", ESP.Page.GLOBAL));
   private final Setting<Boolean> pearls;
   private final Setting<Boolean> xpOrbs;

   private boolean lambda$new$4(ESP.Players var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   static {
      boolean var10000;
      if (!ESP.class.desiredAssertionStatus()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      $assertionsDisabled = var10000;
   }

   private boolean lambda$new$5(ESP.Burrow var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Color var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(ESP.Items var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawNameTag(String var1, BlockPos var2) {
      GlStateManager.pushMatrix();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      GL11.glEnable(3553);
      double var3 = (double)var2.getX() + 0.5;
      double var5 = (double)var2.getY() + 0.7;
      double var7 = (double)var2.getZ() + 0.5;
      float var9 = 0.030833336F;
      GlStateManager.translate(var3 - mc.getRenderManager().renderPosX, var5 - mc.getRenderManager().renderPosY, var7 - mc.getRenderManager().renderPosZ);
      GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(-mc.player.rotationYaw, 0.0F, 1.0F, 0.0F);
      float var10000 = mc.player.rotationPitch;
      float var10001;
      if (mc.gameSettings.thirdPersonView == 2) {
         var10001 = -1.0F;
         boolean var10002 = false;
      } else {
         var10001 = 1.0F;
      }

      GlStateManager.rotate(var10000, var10001, 0.0F, 0.0F);
      GlStateManager.scale(-var9, -var9, var9);
      int var10 = (int)mc.player.getDistance(var3, var5, var7);
      float var11 = (float)var10 / 2.0F / 3.0F;
      if (var11 < 1.0F) {
         var11 = 1.0F;
      }

      GlStateManager.scale(var11, var11, var11);
      GlStateManager.translate(-((double)Managers.TEXT.getStringWidth(var1) / 2.0), 0.0, 0.0);
      TextManager var12 = Managers.TEXT;
      int var10004;
      if (this.textColor.booleanValue) {
         var10004 = this.textColor.getValue().getRGB();
         boolean var10005 = false;
      } else {
         var10004 = -1;
      }

      var12.drawStringWithShadow(var1, 0.0F, 6.0F, var10004);
      GlStateManager.enableDepth();
      GlStateManager.disableBlend();
      GlStateManager.disablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
      GlStateManager.popMatrix();
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private boolean lambda$new$8(Color var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!fullNullCheck()) {
         for(Entity var3 : mc.world.loadedEntityList) {
            if (var3 != mc.player && var3 instanceof EntityPlayer && this.players.getValue() == ESP.Players.BOX && !((EntityPlayer)var3).isSpectator()
               || var3 instanceof EntityExpBottle && this.xp.getValue()
               || var3 instanceof EntityXPOrb && this.xpOrbs.getValue()
               || var3 instanceof EntityEnderPearl && this.pearls.getValue()
               || var3 instanceof EntityItem && this.items.getValue() == ESP.Items.BOX) {
               RenderUtil.drawEntityBoxESP(
                  var3, this.color.getValue(), this.lineColor.booleanValue, this.lineColor.getValue(), 1.0F, true, true, this.color.getValue().getAlpha()
               );
            }

            boolean var10000 = false;
         }

         for(Entity var9 : mc.world.loadedEntityList) {
            if (var9 instanceof EntityItem && this.items.getValue() == ESP.Items.TEXT) {
               ItemStack var4 = ((EntityItem)var9).getItem();
               StringBuilder var12 = new StringBuilder().append(var4.getDisplayName());
               String var10001;
               if (var4.isStackable() && var4.getCount() >= 2) {
                  var10001 = String.valueOf(new StringBuilder().append(" x").append(var4.getCount()));
                  boolean var10002 = false;
               } else {
                  var10001 = "";
               }

               String var5 = String.valueOf(var12.append(var10001));
               Vec3d var6 = InterpolationUtil.getInterpolatedPos(var9, mc.getRenderPartialTicks(), true);
               this.drawNameTag(var5, var6);
            }

            boolean var13 = false;
         }

         for(EntityPlayer var10 : mc.world.playerEntities) {
            BlockPos var11 = new BlockPos(Math.floor(var10.posX), Math.floor(var10.posY + 0.2), Math.floor(var10.posZ));
            if (!var10.isSpectator()
               && !var10.isRiding()
               && var10 != mc.player
               && BlockUtil.getBlock(var11) != Blocks.AIR
               && !BlockUtil.canReplace(var11)
               && !BlockUtil.isStair(BlockUtil.getBlock(var11))
               && !BlockUtil.isSlab(BlockUtil.getBlock(var11))
               && !BlockUtil.isFence(BlockUtil.getBlock(var11))
               && mc.player.getDistanceSq(var11) <= 200.0) {
               if (this.burrow.getValue() == ESP.Burrow.PRETTY) {
                  this.drawBurrowESP(var11);
                  boolean var14 = false;
               } else if (this.burrow.getValue() == ESP.Burrow.TEXT) {
                  String var16;
                  if (BlockUtil.getBlock(var11) == Blocks.WEB) {
                     var16 = "Web";
                     boolean var17 = false;
                  } else {
                     var16 = "Burrow";
                  }

                  this.drawNameTag(var16, var11);
               }
            }

            boolean var15 = false;
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawNameTag(String var1, Vec3d var2) {
      GlStateManager.pushMatrix();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      GL11.glEnable(3553);
      double var3 = var2.x;
      double var5 = var2.y;
      double var7 = var2.z;
      Entity var9 = mc.getRenderViewEntity();
      if (!$assertionsDisabled && var9 == null) {
         throw new AssertionError();
      } else {
         double var10 = var9.getDistance(
            var3 + mc.getRenderManager().viewerPosX, var5 + mc.getRenderManager().viewerPosY, var7 + mc.getRenderManager().viewerPosZ
         );
         double var12 = 0.0018 + 0.003F * var10;
         int var14 = Managers.TEXT.getStringWidth(var1) / 2;
         if (var10 <= 8.0) {
            var12 = 0.0245;
         }

         GlStateManager.translate(var3, var5 + 0.4F, var7);
         GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
         float var10000 = mc.getRenderManager().playerViewX;
         float var10001;
         if (mc.gameSettings.thirdPersonView == 2) {
            var10001 = -1.0F;
            boolean var10002 = false;
         } else {
            var10001 = 1.0F;
         }

         GlStateManager.rotate(var10000, var10001, 0.0F, 0.0F);
         GlStateManager.scale(-var12, -var12, var12);
         TextManager var15 = Managers.TEXT;
         float var16 = (float)(-var14) - 0.1F;
         float var10003 = (float)(-(mc.fontRenderer.FONT_HEIGHT - 1));
         int var10004;
         if (this.textColor.booleanValue) {
            var10004 = this.textColor.getValue().getRGB();
            boolean var10005 = false;
         } else {
            var10004 = -1;
         }

         var15.drawStringWithShadow(var1, var16, var10003, var10004);
         GlStateManager.enableDepth();
         GlStateManager.disableBlend();
         GlStateManager.disablePolygonOffset();
         GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
         GlStateManager.popMatrix();
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private void drawBurrowESP(BlockPos var1) {
      GlStateManager.pushMatrix();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      double var2 = (double)var1.getX() + 0.5;
      double var4 = (double)var1.getY() + 0.4;
      double var6 = (double)var1.getZ() + 0.5;
      int var8 = (int)mc.player.getDistance(var2, var4, var6);
      double var9 = (double)(0.0018F + 0.002F * (float)var8);
      if ((double)var8 <= 8.0) {
         var9 = 0.0245;
      }

      GlStateManager.translate(var2 - mc.getRenderManager().renderPosX, var4 - mc.getRenderManager().renderPosY, var6 - mc.getRenderManager().renderPosZ);
      GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      float var10000 = mc.getRenderManager().playerViewX;
      float var10001;
      if (mc.gameSettings.thirdPersonView == 2) {
         var10001 = -1.0F;
         boolean var10002 = false;
      } else {
         var10001 = 1.0F;
      }

      GlStateManager.rotate(var10000, var10001, 0.0F, 0.0F);
      GlStateManager.scale(-var9, -var9, -var9);
      RenderUtil.glColor(this.color.getValue());
      RenderUtil.drawCircle(1.5F, -5.0F, 16.0F, ColorUtil.injectAlpha(this.color.getValue().getRGB(), 100));
      GlStateManager.enableAlpha();
      Block var11 = BlockUtil.getBlock(var1);
      if (var11 == Blocks.ENDER_CHEST) {
         mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/constant/ingame/echest.png"));
         boolean var12 = false;
      } else if (var11 == Blocks.WEB) {
         mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/constant/ingame/web.png"));
         boolean var13 = false;
      } else {
         mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/constant/ingame/obby.png"));
      }

      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      RenderUtil.drawModalRect(-10, -17, 0.0F, 0.0F, 12, 12, 24, 24, 12.0F, 12.0F);
      GlStateManager.disableAlpha();
      GlStateManager.enableDepth();
      GlStateManager.disableBlend();
      GlStateManager.disablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
      GlStateManager.popMatrix();
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Color var1) {
      boolean var10000;
      if (this.page.getValue() == ESP.Page.COLORS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public ESP() {
      super("ESP", "Highlights entities through walls in several modes", Category.RENDER);
      this.items = this.add(new Setting<>("Items", ESP.Items.BOX, this::lambda$new$0));
      this.xpOrbs = this.add(new Setting<>("ExpOrbs", false, this::lambda$new$1));
      this.xp = this.add(new Setting<>("ExpBottles", false, this::lambda$new$2));
      this.pearls = this.add(new Setting<>("Pearls", true, this::lambda$new$3));
      this.players = this.add(new Setting<>("Players", ESP.Players.BOX, this::lambda$new$4));
      this.burrow = this.add(new Setting<>("Burrow", ESP.Burrow.PRETTY, this::lambda$new$5));
      this.textColor = this.add(new Setting<>("TextColor", new Color(-1), this::lambda$new$6).injectBoolean(false));
      this.color = this.add(new Setting<>("Color", new Color(125, 125, 213, 150), this::lambda$new$7));
      this.lineColor = this.add(new Setting<>("LineColor", new Color(-1493172225, true), this::lambda$new$8).injectBoolean(false));
   }

   public static enum Burrow {
      OFF,
      PRETTY,
      TEXT;
      private static final ESP.Burrow[] $VALUES = new ESP.Burrow[]{PRETTY, ESP.Burrow.TEXT, OFF};
   }

   public static enum Items {
      BOX,
      OFF,
      TEXT;
      private static final ESP.Items[] $VALUES = new ESP.Items[]{BOX, ESP.Items.TEXT, ESP.Items.OFF};
   }

   public static enum Page {
      GLOBAL,
      COLORS;
      private static final ESP.Page[] $VALUES = new ESP.Page[]{ESP.Page.COLORS, GLOBAL};
   }

   public static enum Players {
      OFF,
      BOX;
      private static final ESP.Players[] $VALUES = new ESP.Players[]{ESP.Players.BOX, ESP.Players.OFF};
   }
}
