package me.rebirthclient.mod.modules.impl.render;

import com.google.common.collect.Maps;
import java.awt.Color;
import java.util.Map;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Wrapper;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

public class Tracers extends Module {
   private final Setting<Integer> radius;
   private final Setting<Float> size;
   private final Setting<Color> color;
   private final Setting<Integer> range;
   private final Frustum frustum;
   private final Setting<Float> lineWidth;
   private final Setting<Boolean> outline;
   private final Setting<Tracers.Mode> mode = this.add(new Setting<>("Mode", Tracers.Mode.ARROW));
   private final Tracers.EntityListener entityListener;

   private boolean lambda$new$1(Integer var1) {
      boolean var10000;
      if (this.mode.getValue() == Tracers.Mode.ARROW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean isInViewFrustum(Entity var1) {
      Entity var2 = mc.getRenderViewEntity();
      this.frustum.setPosition(var2.posX, var2.posY, var2.posZ);
      boolean var10000;
      if (!this.frustum.isBoundingBoxInFrustum(var1.getEntityBoundingBox()) && !var1.ignoreFrustumCheck) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Float var1) {
      boolean var10000;
      if (this.mode.getValue() == Tracers.Mode.ARROW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public Tracers() {
      super("Tracers", "Points to the players on your screen", Category.RENDER);
      this.range = this.add(new Setting<>("Range", 100, 10, 200));
      this.color = this.add(new Setting<>("Color", new Color(11935519)));
      this.lineWidth = this.add(new Setting<>("LineWidth", 1.0F, 0.5F, 2.0F, this::lambda$new$0));
      this.radius = this.add(new Setting<>("Radius", 80, 10, 200, this::lambda$new$1));
      this.size = this.add(new Setting<>("Size", 7.5F, 5.0F, 25.0F, this::lambda$new$2));
      this.outline = this.add(new Setting<>("Outline", true, this::lambda$new$3));
      this.entityListener = new Tracers.EntityListener();
      this.frustum = new Frustum();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (mc.getRenderViewEntity() != null) {
         if (this.mode.getValue() == Tracers.Mode.TRACER) {
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3042);
            GL11.glEnable(2848);
            GL11.glHint(3154, 4354);
            GL11.glLineWidth(this.lineWidth.getValue());
            GL11.glDisable(3553);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glBegin(1);

            for(EntityPlayer var3 : mc.world.playerEntities) {
               if (var3 != mc.player) {
                  this.drawTraces(var3);
               }

               boolean var10000 = false;
            }

            GL11.glEnd();
            GL11.glEnable(3553);
            GL11.glDisable(2848);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            GL11.glDisable(3042);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
         }
      }
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == Tracers.Mode.ARROW) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void lambda$onRender2D$4(Entity var1) {
      if (var1 instanceof EntityPlayer && this.isValid((EntityPlayer)var1)) {
         EntityPlayer var2 = (EntityPlayer)var1;
         Vec3d var3 = (Vec3d)this.entityListener.getEntityLowerBounds().get(var2);
         if (var3 != null && !this.isOnScreen(var3) && !this.isInViewFrustum(var2)) {
            int var4 = (int)MathHelper.clamp(255.0F - 255.0F / (float)this.range.getValue().intValue() * mc.player.getDistance(var2), 100.0F, 255.0F);
            Color var5 = new Color(0, 191, 255);
            Color var10000;
            if (Managers.FRIENDS.isFriend(var2.getName())) {
               var10000 = ColorUtil.injectAlpha(var5, var4);
               boolean var10001 = false;
            } else {
               var10000 = ColorUtil.injectAlpha(this.color.getValue(), var4);
            }

            Color var6 = var10000;
            int var10 = Display.getWidth() / 2;
            int var12;
            if (mc.gameSettings.guiScale == 0) {
               var12 = 1;
               boolean var10002 = false;
            } else {
               var12 = mc.gameSettings.guiScale;
            }

            int var7 = var10 / var12;
            int var11 = Display.getHeight() / 2;
            if (mc.gameSettings.guiScale == 0) {
               var12 = 1;
               boolean var14 = false;
            } else {
               var12 = mc.gameSettings.guiScale;
            }

            int var8 = var11 / var12;
            float var9 = this.getRotations(var2) - mc.player.rotationYaw;
            GL11.glTranslatef((float)var7, (float)var8, 0.0F);
            GL11.glRotatef(var9, 0.0F, 0.0F, 1.0F);
            GL11.glTranslatef((float)(-var7), (float)(-var8), 0.0F);
            RenderUtil.drawArrowPointer(
               (float)var7, (float)(var8 - this.radius.getValue()), this.size.getValue(), 2.0F, 1.0F, this.outline.getValue(), 1.1F, var6.getRGB()
            );
            GL11.glTranslatef((float)var7, (float)var8, 0.0F);
            GL11.glRotatef(-var9, 0.0F, 0.0F, 1.0F);
            GL11.glTranslatef((float)(-var7), (float)(-var8), 0.0F);
         }
      }
   }

   private void drawTraces(Entity var1) {
      if (mc.getRenderViewEntity() != null) {
         double var2 = var1.lastTickPosX + (var1.posX - var1.lastTickPosX) * (double)mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosX;
         double var4 = var1.lastTickPosY + (var1.posY - var1.lastTickPosY) * (double)mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosY;
         double var6 = var1.lastTickPosZ + (var1.posZ - var1.lastTickPosZ) * (double)mc.getRenderPartialTicks() - mc.getRenderManager().viewerPosZ;
         Vec3d var8 = new Vec3d(0.0, 0.0, 1.0)
            .rotatePitch(-((float)Math.toRadians((double)mc.getRenderViewEntity().rotationPitch)))
            .rotateYaw(-((float)Math.toRadians((double)mc.getRenderViewEntity().rotationYaw)));
         boolean var9 = Managers.FRIENDS.isFriend(var1.getName());
         float var10000;
         if (var9) {
            var10000 = 0.0F;
            boolean var10001 = false;
         } else {
            var10000 = (float)this.color.getValue().getRed();
         }

         var10000 /= 255.0F;
         float var11;
         if (var9) {
            var11 = 191.0F;
            boolean var10002 = false;
         } else {
            var11 = (float)this.color.getValue().getGreen();
         }

         var11 /= 255.0F;
         float var13;
         if (var9) {
            var13 = 255.0F;
            boolean var10003 = false;
         } else {
            var13 = (float)this.color.getValue().getBlue();
         }

         GL11.glColor4f(
            var10000,
            var11,
            var13 / 255.0F,
            MathHelper.clamp(255.0F - 255.0F / (float)this.range.getValue().intValue() * mc.player.getDistance(var1), 100.0F, 255.0F)
         );
         GL11.glVertex3d(var8.x, var8.y + (double)mc.getRenderViewEntity().getEyeHeight(), var8.z);
         GL11.glVertex3d(var2, var4, var6);
      }
   }

   private boolean isValid(EntityPlayer var1) {
      boolean var10000;
      if (var1 != mc.player && var1.isEntityAlive()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Float var1) {
      boolean var10000;
      if (this.mode.getValue() == Tracers.Mode.TRACER) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if (this.mode.getValue() == Tracers.Mode.ARROW) {
         Tracers.EntityListener.access$100(this.entityListener);
         mc.world.loadedEntityList.forEach(this::lambda$onRender2D$4);
      }
   }

   private float getRotations(EntityLivingBase var1) {
      double var2 = var1.posX - mc.player.posX;
      double var4 = var1.posZ - mc.player.posZ;
      return (float)(-(Math.atan2(var2, var4) * (180.0 / Math.PI)));
   }

   @Override
   public String getInfo() {
      return String.valueOf(this.mode.getValue());
   }

   private boolean isOnScreen(Vec3d var1) {
      if (!(var1.x > -1.0)) {
         return false;
      } else if (!(var1.y < 1.0)) {
         return false;
      } else if (!(var1.z < 1.0)) {
         return false;
      } else {
         int var10000;
         if (mc.gameSettings.guiScale == 0) {
            var10000 = 1;
            boolean var10001 = false;
         } else {
            var10000 = mc.gameSettings.guiScale;
         }

         int var2 = var10000;
         if (!(var1.x / (double)var2 >= 0.0)) {
            return false;
         } else {
            if (mc.gameSettings.guiScale == 0) {
               var10000 = 1;
               boolean var10 = false;
            } else {
               var10000 = mc.gameSettings.guiScale;
            }

            int var3 = var10000;
            if (!(var1.x / (double)var3 <= (double)Display.getWidth())) {
               return false;
            } else {
               if (mc.gameSettings.guiScale == 0) {
                  var10000 = 1;
                  boolean var11 = false;
               } else {
                  var10000 = mc.gameSettings.guiScale;
               }

               int var4 = var10000;
               if (!(var1.y / (double)var4 >= 0.0)) {
                  return false;
               } else {
                  if (mc.gameSettings.guiScale == 0) {
                     var10000 = 1;
                     boolean var12 = false;
                  } else {
                     var10000 = mc.gameSettings.guiScale;
                  }

                  int var5 = var10000;
                  boolean var9;
                  if (var1.y / (double)var5 <= (double)Display.getHeight()) {
                     var9 = true;
                     boolean var13 = false;
                  } else {
                     var9 = false;
                  }

                  return var9;
               }
            }
         }
      }
   }

   private static class EntityListener {
      private final Map<Entity, Vec3d> entityLowerBounds;
      private final Map<Entity, Vec3d> entityUpperBounds = Maps.newHashMap();

      private Vec3d getEntityRenderPosition(Entity var1) {
         double var2 = (double)Wrapper.mc.timer.renderPartialTicks;
         double var4 = var1.lastTickPosX + (var1.posX - var1.lastTickPosX) * var2 - Wrapper.mc.getRenderManager().viewerPosX;
         double var6 = var1.lastTickPosY + (var1.posY - var1.lastTickPosY) * var2 - Wrapper.mc.getRenderManager().viewerPosY;
         double var8 = var1.lastTickPosZ + (var1.posZ - var1.lastTickPosZ) * var2 - Wrapper.mc.getRenderManager().viewerPosZ;
         return new Vec3d(var4, var6, var8);
      }

      private void render() {
         if (!this.entityUpperBounds.isEmpty()) {
            this.entityUpperBounds.clear();
         }

         if (!this.entityLowerBounds.isEmpty()) {
            this.entityLowerBounds.clear();
         }

         for(Entity var2 : Wrapper.mc.world.loadedEntityList) {
            Vec3d var3 = this.getEntityRenderPosition(var2);
            var3.add(new Vec3d(0.0, (double)var2.height + 0.2, 0.0));
            boolean var10000 = false;
            Vec3d var4 = RenderUtil.get2DPos(var3.x, var3.y, var3.z);
            Vec3d var5 = RenderUtil.get2DPos(var3.x, var3.y - 2.0, var3.z);
            if (var4 != null) {
               if (var5 == null) {
                  var10000 = false;
               } else {
                  this.entityUpperBounds.put(var2, var4);
                  var10000 = false;
                  this.entityLowerBounds.put(var2, var5);
                  var10000 = false;
                  var10000 = false;
               }
            }
         }
      }

      public Map<Entity, Vec3d> getEntityLowerBounds() {
         return this.entityLowerBounds;
      }

      private EntityListener() {
         this.entityLowerBounds = Maps.newHashMap();
      }

      EntityListener(Object var1) {
         this();
      }

      static void access$100(Tracers.EntityListener var0) {
         var0.render();
      }
   }

   private static enum Mode {
      TRACER,
      ARROW;
      private static final Tracers.Mode[] $VALUES = new Tracers.Mode[]{TRACER, Tracers.Mode.ARROW};
   }
}
