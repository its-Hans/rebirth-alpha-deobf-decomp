package me.rebirthclient.mod.modules.impl.render;

import com.google.common.collect.Sets;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Set;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.RenderEntityEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.passive.EntityParrot;
import net.minecraft.entity.projectile.EntityWitherSkull;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoLag extends Module {
   public final Setting<Boolean> scoreBoards;
   private static final Set<SoundEvent> BLACKLIST = Sets.newHashSet(
      new SoundEvent[]{
         SoundEvents.ITEM_ARMOR_EQUIP_GENERIC,
         SoundEvents.ITEM_ARMOR_EQIIP_ELYTRA,
         SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND,
         SoundEvents.ITEM_ARMOR_EQUIP_IRON,
         SoundEvents.ITEM_ARMOR_EQUIP_GOLD,
         SoundEvents.ITEM_ARMOR_EQUIP_CHAIN,
         SoundEvents.ITEM_ARMOR_EQUIP_LEATHER
      }
   );
   public final Setting<Boolean> armor;
   public final Setting<Boolean> antiPopLag;
   public final Setting<Boolean> glowing;
   public final Setting<Boolean> parrots;
   public final Setting<Boolean> skulls;
   private final Setting<Boolean> crystals;
   private final Setting<Boolean> antiSound;
   public final Setting<Boolean> antiSpam = this.add(new Setting<>("AntiSpam", true));
   public final Setting<Boolean> tnt;
   public static NoLag INSTANCE;

   public NoLag() {
      super("NoLag", "Removes several things that may cause fps drops", Category.RENDER);
      this.antiPopLag = this.add(new Setting<>("AntiPopLag", true));
      this.skulls = this.add(new Setting<>("WitherSkulls", false));
      this.tnt = this.add(new Setting<>("PrimedTNT", false));
      this.scoreBoards = this.add(new Setting<>("ScoreBoards", true));
      this.glowing = this.add(new Setting<>("GlowingEntities", true));
      this.parrots = this.add(new Setting<>("Parrots", true));
      this.antiSound = this.add(new Setting<>("AntiSound", true).setParent());
      this.armor = this.add(new Setting<>("Armor", true, this::lambda$new$0));
      this.crystals = this.add(new Setting<>("Crystals", true, this::lambda$new$1));
      INSTANCE = this;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.antiSound.isOpen();
   }

   @SubscribeEvent
   public void onRenderEntity(RenderEntityEvent var1) {
      if (var1.getEntity() != null) {
         if (this.skulls.getValue() && var1.getEntity() instanceof EntityWitherSkull) {
            var1.setCanceled(true);
         }

         if (this.tnt.getValue() && var1.getEntity() instanceof EntityTNTPrimed) {
            var1.setCanceled(true);
         }

         if (this.parrots.getValue() && var1.getEntity() instanceof EntityParrot) {
            var1.setCanceled(true);
         }
      }
   }

   @Override
   public void onTick() {
      if (this.glowing.getValue()) {
         for(Entity var2 : mc.world.loadedEntityList) {
            if (var2.isGlowing()) {
               var2.setGlowing(false);
            }

            boolean var10000 = false;
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled()) {
         if (var1.getPacket() instanceof SPacketChat && this.antiPopLag.getValue()) {
            String var2 = var1.getPacket().chatComponent.getUnformattedText();
            if (var2.contains("㼁")
               || var2.contains("㠁")
               || var2.contains("ᬁ")
               || var2.contains("ሁ")
               || var2.contains("ā")
               || var2.contains("嬁")
               || var2.contains("懺")) {
               var1.setCanceled(true);
               var1.getPacket().chatComponent = null;
               this.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Removed lag text")));
               return;
            }
         }

         if (var1.getPacket() instanceof SPacketChat && this.antiSpam.getValue()) {
            String var4 = var1.getPacket().chatComponent.getUnformattedText();
            if (var4.contains("Sorry, but you can't change that here.")
               || var4.contains("Sorry, but you can't place things here.")
               || var4.contains("Sorry, but you can't break that block here.")
               || var4.contains("Sorry, but you can't use that here.")
               || var4.contains("[AdvancedPortals] You don't have permission to build here!")
               || var4.contains("Sorry, but you can't PvP here.")
               || var4.contains("You cannot teleport while in spectator mode.")
               || var4.contains("你莫得 S.use 权限!")) {
               var1.setCanceled(true);
               var1.getPacket().chatComponent = null;
               return;
            }
         }

         if (var1.getPacket() instanceof SPacketSoundEffect && this.antiSound.getValue()) {
            SPacketSoundEffect var3 = var1.getPacket();
            if (this.crystals.getValue() && var3.getCategory() == SoundCategory.BLOCKS && var3.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) {
               var1.setCanceled(true);
               return;
            }

            if (BLACKLIST.contains(var3.getSound()) && this.armor.getValue()) {
               var1.setCanceled(true);
            }
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.antiSound.isOpen();
   }
}
