package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import java.util.HashMap;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class PlaceRender extends Module {
   public final Setting<Color> color;
   private final Setting<Integer> animationTime;
   public static PlaceRender INSTANCE;
   public static HashMap<BlockPos, PlaceRender.placePosition> PlaceMap = new HashMap<>();
   private final Setting<Boolean> sync;
   private final Setting<Boolean> outline;
   private final Setting<Boolean> box = this.add(new Setting<>("Box", true));

   public PlaceRender() {
      super("PlaceRender", "test", Category.RENDER);
      this.outline = this.add(new Setting<>("Outline", false));
      this.animationTime = this.add(new Setting<>("animationTime", 1000, 0, 5000));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255, 100)));
      this.sync = this.add(new Setting<>("Sync", true));
      INSTANCE = this;
   }

   static Setting access$000(PlaceRender var0) {
      return var0.animationTime;
   }

   private void drawBlock(BlockPos var1, double var2, Color var4) {
      if (this.sync.getValue()) {
         var4 = this.color.getValue();
      }

      AxisAlignedBB var5 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
      if (this.outline.getValue()) {
         RenderUtil.drawBBBox(var5, var4, (int)((double)var4.getAlpha() * -var2));
      }

      if (this.box.getValue()) {
         RenderUtil.drawBoxESP(var1, var4, (int)((double)var4.getAlpha() * -var2));
      }
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      boolean var2 = true;

      for(PlaceRender.placePosition var4 : PlaceMap.values()) {
         if (var4.firstFade.easeOutQuad() == 1.0) {
            boolean var10000 = false;
         } else {
            var2 = false;
            this.drawBlock(var4.pos, var4.firstFade.easeOutQuad() - 1.0, var4.posColor);
            boolean var5 = false;
         }
      }

      if (var2) {
         PlaceMap.clear();
      }
   }

   public static class placePosition {
      public Color posColor;
      public BlockPos pos;
      public final FadeUtils firstFade = new FadeUtils((long)((Integer)PlaceRender.access$000(PlaceRender.INSTANCE).getValue()).intValue());

      public placePosition(BlockPos var1) {
         this.pos = var1;
         this.posColor = PlaceRender.INSTANCE.color.getValue();
      }
   }
}
