package me.rebirthclient.mod.modules.impl.render;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class AutoEsu extends Module {
   private final Setting<Boolean> noFriend;
   private final Setting<AutoEsu.Mode> mode;
   private final Setting<Integer> height;
   private final Setting<Integer> offsetY;
   private final Setting<Integer> width;
   private final Setting<Integer> offsetX = this.add(new Setting<>("OffsetX", -42, -500, 500));

   public AutoEsu() {
      super("AutoEsu", "IQ RuiNan", Category.RENDER);
      this.offsetY = this.add(new Setting<>("OffsetY", -27, -500, 500));
      this.width = this.add(new Setting<>("Width", 84, 0, 500));
      this.height = this.add(new Setting<>("Height", 40, 0, 500));
      this.noFriend = this.add(new Setting<>("NoFriend", true));
      this.mode = this.add(new Setting<>("Mode", AutoEsu.Mode.RuiNan));
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      for(EntityPlayer var3 : mc.world.playerEntities) {
         if (this.invalid(var3)) {
            boolean var10000 = false;
         } else {
            this.drawBurrowESP(var3.posX, var3.posY + 1.5, var3.posZ);
            boolean var4 = false;
         }
      }
   }

   private boolean invalid(Entity var1) {
      boolean var10000;
      if (var1 != null
         && !EntityUtil.isDead(var1)
         && !var1.equals(mc.player)
         && (!(var1 instanceof EntityPlayer) || !Managers.FRIENDS.isFriend(var1.getName()) || !this.noFriend.getValue())
         && !(mc.player.getDistanceSq(var1) < MathUtil.square(0.5))) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private void drawBurrowESP(double var1, double var3, double var5) {
      GlStateManager.pushMatrix();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      double var7 = 0.0245;
      GlStateManager.translate(var1 - mc.getRenderManager().renderPosX, var3 - mc.getRenderManager().renderPosY, var5 - mc.getRenderManager().renderPosZ);
      GlStateManager.glNormal3f(0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
      float var10000 = mc.getRenderManager().playerViewX;
      float var10001;
      if (mc.gameSettings.thirdPersonView == 2) {
         var10001 = -1.0F;
         boolean var10002 = false;
      } else {
         var10001 = 1.0F;
      }

      GlStateManager.rotate(var10000, var10001, 0.0F, 0.0F);
      GlStateManager.scale(-var7, -var7, -var7);
      RenderUtil.glColor(new Color(255, 255, 255, 120));
      RenderUtil.drawCircle(1.5F, -5.0F, 16.0F, ColorUtil.injectAlpha(new Color(255, 255, 255, 120).getRGB(), 0));
      GlStateManager.enableAlpha();
      if (this.mode.getValue() == AutoEsu.Mode.ShengJie) {
         mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/mugshot/shengjie.png"));
         boolean var9 = false;
      } else if (this.mode.getValue() == AutoEsu.Mode.RuiNan) {
         mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/mugshot/ruinan.png"));
         boolean var10 = false;
      } else if (this.mode.getValue() == AutoEsu.Mode.ShanZhu) {
         mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/mugshot/shanzhu.png"));
      }

      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      RenderUtil.drawModalRect(
         this.offsetX.getValue(), this.offsetY.getValue(), 0.0F, 0.0F, 12, 12, this.width.getValue(), this.height.getValue(), 12.0F, 12.0F
      );
      GlStateManager.disableAlpha();
      GlStateManager.enableDepth();
      GlStateManager.disableBlend();
      GlStateManager.disablePolygonOffset();
      GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
      GlStateManager.popMatrix();
   }

   public static enum Mode {
      ShanZhu,
      ShengJie,
      RuiNan;

      private static final AutoEsu.Mode[] $VALUES = new AutoEsu.Mode[]{RuiNan, ShengJie, ShanZhu};
   }
}
