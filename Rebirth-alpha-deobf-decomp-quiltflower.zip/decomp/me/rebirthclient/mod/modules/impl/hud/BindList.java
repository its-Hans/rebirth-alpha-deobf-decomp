package me.rebirthclient.mod.modules.impl.hud;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class BindList extends Module {
   private final Setting<Integer> x = this.add(new Setting<>("x", 50, 0, 500));
   private final Setting<Integer> y = this.add(new Setting<>("y", 50, 0, 500));
   private final Setting<Color> color = this.add(new Setting<>("color", new Color(255, 255, 255, 50)));

   @Override
   public void onRender2D(Render2DEvent var1) {
      int var2 = 0;
      int var3 = this.y.getValue();

      for(int var4 = 0; var4 < Managers.MODULES.sortedLength.size(); ++var4) {
         Module var5 = Managers.MODULES.sortedLength.get(var4);
         if (var5.getBind().getKey() == -1) {
            boolean var10000 = false;
         } else {
            String var6 = var5.getName();
            if (Managers.TEXT.getStringWidth(var6) > var2) {
               var2 = Managers.TEXT.getStringWidth(var6);
            }
         }

         boolean var10 = false;
      }

      for(int var7 = 0; var7 < Managers.MODULES.sortedLength.size(); ++var7) {
         Module var8 = Managers.MODULES.sortedLength.get(var7);
         if (var8.getBind().getKey() == -1) {
            boolean var11 = false;
         } else {
            String var9 = var8.getName();
            Managers.TEXT.drawString(var9, (float)this.x.getValue().intValue(), (float)var3, -1, true);
            boolean var12 = false;
            Managers.TEXT.drawString("[toggled]", (float)(this.x.getValue() + 10 + var2), (float)var3, -1, true);
            var12 = false;
            var3 += 10;
         }

         boolean var14 = false;
      }

      RenderUtil.drawRectangleCorrectly(
         this.x.getValue() - 4,
         this.y.getValue() - 16,
         18 + Managers.TEXT.getStringWidth("[toggled]") + var2,
         1,
         ColorUtil.toRGBA(this.color.getValue().getRed(), this.color.getValue().getGreen(), this.color.getValue().getBlue(), 255)
      );
      RenderUtil.drawRectangleCorrectly(
         this.x.getValue() - 4,
         this.y.getValue() - 15,
         18 + Managers.TEXT.getStringWidth("[toggled]") + var2,
         12,
         ColorUtil.toRGBA(new Color(0, 0, 0, this.color.getValue().getAlpha()))
      );
      Managers.TEXT
         .drawString(
            "keybinds",
            (float)(
               (double)this.x.getValue().intValue()
                  + ((double)(11 + var2) + (double)Managers.TEXT.getStringWidth("[toggled]")) / 2.0
                  - (double)Managers.TEXT.getStringWidth("keybinds") / 2.0
            ),
            (float)(this.y.getValue() - 13),
            ColorUtil.toRGBA(255, 255, 255, 255),
            true
         );
      boolean var15 = false;
   }

   public BindList() {
      super("BindList", "test", Category.HUD);
   }
}
