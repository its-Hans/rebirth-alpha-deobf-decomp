package me.rebirthclient.mod.modules.impl.hud;

import java.awt.Color;
import java.util.ArrayList;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;

public class Notifications extends Module {
   private final Setting<Integer> notifyY;
   private final Setting<Color> color = this.add(new Setting<>("Color", new Color(255, 255, 255)));
   public static final ArrayList<Notifications.Notifys> notifyList = new ArrayList<>();

   @Override
   public void onRender2D(Render2DEvent var1) {
      int var2 = Managers.TEXT.scaledHeight - this.notifyY.getValue();
      int var3 = Managers.TEXT.scaledWidth;
      boolean var4 = true;
      int var5 = ColorUtil.toRGBA(this.color.getValue().getRed(), this.color.getValue().getGreen(), this.color.getValue().getBlue(), 255);
      if (!notifyList.isEmpty()) {
         for(Notifications.Notifys var7 : notifyList) {
            if (var7 != null) {
               if (var7.first == null) {
                  boolean var10000 = false;
               } else if (var7.delayed < 1) {
                  boolean var11 = false;
               } else {
                  var4 = false;
                  if (var7.delayed < 5 && !var7.end) {
                     var7.end = true;
                     var7.endFade.reset();
                  }

                  var2 = (int)((double)var2 - 18.0 * var7.yFade.easeOutQuad());
                  String var8 = var7.first;
                  double var9;
                  if (var7.delayed < 5) {
                     var9 = (double)var3 - (double)(Managers.TEXT.getStringWidth(var8) + 10) * (1.0 - var7.endFade.easeOutQuad());
                     boolean var12 = false;
                  } else {
                     var9 = (double)var3 - (double)(Managers.TEXT.getStringWidth(var8) + 10) * var7.firstFade.easeOutQuad();
                  }

                  if (this.color.getValue().getAlpha() > 5) {
                     RenderUtil.drawRectangleCorrectly(
                        (int)var9, var2, 10 + Managers.TEXT.getStringWidth(var8), 15, ColorUtil.toRGBA(20, 20, 20, this.color.getValue().getAlpha())
                     );
                  }

                  Managers.TEXT.drawString(var8, (float)(5 + (int)var9), (float)(4 + var2), this.color.getValue().getRGB(), true);
                  boolean var13 = false;
                  if (var7.delayed < 5) {
                     var2 = (int)((double)var2 + 18.0 * var7.yFade.easeOutQuad() - 18.0 * (1.0 - var7.endFade.easeOutQuad()));
                     var13 = false;
                  } else {
                     RenderUtil.drawRectangleCorrectly((int)var9, var2 + 14, (10 + Managers.TEXT.getStringWidth(var8)) * (var7.delayed - 4) / 62, 1, var5);
                  }

                  var13 = false;
               }
            }
         }

         if (var4) {
            notifyList.clear();
         }
      }
   }

   @Override
   public void onEnable() {
      notifyList.clear();
   }

   @Override
   public void onDisable() {
      notifyList.clear();
   }

   @Override
   public void onUpdate() {
      for(Notifications.Notifys var2 : notifyList) {
         if (var2 == null) {
            boolean var10000 = false;
         } else if (var2.first == null) {
            boolean var3 = false;
         } else {
            --var2.delayed;
            boolean var4 = false;
         }
      }
   }

   public static void add(String var0) {
      notifyList.add(new Notifications.Notifys(var0));
      boolean var10000 = false;
   }

   public Notifications() {
      super("Notifications", "Notify toggle module", Category.HUD);
      this.notifyY = this.add(new Setting<>("Y", 18, 25, 500));
   }

   public static class Notifys {
      public final String first;
      public final FadeUtils yFade;
      public boolean end;
      public final FadeUtils endFade;
      public int delayed;
      public final FadeUtils firstFade = new FadeUtils(500L);

      public Notifys(String var1) {
         this.yFade = new FadeUtils(500L);
         this.endFade = new FadeUtils(350L);
         this.delayed = 55;
         this.first = var1;
         this.firstFade.reset();
         this.yFade.reset();
         this.endFade.reset();
         this.end = false;
      }
   }
}
