package me.rebirthclient.mod.modules.impl.hud;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

public class InventoryPreview extends Module {
   public final Setting<InventoryPreview.YOffset> yOffset;
   public final Setting<Integer> y;
   public final Setting<InventoryPreview.XOffset> xOffset = this.add(new Setting<>("XOffset", InventoryPreview.XOffset.CUSTOM));
   public final Setting<Integer> x = this.add(new Setting<>("X", 500, 0, 1000, this::lambda$new$0));
   public final Setting<Boolean> rect;
   public final Setting<Boolean> outline;
   public final Setting<Color> secondColor;
   public final Setting<Color> rectColor;
   public final Setting<Color> lineColor;

   private boolean lambda$new$1(Integer var1) {
      boolean var10000;
      if (this.yOffset.getValue() == InventoryPreview.YOffset.CUSTOM) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Color var1) {
      return this.outline.isOpen();
   }

   private boolean lambda$new$0(Integer var1) {
      boolean var10000;
      if (this.xOffset.getValue() == InventoryPreview.XOffset.CUSTOM) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if (!fullNullCheck()) {
         GlStateManager.enableTexture2D();
         GlStateManager.disableLighting();
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         GlStateManager.enableBlend();
         GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
         GlStateManager.disableDepth();
         int var10000;
         if (this.xOffset.getValue() == InventoryPreview.XOffset.CUSTOM) {
            var10000 = this.x.getValue();
            boolean var10001 = false;
         } else if (this.xOffset.getValue() == InventoryPreview.XOffset.LEFT) {
            var10000 = 0;
            boolean var12 = false;
         } else {
            var10000 = Managers.TEXT.scaledWidth - 172;
         }

         int var2 = var10000;
         if (this.yOffset.getValue() == InventoryPreview.YOffset.CUSTOM) {
            var10000 = this.y.getValue();
            boolean var13 = false;
         } else if (this.yOffset.getValue() == InventoryPreview.YOffset.TOP) {
            var10000 = 0;
            boolean var14 = false;
         } else {
            var10000 = Managers.TEXT.scaledHeight - 74;
         }

         int var3 = var10000;
         if (this.outline.getValue()) {
            float var10 = (float)var2 + 6.5F;
            float var15 = (float)var3 + 16.5F;
            float var10002 = (float)var2 + 171.5F;
            float var10003 = (float)var3 + 73.5F;
            int var10005 = this.lineColor.getValue().getRGB();
            int var10006;
            if (this.secondColor.booleanValue) {
               var10006 = this.secondColor.getValue().getRGB();
               boolean var10007 = false;
            } else {
               var10006 = this.lineColor.getValue().getRGB();
            }

            RenderUtil.drawNameTagOutline(var10, var15, var10002, var10003, 1.0F, var10005, var10006, false);
         }

         if (this.rect.getValue()) {
            RenderUtil.drawRect((float)(var2 + 7), (float)(var3 + 17), (float)(var2 + 171), (float)(var3 + 73), this.rectColor.getValue().getRGB());
         }

         GlStateManager.enableDepth();
         RenderHelper.enableGUIStandardItemLighting();
         GlStateManager.enableRescaleNormal();
         GlStateManager.enableColorMaterial();
         GlStateManager.enableLighting();
         NonNullList var4 = mc.player.inventory.mainInventory;

         for(int var5 = 0; var5 < var4.size() - 9; ++var5) {
            int var6 = var2 + var5 % 9 * 18 + 8;
            int var7 = var3 + var5 / 9 * 18 + 18;
            ItemStack var8 = (ItemStack)var4.get(var5 + 9);
            mc.getItemRenderer().itemRenderer.zLevel = 501.0F;
            mc.getRenderItem().renderItemAndEffectIntoGUI(var8, var6, var7);
            mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, var8, var6, var7, null);
            mc.getItemRenderer().itemRenderer.zLevel = 0.0F;
            boolean var11 = false;
         }

         GlStateManager.disableLighting();
         GlStateManager.disableBlend();
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }

   private boolean lambda$new$3(Color var1) {
      return this.outline.isOpen();
   }

   private boolean lambda$new$4(Color var1) {
      return this.rect.isOpen();
   }

   public InventoryPreview() {
      super("Inventory", "Allows you to see your own inventory without opening it", Category.HUD);
      this.yOffset = this.add(new Setting<>("YOffset", InventoryPreview.YOffset.CUSTOM));
      this.y = this.add(new Setting<>("Y", 2, 0, 1000, this::lambda$new$1));
      this.outline = this.add(new Setting<>("Outline", true).setParent());
      this.lineColor = this.add(new Setting<>("LineColor", new Color(10, 10, 10, 100), this::lambda$new$2));
      this.secondColor = this.add(new Setting<>("SecondColor", new Color(30, 30, 30, 100), this::lambda$new$3).injectBoolean(true));
      this.rect = this.add(new Setting<>("Rect", true).setParent());
      this.rectColor = this.add(new Setting<>("RectColor", new Color(10, 10, 10, 50), this::lambda$new$4));
   }

   private static enum XOffset {
      LEFT,
      CUSTOM,
      RIGHT;
      private static final InventoryPreview.XOffset[] $VALUES = new InventoryPreview.XOffset[]{
         InventoryPreview.XOffset.CUSTOM, LEFT, InventoryPreview.XOffset.RIGHT
      };
   }

   private static enum YOffset {
      CUSTOM,
      TOP,
      BOTTOM;
      private static final InventoryPreview.YOffset[] $VALUES = new InventoryPreview.YOffset[]{CUSTOM, TOP, InventoryPreview.YOffset.BOTTOM};
   }
}
