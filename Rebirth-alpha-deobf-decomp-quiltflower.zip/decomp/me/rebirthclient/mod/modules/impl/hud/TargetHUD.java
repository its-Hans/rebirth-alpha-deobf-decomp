package me.rebirthclient.mod.modules.impl.hud;

import java.awt.Color;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class TargetHUD extends Module {
   private final Setting<Integer> x = this.add(new Setting<>("X", 50, 0, 2000));
   private final Setting<Integer> y = this.add(new Setting<>("Y", 50, 0, 2000));
   private final Setting<Integer> backgroundAlpha = this.add(new Setting<>("Alpha", 80, 0, 255));
   EntityLivingBase target = mc.player;

   private static boolean checkIsNotPlayer(Entity var0) {
      boolean var10000;
      if (!var0.equals(mc.player)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public synchronized void onRender2D(Render2DEvent var1) {
      if (this.target != null && !this.target.isDead) {
         FontRenderer var2 = mc.fontRenderer;
         int var10000;
         if (this.target.getHealth() / this.target.getMaxHealth() > 0.66F) {
            var10000 = -16711936;
            boolean var10001 = false;
         } else if (this.target.getHealth() / this.target.getMaxHealth() > 0.33F) {
            var10000 = -26368;
            boolean var32 = false;
         } else {
            var10000 = -65536;
         }

         int var3 = var10000;
         GlStateManager.color(1.0F, 1.0F, 1.0F);
         GuiInventory.drawEntityOnScreen(this.x.getValue() + 15, this.y.getValue() + 32, 15, 1.0F, 1.0F, this.target);
         LinkedList var4 = new LinkedList();
         LinkedList var5 = new LinkedList();
         this.target.getArmorInventoryList().forEach(TargetHUD::lambda$onRender2D$0);

         for(int var6 = var5.size() - 1; var6 >= 0; --var6) {
            var4.add(var5.get(var6));
            boolean var14 = false;
            var14 = false;
         }

         int var11 = 0;
         switch(var4.size()) {
            case 0:
               if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 28, this.y.getValue() + 18);
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 43, this.y.getValue() + 18);
                  var11 += 45;
                  boolean var29 = false;
               } else {
                  if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                     break;
                  }

                  RenderItem var27 = mc.getRenderItem();
                  ItemStack var37;
                  if (this.target.getHeldItemMainhand().isEmpty()) {
                     var37 = this.target.getHeldItemOffhand();
                     boolean var41 = false;
                  } else {
                     var37 = this.target.getHeldItemMainhand();
                  }

                  var27.renderItemAndEffectIntoGUI(var37, this.x.getValue() + 28, this.y.getValue() + 18);
                  var11 += 30;
                  boolean var28 = false;
               }
               break;
            case 1:
               var11 = 15;
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
               if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 43, this.y.getValue() + 18);
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 58, this.y.getValue() + 18);
                  var11 += 45;
                  boolean var26 = false;
               } else {
                  if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                     break;
                  }

                  RenderItem var24 = mc.getRenderItem();
                  ItemStack var36;
                  if (this.target.getHeldItemMainhand().isEmpty()) {
                     var36 = this.target.getHeldItemOffhand();
                     boolean var40 = false;
                  } else {
                     var36 = this.target.getHeldItemMainhand();
                  }

                  var24.renderItemAndEffectIntoGUI(var36, this.x.getValue() + 43, this.y.getValue() + 18);
                  var11 += 30;
                  boolean var25 = false;
               }
               break;
            case 2:
               var11 = 30;
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(1), this.x.getValue() + 43, this.y.getValue() + 18);
               if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 58, this.y.getValue() + 18);
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 73, this.y.getValue() + 18);
                  var11 += 45;
                  boolean var23 = false;
               } else {
                  if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                     break;
                  }

                  RenderItem var21 = mc.getRenderItem();
                  ItemStack var35;
                  if (this.target.getHeldItemMainhand().isEmpty()) {
                     var35 = this.target.getHeldItemOffhand();
                     boolean var39 = false;
                  } else {
                     var35 = this.target.getHeldItemMainhand();
                  }

                  var21.renderItemAndEffectIntoGUI(var35, this.x.getValue() + 58, this.y.getValue() + 18);
                  var11 += 30;
                  boolean var22 = false;
               }
               break;
            case 3:
               var11 = 45;
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(1), this.x.getValue() + 43, this.y.getValue() + 18);
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(2), this.x.getValue() + 58, this.y.getValue() + 18);
               if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 73, this.y.getValue() + 18);
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 98, this.y.getValue() + 18);
                  var11 += 45;
                  boolean var20 = false;
               } else {
                  if (this.target.getHeldItemMainhand().isEmpty() && this.target.getHeldItemOffhand().isEmpty()) {
                     break;
                  }

                  RenderItem var18 = mc.getRenderItem();
                  ItemStack var34;
                  if (this.target.getHeldItemMainhand().isEmpty()) {
                     var34 = this.target.getHeldItemOffhand();
                     boolean var38 = false;
                  } else {
                     var34 = this.target.getHeldItemMainhand();
                  }

                  var18.renderItemAndEffectIntoGUI(var34, this.x.getValue() + 73, this.y.getValue() + 18);
                  var11 += 30;
                  boolean var19 = false;
               }
               break;
            case 4:
               var11 = 60;
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(0), this.x.getValue() + 28, this.y.getValue() + 18);
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(1), this.x.getValue() + 43, this.y.getValue() + 18);
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(2), this.x.getValue() + 58, this.y.getValue() + 18);
               mc.getRenderItem().renderItemAndEffectIntoGUI((ItemStack)var4.get(3), this.x.getValue() + 73, this.y.getValue() + 18);
               if (!this.target.getHeldItemMainhand().isEmpty() && !this.target.getHeldItemOffhand().isEmpty()) {
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemMainhand(), this.x.getValue() + 98, this.y.getValue() + 18);
                  mc.getRenderItem().renderItemAndEffectIntoGUI(this.target.getHeldItemOffhand(), this.x.getValue() + 113, this.y.getValue() + 18);
                  var11 += 45;
                  boolean var17 = false;
               } else if (!this.target.getHeldItemMainhand().isEmpty() || !this.target.getHeldItemOffhand().isEmpty()) {
                  RenderItem var16 = mc.getRenderItem();
                  ItemStack var33;
                  if (this.target.getHeldItemMainhand().isEmpty()) {
                     var33 = this.target.getHeldItemOffhand();
                     boolean var10002 = false;
                  } else {
                     var33 = this.target.getHeldItemMainhand();
                  }

                  var16.renderItemAndEffectIntoGUI(var33, this.x.getValue() + 98, this.y.getValue() + 18);
                  var11 += 30;
               }
         }

         int var7 = this.y.getValue() + 35;
         int var8 = var2.getStringWidth(this.target.getName()) + 30;
         int var9;
         if (var2.getStringWidth(this.target.getName()) > var11) {
            var9 = this.x.getValue() + var8;
            boolean var30 = false;
         } else {
            var9 = this.x.getValue() + var11 + 30;
         }

         var9 += 5;
         var7 += 5;
         Gui.drawRect(this.x.getValue() - 2, this.y.getValue(), var9, var7, new Color(0, 0, 0, this.backgroundAlpha.getValue()).getRGB());
         int var10 = (int)(this.target.getHealth() / this.target.getMaxHealth() * (float)(var9 - this.x.getValue()));
         Gui.drawRect(this.x.getValue() - 2, var7 - 2, this.x.getValue() + var10, var7, var3);
         var2.drawString(this.target.getName(), (float)(this.x.getValue() + 30), (float)(this.y.getValue() + 8), new Color(255, 255, 255).getRGB(), true);
         boolean var31 = false;
      }
   }

   public TargetHUD() {
      super("TargetHUD", "description", Category.HUD);
   }

   private static double applyAsDouble(EntityLivingBase var0) {
      return (double)var0.getDistance(mc.player);
   }

   private static void lambda$onRender2D$0(List var0, ItemStack var1) {
      if (!var1.isEmpty()) {
         var0.add(var1);
         boolean var10000 = false;
      }
   }

   @Override
   public synchronized void onTick() {
      LinkedList var1 = new LinkedList();
      Stream var10000 = mc.world.loadedEntityList.stream();
      boolean var10001 = false;
      var10000 = var10000.filter(EntityPlayer.class::isInstance).filter(TargetHUD::checkIsNotPlayer);
      var10001 = false;
      var10000 = var10000.map(EntityLivingBase.class::cast).sorted(Comparator.comparingDouble(TargetHUD::applyAsDouble));
      var10001 = false;
      var10000.forEach(var1::add);
      if (!var1.isEmpty()) {
         this.target = (EntityLivingBase)var1.get(0);
         boolean var4 = false;
      } else {
         this.target = mc.player;
      }

      if (mc.currentScreen instanceof GuiChat) {
         this.target = mc.player;
      }
   }
}
