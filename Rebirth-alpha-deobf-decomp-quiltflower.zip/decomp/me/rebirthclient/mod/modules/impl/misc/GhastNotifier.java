package me.rebirthclient.mod.modules.impl.misc;

import java.util.HashSet;
import java.util.Set;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.init.SoundEvents;

public class GhastNotifier extends Module {
   private final Setting<Boolean> sound;
   private final Setting<Boolean> censorCoords;
   private final Set<Entity> ghasts;
   private final Setting<Boolean> chat = this.add(new Setting<>("Chat", true).setParent());

   @Override
   public void onUpdate() {
      for(Entity var2 : mc.world.getLoadedEntityList()) {
         if (var2 instanceof EntityGhast) {
            if (this.ghasts.contains(var2)) {
               boolean var10000 = false;
            } else {
               if (this.chat.getValue()) {
                  if (this.censorCoords.getValue()) {
                     this.sendMessage("There is a ghast!");
                     boolean var3 = false;
                  } else {
                     this.sendMessage(
                        String.valueOf(
                           new StringBuilder()
                              .append("There is a ghast at: ")
                              .append(var2.getPosition().getX())
                              .append("X, ")
                              .append(var2.getPosition().getY())
                              .append("Y, ")
                              .append(var2.getPosition().getZ())
                              .append("Z.")
                        )
                     );
                  }
               }

               this.ghasts.add(var2);
               boolean var4 = false;
               if (!this.sound.getValue()) {
                  var4 = false;
               } else {
                  mc.player.playSound(SoundEvents.BLOCK_ANVIL_DESTROY, 1.0F, 1.0F);
                  var4 = false;
               }
            }
         }
      }
   }

   public GhastNotifier() {
      super("GhastNotify", "Helps you find ghasts", Category.MISC);
      this.censorCoords = this.add(new Setting<>("CensorCoords", false, this::lambda$new$0));
      this.sound = this.add(new Setting<>("Sound", true));
      this.ghasts = new HashSet();
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.chat.isOpen();
   }

   @Override
   public void onEnable() {
      this.ghasts.clear();
   }
}
