package me.rebirthclient.mod.modules.impl.misc;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;

public class Coords extends Module {
   @Override
   public void onEnable() {
      int var1 = (int)mc.player.posX;
      int var2 = (int)mc.player.posY;
      int var3 = (int)mc.player.posZ;
      String var4 = String.valueOf(new StringBuilder().append("X: ").append(var1).append(" Y: ").append(var2).append(" Z: ").append(var3));
      StringSelection var5 = new StringSelection(var4);
      Clipboard var6 = Toolkit.getDefaultToolkit().getSystemClipboard();
      var6.setContents(var5, null);
      this.disable();
   }

   public Coords() {
      super("Coords", "copies your current position to the clipboard", Category.MISC);
   }
}
