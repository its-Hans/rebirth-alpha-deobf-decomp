package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.network.play.client.CPacketChatMessage;

public class AutoKit extends Module {
   public final Setting<String> Name = this.add(new Setting<>("KitName", "1"));
   boolean needKit = false;

   public AutoKit() {
      super("AutoKit", "Auto select kit", Category.MISC);
   }

   @Override
   public void onUpdate() {
      if (mc.currentScreen instanceof GuiGameOver) {
         this.needKit = true;
         boolean var10000 = false;
      } else if (this.needKit) {
         mc.player.connection.sendPacket(new CPacketChatMessage(String.valueOf(new StringBuilder().append("/kit ").append(this.Name.getValue()))));
         this.needKit = false;
      }
   }
}
