package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoReconnect extends Module {
   private final Setting<Integer> delay = this.add(new Setting<>("Delay", 5));
   private static ServerData serverData;
   public static AutoReconnect INSTANCE;

   public void updateLastConnectedServer() {
      ServerData var1 = mc.getCurrentServerData();
      if (var1 != null) {
         serverData = var1;
      }
   }

   static ServerData access$100() {
      return serverData;
   }

   @SubscribeEvent
   public void sendPacket(GuiOpenEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getGui() instanceof GuiDisconnected) {
            this.updateLastConnectedServer();
            GuiDisconnected var2 = (GuiDisconnected)var1.getGui();
            var1.setGui(new AutoReconnect.GuiDisconnectedHook(this, var2));
         }
      }
   }

   @SubscribeEvent
   public void onWorldUnload(Unload var1) {
      if (!fullNullCheck()) {
         this.updateLastConnectedServer();
      }
   }

   static Setting access$000(AutoReconnect var0) {
      return var0.delay;
   }

   public AutoReconnect() {
      super("AutoReconnect", "Reconnects you if you disconnect", Category.MISC);
      INSTANCE = this;
   }

   private class GuiDisconnectedHook extends GuiDisconnected {
      final AutoReconnect this$0;
      private final Timer timer;

      public GuiDisconnectedHook(AutoReconnect var1, GuiDisconnected var2) {
         super(var2.parentScreen, var2.reason, var2.message);
         this.this$0 = var1;
         this.timer = new Timer();
         this.timer.reset();
         boolean var10000 = false;
      }

      public void updateScreen() {
         if (this.timer.passedS((double)((Integer)AutoReconnect.access$000(this.this$0).getValue()).intValue())) {
            Minecraft var10000 = this.mc;
            GuiConnecting var10001 = new GuiConnecting;
            GuiScreen var10003 = this.parentScreen;
            Minecraft var10004 = this.mc;
            ServerData var10005;
            if (AutoReconnect.access$100() == null) {
               var10005 = this.mc.currentServerData;
               boolean var10006 = false;
            } else {
               var10005 = AutoReconnect.access$100();
            }

            var10001./* $QF: Unable to resugar constructor */<init>(var10003, var10004, var10005);
            var10000.displayGuiScreen(var10001);
         }
      }

      public void drawScreen(int var1, int var2, float var3) {
         super.drawScreen(var1, var2, var3);
         String var4 = String.valueOf(
            new StringBuilder()
               .append("Reconnecting in ")
               .append(MathUtil.round((double)((long)(AutoReconnect.access$000(this.this$0).getValue() * 1000) - this.timer.getPassedTimeMs()) / 1000.0, 1))
         );
         this.mc
            .fontRenderer
            .drawString(var4, (float)this.width / 2.0F - (float)this.mc.fontRenderer.getStringWidth(var4) / 2.0F, (float)(this.height - 16), 16777215, true);
         boolean var10000 = false;
      }
   }
}
