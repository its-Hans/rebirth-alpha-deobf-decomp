package me.rebirthclient.mod.modules.impl.misc;

import java.util.HashMap;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiSpam extends Module {
   int size;
   public static AntiSpam INSTANCE = new AntiSpam();
   private final Setting<Boolean> number = this.add(new Setting<>("Number", true));
   private static final HashMap<String, AntiSpam.text> StringMap = new HashMap<>();

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            if (var1.getPacket() instanceof SPacketChat) {
               var1.setCanceled(true);
               ITextComponent var2 = ((SPacketChat)var1.getPacket()).getChatComponent();
               String var3 = var2.getFormattedText();
               if (StringMap.containsKey(var3)) {
                  StringMap.get(var3).addNumber();
                  GuiNewChat var4 = mc.ingameGUI.getChatGUI();
                  Command.ChatMessage var10001 = new Command.ChatMessage;
                  StringBuilder var10003 = new StringBuilder().append(var3);
                  String var10004;
                  if (this.number.getValue()) {
                     var10004 = String.valueOf(new StringBuilder().append(" §7x").append(StringMap.get(var3).number));
                     boolean var10005 = false;
                  } else {
                     var10004 = "";
                  }

                  var10001./* $QF: Unable to resugar constructor */<init>(String.valueOf(var10003.append(var10004)));
                  var4.printChatMessageWithOptionalDeletion(var10001, StringMap.get(var3).size);
               } else {
                  ++this.size;
                  mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(var2, this.size);
                  StringMap.put(var3, new AntiSpam.text(this.size));
                  boolean var10000 = false;
               }
            }
         }
      }
   }

   public AntiSpam() {
      super("AntiSpam", "Anti Spam", Category.MISC);
      this.size = 2;
      INSTANCE = this;
   }

   private static class text {
      int number = 1;
      int size;

      public void addNumber() {
         ++this.number;
      }

      public text(int var1) {
         this.size = var1;
      }
   }
}
