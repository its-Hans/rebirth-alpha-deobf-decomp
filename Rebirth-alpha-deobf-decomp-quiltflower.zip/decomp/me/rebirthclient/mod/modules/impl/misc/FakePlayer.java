package me.rebirthclient.mod.modules.impl.misc;

import com.mojang.authlib.GameProfile;
import java.util.Random;
import java.util.UUID;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.util.DamageUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.render.EarthPopChams;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.MoverType;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameType;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FakePlayer extends Module {
   EntityOtherPlayerMP player;
   int ticks2;
   private final Setting<Integer> gappleDelay;
   boolean pop;
   private final Setting<Integer> hurtTime;
   private final Setting<String> name = this.add(new Setting<>("Name", ""));
   int ticks;
   private final Setting<Boolean> damage;
   private final Setting<Boolean> move = this.add(new Setting<>("Move", false));
   private final Setting<Integer> totemHurtTime;
   int ticks3;

   private boolean lambda$new$1(Integer var1) {
      return this.damage.isOpen();
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            if (var1.getPacket() instanceof SPacketExplosion && this.damage.getValue()) {
               if (this.player.getDistance(var1.getPacket().posX, var1.getPacket().posY, ((SPacketExplosion)var1.getPacket()).getZ()) > 8.0) {
                  return;
               }

               if (this.ticks3 > this.hurtTime.getValue() - 1 && !this.pop) {
                  BlockPos var4 = new BlockPos(
                     ((SPacketExplosion)var1.getPacket()).getX(), ((SPacketExplosion)var1.getPacket()).getY(), ((SPacketExplosion)var1.getPacket()).getZ()
                  );
                  float var5 = DamageUtil.calculateDamage(var4.down(), this.player);
                  this.doPop(var5);
                  this.ticks3 = 0;
                  boolean var10000 = false;
               } else if (this.ticks3 > this.totemHurtTime.getValue() - 1) {
                  BlockPos var2 = new BlockPos(
                     ((SPacketExplosion)var1.getPacket()).getX(), ((SPacketExplosion)var1.getPacket()).getY(), ((SPacketExplosion)var1.getPacket()).getZ()
                  );
                  float var3 = DamageUtil.calculateDamage(var2.down(), this.player);
                  this.doPop(var3);
                  this.pop = false;
                  this.ticks3 = 0;
               }
            }
         }
      }
   }

   public FakePlayer() {
      super("FakePlayer", "Summons a client-side fake player", Category.MISC);
      this.damage = this.add(new Setting<>("Damage", true).setParent());
      this.totemHurtTime = this.add(new Setting<>("TotemHurtTime", 25, 0, 50, this::lambda$new$0));
      this.hurtTime = this.add(new Setting<>("HurtTime", 10, 0, 50, this::lambda$new$1));
      this.gappleDelay = this.add(new Setting<>("GappleDelay", 100, 0, 200, this::lambda$new$2));
      this.player = null;
      this.ticks3 = 0;
      this.pop = false;
      this.ticks = 0;
      this.ticks2 = 0;
   }

   @Override
   public void onEnable() {
      this.sendMessage(String.valueOf(new StringBuilder().append("Spawned a fakeplayer with the name ").append(this.name.getValue()).append(".")));
      if (mc.player != null && !mc.player.isDead) {
         this.player = new EntityOtherPlayerMP(mc.world, new GameProfile(UUID.fromString("0f75a81d-70e5-43c5-b892-f33c524284f2"), this.name.getValue()));
         this.player.copyLocationAndAnglesFrom(mc.player);
         this.player.rotationYawHead = mc.player.rotationYawHead;
         this.player.rotationYaw = mc.player.rotationYaw;
         this.player.rotationPitch = mc.player.rotationPitch;
         this.player.setGameType(GameType.SURVIVAL);
         this.player.inventory.copyInventory(mc.player.inventory);
         this.player.setHealth(20.0F);
         this.player.setAbsorptionAmount(16.0F);
         mc.world.addEntityToWorld(-12345, this.player);
         this.player.onLivingUpdate();
      } else {
         this.disable();
      }
   }

   @Override
   public void onDisable() {
      if (mc.world != null) {
         mc.world.removeEntityFromWorld(-12345);
         boolean var10000 = false;
      }
   }

   public void travel(float var1, float var2, float var3) {
      double var4 = this.player.posY;
      float var6 = 0.8F;
      float var7 = 0.02F;
      float var8 = (float)EnchantmentHelper.getDepthStriderModifier(this.player);
      if (var8 > 3.0F) {
         var8 = 3.0F;
      }

      if (!this.player.onGround) {
         var8 *= 0.5F;
      }

      if (var8 > 0.0F) {
         var6 += (0.54600006F - var6) * var8 / 3.0F;
         var7 += (this.player.getAIMoveSpeed() - var7) * var8 / 4.0F;
      }

      this.player.moveRelative(var1, var2, var3, var7);
      this.player.move(MoverType.SELF, this.player.motionX, this.player.motionY, this.player.motionZ);
      this.player.motionX *= (double)var6;
      this.player.motionY *= 0.8F;
      this.player.motionZ *= (double)var6;
      if (!this.player.hasNoGravity()) {
         this.player.motionY -= 0.02;
      }

      if (this.player.collidedHorizontally
         && this.player.isOffsetPositionInLiquid(this.player.motionX, this.player.motionY + 0.6F - this.player.posY + var4, this.player.motionZ)) {
         this.player.motionY = 0.3F;
      }
   }

   private boolean lambda$new$0(Integer var1) {
      return this.damage.isOpen();
   }

   private boolean lambda$new$2(Integer var1) {
      return this.damage.isOpen();
   }

   private void doPop(float var1) {
      float var2 = var1 - this.player.getAbsorptionAmount();
      if ((double)(this.player.getHealth() - var2) < 0.1) {
         EarthPopChams.INSTANCE.onTotemPop(this.player);
         mc.world
            .playSound(mc.player, this.player.posX, this.player.posY, this.player.posZ, SoundEvents.ITEM_TOTEM_USE, mc.player.getSoundCategory(), 1.0F, 1.0F);
         this.player.setHealth(2.0F);
         this.player.setAbsorptionAmount(8.0F);
         this.pop = true;
         boolean var10000 = false;
      } else {
         if (var2 < 0.0F) {
            var2 = 0.0F;
         }

         this.player.setHealth(this.player.getHealth() - var2);
         float var3 = this.player.getAbsorptionAmount() - var1;
         if (var3 < 0.0F) {
            var3 = 0.0F;
         }

         this.player.setAbsorptionAmount(var3);
      }
   }

   @Override
   public void onLogin() {
      if (this.isOn()) {
         this.disable();
      }
   }

   @Override
   public void onLogout() {
      if (this.isOn()) {
         this.disable();
      }
   }

   @Override
   public String getInfo() {
      return this.name.getValue();
   }

   @Override
   public void onTick() {
      ++this.ticks;
      ++this.ticks2;
      ++this.ticks3;
      if (this.player != null) {
         if (this.ticks > this.gappleDelay.getValue() - 1) {
            this.player.setAbsorptionAmount(16.0F);
            this.ticks = 0;
         }

         if (this.ticks2 > 19) {
            float var1 = this.player.getHealth() + 1.0F;
            if (var1 > 20.0F) {
               var1 = 20.0F;
            }

            this.player.setHealth(var1);
            this.ticks2 = 0;
         }

         Random var2 = new Random();
         this.player.moveForward = mc.player.moveForward + (float)var2.nextInt(5) / 10.0F;
         this.player.moveStrafing = mc.player.moveStrafing + (float)var2.nextInt(5) / 10.0F;
         if (this.move.getValue()) {
            this.travel(this.player.moveStrafing, this.player.moveVertical, this.player.moveForward);
         }
      }
   }
}
