package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;

public class AutoEZ extends Module {
   public static AutoEZ INSTANCE = new AutoEZ();
   public final Setting<String> EzString = this.add(new Setting<>("String", "EZ"));
   public final Setting<Boolean> whenSelf;
   public final Setting<Boolean> poped = this.add(new Setting<>("popCounter", true));
   public final Setting<String> SelfString;
   public final Setting<Boolean> whenFriend = this.add(new Setting<>("whenFriend", false));

   @Override
   public void onDeath(EntityPlayer var1) {
      if (!PopCounter.INSTANCE.isOn()) {
         PopCounter.INSTANCE.onDeath(var1);
      }
   }

   @Override
   public void onTotemPop(EntityPlayer var1) {
      if (!PopCounter.INSTANCE.isOn()) {
         PopCounter.INSTANCE.onTotemPop(var1);
      }
   }

   public AutoEZ() {
      super("AutoEZ", "say ez for enemy dead", Category.MISC);
      this.whenSelf = this.add(new Setting<>("whenSelf", false));
      this.SelfString = this.add(new Setting<>("SelfString", "potato server nice lag"));
      INSTANCE = this;
   }
}
