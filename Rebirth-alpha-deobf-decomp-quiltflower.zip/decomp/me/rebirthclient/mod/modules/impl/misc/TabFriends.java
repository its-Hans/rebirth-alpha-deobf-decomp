package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.ScorePlayerTeam;

public class TabFriends extends Module {
   public static String color = "";
   public final Setting<TabFriends.FriendColor> mode = this.add(new Setting<>("Color", TabFriends.FriendColor.Green));
   public static TabFriends INSTANCE;
   public static Setting<Boolean> prefix;

   @Override
   public void onUpdate() {
      switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$misc$TabFriends$FriendColor[this.mode.getValue().ordinal()]) {
         case 1:
            color = "§f";
            boolean var15 = false;
            break;
         case 2:
            color = "§4";
            boolean var14 = false;
            break;
         case 3:
            color = "§c";
            boolean var13 = false;
            break;
         case 4:
            color = "§6";
            boolean var12 = false;
            break;
         case 5:
            color = "§e";
            boolean var11 = false;
            break;
         case 6:
            color = "§2";
            boolean var10 = false;
            break;
         case 7:
            color = "§a";
            boolean var9 = false;
            break;
         case 8:
            color = "§b";
            boolean var8 = false;
            break;
         case 9:
            color = "§3";
            boolean var7 = false;
            break;
         case 10:
            color = "§1";
            boolean var6 = false;
            break;
         case 11:
            color = "§9";
            boolean var5 = false;
            break;
         case 12:
            color = "§d";
            boolean var4 = false;
            break;
         case 13:
            color = "§5";
            boolean var3 = false;
            break;
         case 14:
            color = "§7";
            boolean var2 = false;
            break;
         case 15:
            color = "§8";
            boolean var1 = false;
            break;
         case 16:
            color = "§0";
            boolean var10000 = false;
            break;
         case 17:
            color = "";
      }
   }

   public static String getPlayerName(NetworkPlayerInfo var0) {
      String var10000;
      if (var0.getDisplayName() != null) {
         var10000 = var0.getDisplayName().getFormattedText();
         boolean var10001 = false;
      } else {
         var10000 = ScorePlayerTeam.formatPlayerName(var0.getPlayerTeam(), var0.getGameProfile().getName());
      }

      String var1 = var10000;
      if (Managers.FRIENDS.isFriend(var1)) {
         return prefix.getValue()
            ? String.valueOf(new StringBuilder().append("§7[").append(color).append("F§7] ").append(color).append(var1))
            : String.valueOf(new StringBuilder().append(color).append(var1));
      } else {
         return var1;
      }
   }

   public TabFriends() {
      super("TabFriends", "Renders your friends differently in the tablist", Category.MISC);
      prefix = this.add(new Setting<>("Prefix", true));
      INSTANCE = this;
   }

   public static enum FriendColor {
      DarkPurple,
      Gray,
      White,
      DarkGray,
      Yellow,
      LightPurple,
      Aqua,
      Green,
      Red,
      Gold,
      DarkBlue,
      Black,
      DarkRed,
      DarkGreen,
      Blue,
      DarkAqua,
      None;
      private static final TabFriends.FriendColor[] $VALUES = new TabFriends.FriendColor[]{
         DarkRed,
         Red,
         Gold,
         Yellow,
         DarkGreen,
         Green,
         Aqua,
         TabFriends.FriendColor.DarkAqua,
         DarkBlue,
         TabFriends.FriendColor.Blue,
         LightPurple,
         DarkPurple,
         Gray,
         DarkGray,
         Black,
         White,
         TabFriends.FriendColor.None
      };
   }
}
