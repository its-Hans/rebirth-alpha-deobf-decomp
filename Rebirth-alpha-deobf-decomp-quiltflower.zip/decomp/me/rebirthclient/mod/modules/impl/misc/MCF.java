package me.rebirthclient.mod.modules.impl.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.input.Mouse;

public class MCF extends Module {
   private boolean didClick;

   @Override
   public void onUpdate() {
      if (Mouse.isButtonDown(2)) {
         if (!this.didClick && mc.currentScreen == null) {
            this.onClick();
         }

         this.didClick = true;
         boolean var10000 = false;
      } else {
         this.didClick = false;
      }
   }

   public MCF() {
      super("MCF", "Middle click your fellow friends", Category.MISC);
   }

   private void onClick() {
      RayTraceResult var2 = mc.objectMouseOver;
      if (var2 != null && var2.typeOfHit == Type.ENTITY) {
         Entity var1 = var2.entityHit;
         if (var1 instanceof EntityPlayer) {
            if (Managers.FRIENDS.isFriend(var1.getName())) {
               Managers.FRIENDS.removeFriend(var1.getName());
               this.sendMessage(
                  String.valueOf(
                     new StringBuilder().append(ChatFormatting.RED).append(var1.getName()).append(ChatFormatting.RED).append(" has been unfriended.")
                  )
               );
               boolean var10000 = false;
            } else {
               Managers.FRIENDS.addFriend(var1.getName());
               this.sendMessage(
                  String.valueOf(
                     new StringBuilder().append(ChatFormatting.AQUA).append(var1.getName()).append(ChatFormatting.GREEN).append(" has been friended.")
                  )
               );
            }
         }
      }

      this.didClick = true;
   }
}
