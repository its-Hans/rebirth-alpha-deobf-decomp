package me.rebirthclient.mod.modules.impl.misc;

import java.text.DecimalFormat;
import me.rebirthclient.api.events.impl.RenderToolTipEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Items;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.translation.I18n;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ToolTips extends Module {
   private float height;
   private final DecimalFormat format;
   public final Setting<Boolean> onlyShulker;
   public static ToolTips INSTANCE;
   private float width;
   public final Setting<Boolean> wheelPeek;
   public final Setting<Boolean> shulkerPreview = this.add(new Setting<>("ShulkerPreview", true).setParent());

   private String getEnchants(ItemStack var1) {
      StringBuilder var2 = new StringBuilder();

      for(Enchantment var4 : EnchantmentHelper.getEnchantments(var1).keySet()) {
         if (var4 == null) {
            boolean var10000 = false;
         } else {
            String var5 = var4.getTranslatedName(EnchantmentHelper.getEnchantmentLevel(var4, var1));
            if (var5.contains("Vanish")) {
               var2.append("Vanishing ");
               boolean var6 = false;
               var6 = false;
            } else if (var5.contains("Binding")) {
               var2.append("Binding ");
               boolean var8 = false;
            }

            boolean var9 = false;
         }
      }

      if (var1.getItem().equals(Items.GOLDEN_APPLE) && var1.hasEffect()) {
         return "God";
      } else {
         String var10;
         if (var2.length() == 0) {
            var10 = null;
            boolean var10001 = false;
         } else {
            var10 = String.valueOf(var2);
         }

         return var10;
      }
   }

   private int getItemColor(ItemStack var1) {
      if (var1.getItem() instanceof ItemArmor) {
         ItemArmor var2 = (ItemArmor)var1.getItem();
         switch(null.$SwitchMap$net$minecraft$item$ItemArmor$ArmorMaterial[var2.getArmorMaterial().ordinal()]) {
            case 1:
               return 28893;
            case 2:
               int var10000;
               if (EnchantmentHelper.getEnchantments(var1).keySet().isEmpty()) {
                  var10000 = 2031360;
                  boolean var10001 = false;
               } else {
                  var10000 = 10696174;
               }

               return var10000;
            case 3:
            case 4:
               return 2031360;
            case 5:
               return 10329501;
            default:
               boolean var5 = false;
         }
      } else {
         if (var1.getItem().equals(Items.GOLDEN_APPLE)) {
            if (var1.hasEffect()) {
               return 10696174;
            }

            return 52735;
         }

         if (var1.getItem() instanceof ItemSword) {
            ItemSword var4 = (ItemSword)var1.getItem();
            String var3 = var4.getToolMaterialName();
            if (Integer.valueOf("DIAMOND".hashCode()).equals(var3.hashCode())) {
               return 10696174;
            }

            if (Integer.valueOf("CHAIN".hashCode()).equals(var3.hashCode())) {
               return 28893;
            }

            if (Integer.valueOf("GOLD".hashCode()).equals(var3.hashCode())) {
               return 2031360;
            }

            if (Integer.valueOf("IRON".hashCode()).equals(var3.hashCode())) {
               return 2031360;
            }

            if (Integer.valueOf("LEATHER".hashCode()).equals(var3.hashCode())) {
               return 10329501;
            }

            return -1;
         }

         if (var1.getItem().equals(Items.TOTEM_OF_UNDYING)) {
            return 16744448;
         }

         if (var1.getItem().equals(Items.CHORUS_FRUIT)) {
            return 28893;
         }

         if (var1.getItem().equals(Items.ENDER_PEARL)) {
            return 28893;
         }

         if (var1.getItem().equals(Items.END_CRYSTAL)) {
            return 10696174;
         }

         if (var1.getItem().equals(Items.EXPERIENCE_BOTTLE)) {
            return 2031360;
         }

         if (var1.getItem().equals(Items.POTIONITEM)) {
            return 2031360;
         }

         if (Item.getIdFromItem(var1.getItem()) == 130) {
            return 10696174;
         }

         if (var1.getItem() instanceof ItemShulkerBox) {
            return 10696174;
         }
      }

      return -1;
   }

   public static void drawShulkerGui(ItemStack var0, String var1) {
      ItemStack var10000 = var0;

      try {
         Item var2 = var10000.getItem();
         TileEntityShulkerBox var3 = new TileEntityShulkerBox();
         ItemShulkerBox var4 = (ItemShulkerBox)var2;
         var3.blockType = var4.getBlock();
         var3.setWorld(Peek.mc.world);
         ItemStackHelper.loadAllItems(var0.getTagCompound().getCompoundTag("BlockEntityTag"), var3.items);
         var3.readFromNBT(var0.getTagCompound().getCompoundTag("BlockEntityTag"));
         String var10001;
         if (var1 == null) {
            var10001 = var0.getDisplayName();
            boolean var10002 = false;
         } else {
            var10001 = var1;
         }

         var3.setCustomName(var10001);
         new Thread(ToolTips::lambda$drawShulkerGui$1).start();
      } catch (Exception var5) {
         return;
      }

      boolean var6 = false;
   }

   @SubscribeEvent
   public void onRenderToolTip(RenderToolTipEvent var1) {
      if (!var1.isCanceled() && !nullCheck() && !fullNullCheck()) {
         if (!var1.getItemStack().isEmpty()) {
            if (!(var1.getItemStack().getItem() instanceof ItemShulkerBox) && this.onlyShulker.getValue()) {
               return;
            }

            var1.setCanceled(true);
            int var2 = var1.getX();
            int var3 = var1.getY();
            if (var1.getItemStack().getItem() instanceof ItemShulkerBox && this.shulkerPreview.getValue()) {
               this.drawShulkerPreview(var1.getItemStack(), var2 + 3, var3 - 10);
            }

            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.translate((float)(var2 + 10), (float)(var3 - 5), 0.0F);
            String var4 = var1.getItemStack().getDisplayName();
            RenderUtil.drawRect(0.0F, -2.0F, this.width, this.height, -519565792);
            float var5 = this.width;
            this.width = 0.0F;
            int var6 = this.drawString(var4, 3, 1, this.getItemColor(var1.getItemStack()));
            String var7 = this.getEnchants(var1.getItemStack());
            if (var7 != null) {
               var6 = this.drawString(var7, 3, var6, 16711680);
            }

            String var8 = null;
            String var9 = null;
            if (var1.getItemStack().getItem() instanceof ItemArmor) {
               ItemArmor var10 = (ItemArmor)var1.getItemStack().getItem();
               switch(null.$SwitchMap$net$minecraft$inventory$EntityEquipmentSlot[var10.getEquipmentSlot().ordinal()]) {
                  case 1:
                     var8 = "Chest";
                     boolean var21 = false;
                     break;
                  case 2:
                     var8 = "Feet";
                     boolean var20 = false;
                     break;
                  case 3:
                     var8 = "Head";
                     boolean var19 = false;
                     break;
                  case 4:
                     var8 = "Leggings";
                     boolean var10000 = false;
               }

               switch(null.$SwitchMap$net$minecraft$item$ItemArmor$ArmorMaterial[var10.getArmorMaterial().ordinal()]) {
                  case 1:
                     var9 = "Chain";
                     boolean var26 = false;
                     break;
                  case 2:
                     var9 = "Diamond";
                     boolean var25 = false;
                     break;
                  case 3:
                     var9 = "Gold";
                     boolean var24 = false;
                     break;
                  case 4:
                     var9 = "Iron";
                     boolean var23 = false;
                     break;
                  case 5:
                     var9 = "Leather";
                     boolean var22 = false;
               }
            }

            if (var1.getItemStack().getItem() instanceof ItemElytra) {
               var8 = "Chest";
            }

            if (var1.getItemStack().getItem() instanceof ItemSword) {
               var8 = "Mainhand";
               var9 = "Sword";
            }

            if (var8 != null) {
               int var14 = var6;
               var6 = this.drawString(var8, 3, var6, -1);
               if (var9 != null) {
                  this.drawString(var9, (int)(var5 - (float)Managers.TEXT.getStringWidth(var9) - 3.0F), var14, -1);
                  boolean var27 = false;
                  this.width = Math.max(48.0F, var5);
               }
            }

            if (var1.getItemStack().getItem() instanceof ItemSword) {
               ItemSword var15 = (ItemSword)var1.getItemStack().getItem();
               var6 = this.drawString(
                  String.valueOf(new StringBuilder().append(var15.getAttackDamage()).append(" - ").append(var15.getAttackDamage()).append(" Damage")),
                  3,
                  var6,
                  -1
               );
            }

            for(Enchantment var11 : EnchantmentHelper.getEnchantments(var1.getItemStack()).keySet()) {
               String var12 = String.valueOf(
                  new StringBuilder()
                     .append("+")
                     .append(EnchantmentHelper.getEnchantmentLevel(var11, var1.getItemStack()))
                     .append(" ")
                     .append(I18n.translateToLocal(var11.getName()))
               );
               if (!var12.contains("Vanish")) {
                  if (var12.contains("Binding")) {
                     boolean var29 = false;
                  } else {
                     int var13 = -1;
                     if (var12.contains("Mending") || var12.contains("Unbreaking")) {
                        var13 = 65280;
                     }

                     var6 = this.drawString(var12, 3, var6, var13);
                     boolean var28 = false;
                  }
               }
            }

            if (var1.getItemStack().getMaxDamage() > 1) {
               float var17 = (float)(var1.getItemStack().getMaxDamage() - var1.getItemStack().getItemDamage())
                  / (float)var1.getItemStack().getMaxDamage()
                  * 100.0F;
               String var18 = String.format(
                  "Durability %s %s / %s",
                  String.valueOf(new StringBuilder().append(this.format.format((double)var17)).append("%")),
                  var1.getItemStack().getMaxDamage() - var1.getItemStack().getItemDamage(),
                  var1.getItemStack().getMaxDamage()
               );
               var6 = this.drawString(var18, 3, var6, -1);
            }

            GlStateManager.enableDepth();
            mc.getRenderItem().zLevel = 150.0F;
            RenderHelper.enableGUIStandardItemLighting();
            RenderHelper.disableStandardItemLighting();
            mc.getRenderItem().zLevel = 0.0F;
            GlStateManager.enableLighting();
            GlStateManager.translate((float)(-(var2 + 10)), (float)(-(var3 - 5)), 0.0F);
            this.height = (float)(var6 + 1);
         }
      }
   }

   private static void lambda$drawShulkerGui$1(TileEntityShulkerBox var0) {
      long var10000 = 200L;

      label13: {
         try {
            Thread.sleep(var10000);
         } catch (InterruptedException var2) {
            break label13;
         }

         boolean var3 = false;
      }

      Peek.mc.player.displayGUIChest(var0);
   }

   private int drawString(String var1, int var2, int var3, int var4) {
      Managers.TEXT.drawStringWithShadow(var1, (float)var2, (float)var3, var4);
      this.width = Math.max(this.width, (float)(Managers.TEXT.getStringWidth(var1) + var2 + 3));
      return var3 + 9;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.shulkerPreview.isOpen();
   }

   private void drawShulkerPreview(ItemStack var1, int var2, int var3) {
      NBTTagCompound var5 = var1.getTagCompound();
      if (var5 != null && var5.hasKey("BlockEntityTag", 10)) {
         NBTTagCompound var4 = var5.getCompoundTag("BlockEntityTag");
         if (var4.hasKey("Items", 9)) {
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
            GlStateManager.disableDepth();
            RenderUtil.drawRect((float)(var2 + 7), (float)(var3 + 17), (float)(var2 + 171), (float)(var3 + 57 + 16), -519565792);
            GlStateManager.enableDepth();
            RenderHelper.enableGUIStandardItemLighting();
            GlStateManager.enableRescaleNormal();
            GlStateManager.enableColorMaterial();
            GlStateManager.enableLighting();
            NonNullList var6 = NonNullList.withSize(27, ItemStack.EMPTY);
            ItemStackHelper.loadAllItems(var4, var6);

            for(int var7 = 0; var7 < var6.size(); ++var7) {
               int var8 = var2 + var7 % 9 * 18 + 8;
               int var9 = var3 + var7 / 9 * 18 + 18;
               ItemStack var10 = (ItemStack)var6.get(var7);
               Peek.mc.getItemRenderer().itemRenderer.zLevel = 501.0F;
               mc.getRenderItem().renderItemAndEffectIntoGUI(var10, var8, var9);
               mc.getRenderItem().renderItemOverlayIntoGUI(Peek.mc.fontRenderer, var10, var8, var9, null);
               Peek.mc.getItemRenderer().itemRenderer.zLevel = 0.0F;
               boolean var10000 = false;
            }

            GlStateManager.disableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         }
      }
   }

   public ToolTips() {
      super("ToolTips", "Advanced tool tips", Category.MISC);
      this.onlyShulker = this.add(new Setting<>("OnlyShulker", false, this::lambda$new$0));
      this.wheelPeek = this.add(new Setting<>("WheelPeek", true));
      this.format = new DecimalFormat("#");
      INSTANCE = this;
   }
}
