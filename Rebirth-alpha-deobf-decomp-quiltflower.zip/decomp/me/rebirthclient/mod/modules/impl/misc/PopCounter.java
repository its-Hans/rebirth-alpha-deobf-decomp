package me.rebirthclient.mod.modules.impl.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.HashMap;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;

public class PopCounter extends Module {
   public static final HashMap<String, Integer> TotemPopContainer = new HashMap<>();
   public static PopCounter INSTANCE = new PopCounter();

   @Override
   public void onTotemPop(EntityPlayer var1) {
      int var3 = 1;
      if (TotemPopContainer.containsKey(var1.getName())) {
         var3 = TotemPopContainer.get(var1.getName());
         TotemPopContainer.put(var1.getName(), ++var3);
         boolean var4 = false;
         var4 = false;
      } else {
         TotemPopContainer.put(var1.getName(), var3);
         boolean var6 = false;
      }

      if (var3 == 1) {
         if (mc.player.equals(var1)) {
            if (this.isOn()) {
               this.sendMessageWithID(
                  String.valueOf(
                     new StringBuilder()
                        .append(ChatFormatting.BLUE)
                        .append("You popped ")
                        .append(ChatFormatting.RED)
                        .append(var3)
                        .append(ChatFormatting.RED)
                        .append(" Totem.")
                  ),
                  var1.getEntityId()
               );
               boolean var7 = false;
            }
         } else if (this.isOn()) {
            this.sendMessageWithID(
               String.valueOf(
                  new StringBuilder()
                     .append(ChatFormatting.RED)
                     .append(var1.getName())
                     .append(" popped ")
                     .append(ChatFormatting.GREEN)
                     .append(var3)
                     .append(ChatFormatting.RED)
                     .append(" Totem.")
               ),
               var1.getEntityId()
            );
            boolean var8 = false;
         }
      } else if (mc.player.equals(var1)) {
         if (this.isOn()) {
            this.sendMessageWithID(
               String.valueOf(
                  new StringBuilder()
                     .append(ChatFormatting.BLUE)
                     .append("You popped ")
                     .append(ChatFormatting.RED)
                     .append(var3)
                     .append(ChatFormatting.RED)
                     .append(" Totems.")
               ),
               var1.getEntityId()
            );
            boolean var9 = false;
         }
      } else if (this.isOn()) {
         this.sendMessageWithID(
            String.valueOf(
               new StringBuilder()
                  .append(ChatFormatting.RED)
                  .append(var1.getName())
                  .append(" popped ")
                  .append(ChatFormatting.GREEN)
                  .append(var3)
                  .append(ChatFormatting.RED)
                  .append(" Totems.")
            ),
            var1.getEntityId()
         );
      }
   }

   @Override
   public void onDeath(EntityPlayer var1) {
      if (TotemPopContainer.containsKey(var1.getName())) {
         int var2 = TotemPopContainer.get(var1.getName());
         TotemPopContainer.remove(var1.getName());
         boolean var10000 = false;
         if (var2 == 1) {
            if (mc.player.equals(var1)) {
               if (this.isOn()) {
                  this.sendMessageWithID(
                     String.valueOf(
                        new StringBuilder()
                           .append(ChatFormatting.BLUE)
                           .append("You died after popping ")
                           .append(ChatFormatting.RED)
                           .append(var2)
                           .append(ChatFormatting.RED)
                           .append(" Totem!")
                     ),
                     var1.getEntityId()
                  );
               }

               if (AutoEZ.INSTANCE.isOn() && AutoEZ.INSTANCE.whenSelf.getValue()) {
                  mc.player.connection.sendPacket(new CPacketChatMessage(AutoEZ.INSTANCE.SelfString.getValue()));
                  var10000 = false;
               }
            } else {
               if (this.isOn()) {
                  this.sendMessageWithID(
                     String.valueOf(
                        new StringBuilder()
                           .append(ChatFormatting.RED)
                           .append(var1.getName())
                           .append(" died after popping ")
                           .append(ChatFormatting.GREEN)
                           .append(var2)
                           .append(ChatFormatting.RED)
                           .append(" Totem!")
                     ),
                     var1.getEntityId()
                  );
               }

               if (AutoEZ.INSTANCE.isOn() && (!Managers.FRIENDS.isFriend(var1.getName()) || AutoEZ.INSTANCE.whenFriend.getValue())) {
                  if (AutoEZ.INSTANCE.poped.getValue()) {
                     mc.player
                        .connection
                        .sendPacket(
                           new CPacketChatMessage(
                              String.valueOf(
                                 new StringBuilder()
                                    .append(AutoEZ.INSTANCE.EzString.getValue())
                                    .append(" ")
                                    .append(var1.getName())
                                    .append(" popping")
                                    .append(var2)
                                    .append(" Totem!")
                              )
                           )
                        );
                     var10000 = false;
                  } else {
                     mc.player
                        .connection
                        .sendPacket(
                           new CPacketChatMessage(
                              String.valueOf(new StringBuilder().append(AutoEZ.INSTANCE.EzString.getValue()).append(" ").append(var1.getName()))
                           )
                        );
                     var10000 = false;
                  }
               }
            }
         } else if (mc.player.equals(var1)) {
            if (this.isOn()) {
               this.sendMessageWithID(
                  String.valueOf(
                     new StringBuilder()
                        .append(ChatFormatting.BLUE)
                        .append("You died after popping ")
                        .append(ChatFormatting.RED)
                        .append(var2)
                        .append(ChatFormatting.RED)
                        .append(" Totems!")
                  ),
                  var1.getEntityId()
               );
            }

            if (AutoEZ.INSTANCE.isOn() && AutoEZ.INSTANCE.whenSelf.getValue()) {
               mc.player.connection.sendPacket(new CPacketChatMessage(AutoEZ.INSTANCE.SelfString.getValue()));
               var10000 = false;
            }
         } else {
            if (this.isOn()) {
               this.sendMessageWithID(
                  String.valueOf(
                     new StringBuilder()
                        .append(ChatFormatting.RED)
                        .append(var1.getName())
                        .append(" died after popping ")
                        .append(ChatFormatting.GREEN)
                        .append(var2)
                        .append(ChatFormatting.RED)
                        .append(" Totems!")
                  ),
                  var1.getEntityId()
               );
            }

            if (AutoEZ.INSTANCE.isOn() && (!Managers.FRIENDS.isFriend(var1.getName()) || AutoEZ.INSTANCE.whenFriend.getValue())) {
               if (AutoEZ.INSTANCE.poped.getValue()) {
                  mc.player
                     .connection
                     .sendPacket(
                        new CPacketChatMessage(
                           String.valueOf(
                              new StringBuilder()
                                 .append(AutoEZ.INSTANCE.EzString.getValue())
                                 .append(" ")
                                 .append(var1.getName())
                                 .append(" popping ")
                                 .append(var2)
                                 .append(" Totem!")
                           )
                        )
                     );
                  var10000 = false;
               } else {
                  mc.player
                     .connection
                     .sendPacket(
                        new CPacketChatMessage(
                           String.valueOf(new StringBuilder().append(AutoEZ.INSTANCE.EzString.getValue()).append(" ").append(var1.getName()))
                        )
                     );
               }
            }
         }

         var10000 = false;
      } else if (AutoEZ.INSTANCE.isOn() && (!Managers.FRIENDS.isFriend(var1.getName()) || AutoEZ.INSTANCE.whenFriend.getValue())) {
         if (AutoEZ.INSTANCE.poped.getValue()) {
            mc.player
               .connection
               .sendPacket(
                  new CPacketChatMessage(
                     String.valueOf(
                        new StringBuilder().append(AutoEZ.INSTANCE.EzString.getValue()).append(" ").append(var1.getName()).append(" popping 0 Totem!")
                     )
                  )
               );
            boolean var9 = false;
         } else {
            mc.player
               .connection
               .sendPacket(
                  new CPacketChatMessage(String.valueOf(new StringBuilder().append(AutoEZ.INSTANCE.EzString.getValue()).append(" ").append(var1.getName())))
               );
         }
      }
   }

   public PopCounter() {
      super("PopCounter", "Counts other players totem pops", Category.MISC);
      INSTANCE = this;
   }
}
