package me.rebirthclient.mod.modules.impl.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.player.EntityPlayer;

public class PearlNotify extends Module {
   private boolean flag;

   @Override
   public void onEnable() {
      this.flag = true;
   }

   @Override
   public void onUpdate() {
      Entity var1 = null;

      for(Entity var3 : mc.world.loadedEntityList) {
         if (var3 instanceof EntityEnderPearl) {
            var1 = var3;
            boolean var8 = false;
            break;
         }

         boolean var10000 = false;
      }

      if (var1 == null) {
         this.flag = true;
      } else {
         EntityPlayer var5 = null;

         for(EntityPlayer var4 : mc.world.playerEntities) {
            if (var5 == null) {
               var5 = var4;
               boolean var9 = false;
            } else {
               if (var5.getDistance(var1) <= var4.getDistance(var1)) {
                  boolean var11 = false;
                  continue;
               }

               var5 = var4;
            }

            boolean var10 = false;
         }

         if (var5 == mc.player) {
            this.flag = false;
         }

         if (var5 != null && this.flag) {
            String var7 = var1.getHorizontalFacing().toString();
            if (Integer.valueOf("West".hashCode()).equals(var7.hashCode())) {
               var7 = "East";
               boolean var12 = false;
            } else if (Integer.valueOf("East".hashCode()).equals(var7.hashCode())) {
               var7 = "West";
            }

            String var10001;
            if (Managers.FRIENDS.isFriend(var5.getName())) {
               var10001 = String.valueOf(
                  new StringBuilder()
                     .append(ChatFormatting.AQUA)
                     .append(var5.getName())
                     .append(ChatFormatting.GRAY)
                     .append(" has just thrown a pearl heading ")
                     .append(ChatFormatting.AQUA)
                     .append(var7)
                     .append("!")
               );
               boolean var10002 = false;
            } else {
               var10001 = String.valueOf(
                  new StringBuilder()
                     .append(ChatFormatting.RED)
                     .append(var5.getName())
                     .append(ChatFormatting.GRAY)
                     .append(" has just thrown a pearl heading ")
                     .append(ChatFormatting.RED)
                     .append(var7)
                     .append("!")
               );
            }

            this.sendMessageWithID(var10001, var5.getEntityId());
            this.flag = false;
         }
      }
   }

   public PearlNotify() {
      super("PearlNotify", "Notifies pearl throws", Category.MISC);
   }
}
