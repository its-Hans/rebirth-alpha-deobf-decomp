package me.rebirthclient.mod.modules.impl.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityTNTPrimed;

public class TNTTime extends Module {
   public TNTTime() {
      super("TNTTime", "show tnt fuse", Category.MISC);
   }

   @Override
   public void onUpdate() {
      for(Entity var2 : mc.world.loadedEntityList) {
         if (!(var2 instanceof EntityTNTPrimed)) {
            boolean var10000 = false;
         } else {
            String var3 = String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append(""));
            if ((double)((EntityTNTPrimed)var2).getFuse() / 20.0 > 0.0) {
               var3 = String.valueOf(new StringBuilder().append(ChatFormatting.DARK_RED).append(""));
            }

            if ((double)((EntityTNTPrimed)var2).getFuse() / 20.0 > 1.0) {
               var3 = String.valueOf(new StringBuilder().append(ChatFormatting.RED).append(""));
            }

            if ((double)((EntityTNTPrimed)var2).getFuse() / 20.0 > 2.0) {
               var3 = String.valueOf(new StringBuilder().append(ChatFormatting.YELLOW).append(""));
            }

            if ((double)((EntityTNTPrimed)var2).getFuse() / 20.0 > 3.0) {
               var3 = String.valueOf(new StringBuilder().append(ChatFormatting.GREEN).append(""));
            }

            var2.setCustomNameTag(
               String.valueOf(
                  new StringBuilder().append(var3).append(String.valueOf((double)((EntityTNTPrimed)var2).getFuse() / 20.0).substring(0, 3)).append("s")
               )
            );
            var2.setAlwaysRenderNameTag(true);
            boolean var4 = false;
         }
      }
   }
}
