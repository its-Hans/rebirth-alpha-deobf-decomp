package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.network.play.client.CPacketChatMessage;
import org.apache.commons.lang3.RandomStringUtils;

public class Message extends Module {
   private final Setting<Integer> random;
   private final Setting<Integer> delay;
   private final Timer timer = new Timer();
   private final Setting<String> custom = this.add(new Setting<>("Custom", "Rebirth very good"));

   @Override
   public void onTick() {
      if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         mc.player
            .connection
            .sendPacket(
               new CPacketChatMessage(
                  String.valueOf(
                     new StringBuilder().append(this.custom.getValue()).append(" ").append(RandomStringUtils.randomAlphanumeric(this.random.getValue()))
                  )
               )
            );
         this.timer.reset();
         boolean var10000 = false;
      }
   }

   public Message() {
      super("Spammer", "Message", Category.MISC);
      this.random = this.add(new Setting<>("Random", 0, 0, 20));
      this.delay = this.add(new Setting<>("Delay", 100, 0, 10000));
   }
}
