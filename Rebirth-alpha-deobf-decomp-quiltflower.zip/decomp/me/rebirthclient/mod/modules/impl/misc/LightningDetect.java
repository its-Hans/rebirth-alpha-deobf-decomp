package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.network.play.server.SPacketSpawnGlobalEntity;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class LightningDetect extends Module {
   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled()) {
         if (var1.getPacket() instanceof SPacketSpawnGlobalEntity) {
            String var2 = String.valueOf(
               new StringBuilder()
                  .append("Lightning Detected! X:")
                  .append((int)((SPacketSpawnGlobalEntity)var1.getPacket()).getX())
                  .append(" Y:")
                  .append((int)((SPacketSpawnGlobalEntity)var1.getPacket()).getY())
                  .append(" Z:")
                  .append((int)((SPacketSpawnGlobalEntity)var1.getPacket()).getZ())
            );
            this.sendMessage(var2);
         }
      }
   }

   public LightningDetect() {
      super("LightningDetect", "EZ", Category.MISC);
   }
}
