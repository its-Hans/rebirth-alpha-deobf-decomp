package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.events.impl.BlockEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Debug extends Module {
   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck() && !mc.player.isCreative() && var1.getPacket() instanceof CPacketPlayerDigging) {
         this.sendMessage(((CPacketPlayerDigging)var1.getPacket()).getAction().name());
      }
   }

   public Debug() {
      super("Debug", "dev!", Category.MISC);
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onClickBlock(BlockEvent var1) {
      if (!fullNullCheck()) {
         var1.setCanceled(true);
      }
   }
}
