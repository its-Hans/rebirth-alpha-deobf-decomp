package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class KillEffects extends Module {
   private final Setting<KillEffects.KillSound> killSound;
   private final Timer timer;
   private final Setting<Boolean> oneself;
   private final Setting<KillEffects.Lightning> lightning = this.add(new Setting<>("Lightning", KillEffects.Lightning.NORMAL));

   public KillEffects() {
      super("KillEffects", "jajaja hypixel mode", Category.MISC);
      this.killSound = this.add(new Setting<>("KillSound", KillEffects.KillSound.OFF));
      this.oneself = this.add(new Setting<>("Oneself", true));
      this.timer = new Timer();
   }

   private SoundEvent getSound() {
      switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$misc$KillEffects$KillSound[this.killSound.getValue().ordinal()]) {
         case 1:
            return new SoundEvent(new ResourceLocation("rebirth", "kill_sound_cs"));
         case 2:
            return new SoundEvent(new ResourceLocation("rebirth", "kill_sound_nl"));
         case 3:
            return SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP;
         default:
            return null;
      }
   }

   @Override
   public void onDeath(EntityPlayer var1) {
      if (var1 != null
         && (var1 != mc.player || this.oneself.getValue())
         && !(var1.getHealth() > 0.0F)
         && !mc.player.isDead
         && !nullCheck()
         && !fullNullCheck()) {
         if (this.timer.passedMs(1500L)) {
            if (this.lightning.getValue() != KillEffects.Lightning.OFF) {
               mc.world.spawnEntity(new EntityLightningBolt(mc.world, var1.posX, var1.posY, var1.posZ, true));
               boolean var10000 = false;
               if (this.lightning.getValue() == KillEffects.Lightning.NORMAL) {
                  mc.player.playSound(SoundEvents.ENTITY_LIGHTNING_THUNDER, 0.5F, 1.0F);
               }
            }

            if (this.killSound.getValue() != KillEffects.KillSound.OFF) {
               SoundEvent var2 = this.getSound();
               if (var2 != null) {
                  mc.player.playSound(var2, 1.0F, 1.0F);
               }
            }

            this.timer.reset();
            boolean var3 = false;
         }
      }
   }

   private static enum KillSound {
      HYPIXEL,
      NEVERLOSE,
      CS,
      OFF;
      private static final KillEffects.KillSound[] $VALUES = new KillEffects.KillSound[]{
         KillEffects.KillSound.CS, KillEffects.KillSound.NEVERLOSE, KillEffects.KillSound.HYPIXEL, KillEffects.KillSound.OFF
      };
   }

   private static enum Lightning {
      NORMAL,
      OFF,
      SILENT;
      private static final KillEffects.Lightning[] $VALUES = new KillEffects.Lightning[]{
         KillEffects.Lightning.NORMAL, KillEffects.Lightning.SILENT, KillEffects.Lightning.OFF
      };
   }
}
