package me.rebirthclient.mod.modules.impl.misc;

import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoTNT extends Module {
   private final Setting<Float> range;
   private final Setting<Boolean> packet;
   private EntityPlayer target;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));

   private EntityPlayer getTarget(double var1) {
      EntityPlayer var3 = null;
      double var4 = var1;

      for(EntityPlayer var7 : mc.world.playerEntities) {
         if (EntityUtil.invalid(var7, var1)) {
            boolean var11 = false;
         } else if (!BlockUtil.canPlace(EntityUtil.getEntityPos(var7).up(2))
            && mc.world.getBlockState(EntityUtil.getEntityPos(var7).up(2)).getBlock() != Blocks.TNT) {
            boolean var10 = false;
         } else if (var3 == null) {
            var3 = var7;
            var4 = mc.player.getDistanceSq(var7);
            boolean var10000 = false;
         } else if (mc.player.getDistanceSq(var7) >= var4) {
            boolean var8 = false;
         } else {
            var3 = var7;
            var4 = mc.player.getDistanceSq(var7);
            boolean var9 = false;
         }
      }

      return var3;
   }

   @Override
   public void onUpdate() {
      if (InventoryUtil.findHotbarBlock(Blocks.TNT) != -1) {
         if (InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL) != -1 || InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) != -1) {
            this.target = this.getTarget((double)this.range.getValue().floatValue());
            if (this.target != null) {
               int var1 = mc.player.inventory.currentItem;
               BlockPos var2 = EntityUtil.getEntityPos(this.target).up(2);
               if (BlockUtil.canPlace(var2)) {
                  InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.TNT));
                  BlockUtil.placeBlock(var2, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                  InventoryUtil.doSwap(var1);
               }

               if (mc.world.getBlockState(var2).getBlock() == Blocks.TNT) {
                  if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) != -1) {
                     for(EnumFacing var6 : EnumFacing.VALUES) {
                        if (mc.world.getBlockState(var2.offset(var6)).getBlock() == Blocks.REDSTONE_BLOCK) {
                           return;
                        }

                        boolean var10000 = false;
                     }

                     for(EnumFacing var13 : EnumFacing.VALUES) {
                        if (var13 == EnumFacing.DOWN) {
                           boolean var15 = false;
                        } else if (BlockUtil.canPlace(var2.offset(var13))) {
                           InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK));
                           BlockUtil.placeBlock(var2.offset(var13), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                           InventoryUtil.doSwap(var1);
                           return;
                        }

                        boolean var16 = false;
                     }

                     boolean var17 = false;
                  } else if (InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL) != -1) {
                     InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL));
                     Vec3d var8 = new Vec3d(var2).add(0.5, 0.5, 0.5).add(new Vec3d(BlockUtil.getRayTraceFacing(var2).getDirectionVec()).scale(0.5));
                     if (this.rotate.getValue()) {
                        EntityUtil.faceVector(var8);
                     }

                     float var10 = (float)(var8.x - (double)var2.getX());
                     float var12 = (float)(var8.y - (double)var2.getY());
                     float var14 = (float)(var8.z - (double)var2.getZ());
                     mc.player
                        .connection
                        .sendPacket(new CPacketPlayerTryUseItemOnBlock(var2, BlockUtil.getRayTraceFacing(var2), EnumHand.MAIN_HAND, var10, var12, var14));
                     InventoryUtil.doSwap(var1);
                  }
               }
            }
         }
      }
   }

   public AutoTNT() {
      super("AutoTNT", "IQless", Category.MISC);
      this.packet = this.add(new Setting<>("Packet", true));
      this.range = this.add(new Setting<>("Range", 4.0F, 0.0F, 6.0F));
   }

   @Override
   public String getInfo() {
      return this.target != null ? this.target.getName() : null;
   }
}
