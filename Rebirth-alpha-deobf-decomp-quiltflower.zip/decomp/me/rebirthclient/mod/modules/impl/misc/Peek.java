package me.rebirthclient.mod.modules.impl.misc;

import java.awt.Color;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.client.ClickGui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Peek extends Module {
   private final Map<EntityPlayer, Timer> playerTimers;
   private final Map<EntityPlayer, ItemStack> spiedPlayers = new ConcurrentHashMap();

   @Override
   public void onUpdate() {
      for(EntityPlayer var2 : mc.world.playerEntities) {
         if (var2 != null && var2.getHeldItemMainhand().getItem() instanceof ItemShulkerBox) {
            if (mc.player == var2) {
               boolean var10000 = false;
            } else {
               ItemStack var3 = var2.getHeldItemMainhand();
               this.spiedPlayers.put(var2, var3);
               boolean var4 = false;
               var4 = false;
            }
         }
      }
   }

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void makeTooltip(ItemTooltipEvent var1) {
   }

   private void renderShulkerToolTip(ItemStack var1, int var2, int var3, String var4) {
      NBTTagCompound var6 = var1.getTagCompound();
      if (var6 != null && var6.hasKey("BlockEntityTag", 10)) {
         NBTTagCompound var5 = var6.getCompoundTag("BlockEntityTag");
         if (var5.hasKey("Items", 9)) {
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA, SourceFactor.ONE, DestFactor.ZERO);
            mc.getTextureManager().bindTexture(new ResourceLocation("textures/rebirth/constant/ingame/container.png"));
            this.drawTexturedRect(var2, var3, 0, 16);
            this.drawTexturedRect(var2, var3 + 16, 16, 57);
            this.drawTexturedRect(var2, var3 + 16 + 54, 160, 8);
            GlStateManager.disableDepth();
            Color var7 = new Color(
               ClickGui.INSTANCE.color.getValue().getRed(), ClickGui.INSTANCE.color.getValue().getGreen(), ClickGui.INSTANCE.color.getValue().getBlue(), 200
            );
            TextManager var10000 = Managers.TEXT;
            String var10001;
            if (var4 == null) {
               var10001 = var1.getDisplayName();
               boolean var10002 = false;
            } else {
               var10001 = var4;
            }

            var10000.drawStringWithShadow(var10001, (float)(var2 + 8), (float)(var3 + 6), ColorUtil.toRGBA(var7));
            GlStateManager.enableDepth();
            RenderHelper.enableGUIStandardItemLighting();
            GlStateManager.enableRescaleNormal();
            GlStateManager.enableColorMaterial();
            GlStateManager.enableLighting();
            NonNullList var8 = NonNullList.withSize(27, ItemStack.EMPTY);
            ItemStackHelper.loadAllItems(var5, var8);

            for(int var9 = 0; var9 < var8.size(); ++var9) {
               int var10 = var2 + var9 % 9 * 18 + 8;
               int var11 = var3 + var9 / 9 * 18 + 18;
               ItemStack var12 = (ItemStack)var8.get(var9);
               mc.getItemRenderer().itemRenderer.zLevel = 501.0F;
               mc.getRenderItem().renderItemAndEffectIntoGUI(var12, var10, var11);
               mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, var12, var10, var11, null);
               mc.getItemRenderer().itemRenderer.zLevel = 0.0F;
               boolean var13 = false;
            }

            GlStateManager.disableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         }
      }
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if (!fullNullCheck()) {
         int var2 = Managers.TEXT.scaledWidth / 2 - 78;
         byte var3 = 24;

         for(EntityPlayer var5 : mc.world.playerEntities) {
            if (this.spiedPlayers.get(var5) == null) {
               boolean var16 = false;
            } else {
               if (var5.getHeldItemMainhand() == null || !(var5.getHeldItemMainhand().getItem() instanceof ItemShulkerBox)) {
                  Timer var8 = this.playerTimers.get(var5);
                  if (var8 == null) {
                     Timer var7 = new Timer();
                     var7.reset();
                     boolean var11 = false;
                     this.playerTimers.put(var5, var7);
                     var11 = false;
                     var11 = false;
                  } else if (var8.passedS(3.0)) {
                     boolean var15 = false;
                     continue;
                  }
               } else if (var5.getHeldItemMainhand().getItem() instanceof ItemShulkerBox) {
                  Timer var6 = this.playerTimers.get(var5);
                  if (var6 != null) {
                     var6.reset();
                     boolean var10000 = false;
                     this.playerTimers.put(var5, var6);
                     var10000 = false;
                  }
               }

               ItemStack var9 = (ItemStack)this.spiedPlayers.get(var5);
               this.renderShulkerToolTip(var9, var2, var3, var5.getName());
               boolean var14 = false;
            }
         }
      }
   }

   public Peek() {
      super("Peek", "Allows you to peek into your enemy's shulkerboxes", Category.MISC);
      this.playerTimers = new ConcurrentHashMap<>();
   }

   private void drawTexturedRect(int var1, int var2, int var3, int var4) {
      Tessellator var5 = Tessellator.getInstance();
      BufferBuilder var6 = var5.getBuffer();
      var6.begin(7, DefaultVertexFormats.POSITION_TEX);
      var6.pos((double)var1, (double)(var2 + var4), 500.0).tex(0.0, (double)((float)(var3 + var4) * 0.00390625F)).endVertex();
      var6.pos((double)(var1 + 176), (double)(var2 + var4), 500.0).tex(0.6875, (double)((float)(var3 + var4) * 0.00390625F)).endVertex();
      var6.pos((double)(var1 + 176), (double)var2, 500.0).tex(0.6875, (double)((float)var3 * 0.00390625F)).endVertex();
      var6.pos((double)var1, (double)var2, 500.0).tex(0.0, (double)((float)var3 * 0.00390625F)).endVertex();
      var5.draw();
   }
}
