package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class CombatSetting extends Module {
   public final Setting<Boolean> strictPlace = this.add(new Setting<>("StrictPlace", false).setParent());
   public static final Timer timer = new Timer();
   public final Setting<Boolean> resetRotation;
   public final Setting<Boolean> resetPosition;
   public final Setting<Boolean> checkRaytrace = this.add(new Setting<>("CheckRaytrace", false, this::lambda$new$0));
   public final Setting<Integer> attackDelay;
   public static Vec3d vec;
   private final Setting<Integer> rotateTimer;
   public static CombatSetting INSTANCE;

   private void faceVector(Vec3d var1, MotionEvent var2) {
      float[] var3 = EntityUtil.getLegitRotations(var1);
      var2.setRotation(var3[0], var3[1]);
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.strictPlace.isOpen();
   }

   @SubscribeEvent
   public final void onMotion(MotionEvent var1) {
      if (!fullNullCheck()) {
         if (!timer.passedMs((long)this.rotateTimer.getValue().intValue()) && vec != null) {
            this.faceVector(vec, var1);
         }
      }
   }

   public CombatSetting() {
      super("CombatSetting", "idk", Category.COMBAT);
      this.resetRotation = this.add(new Setting<>("ResetRotation", false));
      this.resetPosition = this.add(new Setting<>("ResetPosition", false));
      this.attackDelay = this.add(new Setting<>("AttackDelay", 300, 0, 1000));
      this.rotateTimer = this.add(new Setting<>("RotateTimer", 300, 0, 1000));
      INSTANCE = this;
   }
}
