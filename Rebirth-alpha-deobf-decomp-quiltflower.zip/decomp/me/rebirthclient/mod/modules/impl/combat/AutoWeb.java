package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockWeb;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class AutoWeb extends Module {
   private final Setting<Boolean> noInWeb;
   private final Setting<Boolean> onlyGround;
   private final Setting<Boolean> onlyAir;
   private final Timer timer;
   private final Setting<Boolean> down;
   private final Setting<Integer> delay;
   private final Setting<Integer> multiPlace;
   private final Setting<Float> range;
   private final Setting<Boolean> feet;
   private final Setting<Boolean> air;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private final Setting<Double> maxSelfSpeed;
   private EntityPlayer target;
   private final Setting<Boolean> raytrace;
   private final Setting<Double> minTargetSpeed;
   private int progress;
   private final Setting<Boolean> packet = this.add(new Setting<>("Packet", true));
   private final Setting<Boolean> checkSelf;
   private final Setting<Boolean> face;
   private final Setting<Integer> surroundCheck;

   private static boolean isWeb(BlockPos var0) {
      boolean var10000;
      if (mc.world.getBlockState(var0).getBlock() == Blocks.WEB && checkEntity(var0)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         if (this.onlyGround.getValue() && !mc.player.onGround) {
            this.target = null;
         } else if (Managers.SPEED.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue()) {
            this.target = null;
         } else if (PullCrystal.INSTANCE.isOn() && PullCrystal.INSTANCE.pauseWeb.getValue()) {
            this.target = null;
         } else {
            this.progress = 0;
            boolean var1 = false;

            for(EntityPlayer var3 : mc.world.playerEntities) {
               if (EntityUtil.invalid(var3, (double)this.range.getValue().floatValue())) {
                  boolean var7 = false;
               } else if (isInWeb(var3) && this.noInWeb.getValue()) {
                  boolean var6 = false;
               } else {
                  var1 = true;
                  this.target = var3;
                  if (this.onlyAir.getValue() && var3.onGround) {
                     boolean var5 = false;
                  } else {
                     if (this.down.getValue()) {
                        this.placeWeb(new BlockPos(this.target.posX, this.target.posY - 0.3, this.target.posZ));
                        this.placeWeb(new BlockPos(this.target.posX + 0.1, this.target.posY - 0.3, this.target.posZ + 0.1));
                        this.placeWeb(new BlockPos(this.target.posX - 0.1, this.target.posY - 0.3, this.target.posZ + 0.1));
                        this.placeWeb(new BlockPos(this.target.posX - 0.1, this.target.posY - 0.3, this.target.posZ - 0.1));
                        this.placeWeb(new BlockPos(this.target.posX + 0.1, this.target.posY - 0.3, this.target.posZ - 0.1));
                     }

                     if (this.face.getValue()) {
                        this.placeWeb(new BlockPos(this.target.posX + 0.2, this.target.posY + 1.5, this.target.posZ + 0.2));
                        this.placeWeb(new BlockPos(this.target.posX - 0.2, this.target.posY + 1.5, this.target.posZ + 0.2));
                        this.placeWeb(new BlockPos(this.target.posX - 0.2, this.target.posY + 1.5, this.target.posZ - 0.2));
                        this.placeWeb(new BlockPos(this.target.posX + 0.2, this.target.posY + 1.5, this.target.posZ - 0.2));
                     }

                     if (Managers.SPEED.getPlayerSpeed(var3) < this.minTargetSpeed.getValue()) {
                        if (!this.air.getValue()) {
                           continue;
                        }

                        if (var3.onGround) {
                           boolean var4 = false;
                           continue;
                        }
                     }

                     if (this.feet.getValue() && !CombatUtil.isHole(EntityUtil.getEntityPos(this.target), true, this.surroundCheck.getValue(), false)) {
                        this.placeWeb(new BlockPos(this.target.posX + 0.2, this.target.posY + 0.5, this.target.posZ + 0.2));
                        this.placeWeb(new BlockPos(this.target.posX - 0.2, this.target.posY + 0.5, this.target.posZ + 0.2));
                        this.placeWeb(new BlockPos(this.target.posX - 0.2, this.target.posY + 0.5, this.target.posZ - 0.2));
                        this.placeWeb(new BlockPos(this.target.posX + 0.2, this.target.posY + 0.5, this.target.posZ - 0.2));
                     }

                     boolean var10000 = false;
                  }
               }
            }

            if (!var1) {
               this.target = null;
            }
         }
      }
   }

   private boolean canPlace(BlockPos var1) {
      if (!BlockUtil.canBlockFacing(var1)) {
         return false;
      } else {
         return !BlockUtil.canReplace(var1) ? false : this.strictPlaceCheck(var1);
      }
   }

   @Override
   public String getInfo() {
      return this.target != null ? this.target.getName() : null;
   }

   private static boolean checkEntity(BlockPos var0) {
      for(Entity var2 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var0))) {
         if (var2 instanceof EntityPlayer) {
            if (var2 != mc.player) {
               return true;
            }

            boolean var10000 = false;
         }
      }

      return false;
   }

   private boolean lambda$new$0(Integer var1) {
      return this.feet.isOpen();
   }

   private boolean isSelf(BlockPos var1) {
      if (!this.checkSelf.getValue()) {
         return false;
      } else {
         for(Entity var3 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var1))) {
            if (var3 == mc.player) {
               return true;
            }

            boolean var10000 = false;
         }

         return false;
      }
   }

   private boolean strictPlaceCheck(BlockPos var1) {
      if (!CombatSetting.INSTANCE.strictPlace.getValue() && this.raytrace.getValue()) {
         return true;
      } else {
         boolean var10002;
         if (!CombatSetting.INSTANCE.checkRaytrace.getValue() && this.raytrace.getValue()) {
            var10002 = false;
         } else {
            var10002 = true;
            boolean var10003 = false;
         }

         for(EnumFacing var3 : BlockUtil.getPlacableFacings(var1, true, var10002)) {
            if (BlockUtil.canClick(var1.offset(var3))) {
               return true;
            }

            boolean var10000 = false;
         }

         return false;
      }
   }

   public static boolean isInWeb(EntityPlayer var0) {
      if (isWeb(new BlockPos(var0.posX + 0.3, var0.posY + 1.5, var0.posZ + 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX - 0.3, var0.posY + 1.5, var0.posZ + 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX - 0.3, var0.posY + 1.5, var0.posZ - 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX + 0.3, var0.posY + 1.5, var0.posZ - 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX + 0.3, var0.posY - 0.5, var0.posZ + 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX - 0.3, var0.posY - 0.5, var0.posZ + 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX - 0.3, var0.posY - 0.5, var0.posZ - 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX + 0.3, var0.posY - 0.5, var0.posZ - 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX + 0.3, var0.posY + 0.5, var0.posZ + 0.3))) {
         return true;
      } else if (isWeb(new BlockPos(var0.posX - 0.3, var0.posY + 0.5, var0.posZ + 0.3))) {
         return true;
      } else {
         return isWeb(new BlockPos(var0.posX - 0.3, var0.posY + 0.5, var0.posZ - 0.3))
            ? true
            : isWeb(new BlockPos(var0.posX + 0.3, var0.posY + 0.5, var0.posZ - 0.3));
      }
   }

   private void placeWeb(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (mc.world.isAirBlock(var1.up())) {
            if (this.canPlace(var1)) {
               if (!this.isSelf(var1)) {
                  if (InventoryUtil.findHotbarClass(BlockWeb.class) != -1) {
                     int var2 = mc.player.inventory.currentItem;
                     InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockWeb.class));
                     BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                     ++this.progress;
                     InventoryUtil.doSwap(var2);
                     this.timer.reset();
                     boolean var10000 = false;
                  }
               }
            }
         }
      }
   }

   public AutoWeb() {
      super("AutoWeb", "", Category.COMBAT);
      this.delay = this.add(new Setting<>("Delay", 50, 0, 2000));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 8));
      this.raytrace = this.add(new Setting<>("Raytrace", false));
      this.noInWeb = this.add(new Setting<>("NoInWeb", true));
      this.checkSelf = this.add(new Setting<>("CheckSelf", true));
      this.onlyGround = this.add(new Setting<>("SelfGround", true));
      this.down = this.add(new Setting<>("Down", false));
      this.face = this.add(new Setting<>("Face", false));
      this.feet = this.add(new Setting<>("Feet", true).setParent());
      this.onlyAir = this.add(new Setting<>("OnlyAir", true));
      this.surroundCheck = this.add(new Setting<>("SurroundCheck", 3, 1, 5, this::lambda$new$0));
      this.air = this.add(new Setting<>("Air", true));
      this.maxSelfSpeed = this.add(new Setting<>("MaxSelfSpeed", 6.0, 1.0, 30.0));
      this.minTargetSpeed = this.add(new Setting<>("MinTargetSpeed", 0.0, 0.0, 20.0));
      this.range = this.add(new Setting<>("Range", 5.0F, 1.0F, 6.0F));
      this.timer = new Timer();
      this.progress = 0;
   }
}
