package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockWeb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class Filler extends Module {
   private final Setting<Boolean> noInWeb;
   private final Setting<Boolean> allowUp;
   private final Setting<Float> holeRange;
   private final Setting<Boolean> onlyCanStand;
   private final Setting<Float> placeRange;
   private final Setting<Integer> delay;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> packet;
   private final Setting<Boolean> holeCheck;
   private final Setting<Boolean> air;
   int progress;
   private final Setting<Double> maxSelfSpeed;
   private final Setting<Boolean> anyBlock;
   private final Setting<Integer> multiPlace;
   private final Setting<Float> range;
   private final Timer timer = new Timer();
   private final Setting<Integer> check;
   public EntityPlayer target;
   private final Setting<Boolean> raytrace;
   private final Setting<Double> minTargetSpeed;
   private final Setting<Float> minSelfRange;
   private final Setting<Boolean> web;

   private boolean canPlace(BlockPos var1) {
      if (!BlockUtil.canBlockFacing(var1)) {
         return false;
      } else if (!BlockUtil.canReplace(var1)) {
         return false;
      } else if (!this.strictPlaceCheck(var1)) {
         return false;
      } else if (this.web.getValue() && InventoryUtil.findHotbarBlock(Blocks.WEB) != -1) {
         return true;
      } else {
         boolean var10000;
         if (!BlockUtil.checkEntity(var1)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private boolean strictPlaceCheck(BlockPos var1) {
      if (!CombatSetting.INSTANCE.strictPlace.getValue() && this.raytrace.getValue()) {
         return true;
      } else {
         boolean var10002;
         if (this.raytrace.getValue() && !CombatSetting.INSTANCE.checkRaytrace.getValue()) {
            var10002 = false;
         } else {
            var10002 = true;
            boolean var10003 = false;
         }

         for(EnumFacing var3 : BlockUtil.getPlacableFacings(var1, true, var10002)) {
            if (BlockUtil.canClick(var1.offset(var3))) {
               return true;
            }

            boolean var10000 = false;
         }

         return false;
      }
   }

   private void placeBlock(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (!(
            mc.player.getDistance((double)var1.getX() + 0.5, (double)var1.getY(), (double)var1.getZ() + 0.5) > (double)this.placeRange.getValue().floatValue()
         )) {
            if (!(
               mc.player.getDistance((double)var1.getX() + 0.5, (double)var1.getY(), (double)var1.getZ() + 0.5)
                  <= (double)this.minSelfRange.getValue().floatValue()
            )) {
               if (!this.holeCheck.getValue() || CombatUtil.isHole(var1, this.anyBlock.getValue(), this.check.getValue(), this.onlyCanStand.getValue())) {
                  if (this.canPlace(var1)) {
                     int var2 = mc.player.inventory.currentItem;
                     if (this.web.getValue() && InventoryUtil.findHotbarClass(BlockWeb.class) != -1) {
                        InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockWeb.class));
                        BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                        InventoryUtil.doSwap(var2);
                        boolean var10000 = false;
                     } else if (InventoryUtil.findHotbarClass(BlockObsidian.class) != -1) {
                        InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockObsidian.class));
                        BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                        InventoryUtil.doSwap(var2);
                     }

                     this.timer.reset();
                     boolean var3 = false;
                     ++this.progress;
                  }
               }
            }
         }
      }
   }

   public Filler() {
      super("Filler", "Automatically pave the road for the enemy", Category.COMBAT);
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 0, 8));
      this.delay = this.add(new Setting<>("Delay", 50, 0, 500));
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.packet = this.add(new Setting<>("Packet", true));
      this.holeCheck = this.add(new Setting<>("HoleCheck", true).setParent());
      this.holeRange = this.add(new Setting<>("HoleRange", 2.0F, 0.5F, 3.0F, this::lambda$new$0));
      this.check = this.add(new Setting<>("Check", 3, 2, 4, this::lambda$new$1));
      this.anyBlock = this.add(new Setting<>("anyBlock", true, this::lambda$new$2));
      this.onlyCanStand = this.add(new Setting<>("OnlyCanStand", false, this::lambda$new$3));
      this.allowUp = this.add(new Setting<>("AllowUp", false, this::lambda$new$4));
      this.minSelfRange = this.add(new Setting<>("MinSelfRange", 2.0F, 1.0F, 4.0F, this::lambda$new$5));
      this.raytrace = this.add(new Setting<>("Raytrace", false));
      this.web = this.add(new Setting<>("Web", true));
      this.noInWeb = this.add(new Setting<>("NoInWeb", false));
      this.range = this.add(new Setting<>("Range", 5.0F, 1.0F, 6.0F));
      this.placeRange = this.add(new Setting<>("PlaceRange", 4.0F, 1.0F, 6.0F));
      this.maxSelfSpeed = this.add(new Setting<>("MaxSelfSpeed", 20.0, 1.0, 30.0));
      this.minTargetSpeed = this.add(new Setting<>("MinTargetSpeed", 6.0, 0.0, 20.0));
      this.air = this.add(new Setting<>("SelfGround", false));
      this.progress = 0;
   }

   private boolean lambda$new$4(Boolean var1) {
      return this.holeCheck.isOpen();
   }

   @Override
   public void onUpdate() {
      if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         this.progress = 0;
         if (this.air.getValue() && !mc.player.onGround) {
            this.target = null;
         } else if (Managers.SPEED.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue()) {
            this.target = null;
         } else {
            boolean var1 = false;

            for(EntityPlayer var3 : mc.world.playerEntities) {
               if (this.progress >= this.multiPlace.getValue()) {
                  return;
               }

               if (EntityUtil.invalid(var3, (double)this.range.getValue().floatValue())) {
                  boolean var30 = false;
               } else if (AutoWeb.isInWeb(var3) && this.noInWeb.getValue()) {
                  boolean var29 = false;
               } else if (Managers.SPEED.getPlayerSpeed(var3) < this.minTargetSpeed.getValue()) {
                  boolean var28 = false;
               } else {
                  this.target = var3;
                  var1 = true;
                  if (this.holeCheck.getValue()) {
                     for(BlockPos var5 : BlockUtil.getBox(this.holeRange.getValue() + 2.0F, EntityUtil.getEntityPos(var3).down())) {
                        if (var5.getY() >= EntityUtil.getEntityPos(var3).getY() && !this.allowUp.getValue()) {
                           boolean var23 = false;
                        } else if (var5.equals(EntityUtil.getEntityPos(var3))) {
                           boolean var22 = false;
                        } else {
                           if (this.allowUp.getValue()) {
                              boolean var6 = false;

                              for(EnumFacing var10 : EnumFacing.values()) {
                                 if (var10 != EnumFacing.UP) {
                                    if (var10 == EnumFacing.DOWN) {
                                       boolean var10000 = false;
                                    } else if (var5.equals(EntityUtil.getEntityPos(var3).offset(var10))) {
                                       var6 = true;
                                       boolean var17 = false;
                                       break;
                                    }
                                 }

                                 boolean var16 = false;
                              }

                              if (var6) {
                                 boolean var21 = false;
                                 continue;
                              }
                           }

                           if (var3.getDistance((double)var5.getX() + 0.5, (double)var5.getY(), (double)var5.getZ() + 0.5)
                                 > (double)this.holeRange.getValue().floatValue()
                              && var3.getDistance((double)var5.getX() + 0.5, (double)(var5.getY() + 1), (double)var5.getZ() + 0.5)
                                 > (double)this.holeRange.getValue().floatValue()) {
                              boolean var20 = false;
                           } else if (mc.player.getDistance((double)var5.getX() + 0.5, (double)var5.getY() + 0.5, (double)var5.getZ() + 0.5)
                              > (double)this.placeRange.getValue().floatValue()) {
                              boolean var18 = false;
                           } else {
                              this.placeBlock(var5);
                              boolean var19 = false;
                           }
                        }
                     }

                     boolean var24 = false;
                  } else {
                     BlockPos var11 = new BlockPos(this.target.posX, this.target.posY + 0.5, this.target.posZ);
                     this.placeBlock(var11.down());

                     for(EnumFacing var15 : EnumFacing.values()) {
                        if (var15 != EnumFacing.UP) {
                           if (var15 == EnumFacing.DOWN) {
                              boolean var25 = false;
                           } else {
                              this.placeBlock(var11.offset(var15).down());
                           }
                        }

                        boolean var26 = false;
                     }
                  }

                  boolean var27 = false;
               }
            }

            if (!var1) {
               this.target = null;
            }
         }
      }
   }

   private boolean lambda$new$3(Boolean var1) {
      return this.holeCheck.isOpen();
   }

   @Override
   public String getInfo() {
      return this.target != null ? this.target.getName() : null;
   }

   private boolean lambda$new$1(Integer var1) {
      return this.holeCheck.isOpen();
   }

   private boolean lambda$new$5(Float var1) {
      return this.holeCheck.isOpen();
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.holeCheck.isOpen();
   }

   private boolean lambda$new$0(Float var1) {
      return this.holeCheck.isOpen();
   }
}
