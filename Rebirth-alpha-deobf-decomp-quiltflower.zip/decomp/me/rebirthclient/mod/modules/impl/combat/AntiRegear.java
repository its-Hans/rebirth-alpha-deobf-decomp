package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityShulkerBox;

public class AntiRegear extends Module {
   private final Setting<Integer> safeRange = this.add(new Setting<>("SafeRange", 2, 0, 8));
   private final Setting<Integer> range = this.add(new Setting<>("Range", 5, 0, 8));

   @Override
   public void onUpdate() {
      if (PacketMine.breakPos == null || !BlockUtil.shulkerList.contains(mc.world.getBlockState(PacketMine.breakPos).getBlock())) {
         if (this.getBlock() != null) {
            CombatUtil.mineBlock(this.getBlock().getPos());
         }
      }
   }

   public AntiRegear() {
      super("AntiRegear", "Shulker nuker", Category.COMBAT);
   }

   private TileEntity getBlock() {
      TileEntity var1 = null;

      for(TileEntity var3 : mc.world.loadedTileEntityList) {
         if (var3 instanceof TileEntityShulkerBox) {
            if (mc.player.getDistance((double)var3.getPos().getX() + 0.5, (double)var3.getPos().getY() + 0.5, (double)var3.getPos().getZ() + 0.5)
               <= (double)this.safeRange.getValue().intValue()) {
               boolean var4 = false;
               continue;
            }

            if (mc.player.getDistance((double)var3.getPos().getX() + 0.5, (double)var3.getPos().getY() + 0.5, (double)var3.getPos().getZ() + 0.5)
               <= (double)this.range.getValue().intValue()) {
               var1 = var3;
            }
         }

         boolean var10000 = false;
      }

      return var1;
   }
}
