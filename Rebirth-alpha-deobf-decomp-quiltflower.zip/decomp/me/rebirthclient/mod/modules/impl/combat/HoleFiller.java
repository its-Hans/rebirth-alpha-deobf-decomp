package me.rebirthclient.mod.modules.impl.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockWeb;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HoleFiller extends Module {
   private final Setting<Double> range;
   private final Setting<Integer> smartRange;
   private final Setting<Boolean> smart;
   private EntityPlayer closestTarget;
   private final Setting<Boolean> packet;
   private final Map<BlockPos, Long> renderBlocks;
   private final Setting<Boolean> autoDisable;
   private final Setting<Boolean> webs;
   private final Setting<HoleFiller.Logic> logic;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", false));
   private final Setting<Boolean> render;
   private final Timer renderTimer;
   private final Setting<Boolean> box;
   private final Setting<Boolean> line;

   @Override
   public String getInfo() {
      return this.smart.getValue() ? Managers.TEXT.normalizeCases(this.logic.getValue()) : "Normal";
   }

   private BlockPos getClosestTargetPos(EntityPlayer var1) {
      return new BlockPos(Math.floor(var1.posX), Math.floor(var1.posY), Math.floor(var1.posZ));
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (this.render.getValue()) {
         this.renderTimer.reset();
         boolean var10000 = false;
         this.renderBlocks.forEach(this::lambda$onRender3D$4);
      }
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   private boolean lambda$new$0(HoleFiller.Logic var1) {
      return this.smart.isOpen();
   }

   private boolean isInRange(BlockPos var1) {
      NonNullList var2 = NonNullList.create();
      var2.addAll(this.getSphere(this.getPlayerPos(), this.range.getValue().floatValue()).stream().filter(this::isHole).collect(Collectors.toList()));
      boolean var10000 = false;
      return var2.contains(var1);
   }

   @Override
   public void onDisable() {
      this.closestTarget = null;
      Managers.ROTATIONS.resetRotationsPacket();
   }

   @Override
   public void onUpdate() {
      if (mc.world != null) {
         if (this.smart.getValue()) {
            this.findClosestTarget();
         }

         List var1 = this.getPlacePositions();
         BlockPos var2 = null;
         int var3 = InventoryUtil.findHotbarClass(BlockObsidian.class);
         int var4 = InventoryUtil.findHotbarClass(BlockEnderChest.class);
         int var5 = InventoryUtil.findHotbarClass(BlockWeb.class);
         if (this.webs.getValue() || var3 != -1 || var4 != -1) {
            if (!this.webs.getValue() || var5 != -1 || var3 != -1 || var4 != -1) {
               int var6 = mc.player.inventory.currentItem;

               for(BlockPos var8 : var1) {
                  if (!mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var8)).isEmpty()) {
                     boolean var11 = false;
                  } else if (this.smart.getValue() && this.isInRange(var8)) {
                     var2 = var8;
                     boolean var10 = false;
                  } else if (this.smart.getValue()
                     && this.isInRange(var8)
                     && this.logic.getValue() == HoleFiller.Logic.HOLE
                     && this.closestTarget.getDistanceSq(var8) <= (double)this.smartRange.getValue().intValue()) {
                     var2 = var8;
                     boolean var9 = false;
                  } else {
                     var2 = var8;
                     boolean var10000 = false;
                  }
               }

               if (var2 != null && mc.player.onGround) {
                  int var12;
                  if (this.webs.getValue()) {
                     if (var5 == -1) {
                        if (var3 == -1) {
                           var12 = var4;
                           boolean var10001 = false;
                        } else {
                           var12 = var3;
                           boolean var14 = false;
                        }
                     } else {
                        var12 = var5;
                        boolean var15 = false;
                     }
                  } else if (var3 == -1) {
                     var12 = var4;
                     boolean var16 = false;
                  } else {
                     var12 = var3;
                  }

                  InventoryUtil.doSwap(var12);
                  this.renderBlocks.put(var2, System.currentTimeMillis());
                  boolean var13 = false;
                  Managers.INTERACTIONS.placeBlock(var2, this.rotate.getValue(), this.packet.getValue(), false);
                  if (mc.player.inventory.currentItem != var6) {
                     InventoryUtil.doSwap(var6);
                  }

                  mc.player.swingArm(EnumHand.MAIN_HAND);
                  mc.player.inventory.currentItem = var6;
               }

               if (var2 == null && this.autoDisable.getValue() && !this.smart.getValue()) {
                  this.disable();
               }
            }
         }
      }
   }

   private void lambda$onRender3D$4(BlockPos var1, Long var2) {
      short var3 = 255;
      byte var4 = 80;
      if (System.currentTimeMillis() - var2 > 400L) {
         this.renderTimer.reset();
         boolean var10000 = false;
         this.renderBlocks.remove(var1);
         var10000 = false;
         var10000 = false;
      } else {
         long var5 = System.currentTimeMillis() - var2 - 100L;
         double var7 = MathUtil.normalize((double)var5, 0.0, 500.0);
         var7 = MathHelper.clamp(var7, 0.0, 1.0);
         var7 = -var7 + 1.0;
         int var9 = (int)(var7 * (double)var3);
         int var10 = (int)(var7 * (double)var4);
         RenderUtil.drawBoxESP(
            new BlockPos(var1),
            Managers.COLORS.getCurrent(),
            true,
            new Color(255, 255, 255, var9),
            0.7F,
            this.line.getValue(),
            this.box.getValue(),
            var10,
            true,
            0.0
         );
      }
   }

   private List<BlockPos> getSphere(BlockPos var1, float var2) {
      ArrayList var3 = new ArrayList();
      int var4 = var1.getX();
      int var5 = var1.getY();
      int var6 = var1.getZ();

      for(int var7 = var4 - (int)var2; (float)var7 <= (float)var4 + var2; ++var7) {
         for(int var8 = var6 - (int)var2; (float)var8 <= (float)var6 + var2; ++var8) {
            int var9 = var5 - (int)var2;

            while(true) {
               float var10 = (float)var9;
               float var11 = (float)var5 + var2;
               if (!(var10 < var11)) {
                  boolean var16 = false;
                  var16 = false;
                  break;
               }

               double var12 = (double)((var4 - var7) * (var4 - var7) + (var6 - var8) * (var6 - var8) + (var5 - var9) * (var5 - var9));
               if (var12 < (double)(var2 * var2)) {
                  BlockPos var14 = new BlockPos(var7, var9, var8);
                  var3.add(var14);
                  boolean var10000 = false;
               }

               boolean var15 = false;
               ++var9;
            }
         }

         boolean var18 = false;
      }

      return var3;
   }

   private boolean lambda$new$1(Integer var1) {
      return this.smart.isOpen();
   }

   public HoleFiller() {
      super("HoleFiller", "Fills all safe spots in radius", Category.COMBAT);
      this.packet = this.add(new Setting<>("Packet", false));
      this.webs = this.add(new Setting<>("Webs", false));
      this.autoDisable = this.add(new Setting<>("AutoDisable", true));
      this.range = this.add(new Setting<>("Radius", 4.0, 0.0, 6));
      this.smart = this.add(new Setting<>("Smart", false).setParent());
      this.logic = this.add(new Setting<>("Logic", HoleFiller.Logic.PLAYER, this::lambda$new$0));
      this.smartRange = this.add(new Setting<>("EnemyRange", 4, 0, 6, this::lambda$new$1));
      this.render = this.add(new Setting<>("Render", true).setParent());
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$2));
      this.line = this.add(new Setting<>("Line", true, this::lambda$new$3));
      this.renderBlocks = new ConcurrentHashMap<>();
      this.renderTimer = new Timer();
   }

   private void findClosestTarget() {
      List var1 = mc.world.playerEntities;
      this.closestTarget = null;

      for(EntityPlayer var3 : var1) {
         if (var3 != mc.player && !Managers.FRIENDS.isFriend(var3.getName()) && EntityUtil.isLiving(var3)) {
            if (var3.getHealth() <= 0.0F) {
               boolean var10000 = false;
            } else if (this.closestTarget == null) {
               this.closestTarget = var3;
               boolean var4 = false;
            } else if (!(mc.player.getDistance(var3) < mc.player.getDistance(this.closestTarget))) {
               boolean var5 = false;
            } else {
               this.closestTarget = var3;
               boolean var6 = false;
            }
         }
      }
   }

   private boolean isHole(BlockPos var1) {
      BlockPos var2 = var1.add(0, 1, 0);
      BlockPos var3 = var1.add(0, 0, 0);
      BlockPos var4 = var1.add(0, 0, -1);
      BlockPos var5 = var1.add(1, 0, 0);
      BlockPos var6 = var1.add(-1, 0, 0);
      BlockPos var7 = var1.add(0, 0, 1);
      BlockPos var8 = var1.add(0, 2, 0);
      BlockPos var9 = var1.add(0.5, 0.5, 0.5);
      BlockPos var10 = var1.add(0, -1, 0);
      boolean var10000;
      if (mc.world.getBlockState(var2).getBlock() != Blocks.AIR
         || mc.world.getBlockState(var3).getBlock() != Blocks.AIR
         || mc.world.getBlockState(var8).getBlock() != Blocks.AIR
         || mc.world.getBlockState(var4).getBlock() != Blocks.OBSIDIAN && mc.world.getBlockState(var4).getBlock() != Blocks.BEDROCK
         || mc.world.getBlockState(var5).getBlock() != Blocks.OBSIDIAN && mc.world.getBlockState(var5).getBlock() != Blocks.BEDROCK
         || mc.world.getBlockState(var6).getBlock() != Blocks.OBSIDIAN && mc.world.getBlockState(var6).getBlock() != Blocks.BEDROCK
         || mc.world.getBlockState(var7).getBlock() != Blocks.OBSIDIAN && mc.world.getBlockState(var7).getBlock() != Blocks.BEDROCK
         || mc.world.getBlockState(var9).getBlock() != Blocks.AIR
         || mc.world.getBlockState(var10).getBlock() != Blocks.OBSIDIAN && mc.world.getBlockState(var10).getBlock() != Blocks.BEDROCK) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled()) {
         if (var1.getPacket() instanceof SPacketBlockChange && this.renderBlocks.containsKey(((SPacketBlockChange)var1.getPacket()).getBlockPosition())) {
            this.renderTimer.reset();
            boolean var10000 = false;
            if (((SPacketBlockChange)var1.getPacket()).getBlockState().getBlock() != Blocks.AIR && this.renderTimer.passedMs(400L)) {
               this.renderBlocks.remove(((SPacketBlockChange)var1.getPacket()).getBlockPosition());
               var10000 = false;
            }
         }
      }
   }

   private BlockPos getPlayerPos() {
      return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
   }

   private boolean lambda$new$3(Boolean var1) {
      return this.render.isOpen();
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.render.isOpen();
   }

   private List<BlockPos> getPlacePositions() {
      NonNullList var1 = NonNullList.create();
      if (this.smart.getValue() && this.closestTarget != null) {
         var1.addAll(
            this.getSphere(this.getClosestTargetPos(this.closestTarget), this.smartRange.getValue().floatValue())
               .stream()
               .filter(this::isHole)
               .filter(this::isInRange)
               .collect(Collectors.toList())
         );
         boolean var2 = false;
         var2 = false;
      } else if (!this.smart.getValue()) {
         var1.addAll(this.getSphere(this.getPlayerPos(), this.range.getValue().floatValue()).stream().filter(this::isHole).collect(Collectors.toList()));
         boolean var10000 = false;
      }

      return var1;
   }

   private static enum Logic {
      PLAYER,
      HOLE;

      private static final HoleFiller.Logic[] $VALUES = new HoleFiller.Logic[]{PLAYER, HOLE};
   }
}
