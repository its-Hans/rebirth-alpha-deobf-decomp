package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.DamageUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Items;
import net.minecraft.util.EnumHand;

public class AutoWire extends Module {
   private final Setting<Boolean> face;
   private final Setting<Boolean> checkDamage;
   boolean active;
   private final Setting<Boolean> packet;
   private final Setting<Double> maxSelfSpeed;
   private final Setting<Float> crystalRange;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private final Setting<Double> minDamage;
   private final Setting<Boolean> onlyGround;

   private boolean lambda$new$1(Double var1) {
      return this.checkDamage.isOpen();
   }

   @Override
   public String getInfo() {
      return this.active ? "Active" : null;
   }

   private boolean lambda$new$0(Float var1) {
      return this.checkDamage.isOpen();
   }

   public AutoWire() {
      super("AutoWire", "", Category.COMBAT);
      this.packet = this.add(new Setting<>("Packet", true));
      this.onlyGround = this.add(new Setting<>("OnlyGround", true));
      this.face = this.add(new Setting<>("Face", true));
      this.checkDamage = this.add(new Setting<>("CheckDamage", true).setParent());
      this.crystalRange = this.add(new Setting<>("CrystalRange", 6.0F, 0.0F, 16.0F, this::lambda$new$0));
      this.minDamage = this.add(new Setting<>("MinDamage", 5.0, 0.0, 20.0, this::lambda$new$1));
      this.maxSelfSpeed = this.add(new Setting<>("MaxSelfSpeed", 12.0, 1.0, 30.0));
      this.active = false;
   }

   @Override
   public void onTick() {
      if (InventoryUtil.findItemInHotbar(Items.STRING) == -1) {
         this.active = false;
      } else if (!this.onlyGround.getValue() || mc.player.onGround && !MovementUtil.isJumping()) {
         if (Managers.SPEED.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue()) {
            this.active = false;
         } else {
            if (this.checkDamage.getValue()) {
               boolean var1 = true;

               for(Entity var3 : mc.world.loadedEntityList) {
                  if (!(var3 instanceof EntityEnderCrystal)) {
                     boolean var10000 = false;
                  } else if (mc.player.getDistance(var3) > this.crystalRange.getValue()) {
                     boolean var7 = false;
                  } else {
                     float var4 = DamageUtil.calculateDamage(var3, mc.player);
                     if ((double)var4 > this.minDamage.getValue()) {
                        var1 = false;
                        boolean var9 = false;
                        break;
                     }

                     boolean var8 = false;
                  }
               }

               if (var1) {
                  this.active = false;
                  return;
               }
            }

            this.active = true;
            if (BlockUtil.canBlockFacing(EntityUtil.getPlayerPos()) && mc.world.isAirBlock(EntityUtil.getPlayerPos())) {
               int var5 = mc.player.inventory.currentItem;
               if (InventoryUtil.findItemInHotbar(Items.STRING) == -1) {
                  return;
               }

               InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.STRING));
               BlockUtil.placeBlock(EntityUtil.getPlayerPos(), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
               InventoryUtil.doSwap(var5);
            }

            if (this.face.getValue() && BlockUtil.canBlockFacing(EntityUtil.getPlayerPos().up()) && mc.world.isAirBlock(EntityUtil.getPlayerPos().up())) {
               int var6 = mc.player.inventory.currentItem;
               if (InventoryUtil.findItemInHotbar(Items.STRING) == -1) {
                  return;
               }

               InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.STRING));
               BlockUtil.placeBlock(EntityUtil.getPlayerPos().up(), EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
               InventoryUtil.doSwap(var6);
            }
         }
      } else {
         this.active = false;
      }
   }
}
