package me.rebirthclient.mod.modules.impl.combat;

import java.awt.Color;
import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.RotationManager;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CrystalUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.asm.accessors.IEntityPlayerSP;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class CrystalBot extends Module {
   private final ConcurrentHashMap<Integer, Long> breakLocations;
   private final Setting<Boolean> noMineSwitch;
   private final Setting<Float> range;
   private final Timer placeTimer;
   private final Setting<CrystalBot.ConfirmMode> confirm;
   private final Setting<Integer> attackFactor;
   private final Setting<Integer> switchCooldown;
   private final Setting<Boolean> rightClickGap;
   private final Setting<Float> disableUnderHealth;
   private final Timer rotationTimer;
   private final Setting<Boolean> text;
   private EntityEnderCrystal postBreakPos;
   private EnumFacing postFacing;
   private final Setting<CrystalBot.ACSwapMode> autoSwap;
   private final Setting<Color> boxColor;
   private final Setting<Color> targetColor;
   public BlockPos renderBlock;
   private final Timer inhibitTimer;
   private final AtomicBoolean lastBroken;
   private final Setting<Boolean> noGapSwitch;
   private static float aboba;
   private final Setting<Float> compromise;
   private final Timer breakTimer;
   public static Setting<Boolean> collision;
   private final Timer scatterTimer;
   private final Setting<Boolean> liquids;
   private final Setting<Float> lineWidth;
   private AxisAlignedBB renderBB;
   private int ticks;
   private final ConcurrentHashMap<BlockPos, Long> placeLocations;
   private final Setting<Float> mergeOffset;
   private final Setting<Boolean> armorBreaker;
   private final Setting<CrystalBot.YawStepMode> yawStep;
   public static Setting<Boolean> terrainIgnore;
   private EntityPlayer renderTarget;
   private final Setting<Float> placeSpeed;
   private final Setting<Float> slabHeight;
   public int oldSlotCrystal;
   public float renderDamage;
   private final List<BlockPos> selfPlacePositions;
   private final AtomicBoolean shouldRunThread;
   private final Setting<CrystalBot.TargetingMode> targetingMode;
   private final Setting<CrystalBot.TargetRenderMode> targetRender;
   public float[] rotations;
   public BlockPos cachePos;
   private final Setting<Float> duration;
   private final Setting<Float> crystalRange;
   private float timePassed;
   private final Setting<Boolean> protocol;
   private final Setting<Float> accel;
   private final AtomicBoolean tickRunning;
   public int oldSlotSword;
   private final Setting<Boolean> colorSync;
   private final Timer renderTargetTimer = new Timer();
   private final Timer linearTimer;
   private final Setting<CrystalBot.SyncMode> syncMode;
   private final Setting<Float> minPlaceDamage;
   private final Setting<Integer> startFadeTime;
   private final Timer cacheTimer;
   private BlockPos postPlacePos;
   private final List<CrystalBot.currentPos> positions;
   private final Setting<Float> yawAngle;
   private final Setting<CrystalBot.RotationMode> rotationMode;
   private final Map<EntityPlayer, Timer> totemPops;
   private final Setting<Boolean> fadeFactor;
   private Vec3d bilateralVec;
   public EntityEnderCrystal inhibitEntity;
   private final Setting<Float> placeWallsRange;
   public final Setting<CrystalBot.DirectionMode> directionMode;
   private int lastSlot;
   private final Setting<Float> swapDelay;
   private final Setting<Color> outlineColor;
   private final Timer renderBreakingTimer;
   private final Setting<Boolean> Actualp;
   private final Setting<Boolean> swing;
   private final FadeUtils fadeUtils = new FadeUtils(500L);
   private final Setting<Boolean> check;
   private final Setting<Boolean> scaleFactor;
   public boolean isPlacing;
   private final Setting<Integer> max;
   private final Setting<Boolean> fire;
   private final Setting<Float> security;
   private final Setting<Float> enemyRange;
   private final Setting<Float> suicideHealth;
   private final Setting<Boolean> slabFactor;
   private final Setting<Integer> yawTicks;
   private static CrystalBot INSTANCE;
   public BlockPos renderBreakingPos;
   private final Setting<Float> depletion;
   private final Setting<Float> breakWallsRange;
   private final Setting<Float> breakRange;
   private final Setting<CrystalBot.RenderMode> renderMode;
   public final Setting<Boolean> strictDirection;
   private final Setting<Float> delay;
   private RayTraceResult postResult;
   private final Setting<CrystalBot.Pages> setting;
   private final Setting<CrystalBot.TimingMode> timingMode;
   private final Setting<Float> faceplaceHealth;
   private static final Timer switchTimer = new Timer();
   private final Setting<Float> breakSpeed;
   private final Setting<CrystalBot.ACAntiWeakness> antiWeakness;
   public static Setting<Integer> predictTicks;
   private boolean foundDoublePop;
   public final Setting<Float> placeRange;
   private final Setting<Float> maxSelfPlace;
   private final Setting<Boolean> limit;
   private final Setting<Bind> forceFaceplace;
   public Vec3d rotationVector;
   private final Setting<Boolean> predictPops;
   private final Setting<Boolean> inhibit;
   private final Setting<Integer> fadeTime;
   private final Timer swapTimer;
   private Thread thread;
   private final Setting<Float> moveSpeed;
   private final Timer renderTimeoutTimer;
   private BlockPos lastpos;

   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (var1.getPacket() instanceof SPacketSpawnObject) {
         SPacketSpawnObject var3 = var1.getPacket();
         if (var3.getType() == 51) {
            this.placeLocations.forEach(this::lambda$onReceivePacket$90);
         }

         boolean var10000 = false;
      } else if (var1.getPacket() instanceof SPacketSoundEffect) {
         SPacketSoundEffect var6 = var1.getPacket();
         if (var6.getCategory() == SoundCategory.BLOCKS && var6.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) {
            if (this.inhibitEntity != null && this.inhibitEntity.getDistance(var6.getX(), var6.getY(), var6.getZ()) < 6.0) {
               this.inhibitEntity = null;
            }

            label38:
            if (this.security.getValue() >= 0.5F) {
               List var7 = this.selfPlacePositions;
               BlockPos var10001 = new BlockPos;
               BlockPos var10002 = var10001;
               SPacketSoundEffect var10003 = var6;

               try {
                  var10002./* $QF: Unable to resugar constructor */<init>(var10003.getX(), var6.getY() - 1.0, var6.getZ());
                  var7.remove(var10001);
                  boolean var8 = false;
               } catch (ConcurrentModificationException var5) {
                  break label38;
               }

               boolean var9 = false;
            }
         }

         boolean var10 = false;
      } else if (var1.getPacket() instanceof SPacketEntityStatus) {
         SPacketEntityStatus var2 = var1.getPacket();
         if (var2.getOpCode() == 35 && var2.getEntity(mc.world) instanceof EntityPlayer) {
            this.totemPops.put((EntityPlayer)var2.getEntity(mc.world), new Timer());
            boolean var11 = false;
         }
      }
   }

   private boolean lambda$new$52(CrystalBot.ACAntiWeakness var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Break) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean canPlaceCrystal(BlockPos var1) {
      if (mc.world.getBlockState(var1).getBlock() != Blocks.BEDROCK && mc.world.getBlockState(var1).getBlock() != Blocks.OBSIDIAN) {
         return false;
      } else {
         BlockPos var2 = var1.add(0, 1, 0);
         if (mc.world.getBlockState(var2).getBlock() == Blocks.AIR
            || mc.world.getBlockState(var2).getBlock() == Blocks.FIRE && this.fire.getValue()
            || mc.world.getBlockState(var2).getBlock() instanceof BlockLiquid && this.liquids.getValue()) {
            BlockPos var3 = var1.add(0, 2, 0);
            if (this.protocol.getValue()
               || mc.world.getBlockState(var3).getBlock() == Blocks.AIR
               || mc.world.getBlockState(var2).getBlock() instanceof BlockLiquid && this.liquids.getValue()) {
               if (this.check.getValue() && !CrystalUtil.rayTraceBreak((double)var1.getX() + 0.5, (double)var1.getY() + 1.0, (double)var1.getZ() + 0.5)) {
                  Vec3d var4 = new Vec3d((double)var1.getX() + 0.5, (double)var1.getY() + 1.0, (double)var1.getZ() + 0.5);
                  if (mc.player.getPositionEyes(1.0F).distanceTo(var4) > (double)this.breakWallsRange.getValue().floatValue()) {
                     return false;
                  }
               }

               if (this.placeWallsRange.getValue() < this.placeRange.getValue()) {
                  if (!CrystalUtil.rayTracePlace(var1)) {
                     if (this.strictDirection.getValue()) {
                        Vec3d var5 = mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0);
                        boolean var21 = false;
                        if (this.directionMode.getValue() == CrystalBot.DirectionMode.VANILLA) {
                           for(EnumFacing var9 : EnumFacing.values()) {
                              Vec3d var32 = new Vec3d(
                                 (double)var1.getX() + 0.5 + (double)var9.getDirectionVec().getX() * 0.5,
                                 (double)var1.getY() + 0.5 + (double)var9.getDirectionVec().getY() * 0.5,
                                 (double)var1.getZ() + 0.5 + (double)var9.getDirectionVec().getZ() * 0.5
                              );
                              if (var5.distanceTo(var32) <= (double)this.placeWallsRange.getValue().floatValue()) {
                                 var21 = true;
                                 boolean var46 = false;
                                 break;
                              }

                              boolean var44 = false;
                              var44 = false;
                           }

                           boolean var47 = false;
                        } else {
                           double var6 = 0.45;
                           double var8 = 0.05;
                           double var10 = 0.95;

                           boolean var43;
                           label108:
                           for(double var12 = var8; var12 <= var10; var43 = false) {
                              for(double var14 = var8; var14 <= var10; var43 = false) {
                                 for(double var16 = var8; var16 <= var10; var43 = false) {
                                    Vec3d var18 = new Vec3d(var1).add(var12, var14, var16);
                                    double var19 = var5.distanceTo(var18);
                                    if (var19 <= (double)this.placeWallsRange.getValue().floatValue()) {
                                       var21 = true;
                                       var43 = false;
                                       break label108;
                                    }

                                    var43 = false;
                                    var16 += var6;
                                 }

                                 var14 += var6;
                              }

                              var12 += var6;
                           }
                        }

                        if (!var21) {
                           return false;
                        }

                        boolean var48 = false;
                     } else if ((double)var1.getY() > mc.player.posY + (double)mc.player.getEyeHeight()) {
                        if (mc.player.getDistance((double)var1.getX() + 0.5, (double)var1.getY(), (double)var1.getZ() + 0.5)
                           > (double)this.placeWallsRange.getValue().floatValue()) {
                           boolean var49 = false;
                           return false;
                        }
                     } else if (mc.player.getDistance((double)var1.getX() + 0.5, (double)(var1.getY() + 1), (double)var1.getZ() + 0.5)
                        > (double)this.placeWallsRange.getValue().floatValue()) {
                        return false;
                     }
                  }
               } else if (this.strictDirection.getValue()) {
                  Vec3d var23 = mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0);
                  boolean var22 = false;
                  if (this.directionMode.getValue() == CrystalBot.DirectionMode.VANILLA) {
                     for(EnumFacing var31 : EnumFacing.values()) {
                        Vec3d var34 = new Vec3d(
                           (double)var1.getX() + 0.5 + (double)var31.getDirectionVec().getX() * 0.5,
                           (double)var1.getY() + 0.5 + (double)var31.getDirectionVec().getY() * 0.5,
                           (double)var1.getZ() + 0.5 + (double)var31.getDirectionVec().getZ() * 0.5
                        );
                        if (var23.distanceTo(var34) <= (double)this.placeRange.getValue().floatValue()) {
                           var22 = true;
                           boolean var57 = false;
                           break;
                        }

                        boolean var55 = false;
                        var55 = false;
                     }

                     boolean var58 = false;
                  } else {
                     double var25 = 0.45;
                     double var29 = 0.05;
                     double var33 = 0.95;

                     boolean var54;
                     label138:
                     for(double var35 = var29; var35 <= var33; var54 = false) {
                        for(double var36 = var29; var36 <= var33; var54 = false) {
                           for(double var37 = var29; var37 <= var33; var54 = false) {
                              Vec3d var38 = new Vec3d(var1).add(var35, var36, var37);
                              double var39 = var23.distanceTo(var38);
                              if (var39 <= (double)this.placeRange.getValue().floatValue()) {
                                 var22 = true;
                                 var54 = false;
                                 break label138;
                              }

                              var54 = false;
                              var37 += var25;
                           }

                           var36 += var25;
                        }

                        var35 += var25;
                     }
                  }

                  if (!var22) {
                     return false;
                  }
               }

               return mc.world
                  .getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var2, var3.add(1, 1, 1)))
                  .stream()
                  .noneMatch(this::lambda$canPlaceCrystal$70);
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   private List<Entity> getCrystalInRange() {
      return mc.world
         .loadedEntityList
         .stream()
         .filter(CrystalBot::lambda$getCrystalInRange$82)
         .filter(this::lambda$getCrystalInRange$83)
         .collect(Collectors.toList());
   }

   private boolean lambda$canPlaceCrystal$70(Entity var1) {
      boolean var10000;
      if (this.breakLocations.containsKey(var1.getEntityId()) || var1 instanceof EntityEnderCrystal && var1.ticksExisted <= 20) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean isValidCrystalTarget(EntityEnderCrystal var1) {
      if (mc.player.getPositionEyes(1.0F).distanceTo(var1.getPositionVector()) > (double)this.breakRange.getValue().floatValue()) {
         return false;
      } else if (this.breakLocations.containsKey(var1.getEntityId()) && this.limit.getValue()) {
         return false;
      } else if (this.breakLocations.containsKey(var1.getEntityId())
         && (float)var1.ticksExisted > this.delay.getValue() + (float)this.attackFactor.getValue().intValue()) {
         return false;
      } else {
         boolean var10000;
         if (!(CrystalUtil.calculateDamage(var1, mc.player) + this.suicideHealth.getValue() >= mc.player.getHealth() + mc.player.getAbsorptionAmount())) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private List<EntityPlayer> getTargetsInRange() {
      List var1 = mc.world
         .playerEntities
         .stream()
         .filter(CrystalBot::lambda$getTargetsInRange$71)
         .filter(CrystalBot::lambda$getTargetsInRange$72)
         .filter(CrystalBot::lambda$getTargetsInRange$73)
         .filter(CrystalBot::lambda$getTargetsInRange$74)
         .filter(this::lambda$getTargetsInRange$75)
         .sorted(Comparator.comparing(CrystalBot::lambda$getTargetsInRange$76))
         .collect(Collectors.toList());
      if (this.targetingMode.getValue() == CrystalBot.TargetingMode.SMART) {
         List var2 = var1.stream()
            .filter(CrystalBot::lambda$getTargetsInRange$77)
            .sorted(Comparator.comparing(CrystalBot::lambda$getTargetsInRange$78))
            .collect(Collectors.toList());
         if (var2.size() > 0) {
            var1 = var2;
         }
      }

      return var1;
   }

   private boolean lambda$new$17(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.GLIDE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(CrystalBot.TargetRenderMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$65(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static Float lambda$getTargetsInRange$76(EntityPlayer var0) {
      return mc.player.getDistance(var0);
   }

   private boolean lambda$new$58(CrystalBot.ConfirmMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$44(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static Float lambda$getTargetsInRange$78(EntityPlayer var0) {
      return mc.player.getDistance(var0);
   }

   private boolean lambda$findCrystalTarget$88(Entity var1) {
      boolean var10000;
      if (!(var1.getPositionVector().distanceTo(mc.player.getPositionEyes(1.0F)) < (double)this.breakWallsRange.getValue().floatValue())
         && !CrystalUtil.rayTraceBreak(var1.posX, var1.posY, var1.posZ)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   public static List<BlockPos> getSphere(BlockPos var0, float var1, int var2, boolean var3, boolean var4, int var5) {
      ArrayList var6 = new ArrayList();
      int var7 = var0.getX();
      int var8 = var0.getY();
      int var9 = var0.getZ();

      for(int var10 = var7 - (int)var1; (float)var10 <= (float)var7 + var1; ++var10) {
         for(int var11 = var9 - (int)var1; (float)var11 <= (float)var9 + var1; ++var11) {
            int var10000;
            if (var4) {
               var10000 = var8 - (int)var1;
               boolean var10001 = false;
            } else {
               var10000 = var8;
            }

            int var12 = var10000;

            while(true) {
               float var14 = (float)var12;
               float var18;
               if (var4) {
                  var18 = (float)var8 + var1;
                  boolean var25 = false;
               } else {
                  var18 = (float)(var8 + var2);
               }

               float var13 = var18;
               if (!(var14 < var13)) {
                  boolean var22 = false;
                  var22 = false;
                  break;
               }

               var10000 = (var7 - var10) * (var7 - var10) + (var9 - var11) * (var9 - var11);
               int var26;
               if (var4) {
                  var26 = (var8 - var12) * (var8 - var12);
                  boolean var10002 = false;
               } else {
                  var26 = 0;
               }

               double var15 = (double)(var10000 + var26);
               if (var15 < (double)(var1 * var1) && (!var3 || !(var15 < (double)((var1 - 1.0F) * (var1 - 1.0F))))) {
                  BlockPos var17 = new BlockPos(var10, var12 + var5, var11);
                  var6.add(var17);
                  boolean var20 = false;
               }

               boolean var21 = false;
               ++var12;
            }
         }

         boolean var24 = false;
      }

      return var6;
   }

   private boolean lambda$new$8(Color var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$49(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Break) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$50(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Break) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$findCrystalTarget$86(Entity var1) {
      boolean var10000;
      if (!(var1.getPositionVector().distanceTo(mc.player.getPositionEyes(1.0F)) < (double)this.breakWallsRange.getValue().floatValue())
         && !CrystalUtil.rayTraceBreak(var1.posX, var1.posY, var1.posZ)) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.GLIDE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean hasCrystal() {
      if (this.isOffhand()) {
         return true;
      } else {
         int var1 = CrystalUtil.getCrystalSlot();
         if (var1 == -1) {
            return false;
         } else if (mc.player.inventory.currentItem == var1) {
            return true;
         } else {
            if (this.autoSwap.getValue() == CrystalBot.ACSwapMode.SILENT) {
               this.oldSlotCrystal = mc.player.inventory.currentItem;
            }

            mc.player.inventory.currentItem = var1;
            mc.player.connection.sendPacket(new CPacketHeldItemChange(var1));
            return true;
         }
      }
   }

   private boolean lambda$findCrystalTarget$85(Entity var1) {
      return this.selfPlacePositions.contains(new BlockPos(var1.posX, var1.posY - 1.0, var1.posZ));
   }

   private boolean lambda$new$64(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$36(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$61(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$53(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Break) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$63(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$34(CrystalBot.SyncMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public CrystalBot() {
      super("CrystalBot", "Muse Callisto", Category.COMBAT);
      this.positions = new ArrayList<>();
      this.setting = this.add(new Setting<>("Page", CrystalBot.Pages.General));
      this.compromise = this.add(new Setting<>("Compromise", 1.0F, 0.05F, 2.0F, this::lambda$new$0));
      this.switchCooldown = this.add(new Setting<>("SwitchCooldown", 100, 0, 1000, this::lambda$new$1));
      this.range = this.add(new Setting<>("Range", 10.0F, 0.0F, 50.0F, this::lambda$new$2));
      this.targetRender = this.add(new Setting<>("TargetRender", CrystalBot.TargetRenderMode.JELLO, this::lambda$new$3));
      this.targetColor = this.add(new Setting<>("TargetColor", new Color(255, 255, 255, 255), this::lambda$new$4));
      this.Actualp = this.add(new Setting<>("ActualRender+", true, this::lambda$new$5));
      this.text = this.add(new Setting<>("Text", false, this::lambda$new$6));
      this.boxColor = this.add(new Setting<>("BoxColor", new Color(255, 255, 255, 100), this::lambda$new$7).injectBoolean(true));
      this.outlineColor = this.add(new Setting<>("OutlineColor", new Color(255, 255, 255, 255), this::lambda$new$8).injectBoolean(true));
      this.renderMode = this.add(new Setting<>("APacketRenderMode", CrystalBot.RenderMode.STATIC, this::lambda$new$9));
      this.fadeFactor = this.add(new Setting<>("APacketFade", true, this::lambda$new$10));
      this.scaleFactor = this.add(new Setting<>("APacketShrink", false, this::lambda$new$11));
      this.slabFactor = this.add(new Setting<>("APacketSlab", false, this::lambda$new$12));
      this.duration = this.add(new Setting<>("APacketDuration", 1500.0F, 0.0F, 5000.0F, this::lambda$new$13));
      this.max = this.add(new Setting<>("APacketMaxPositions", 15, 1, 30, this::lambda$new$14));
      this.slabHeight = this.add(new Setting<>("APacketSlabDepth", 1.0F, -1.0F, 1.0F, this::lambda$new$15));
      this.moveSpeed = this.add(new Setting<>("APacketSpeed", 200.0F, 0.0F, 3000.0F, this::lambda$new$16));
      this.accel = this.add(new Setting<>("APacketDeceleration", 0.8F, 0.0F, 5.0F, this::lambda$new$17));
      this.colorSync = this.add(new Setting<>("APacketCSync", false, this::lambda$new$18));
      this.fadeTime = this.add(new Setting<>("FadeTime", 800, 0, 3000, this::lambda$new$19));
      this.startFadeTime = this.add(new Setting<>("StartFadeTime", 300, 0, 2000, this::lambda$new$20));
      this.lineWidth = this.add(new Setting<>("LineWidth", 1.5F, 0.1F, 5.0F, this::lambda$new$21));
      this.lastSlot = -1;
      this.noMineSwitch = this.add(new Setting<>("NoMining", Boolean.FALSE, this::lambda$new$22));
      this.noGapSwitch = this.add(new Setting<>("NoGapping", Boolean.FALSE, this::lambda$new$23));
      this.rightClickGap = this.add(new Setting<>("RightClickGap", Boolean.FALSE, this::lambda$new$24));
      this.timingMode = this.add(new Setting<>("Timing", CrystalBot.TimingMode.SEQUENTIAL, this::lambda$new$25));
      this.inhibit = this.add(new Setting<>("Inhibit", Boolean.FALSE, this::lambda$new$26));
      this.limit = this.add(new Setting<>("Limit", Boolean.TRUE, this::lambda$new$27));
      this.rotationMode = this.add(new Setting<>("Rotate", CrystalBot.RotationMode.TRACK, this::lambda$new$28));
      this.yawStep = this.add(new Setting<>("YawStep", CrystalBot.YawStepMode.OFF, this::lambda$new$29));
      this.yawAngle = this.add(new Setting<>("YawAngle", 0.3F, 0.1F, 1.0F, this::lambda$new$30));
      this.yawTicks = this.add(new Setting<>("YawTicks", 1, 1, 5, this::lambda$new$31));
      this.strictDirection = this.add(new Setting<>("StrictDirection", Boolean.TRUE, this::lambda$new$32));
      this.swing = this.add(new Setting<>("Swing", Boolean.TRUE, this::lambda$new$33));
      this.syncMode = this.add(new Setting<>("Sync", CrystalBot.SyncMode.MERGE, this::lambda$new$34));
      this.mergeOffset = this.add(new Setting<>("MergeOffset", 0.0F, 0.0F, 8.0F, this::lambda$new$35));
      this.enemyRange = this.add(new Setting<>("EnemyRange", 8.0F, 4.0F, 15.0F, this::lambda$new$36));
      this.crystalRange = this.add(new Setting<>("CrystalRange", 6.0F, 2.0F, 12.0F, this::lambda$new$37));
      this.disableUnderHealth = this.add(new Setting<>("DisableHealth", 0.0F, 0.0F, 10.0F, this::lambda$new$38));
      this.placeRange = this.add(new Setting<>("PlaceRange", 4.0F, 1.0F, 6.0F, this::lambda$new$39));
      this.placeWallsRange = this.add(new Setting<>("PlaceWallsRange", 3.0F, 1.0F, 6.0F, this::lambda$new$40));
      this.placeSpeed = this.add(new Setting<>("PlaceSpeed", 20.0F, 2.0F, 20.0F, this::lambda$new$41));
      this.autoSwap = this.add(new Setting<>("AutoSwap", CrystalBot.ACSwapMode.OFF, this::lambda$new$42));
      this.swapDelay = this.add(new Setting<>("SwapDelay", 0.0F, 0.0F, 10.0F, this::lambda$new$43));
      this.check = this.add(new Setting<>("PlacementsCheck", Boolean.TRUE, this::lambda$new$44));
      this.directionMode = this.add(new Setting<>("Interact", CrystalBot.DirectionMode.NORMAL, this::lambda$new$45));
      this.protocol = this.add(new Setting<>("1.13+ Place", Boolean.FALSE, this::lambda$new$46));
      this.liquids = this.add(new Setting<>("PlaceInLiquids", Boolean.FALSE, this::lambda$new$47));
      this.fire = this.add(new Setting<>("PlaceInFire", Boolean.FALSE, this::lambda$new$48));
      this.breakRange = this.add(new Setting<>("BreakRange", 4.3F, 1.0F, 6.0F, this::lambda$new$49));
      this.breakWallsRange = this.add(new Setting<>("BreakWalls", 3.0F, 1.0F, 6.0F, this::lambda$new$50));
      this.attackFactor = this.add(new Setting<>("AttackFactor", 3, 1, 20, this::lambda$new$51));
      this.antiWeakness = this.add(new Setting<>("AntiWeakness", CrystalBot.ACAntiWeakness.OFF, this::lambda$new$52));
      this.breakSpeed = this.add(new Setting<>("BreakSpeed", 20.0F, 1.0F, 20.0F, this::lambda$new$53));
      collision = this.add(new Setting<>("Collision", Boolean.FALSE, this::lambda$new$54));
      predictTicks = this.add(new Setting<>("PredictTicks", 1, 0, 10, this::lambda$new$55));
      terrainIgnore = this.add(new Setting<>("TerrainTrace", Boolean.FALSE, this::lambda$new$56));
      this.predictPops = this.add(new Setting<>("PredictPops", Boolean.FALSE, this::lambda$new$57));
      this.confirm = this.add(new Setting<>("Confirm", CrystalBot.ConfirmMode.OFF, this::lambda$new$58));
      this.delay = this.add(new Setting<>("TicksExisted", 0.0F, 0.0F, 20.0F, this::lambda$new$59));
      this.targetingMode = this.add(new Setting<>("Target", CrystalBot.TargetingMode.ALL, this::lambda$new$60));
      this.security = this.add(new Setting<>("DamageBalance", 1.0F, 0.1F, 5.0F, this::lambda$new$61));
      this.minPlaceDamage = this.add(new Setting<>("MinDamage", 6.0F, 0.0F, 20.0F, this::lambda$new$62));
      this.maxSelfPlace = this.add(new Setting<>("MaxSelfDmg", 12.0F, 0.0F, 20.0F, this::lambda$new$63));
      this.suicideHealth = this.add(new Setting<>("SuicideHealth", 2.0F, 0.0F, 10.0F, this::lambda$new$64));
      this.faceplaceHealth = this.add(new Setting<>("FacePlaceHealth", 4.0F, 0.0F, 36.0F, this::lambda$new$65));
      this.forceFaceplace = this.add(new Setting<>("FacePlace", new Bind(-1), this::lambda$new$66));
      this.armorBreaker = this.add(new Setting<>("ArmorBreaker", Boolean.TRUE, this::lambda$new$67));
      this.depletion = this.add(new Setting<>("ArmorDepletion", 0.9F, 0.1F, 1.0F, this::lambda$new$68));
      this.rotationVector = null;
      this.rotations = new float[]{0.0F, 0.0F};
      this.rotationTimer = new Timer();
      this.placeTimer = new Timer();
      this.breakTimer = new Timer();
      this.swapTimer = new Timer();
      this.renderDamage = 0.0F;
      this.renderTimeoutTimer = new Timer();
      this.renderBreakingTimer = new Timer();
      this.isPlacing = false;
      this.placeLocations = new ConcurrentHashMap<>();
      this.breakLocations = new ConcurrentHashMap<>();
      this.totemPops = new ConcurrentHashMap<>();
      this.selfPlacePositions = new CopyOnWriteArrayList();
      this.tickRunning = new AtomicBoolean(false);
      this.linearTimer = new Timer();
      this.cacheTimer = new Timer();
      this.cachePos = null;
      this.inhibitTimer = new Timer();
      this.inhibitEntity = null;
      this.scatterTimer = new Timer();
      this.bilateralVec = null;
      this.shouldRunThread = new AtomicBoolean(false);
      this.lastBroken = new AtomicBoolean(false);
      this.foundDoublePop = false;
      this.oldSlotCrystal = -1;
      this.oldSlotSword = -1;
      this.setInstance();
   }

   public boolean placeCrystal(BlockPos var1, EnumFacing var2) {
      if (var1 != null) {
         if (this.autoSwap.getValue() != CrystalBot.ACSwapMode.OFF && InventoryUtil.findItemInHotbar(Items.END_CRYSTAL) == -1) {
            return false;
         } else if (this.autoSwap.getValue() != CrystalBot.ACSwapMode.OFF && !this.hasCrystal()) {
            return false;
         } else if (!this.isOffhand() && mc.player.getHeldItemMainhand().getItem() != Items.END_CRYSTAL) {
            if (this.oldSlotCrystal != -1) {
               mc.player.inventory.currentItem = this.oldSlotCrystal;
               mc.player.connection.sendPacket(new CPacketHeldItemChange(this.oldSlotCrystal));
               this.oldSlotCrystal = -1;
            }

            return false;
         } else if (mc.world.getBlockState(var1.up()).getBlock() == Blocks.FIRE) {
            mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, var1.up(), EnumFacing.UP));
            mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, var1.up(), EnumFacing.UP));
            if (this.oldSlotCrystal != -1) {
               mc.player.inventory.currentItem = this.oldSlotCrystal;
               mc.player.connection.sendPacket(new CPacketHeldItemChange(this.oldSlotCrystal));
               this.oldSlotCrystal = -1;
            }

            return true;
         } else {
            this.isPlacing = true;
            if (this.postResult == null) {
               Vec3d var10001 = mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0);
               EnumHand var10002;
               if (this.isOffhand()) {
                  var10002 = EnumHand.OFF_HAND;
                  boolean var10003 = false;
               } else {
                  var10002 = EnumHand.MAIN_HAND;
               }

               BlockUtil.rightClickBlock(var1, var10001, var10002, var2, true);
               boolean var10000 = false;
            } else {
               NetHandlerPlayClient var3 = mc.player.connection;
               CPacketPlayerTryUseItemOnBlock var9 = new CPacketPlayerTryUseItemOnBlock;
               EnumHand var10005;
               if (this.isOffhand()) {
                  var10005 = EnumHand.OFF_HAND;
                  boolean var10006 = false;
               } else {
                  var10005 = EnumHand.MAIN_HAND;
               }

               var9./* $QF: Unable to resugar constructor */<init>(
                  var1, var2, var10005, (float)this.postResult.hitVec.x, (float)this.postResult.hitVec.y, (float)this.postResult.hitVec.z
               );
               var3.sendPacket(var9);
               var3 = mc.player.connection;
               CPacketAnimation var10 = new CPacketAnimation;
               EnumHand var11;
               if (this.isOffhand()) {
                  var11 = EnumHand.OFF_HAND;
                  boolean var10004 = false;
               } else {
                  var11 = EnumHand.MAIN_HAND;
               }

               var10./* $QF: Unable to resugar constructor */<init>(var11);
               var3.sendPacket(var10);
            }

            if (this.foundDoublePop && this.renderTarget != null) {
               this.totemPops.put(this.renderTarget, new Timer());
               boolean var5 = false;
            }

            this.isPlacing = false;
            this.placeLocations.put(var1, System.currentTimeMillis());
            boolean var6 = false;
            if (this.security.getValue() >= 0.5F) {
               this.selfPlacePositions.add(var1);
               var6 = false;
            }

            this.renderTimeoutTimer.reset();
            var6 = false;
            if (this.oldSlotCrystal != -1) {
               mc.player.inventory.currentItem = this.oldSlotCrystal;
               mc.player.connection.sendPacket(new CPacketHeldItemChange(this.oldSlotCrystal));
               this.oldSlotCrystal = -1;
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private boolean lambda$new$38(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayerPre(UpdateWalkingPlayerEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getStage() == 0) {
            this.placeLocations.forEach(this::lambda$onUpdateWalkingPlayerPre$69);
            --this.ticks;
            if (this.bilateralVec != null) {
               for(Entity var3 : mc.world.loadedEntityList) {
                  if (var3 instanceof EntityEnderCrystal) {
                     if (!(var3.getDistance(this.bilateralVec.x, this.bilateralVec.y, this.bilateralVec.z) <= 6.0)) {
                        boolean var10000 = false;
                     } else {
                        this.breakLocations.put(var3.getEntityId(), System.currentTimeMillis());
                        boolean var5 = false;
                        var5 = false;
                     }
                  }
               }

               this.bilateralVec = null;
            }

            if (var1.isCanceled()) {
               return;
            }

            this.postBreakPos = null;
            this.postPlacePos = null;
            this.postFacing = null;
            this.postResult = null;
            this.foundDoublePop = false;
            this.handleSequential();
            if (this.rotationMode.getValue() != CrystalBot.RotationMode.OFF && !this.rotationTimer.passedMs(650L) && this.rotationVector != null) {
               if (this.rotationMode.getValue() == CrystalBot.RotationMode.TRACK) {
                  this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
               }

               if (this.yawAngle.getValue() < 1.0F
                  && this.yawStep.getValue() != CrystalBot.YawStepMode.OFF
                  && (this.postBreakPos != null || this.yawStep.getValue() == CrystalBot.YawStepMode.FULL)) {
                  if (this.ticks > 0) {
                     this.rotations[0] = ((IEntityPlayerSP)mc.player).getLastReportedYaw();
                     this.postBreakPos = null;
                     this.postPlacePos = null;
                     boolean var7 = false;
                  } else {
                     float var4 = MathHelper.wrapDegrees(this.rotations[0] - ((IEntityPlayerSP)mc.player).getLastReportedYaw());
                     if (Math.abs(var4) > 180.0F * this.yawAngle.getValue()) {
                        this.rotations[0] = ((IEntityPlayerSP)mc.player).getLastReportedYaw() + var4 * (180.0F * this.yawAngle.getValue() / Math.abs(var4));
                        this.postBreakPos = null;
                        this.postPlacePos = null;
                        this.ticks = this.yawTicks.getValue();
                     }
                  }
               }

               this.lookAtAngles(this.rotations[0], this.rotations[1]);
            }
         }
      }
   }

   private boolean lambda$getCrystalInRange$83(Entity var1) {
      return this.isValidCrystalTarget((EntityEnderCrystal)var1);
   }

   private boolean lambda$new$32(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private List<BlockPos> findCrystalBlocks() {
      NonNullList var1 = NonNullList.create();
      BlockPos var10001 = new BlockPos(mc.player);
      float var10002;
      if (this.strictDirection.getValue()) {
         var10002 = this.placeRange.getValue() + 2.0F;
         boolean var10003 = false;
      } else {
         var10002 = this.placeRange.getValue();
      }

      var1.addAll(
         getSphere(var10001, var10002, this.placeRange.getValue().intValue(), false, true, 0)
            .stream()
            .filter(this::canPlaceCrystal)
            .collect(Collectors.toList())
      );
      boolean var10000 = false;
      return var1;
   }

   @SubscribeEvent
   public void onChangeItem(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (var1.getPacket() instanceof CPacketHeldItemChange) {
            this.swapTimer.reset();
            boolean var10000 = false;
         }
      }
   }

   static void access$400(CrystalBot var0) {
      var0.doInstant();
   }

   private boolean lambda$new$5(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onEnable() {
      this.postBreakPos = null;
      this.postPlacePos = null;
      this.postFacing = null;
      this.postResult = null;
      this.cachePos = null;
      this.bilateralVec = null;
      this.lastBroken.set(false);
      this.rotationVector = null;
      this.rotationTimer.reset();
      this.isPlacing = false;
      this.foundDoublePop = false;
      this.totemPops.clear();
      this.oldSlotCrystal = -1;
      this.oldSlotSword = -1;
   }

   private boolean lambda$new$4(Color var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.targetRender.getValue() != CrystalBot.TargetRenderMode.OFF) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static CrystalBot getInstance() {
      if (INSTANCE == null) {
         INSTANCE = new CrystalBot();
      }

      return INSTANCE;
   }

   public void handleBreakRotation(double var1, double var3, double var5) {
      if (this.rotationMode.getValue() != CrystalBot.RotationMode.OFF) {
         if (this.rotationMode.getValue() == CrystalBot.RotationMode.INTERACT && this.rotationVector != null && !this.rotationTimer.passedMs(650L)) {
            if (this.rotationVector.y < var3 - 0.1) {
               this.rotationVector = new Vec3d(this.rotationVector.x, var3, this.rotationVector.z);
            }

            this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
            this.rotationTimer.reset();
            boolean var42 = false;
            return;
         }

         AxisAlignedBB var7 = new AxisAlignedBB(var1 - 1.0, var3, var5 - 1.0, var1 + 1.0, var3 + 2.0, var5 + 1.0);
         Vec3d var8 = new Vec3d(mc.player.posX, mc.player.getEntityBoundingBox().minY + (double)mc.player.getEyeHeight(), mc.player.posZ);
         double var9 = 0.1;
         double var11 = 0.15;
         double var13 = 0.85;
         if (var7.intersects(mc.player.getEntityBoundingBox())) {
            var11 = 0.4;
            var13 = 0.6;
            var9 = 0.05;
         }

         Vec3d var15 = null;
         double[] var16 = null;
         boolean var17 = false;

         boolean var40;
         for(double var18 = var11; var18 <= var13; var40 = false) {
            for(double var20 = var11; var20 <= var13; var40 = false) {
               for(double var22 = var11; var22 <= var13; var40 = false) {
                  Vec3d var24 = new Vec3d(
                     var7.minX + (var7.maxX - var7.minX) * var18, var7.minY + (var7.maxY - var7.minY) * var20, var7.minZ + (var7.maxZ - var7.minZ) * var22
                  );
                  double var25 = var24.x - var8.x;
                  double var27 = var24.y - var8.y;
                  double var29 = var24.z - var8.z;
                  double[] var31 = new double[]{
                     (double)MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2(var29, var25)) - 90.0F),
                     (double)MathHelper.wrapDegrees((float)(-Math.toDegrees(Math.atan2(var27, Math.sqrt(var25 * var25 + var29 * var29)))))
                  };
                  if (this.directionMode.getValue() != CrystalBot.DirectionMode.VANILLA && !CrystalUtil.isVisible(var24)) {
                     var40 = false;
                  } else {
                     var40 = true;
                     boolean var10001 = false;
                  }

                  boolean var32 = var40;
                  if (this.strictDirection.getValue()) {
                     if (var15 != null) {
                        if (var32 || !var17) {
                           if (!(
                              mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var24)
                                 < mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var15)
                           )) {
                              var40 = false;
                           } else {
                              var15 = var24;
                              var16 = var31;
                              var40 = false;
                           }
                        }
                     } else {
                        var15 = var24;
                        var16 = var31;
                        var17 = var32;
                        var40 = false;
                     }
                  } else if (var15 != null) {
                     if (var32 || !var17) {
                        if (!(
                           Math.hypot(
                                 ((var31[0] - (double)((IEntityPlayerSP)mc.player).getLastReportedYaw()) % 360.0 + 540.0) % 360.0 - 180.0,
                                 var31[1] - (double)((IEntityPlayerSP)mc.player).getLastReportedPitch()
                              )
                              < Math.hypot(
                                 ((var16[0] - (double)((IEntityPlayerSP)mc.player).getLastReportedYaw()) % 360.0 + 540.0) % 360.0 - 180.0,
                                 var16[1] - (double)((IEntityPlayerSP)mc.player).getLastReportedPitch()
                              )
                        )) {
                           var40 = false;
                        } else {
                           var15 = var24;
                           var16 = var31;
                           var40 = false;
                        }
                     }
                  } else {
                     var15 = var24;
                     var16 = var31;
                     var17 = var32;
                  }

                  var22 += var9;
               }

               var20 += var9;
            }

            var18 += var9;
         }

         this.rotationTimer.reset();
         var40 = false;
         this.rotationVector = var15;
         this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
      }
   }

   private boolean lambda$new$47(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onDisable() {
      this.positions.clear();
   }

   private void handleSequential() {
      if (!(mc.player.getHealth() + mc.player.getAbsorptionAmount() < this.disableUnderHealth.getValue())
         && (!this.noGapSwitch.getValue() || !EntityUtil.isEating())
         && (!this.noMineSwitch.getValue() || !mc.playerController.getIsHittingBlock() || !(mc.player.getHeldItemMainhand().getItem() instanceof ItemTool))
         && switchTimer.passedMs((long)this.switchCooldown.getValue().intValue())) {
         if (this.noGapSwitch.getValue()
            && this.rightClickGap.getValue()
            && mc.gameSettings.keyBindUseItem.isKeyDown()
            && mc.player.inventory.getCurrentItem().getItem() instanceof ItemEndCrystal) {
            int var1 = -1;

            for(int var2 = 0; var2 < 9; ++var2) {
               if (mc.player.inventory.getStackInSlot(var2).getItem() == Items.GOLDEN_APPLE) {
                  var1 = var2;
                  boolean var9 = false;
                  break;
               }

               boolean var10000 = false;
               var10000 = false;
            }

            if (var1 != -1 && var1 != mc.player.inventory.currentItem) {
               mc.player.inventory.currentItem = var1;
               mc.player.connection.sendPacket(new CPacketHeldItemChange(var1));
               return;
            }
         }

         if (this.isOffhand()
            || mc.player.inventory.getCurrentItem().getItem() instanceof ItemEndCrystal
            || this.autoSwap.getValue() != CrystalBot.ACSwapMode.OFF) {
            List var6 = this.getTargetsInRange();
            EntityEnderCrystal var7 = this.findCrystalTarget(var6);
            int var3 = (int)Math.max(100.0F, (float)(CrystalUtil.ping() + 50)) + 150;
            if (var7 != null
               && this.breakTimer.passedMs((long)(1000.0F - this.breakSpeed.getValue() * 50.0F))
               && ((float)var7.ticksExisted >= this.delay.getValue() || this.timingMode.getValue() == CrystalBot.TimingMode.VANILLA)) {
               this.postBreakPos = var7;
               this.handleBreakRotation(this.postBreakPos.posX, this.postBreakPos.posY, this.postBreakPos.posZ);
            }

            if (var7 == null
               && (
                  this.confirm.getValue() != CrystalBot.ConfirmMode.FULL
                     || this.inhibitEntity == null
                     || (double)this.inhibitEntity.ticksExisted >= (double)this.delay.getValue().intValue()
               )
               && (
                  this.syncMode.getValue() != CrystalBot.SyncMode.STRICT
                     || this.breakTimer.passedMs((long)(950.0F - this.breakSpeed.getValue() * 50.0F - (float)CrystalUtil.ping()))
               )
               && this.placeTimer.passedMs((long)(1000.0F - this.placeSpeed.getValue() * 50.0F))
               && (
                  this.timingMode.getValue() == CrystalBot.TimingMode.SEQUENTIAL
                     || this.linearTimer.passedMs((long)((float)this.delay.getValue().intValue() * 5.0F))
               )) {
               if (this.confirm.getValue() != CrystalBot.ConfirmMode.OFF
                  && this.cachePos != null
                  && !this.cacheTimer.passedMs((long)(var3 + 100))
                  && this.canPlaceCrystal(this.cachePos)) {
                  this.postPlacePos = this.cachePos;
                  this.postFacing = this.handlePlaceRotation(this.postPlacePos);
                  this.lastBroken.set(false);
                  return;
               }

               List var5 = this.findCrystalBlocks();
               if (!var5.isEmpty()) {
                  BlockPos var4 = this.findPlacePosition(var5, var6);
                  if (var4 != null) {
                     this.postPlacePos = var4;
                     this.postFacing = this.handlePlaceRotation(this.postPlacePos);
                  }
               }
            }

            this.lastBroken.set(false);
         }
      } else {
         this.rotationVector = null;
      }
   }

   private boolean lambda$new$27(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$59(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void runInstantThread() {
      if (this.mergeOffset.getValue() == 0.0F) {
         this.doInstant();
         boolean var10000 = false;
      } else {
         this.shouldRunThread.set(true);
         if (this.thread == null || this.thread.isInterrupted() || !this.thread.isAlive()) {
            if (this.thread == null) {
               this.thread = new Thread(CrystalBot.InstantThread.getInstance(this));
            }

            if (this.thread.isInterrupted() || !this.thread.isAlive()) {
               this.thread = new Thread(CrystalBot.InstantThread.getInstance(this));
            }

            if (this.thread.getState() == State.NEW) {
               CrystalBot var3 = this;

               try {
                  var3.thread.start();
               } catch (Exception var2) {
                  return;
               }

               boolean var4 = false;
            }
         }
      }
   }

   private boolean lambda$new$31(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$43(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.FADE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$39(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$42(CrystalBot.ACSwapMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$28(CrystalBot.RotationMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public boolean isOffhand() {
      boolean var10000;
      if (mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$29(CrystalBot.YawStepMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$68(Float var1) {
      boolean var10000;
      if (this.armorBreaker.getValue() && this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(CrystalBot.RenderMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$onRender3D$81(CrystalBot.currentPos var1) {
      boolean var10000;
      if (!(var1.getRenderTime() >= this.duration.getValue()) && !mc.world.isAirBlock(var1.renderBlock()) && mc.world.isAirBlock(var1.renderBlock().up())) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private static boolean lambda$getTargetsInRange$73(EntityPlayer var0) {
      boolean var10000;
      if (!Managers.FRIENDS.isFriend(var0.getName())) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void swingArmAfterBreaking(EnumHand var1) {
      if (this.swing.getValue()) {
         ItemStack var2 = mc.player.getHeldItem(var1);
         if (var2.isEmpty() || !var2.getItem().onEntitySwing(mc.player, var2)) {
            if (!mc.player.isSwingInProgress || mc.player.swingProgressInt >= this.getSwingAnimTime(mc.player) / 2 || mc.player.swingProgressInt < 0) {
               mc.player.swingProgressInt = -1;
               mc.player.isSwingInProgress = true;
               mc.player.swingingHand = var1;
            }
         }
      }
   }

   private boolean lambda$new$6(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$33(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private double easeInOutQuad(double var1) {
      double var10000;
      if (var1 < 0.5) {
         var10000 = 2.0 * var1 * var1;
         boolean var10001 = false;
      } else {
         var10000 = 1.0 - Math.pow(-2.0 * var1 + 2.0, 2.0) / 2.0;
      }

      return var10000;
   }

   private boolean lambda$new$67(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void lambda$onReceivePacket$90(SPacketSpawnObject var1, PacketEvent.Receive var2, BlockPos var3, Long var4) {
      if (this.getDistance((double)var3.getX() + 0.5, (double)var3.getY(), (double)var3.getZ() + 0.5, var1.getX(), var1.getY() - 1.0, var1.getZ()) < 1.0) {
         ConcurrentHashMap var10000 = this.placeLocations;
         BlockPos var10001 = var3;

         label96: {
            try {
               var10000.remove(var10001);
               boolean var9 = false;
               this.cachePos = null;
               if (!this.limit.getValue() && this.inhibit.getValue()) {
                  this.scatterTimer.reset();
                  boolean var10 = false;
               }
            } catch (ConcurrentModificationException var8) {
               break label96;
            }

            boolean var11 = false;
         }

         if (this.timingMode.getValue() != CrystalBot.TimingMode.VANILLA) {
            return;
         }

         if (!this.swapTimer.passedMs((long)(this.swapDelay.getValue() * 100.0F))) {
            return;
         }

         if (this.tickRunning.get()) {
            return;
         }

         if (mc.player.isPotionActive(MobEffects.WEAKNESS)) {
            return;
         }

         if (this.breakLocations.containsKey(var1.getEntityID())) {
            return;
         }

         if (mc.player.getHealth() + mc.player.getAbsorptionAmount() < this.disableUnderHealth.getValue()
            || this.noGapSwitch.getValue() && EntityUtil.isEating()
            || this.noMineSwitch.getValue() && mc.playerController.getIsHittingBlock() && mc.player.getHeldItemMainhand().getItem() instanceof ItemTool) {
            this.rotationVector = null;
            return;
         }

         Vec3d var5 = new Vec3d(var1.getX(), var1.getY(), var1.getZ());
         if (mc.player.getPositionEyes(1.0F).distanceTo(var5) > (double)this.breakRange.getValue().floatValue()) {
            return;
         }

         if (!this.breakTimer.passedMs((long)(1000.0F - this.breakSpeed.getValue() * 50.0F))) {
            return;
         }

         if (CrystalUtil.calculateDamage(var1.getX(), var1.getY(), var1.getZ(), mc.player) + this.suicideHealth.getValue()
            >= mc.player.getHealth() + mc.player.getAbsorptionAmount()) {
            return;
         }

         this.breakLocations.put(var1.getEntityID(), System.currentTimeMillis());
         boolean var12 = false;
         this.bilateralVec = new Vec3d(var1.getX(), var1.getY(), var1.getZ());
         CPacketUseEntity var6 = new CPacketUseEntity();
         SPacketSpawnObject var7 = var2.getPacket();
         var6.entityId = var7.getEntityID();
         var6.action = net.minecraft.network.play.client.CPacketUseEntity.Action.ATTACK;
         mc.player.connection.sendPacket(var6);
         NetHandlerPlayClient var13 = mc.player.connection;
         CPacketAnimation var18 = new CPacketAnimation;
         EnumHand var10003;
         if (this.isOffhand()) {
            var10003 = EnumHand.OFF_HAND;
            boolean var10004 = false;
         } else {
            var10003 = EnumHand.MAIN_HAND;
         }

         var18./* $QF: Unable to resugar constructor */<init>(var10003);
         var13.sendPacket(var18);
         EnumHand var19;
         if (this.isOffhand()) {
            var19 = EnumHand.OFF_HAND;
            boolean var10002 = false;
         } else {
            var19 = EnumHand.MAIN_HAND;
         }

         this.swingArmAfterBreaking(var19);
         this.renderBreakingPos = new BlockPos(var1.getX(), var1.getY() - 1.0, var1.getZ());
         this.renderBreakingTimer.reset();
         boolean var14 = false;
         this.breakTimer.reset();
         boolean var15 = false;
         this.linearTimer.reset();
         boolean var16 = false;
         if (this.syncMode.getValue() == CrystalBot.SyncMode.MERGE) {
            this.placeTimer.reset();
            boolean var17 = false;
         }

         if (this.syncMode.getValue() == CrystalBot.SyncMode.STRICT) {
            this.lastBroken.set(true);
         }

         if (this.syncMode.getValue() == CrystalBot.SyncMode.MERGE) {
            this.runInstantThread();
         }
      }
   }

   private boolean lambda$new$41(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$24(Boolean var1) {
      boolean var10000;
      if (this.noGapSwitch.getValue() && this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   static float access$100() {
      return aboba;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!this.renderTargetTimer.passedMs((long)this.startFadeTime.getValue().intValue())) {
         this.fadeUtils.reset();
      }

      this.fadeUtils.setLength((long)this.fadeTime.getValue().intValue());
      if (this.fadeUtils.easeOutQuad() != 1.0) {
         if (this.renderBlock != null && this.Actualp.getValue()) {
            double var2 = Math.abs(this.fadeUtils.easeOutQuad() - 1.0);
            if (!this.renderTargetTimer.passedMs((long)this.startFadeTime.getValue().intValue()) || this.renderMode.getValue() == CrystalBot.RenderMode.FADE) {
               var2 = 1.0;
            }

            Color var4 = ColorUtil.injectAlpha(this.boxColor.getValue(), (int)((double)this.boxColor.getValue().getAlpha() * var2));
            Color var5 = ColorUtil.injectAlpha(this.outlineColor.getValue(), (int)((double)this.outlineColor.getValue().getAlpha() * var2));
            if (this.renderBlock != null && (this.boxColor.booleanValue || this.outlineColor.booleanValue)) {
               if (this.renderMode.getValue() == CrystalBot.RenderMode.FADE) {
                  this.positions.removeIf(this::lambda$onRender3D$79);
                  boolean var10000 = false;
                  this.positions.add(new CrystalBot.currentPos(this.renderBlock, 0.0F));
                  var10000 = false;
               }

               if (this.renderMode.getValue() == CrystalBot.RenderMode.STATIC) {
                  RenderUtil.drawSexyBoxPhobosIsRetardedFuckYouESP(
                     new AxisAlignedBB(this.renderBlock),
                     var4,
                     var5,
                     this.lineWidth.getValue(),
                     this.outlineColor.booleanValue,
                     this.boxColor.booleanValue,
                     this.colorSync.getValue(),
                     1.0F,
                     1.0F,
                     this.slabHeight.getValue()
                  );
               }

               if (this.renderMode.getValue() == CrystalBot.RenderMode.GLIDE) {
                  if (this.positions.size() > this.max.getValue()) {
                     this.positions.remove(0);
                     boolean var37 = false;
                  }

                  if (this.lastpos == null
                     || mc.player.getDistance(this.renderBB.minX, this.renderBB.minY, this.renderBB.minZ) > (double)this.range.getValue().floatValue()) {
                     this.lastpos = this.renderBlock;
                     this.renderBB = new AxisAlignedBB(this.renderBlock);
                     this.timePassed = 0.0F;
                  }

                  if (!this.lastpos.equals(this.renderBlock)) {
                     this.lastpos = this.renderBlock;
                     this.timePassed = 0.0F;
                  }

                  double var6 = (double)this.renderBlock.getX() - this.renderBB.minX;
                  double var8 = (double)this.renderBlock.getY() - this.renderBB.minY;
                  double var10 = (double)this.renderBlock.getZ() - this.renderBB.minZ;
                  float var12 = this.timePassed / this.moveSpeed.getValue() * this.accel.getValue();
                  if (var12 > 1.0F) {
                     var12 = 1.0F;
                  }

                  this.renderBB = this.renderBB.offset(var6 * (double)var12, var8 * (double)var12, var10 * (double)var12);
                  RenderUtil.drawSexyBoxPhobosIsRetardedFuckYouESP(
                     this.renderBB,
                     var4,
                     var5,
                     this.lineWidth.getValue(),
                     this.outlineColor.booleanValue,
                     this.boxColor.booleanValue,
                     this.colorSync.getValue(),
                     1.0F,
                     1.0F,
                     this.slabHeight.getValue()
                  );
                  if (this.text.getValue()) {
                     AxisAlignedBB var38 = this.renderBB.offset(0.0, (double)(1.0F - this.slabHeight.getValue() / 2.0F) - 0.4, 0.0);
                     Object var10001;
                     if (Math.floor((double)this.renderDamage) == (double)this.renderDamage) {
                        var10001 = (int)this.renderDamage;
                        boolean var10002 = false;
                     } else {
                        var10001 = String.format("%.1f", this.renderDamage);
                     }

                     RenderUtil.drawText(var38, String.valueOf(var10001));
                  }

                  if (this.renderBB.equals(new AxisAlignedBB(this.renderBlock))) {
                     this.timePassed = 0.0F;
                     boolean var39 = false;
                  } else {
                     this.timePassed += 50.0F;
                  }
               }
            }

            if (this.renderMode.getValue() == CrystalBot.RenderMode.FADE) {
               this.positions.forEach(this::lambda$onRender3D$80);
               this.positions.removeIf(this::lambda$onRender3D$81);
               boolean var40 = false;
               if (this.positions.size() > this.max.getValue()) {
                  this.positions.remove(0);
                  var40 = false;
               }
            }

            if (this.renderBlock != null && this.text.getValue() && this.renderMode.getValue() != CrystalBot.RenderMode.GLIDE) {
               AxisAlignedBB var42 = new AxisAlignedBB(this.renderBlock);
               double var54;
               if (this.renderMode.getValue() != CrystalBot.RenderMode.FADE) {
                  var54 = (double)(1.0F - this.slabHeight.getValue() / 2.0F) - 0.4;
                  boolean var10003 = false;
               } else {
                  var54 = 0.1;
               }

               var42 = var42.offset(0.0, var54, 0.0);
               Object var50;
               if (Math.floor((double)this.renderDamage) == (double)this.renderDamage) {
                  var50 = (int)this.renderDamage;
                  boolean var55 = false;
               } else {
                  var50 = String.format("%.1f", this.renderDamage);
               }

               RenderUtil.drawText(var42, String.valueOf(var50));
            }
         }

         if (this.renderTarget != null) {
            if (this.targetRender.getValue() == CrystalBot.TargetRenderMode.OLD) {
               RenderUtil.drawEntityBoxESP(this.renderTarget, this.targetColor.getValue(), true, new Color(255, 255, 255, 130), 0.7F, true, true, 35);
               boolean var44 = false;
            } else if (this.targetRender.getValue() == CrystalBot.TargetRenderMode.JELLO) {
               double var31 = 1500.0;
               double var32 = (double)System.currentTimeMillis() % var31;
               boolean var45;
               if (var32 > var31 / 2.0) {
                  var45 = true;
                  boolean var51 = false;
               } else {
                  var45 = false;
               }

               boolean var33 = var45;
               double var7 = var32 / (var31 / 2.0);
               if (!var33) {
                  var7 = 1.0 - var7;
                  var45 = false;
               } else {
                  --var7;
               }

               var7 = this.easeInOutQuad(var7);
               mc.entityRenderer.disableLightmap();
               GL11.glPushMatrix();
               GL11.glDisable(3553);
               GL11.glBlendFunc(770, 771);
               GL11.glEnable(2848);
               GL11.glEnable(3042);
               GL11.glDisable(2929);
               GL11.glDisable(2884);
               GL11.glShadeModel(7425);
               mc.entityRenderer.disableLightmap();
               double var9 = (double)this.renderTarget.width;
               double var11 = (double)this.renderTarget.height + 0.1;
               double var13 = this.renderTarget.lastTickPosX
                  + (this.renderTarget.posX - this.renderTarget.lastTickPosX) * (double)mc.getRenderPartialTicks()
                  - mc.renderManager.viewerPosX;
               double var15 = this.renderTarget.lastTickPosY
                  + (this.renderTarget.posY - this.renderTarget.lastTickPosY) * (double)mc.getRenderPartialTicks()
                  - mc.renderManager.viewerPosY
                  + var11 * var7;
               double var17 = this.renderTarget.lastTickPosZ
                  + (this.renderTarget.posZ - this.renderTarget.lastTickPosZ) * (double)mc.getRenderPartialTicks()
                  - mc.renderManager.viewerPosZ;
               double var47 = var11 / 3.0;
               double var52;
               if (var7 > 0.5) {
                  var52 = 1.0 - var7;
                  boolean var56 = false;
               } else {
                  var52 = var7;
               }

               double var48 = var47 * var52;
               byte var53;
               if (var33) {
                  var53 = -1;
                  boolean var57 = false;
               } else {
                  var53 = 1;
               }

               double var19 = var48 * (double)var53;

               for(int var21 = 0; var21 < 360; var21 += 5) {
                  Color var22 = this.targetColor.getValue();
                  double var23 = var13 - Math.sin((double)var21 * Math.PI / 180.0) * var9;
                  double var25 = var17 + Math.cos((double)var21 * Math.PI / 180.0) * var9;
                  double var27 = var13 - Math.sin((double)(var21 - 5) * Math.PI / 180.0) * var9;
                  double var29 = var17 + Math.cos((double)(var21 - 5) * Math.PI / 180.0) * var9;
                  GL11.glBegin(7);
                  GL11.glColor4f(
                     (float)ColorUtil.pulseColor(var22, 200, 1).getRed() / 255.0F,
                     (float)ColorUtil.pulseColor(var22, 200, 1).getGreen() / 255.0F,
                     (float)ColorUtil.pulseColor(var22, 200, 1).getBlue() / 255.0F,
                     0.0F
                  );
                  GL11.glVertex3d(var23, var15 + var19, var25);
                  GL11.glVertex3d(var27, var15 + var19, var29);
                  GL11.glColor4f(
                     (float)ColorUtil.pulseColor(var22, 200, 1).getRed() / 255.0F,
                     (float)ColorUtil.pulseColor(var22, 200, 1).getGreen() / 255.0F,
                     (float)ColorUtil.pulseColor(var22, 200, 1).getBlue() / 255.0F,
                     200.0F
                  );
                  GL11.glVertex3d(var27, var15, var29);
                  GL11.glVertex3d(var23, var15, var25);
                  GL11.glEnd();
                  GL11.glBegin(2);
                  GL11.glVertex3d(var27, var15, var29);
                  GL11.glVertex3d(var23, var15, var25);
                  GL11.glEnd();
                  var45 = false;
               }

               GL11.glEnable(2884);
               GL11.glShadeModel(7424);
               GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
               GL11.glEnable(2929);
               GL11.glDisable(2848);
               GL11.glDisable(3042);
               GL11.glEnable(3553);
               GL11.glPopMatrix();
            }
         }
      }
   }

   private boolean lambda$new$7(Color var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$62(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$66(Bind var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$22(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void setPlayerRotations(float var1, float var2) {
      mc.player.rotationYaw = var1;
      mc.player.rotationYawHead = var1;
      mc.player.rotationPitch = var2;
   }

   private boolean lambda$new$45(CrystalBot.DirectionMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   static AtomicBoolean access$000(CrystalBot var0) {
      return var0.shouldRunThread;
   }

   private void doInstant() {
      if (this.confirm.getValue() != CrystalBot.ConfirmMode.OFF
         && (
            this.confirm.getValue() != CrystalBot.ConfirmMode.FULL
               || this.inhibitEntity == null
               || (double)this.inhibitEntity.ticksExisted >= (double)this.delay.getValue().intValue()
         )) {
         int var3 = (int)Math.max(100.0F, (float)(CrystalUtil.ping() + 50)) + 150;
         if (this.cachePos != null && !this.cacheTimer.passedMs((long)(var3 + 100)) && this.canPlaceCrystal(this.cachePos)) {
            this.postPlacePos = this.cachePos;
            this.postFacing = this.handlePlaceRotation(this.postPlacePos);
            if (this.postPlacePos != null) {
               if (!this.placeCrystal(this.postPlacePos, this.postFacing)) {
                  this.postPlacePos = null;
                  return;
               }

               this.placeTimer.reset();
               boolean var4 = false;
               this.postPlacePos = null;
            }

            return;
         }
      }

      List var2 = this.findCrystalBlocks();
      if (!var2.isEmpty()) {
         BlockPos var1 = this.findPlacePosition(var2, this.getTargetsInRange());
         if (var1 != null) {
            this.postPlacePos = var1;
            this.postFacing = this.handlePlaceRotation(this.postPlacePos);
            if (this.postPlacePos != null) {
               if (!this.placeCrystal(this.postPlacePos, this.postFacing)) {
                  this.postPlacePos = null;
                  return;
               }

               this.placeTimer.reset();
               boolean var10000 = false;
               this.postPlacePos = null;
            }
         }
      }
   }

   private void setInstance() {
      INSTANCE = this;
   }

   static AtomicBoolean access$300(CrystalBot var0) {
      return var0.tickRunning;
   }

   private static boolean lambda$getTargetsInRange$72(EntityPlayer var0) {
      boolean var10000;
      if (!var0.isDead) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      float var1 = (float)this.renderTargetTimer.getPassedTimeMs();
      if (this.renderTarget != null && !this.renderTargetTimer.passedMs(800L) && !this.renderTarget.isDead) {
         StringBuilder var10000 = new StringBuilder().append(this.renderTarget.getName()).append(" , ");
         Object var10001;
         if (Math.floor((double)this.renderDamage) == (double)this.renderDamage) {
            var10001 = (int)this.renderDamage;
            boolean var10002 = false;
         } else {
            var10001 = String.format("%.1f", this.renderDamage);
         }

         return String.valueOf(var10000.append(var10001));
      } else {
         return null;
      }
   }

   private boolean lambda$new$30(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$48(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$getTargetsInRange$75(EntityPlayer var1) {
      boolean var10000;
      if (mc.player.getDistance(var1) < this.enemyRange.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private int getSwingAnimTime(EntityLivingBase var1) {
      if (var1.isPotionActive(MobEffects.HASTE)) {
         return 6 - (1 + ((PotionEffect)Objects.requireNonNull(var1.getActivePotionEffect(MobEffects.HASTE))).getAmplifier());
      } else {
         int var10000;
         if (var1.isPotionActive(MobEffects.MINING_FATIGUE)) {
            var10000 = 6 + (1 + ((PotionEffect)Objects.requireNonNull(var1.getActivePotionEffect(MobEffects.MINING_FATIGUE))).getAmplifier()) * 2;
            boolean var10001 = false;
         } else {
            var10000 = 6;
         }

         return var10000;
      }
   }

   private boolean lambda$new$21(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.outlineColor.booleanValue) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$20(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private EntityEnderCrystal findCrystalTarget(List<EntityPlayer> var1) {
      this.breakLocations.forEach(this::lambda$findCrystalTarget$84);
      if (this.syncMode.getValue() == CrystalBot.SyncMode.STRICT && !this.limit.getValue() && this.lastBroken.get()) {
         return null;
      } else {
         EntityEnderCrystal var2 = null;
         int var3 = (int)Math.max(100.0F, (float)(CrystalUtil.ping() + 50)) + 150;
         if (this.inhibit.getValue()
            && !this.limit.getValue()
            && !this.inhibitTimer.passedMs((long)var3)
            && this.inhibitEntity != null
            && mc.world.getEntityByID(this.inhibitEntity.getEntityId()) != null
            && this.isValidCrystalTarget(this.inhibitEntity)) {
            return this.inhibitEntity;
         } else {
            List var4 = this.getCrystalInRange();
            if (var4.isEmpty()) {
               return null;
            } else {
               if (this.security.getValue() >= 1.0F) {
                  double var5 = 0.5;

                  for(Entity var8 : var4) {
                     if (!(var8.getPositionVector().distanceTo(mc.player.getPositionEyes(1.0F)) < (double)this.breakWallsRange.getValue().floatValue())
                        && !CrystalUtil.rayTraceBreak(var8.posX, var8.posY, var8.posZ)) {
                        boolean var19 = false;
                     } else {
                        EntityEnderCrystal var9 = (EntityEnderCrystal)var8;
                        double var10 = 0.0;

                        for(EntityPlayer var13 : var1) {
                           double var14 = (double)CrystalUtil.calculateDamage(var9, var13);
                           var10 += var14;
                           boolean var10000 = false;
                        }

                        double var16 = (double)CrystalUtil.calculateDamage(var9, mc.player);
                        if (!(var16 > var10 * (double)(this.security.getValue() - 0.8F))
                           || this.selfPlacePositions.contains(new BlockPos(var8.posX, var8.posY - 1.0, var8.posZ))) {
                           if (!(var10 > var5)) {
                              boolean var17 = false;
                           } else {
                              var5 = var10;
                              var2 = var9;
                              boolean var18 = false;
                           }
                        }
                     }
                  }

                  boolean var20 = false;
               } else {
                  EntityEnderCrystal var21;
                  if (this.security.getValue() >= 0.5F) {
                     var21 = (EntityEnderCrystal)var4.stream()
                        .filter(this::lambda$findCrystalTarget$85)
                        .filter(this::lambda$findCrystalTarget$86)
                        .min(Comparator.comparing(CrystalBot::lambda$findCrystalTarget$87))
                        .orElse(null);
                     boolean var10001 = false;
                  } else {
                     var21 = (EntityEnderCrystal)var4.stream()
                        .filter(this::lambda$findCrystalTarget$88)
                        .min(Comparator.comparing(CrystalBot::lambda$findCrystalTarget$89))
                        .orElse(null);
                  }

                  var2 = var21;
               }

               return var2;
            }
         }
      }
   }

   private boolean lambda$new$55(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static Float lambda$findCrystalTarget$89(Entity var0) {
      return mc.player.getDistance(var0);
   }

   private boolean lambda$new$40(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private double getDistance(double var1, double var3, double var5, double var7, double var9, double var11) {
      double var13 = var1 - var7;
      double var15 = var3 - var9;
      double var17 = var5 - var11;
      return Math.sqrt(var13 * var13 + var15 * var15 + var17 * var17);
   }

   private boolean lambda$new$15(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render
         && (this.renderMode.getValue() == CrystalBot.RenderMode.STATIC || this.renderMode.getValue() == CrystalBot.RenderMode.GLIDE)
         && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$56(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.FADE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$26(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean lambda$getTargetsInRange$71(EntityPlayer var0) {
      boolean var10000;
      if (var0 != mc.player && var0 != mc.getRenderViewEntity()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$19(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$46(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$37(Float var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$onRender3D$79(CrystalBot.currentPos var1) {
      return var1.renderBlock().equals(this.renderBlock);
   }

   private boolean lambda$new$14(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.FADE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$18(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void lambda$onUpdateWalkingPlayerPre$69(BlockPos var1, Long var2) {
      if (System.currentTimeMillis() - var2 > 1500L) {
         this.placeLocations.remove(var1);
         boolean var10000 = false;
      }
   }

   private void lambda$onRender3D$80(Color var1, Color var2, CrystalBot.currentPos var3) {
      float var4 = (this.duration.getValue() - var3.getRenderTime()) / this.duration.getValue();
      AxisAlignedBB var10000 = new AxisAlignedBB(var3.renderBlock());
      float var10003 = this.lineWidth.getValue();
      boolean var10004 = this.outlineColor.booleanValue;
      boolean var10005 = this.boxColor.booleanValue;
      boolean var10006 = this.colorSync.getValue();
      float var10007;
      if (this.fadeFactor.getValue()) {
         var10007 = var4;
         boolean var10008 = false;
      } else {
         var10007 = 1.0F;
      }

      float var5;
      if (this.scaleFactor.getValue()) {
         var5 = var4;
         boolean var10009 = false;
      } else {
         var5 = 1.0F;
      }

      float var6;
      if (this.slabFactor.getValue()) {
         var6 = var4;
         boolean var10010 = false;
      } else {
         var6 = 1.0F;
      }

      RenderUtil.drawSexyBoxPhobosIsRetardedFuckYouESP(var10000, var1, var2, var10003, var10004, var10005, var10006, var10007, var5, var6);
      var3.setRenderTime(var3.getRenderTime() + 5.0F);
   }

   private static boolean lambda$getTargetsInRange$77(EntityPlayer var0) {
      boolean var10000;
      if (var0.getHealth() + var0.getAbsorptionAmount() < 10.0F) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void lambda$findCrystalTarget$84(Integer var1, Long var2) {
      if (System.currentTimeMillis() - var2 > 1000L) {
         this.breakLocations.remove(var1);
         boolean var10000 = false;
      }
   }

   public boolean switchToSword() {
      int var1 = CrystalUtil.getSwordSlot();
      if (mc.player.inventory.currentItem != var1 && var1 != -1) {
         if (this.antiWeakness.getValue() == CrystalBot.ACAntiWeakness.SILENT) {
            this.oldSlotSword = mc.player.inventory.currentItem;
         }

         mc.player.inventory.currentItem = var1;
         mc.player.connection.sendPacket(new CPacketHeldItemChange(var1));
      }

      boolean var10000;
      if (var1 != -1) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$51(Integer var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Break) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayerPost(UpdateWalkingPlayerEvent var1) {
      if (!fullNullCheck()) {
         aboba = this.mergeOffset.getValue() / 10.0F;
         if (var1.getStage() == 1) {
            if (this.postBreakPos != null) {
               if (this.breakCrystal(this.postBreakPos)) {
                  this.breakTimer.reset();
                  boolean var10000 = false;
                  this.breakLocations.put(this.postBreakPos.getEntityId(), System.currentTimeMillis());
                  var10000 = false;

                  for(Entity var3 : mc.world.loadedEntityList) {
                     if (var3 instanceof EntityEnderCrystal) {
                        if (!(var3.getDistance(this.postBreakPos.posX, this.postBreakPos.posY, this.postBreakPos.posZ) <= 6.0)) {
                           var10000 = false;
                        } else {
                           this.breakLocations.put(var3.getEntityId(), System.currentTimeMillis());
                           var10000 = false;
                           var10000 = false;
                        }
                     }
                  }

                  this.postBreakPos = null;
                  if (this.syncMode.getValue() == CrystalBot.SyncMode.MERGE) {
                     this.runInstantThread();
                     var10000 = false;
                  }
               }
            } else if (this.postPlacePos != null) {
               if (!this.placeCrystal(this.postPlacePos, this.postFacing)) {
                  this.shouldRunThread.set(false);
                  this.postPlacePos = null;
                  return;
               }

               this.placeTimer.reset();
               boolean var9 = false;
               this.postPlacePos = null;
            }
         }
      }
   }

   private boolean lambda$new$12(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.FADE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private BlockPos findPlacePosition(List<BlockPos> var1, List<EntityPlayer> var2) {
      if (var2.isEmpty()) {
         return null;
      } else {
         float var3 = 0.5F;
         EntityPlayer var4 = null;
         BlockPos var5 = null;
         this.foundDoublePop = false;
         EntityPlayer var6 = null;

         for(BlockPos var8 : var1) {
            float var9 = CrystalUtil.calculateDamage(var8, mc.player);
            if ((double)var9 + (double)this.suicideHealth.getValue().floatValue() < (double)(mc.player.getHealth() + mc.player.getAbsorptionAmount())) {
               if (!(var9 <= this.maxSelfPlace.getValue())) {
                  boolean var22 = false;
               } else if (this.targetingMode.getValue() != CrystalBot.TargetingMode.ALL) {
                  var6 = (EntityPlayer)var2.get(0);
                  if (var6.getDistance((double)var8.getX() + 0.5, (double)var8.getY() + 0.5, (double)var8.getZ() + 0.5)
                     > (double)this.crystalRange.getValue().floatValue()) {
                     boolean var21 = false;
                  } else {
                     float var13 = CrystalUtil.calculateDamage(var8, var6);
                     if (!this.isDoublePoppable(var6, var13) || var5 != null && !(var6.getDistanceSq(var8) < var6.getDistanceSq(var5))) {
                        if (!this.foundDoublePop
                           && var13 > var3
                           && (var13 * this.compromise.getValue() > var9 || var13 > var6.getHealth() + var6.getAbsorptionAmount())) {
                           if (var13 < this.minPlaceDamage.getValue()
                              && var6.getHealth() + var6.getAbsorptionAmount() > this.faceplaceHealth.getValue()
                              && !this.forceFaceplace.getValue().isDown()
                              && !this.shouldArmorBreak(var6)) {
                              boolean var20 = false;
                           } else {
                              var3 = var13;
                              var4 = var6;
                              var5 = var8;
                              boolean var19 = false;
                           }
                        }
                     } else {
                        var4 = var6;
                        var3 = var13;
                        var5 = var8;
                        this.foundDoublePop = true;
                        boolean var18 = false;
                     }
                  }
               } else {
                  for(EntityPlayer var11 : var2) {
                     if (!var11.equals(var6)) {
                        if (var11.getDistance((double)var8.getX() + 0.5, (double)var8.getY() + 0.5, (double)var8.getZ() + 0.5)
                           > (double)this.crystalRange.getValue().floatValue()) {
                           boolean var16 = false;
                        } else {
                           float var12 = CrystalUtil.calculateDamage(var8, var11);
                           if (!this.isDoublePoppable(var11, var12) || var5 != null && !(var11.getDistanceSq(var8) < var11.getDistanceSq(var5))) {
                              if (!this.foundDoublePop
                                 && var12 > var3
                                 && (var12 * this.compromise.getValue() > var9 || var12 > var11.getHealth() + var11.getAbsorptionAmount())) {
                                 if (var12 < this.minPlaceDamage.getValue()
                                    && var11.getHealth() + var11.getAbsorptionAmount() > this.faceplaceHealth.getValue()
                                    && !this.forceFaceplace.getValue().isDown()
                                    && !this.shouldArmorBreak(var11)) {
                                    boolean var15 = false;
                                 } else {
                                    var3 = var12;
                                    var4 = var11;
                                    var5 = var8;
                                    boolean var14 = false;
                                 }
                              }
                           } else {
                              var4 = var11;
                              var3 = var12;
                              var5 = var8;
                              this.foundDoublePop = true;
                              boolean var10000 = false;
                           }
                        }
                     }
                  }

                  boolean var17 = false;
               }
            }
         }

         if (var4 != null) {
            this.renderTarget = var4;
            this.renderTargetTimer.reset();
            boolean var23 = false;
            this.fadeUtils.reset();
         }

         if (var5 != null) {
            this.renderBlock = var5;
            this.renderDamage = var3;
         }

         this.cachePos = var5;
         this.cacheTimer.reset();
         boolean var24 = false;
         return var5;
      }
   }

   private boolean lambda$new$23(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$57(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean lambda$getCrystalInRange$82(Entity var0) {
      return var0 instanceof EntityEnderCrystal;
   }

   @Override
   public void onTick() {
      if (this.lastSlot != mc.player.inventory.currentItem) {
         this.lastSlot = mc.player.inventory.currentItem;
         switchTimer.reset();
         boolean var10000 = false;
      }
   }

   private boolean lambda$new$54(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static Float lambda$findCrystalTarget$87(Entity var0) {
      return mc.player.getDistance(var0);
   }

   private static boolean lambda$getTargetsInRange$74(EntityPlayer var0) {
      boolean var10000;
      if (var0.getHealth() > 0.0F) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$25(CrystalBot.TimingMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   static Thread access$200(CrystalBot var0) {
      return var0.thread;
   }

   private boolean isDoublePoppable(EntityPlayer var1, float var2) {
      if (this.predictPops.getValue()
         && var1.getHealth() + var1.getAbsorptionAmount() <= 2.0F
         && (double)var2 > (double)var1.getHealth() + (double)var1.getAbsorptionAmount() + 0.5
         && var2 <= 4.0F) {
         Timer var3 = this.totemPops.get(var1);
         boolean var10000;
         if (var3 != null && !var3.passedMs(500L)) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var10001 = false;
         }

         return var10000;
      } else {
         return false;
      }
   }

   private boolean lambda$new$11(Boolean var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Render && this.renderMode.getValue() == CrystalBot.RenderMode.FADE && this.Actualp.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void lookAtAngles(float var1, float var2) {
      this.setPlayerRotations(var1, var2);
      mc.player.rotationYawHead = var1;
   }

   private boolean breakCrystal(EntityEnderCrystal var1) {
      if (var1 != null) {
         if (this.antiWeakness.getValue() != CrystalBot.ACAntiWeakness.OFF
            && mc.player.isPotionActive(MobEffects.WEAKNESS)
            && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword)
            && !this.switchToSword()) {
            return false;
         } else if (!this.swapTimer.passedMs((long)(this.swapDelay.getValue() * 100.0F))) {
            return false;
         } else {
            mc.playerController.attackEntity(mc.player, var1);
            NetHandlerPlayClient var10000 = mc.player.connection;
            CPacketAnimation var10001 = new CPacketAnimation;
            EnumHand var10003;
            if (this.isOffhand()) {
               var10003 = EnumHand.OFF_HAND;
               boolean var10004 = false;
            } else {
               var10003 = EnumHand.MAIN_HAND;
            }

            var10001./* $QF: Unable to resugar constructor */<init>(var10003);
            var10000.sendPacket(var10001);
            EnumHand var5;
            if (this.isOffhand()) {
               var5 = EnumHand.OFF_HAND;
               boolean var10002 = false;
            } else {
               var5 = EnumHand.MAIN_HAND;
            }

            this.swingArmAfterBreaking(var5);
            if (this.oldSlotSword != -1 && mc.player.getHeldItemMainhand().getItem() instanceof ItemSword) {
               mc.player.inventory.currentItem = this.oldSlotSword;
               mc.player.connection.sendPacket(new CPacketHeldItemChange(this.oldSlotSword));
               this.oldSlotSword = -1;
            }

            if (this.syncMode.getValue() == CrystalBot.SyncMode.MERGE) {
               this.placeTimer.reset();
               boolean var2 = false;
            }

            if (this.syncMode.getValue() == CrystalBot.SyncMode.STRICT) {
               this.lastBroken.set(true);
            }

            this.inhibitTimer.reset();
            boolean var3 = false;
            this.inhibitEntity = var1;
            this.renderBreakingPos = new BlockPos(var1).down();
            this.renderBreakingTimer.reset();
            boolean var4 = false;
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean lambda$new$35(Float var1) {
      boolean var10000;
      if (this.syncMode.getValue() == CrystalBot.SyncMode.MERGE && this.setting.getValue() == CrystalBot.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public EnumFacing handlePlaceRotation(BlockPos var1) {
      if (var1 != null && mc.player != null) {
         EnumFacing var2 = null;
         if (this.directionMode.getValue() != CrystalBot.DirectionMode.VANILLA) {
            Vec3d var30 = null;
            double[] var31 = null;
            double var32 = 0.45;
            double var34 = 0.05;
            double var36 = 0.95;
            Vec3d var38 = new Vec3d(mc.player.posX, mc.player.getEntityBoundingBox().minY + (double)mc.player.getEyeHeight(), mc.player.posZ);

            boolean var78;
            for(double var28 = var34; var28 <= var36; var78 = false) {
               for(double var26 = var34; var26 <= var36; var78 = false) {
                  for(double var24 = var34; var24 <= var36; var78 = false) {
                     label274: {
                        Vec3d var23 = new Vec3d(var1).add(var28, var26, var24);
                        double var21 = var38.distanceTo(var23);
                        double var19 = var23.x - var38.x;
                        double var17 = var23.y - var38.y;
                        double var15 = var23.z - var38.z;
                        double var13 = (double)MathHelper.sqrt(var19 * var19 + var15 * var15);
                        double[] var12 = new double[]{
                           (double)MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2(var15, var19)) - 90.0F),
                           (double)MathHelper.wrapDegrees((float)(-Math.toDegrees(Math.atan2(var17, var13))))
                        };
                        float var11 = MathHelper.cos((float)(-var12[0] * (float) (Math.PI / 180.0) - (float) Math.PI));
                        float var10 = MathHelper.sin((float)(-var12[0] * (float) (Math.PI / 180.0) - (float) Math.PI));
                        float var9 = -MathHelper.cos((float)(-var12[1] * (float) (Math.PI / 180.0)));
                        float var8 = MathHelper.sin((float)(-var12[1] * (float) (Math.PI / 180.0)));
                        Vec3d var7 = new Vec3d((double)(var10 * var9), (double)var8, (double)(var11 * var9));
                        Vec3d var6 = var38.add(var7.x * var21, var7.y * var21, var7.z * var21);
                        RayTraceResult var5 = mc.world.rayTraceBlocks(var38, var6, false, true, false);
                        if (!(this.placeWallsRange.getValue() >= this.placeRange.getValue())) {
                           if (var5 == null || var5.typeOfHit != Type.BLOCK) {
                              break label274;
                           }

                           if (!var5.getBlockPos().equals(var1)) {
                              var78 = false;
                              break label274;
                           }
                        }

                        if (this.strictDirection.getValue()) {
                           if (var30 != null && var31 != null && (var5 != null && var5.typeOfHit == Type.BLOCK || var2 == null)) {
                              if (!(
                                 mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var23)
                                    < mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var30)
                              )) {
                                 var78 = false;
                              } else {
                                 var30 = var23;
                                 var31 = var12;
                                 if (var5 != null) {
                                    if (var5.typeOfHit != Type.BLOCK) {
                                       var78 = false;
                                    } else {
                                       var2 = var5.sideHit;
                                       this.postResult = var5;
                                       var78 = false;
                                    }
                                 }
                              }
                           } else {
                              var30 = var23;
                              var31 = var12;
                              if (var5 != null) {
                                 if (var5.typeOfHit != Type.BLOCK) {
                                    var78 = false;
                                 } else {
                                    var2 = var5.sideHit;
                                    this.postResult = var5;
                                    var78 = false;
                                 }
                              }
                           }
                        } else if (var30 != null && var31 != null && (var5 != null && var5.typeOfHit == Type.BLOCK || var2 == null)) {
                           if (!(
                              Math.hypot(
                                    ((var12[0] - (double)((IEntityPlayerSP)mc.player).getLastReportedYaw()) % 360.0 + 540.0) % 360.0 - 180.0,
                                    var12[1] - (double)((IEntityPlayerSP)mc.player).getLastReportedPitch()
                                 )
                                 < Math.hypot(
                                    ((var31[0] - (double)((IEntityPlayerSP)mc.player).getLastReportedYaw()) % 360.0 + 540.0) % 360.0 - 180.0,
                                    var31[1] - (double)((IEntityPlayerSP)mc.player).getLastReportedPitch()
                                 )
                           )) {
                              var78 = false;
                           } else {
                              var30 = var23;
                              var31 = var12;
                              if (var5 != null) {
                                 if (var5.typeOfHit != Type.BLOCK) {
                                    var78 = false;
                                 } else {
                                    var2 = var5.sideHit;
                                    this.postResult = var5;
                                    var78 = false;
                                 }
                              }
                           }
                        } else {
                           var30 = var23;
                           var31 = var12;
                           if (var5 != null) {
                              if (var5.typeOfHit != Type.BLOCK) {
                                 var78 = false;
                              } else {
                                 var2 = var5.sideHit;
                                 this.postResult = var5;
                              }
                           }
                        }
                     }

                     var24 += var32;
                  }

                  var26 += var32;
               }

               var28 += var32;
            }

            if (this.placeWallsRange.getValue() < this.placeRange.getValue() && this.directionMode.getValue() == CrystalBot.DirectionMode.STRICT) {
               if (var31 != null && var2 != null) {
                  this.rotationTimer.reset();
                  var78 = false;
                  this.rotationVector = var30;
                  this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
                  return var2;
               }

               for(double var66 = var34; var66 <= var36; var78 = false) {
                  for(double var65 = var34; var65 <= var36; var78 = false) {
                     for(double var64 = var34; var64 <= var36; var78 = false) {
                        Vec3d var63 = new Vec3d(var1).add(var66, var65, var64);
                        double var62 = var38.distanceTo(var63);
                        double var61 = var63.x - var38.x;
                        double var60 = var63.y - var38.y;
                        double var59 = var63.z - var38.z;
                        double var58 = (double)MathHelper.sqrt(var61 * var61 + var59 * var59);
                        double[] var57 = new double[]{
                           (double)MathHelper.wrapDegrees((float)Math.toDegrees(Math.atan2(var59, var61)) - 90.0F),
                           (double)MathHelper.wrapDegrees((float)(-Math.toDegrees(Math.atan2(var60, var58))))
                        };
                        float var56 = MathHelper.cos((float)(-var57[0] * (float) (Math.PI / 180.0) - (float) Math.PI));
                        float var54 = MathHelper.sin((float)(-var57[0] * (float) (Math.PI / 180.0) - (float) Math.PI));
                        float var51 = -MathHelper.cos((float)(-var57[1] * (float) (Math.PI / 180.0)));
                        float var48 = MathHelper.sin((float)(-var57[1] * (float) (Math.PI / 180.0)));
                        Vec3d var45 = new Vec3d((double)(var54 * var51), (double)var48, (double)(var56 * var51));
                        Vec3d var42 = var38.add(var45.x * var62, var45.y * var62, var45.z * var62);
                        RayTraceResult var40 = mc.world.rayTraceBlocks(var38, var42, false, true, true);
                        if (var40 != null) {
                           if (var40.typeOfHit != Type.BLOCK) {
                              var78 = false;
                           } else if (this.strictDirection.getValue()) {
                              if (var30 != null && var31 != null && (var40.typeOfHit == Type.BLOCK || var2 == null)) {
                                 if (!(
                                    mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var63)
                                       < mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var30)
                                 )) {
                                    var78 = false;
                                 } else {
                                    var30 = var63;
                                    var31 = var57;
                                    if (var40.typeOfHit != Type.BLOCK) {
                                       var78 = false;
                                    } else {
                                       var2 = var40.sideHit;
                                       this.postResult = var40;
                                       var78 = false;
                                    }
                                 }
                              } else {
                                 var30 = var63;
                                 var31 = var57;
                                 if (var40.typeOfHit != Type.BLOCK) {
                                    var78 = false;
                                 } else {
                                    var2 = var40.sideHit;
                                    this.postResult = var40;
                                    var78 = false;
                                 }
                              }
                           } else if (var30 != null && var31 != null && (var40.typeOfHit == Type.BLOCK || var2 == null)) {
                              if (!(
                                 Math.hypot(
                                       ((var57[0] - (double)((IEntityPlayerSP)mc.player).getLastReportedYaw()) % 360.0 + 540.0) % 360.0 - 180.0,
                                       var57[1] - (double)((IEntityPlayerSP)mc.player).getLastReportedPitch()
                                    )
                                    < Math.hypot(
                                       ((var31[0] - (double)((IEntityPlayerSP)mc.player).getLastReportedYaw()) % 360.0 + 540.0) % 360.0 - 180.0,
                                       var31[1] - (double)((IEntityPlayerSP)mc.player).getLastReportedPitch()
                                    )
                              )) {
                                 var78 = false;
                              } else {
                                 var30 = var63;
                                 var31 = var57;
                                 if (var40.typeOfHit != Type.BLOCK) {
                                    var78 = false;
                                 } else {
                                    var2 = var40.sideHit;
                                    this.postResult = var40;
                                    var78 = false;
                                 }
                              }
                           } else {
                              var30 = var63;
                              var31 = var57;
                              if (var40.typeOfHit != Type.BLOCK) {
                                 var78 = false;
                              } else {
                                 var2 = var40.sideHit;
                                 this.postResult = var40;
                              }
                           }
                        }

                        var64 += var32;
                     }

                     var65 += var32;
                  }

                  var66 += var32;
               }
            } else {
               if (var31 != null) {
                  this.rotationTimer.reset();
                  var78 = false;
                  this.rotationVector = var30;
                  this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
               }

               if (var2 != null) {
                  return var2;
               }
            }

            var78 = false;
         } else {
            EnumFacing var4 = null;
            Vec3d var41 = null;

            for(EnumFacing var52 : EnumFacing.values()) {
               Vec3d var3 = new Vec3d(
                  (double)var1.getX() + 0.5 + (double)var52.getDirectionVec().getX() * 0.5,
                  (double)var1.getY() + 0.5 + (double)var52.getDirectionVec().getY() * 0.5,
                  (double)var1.getZ() + 0.5 + (double)var52.getDirectionVec().getZ() * 0.5
               );
               RayTraceResult var55 = mc.world
                  .rayTraceBlocks(new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ), var3, false, true, false);
               if (var55 != null && var55.typeOfHit.equals(Type.BLOCK)) {
                  if (!var55.getBlockPos().equals(var1)) {
                     boolean var95 = false;
                  } else {
                     if (!this.strictDirection.getValue()) {
                        this.rotationTimer.reset();
                        boolean var99 = false;
                        this.rotationVector = var3;
                        this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
                        return var52;
                     }

                     if (var41 != null
                        && !(
                           mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var3)
                              < mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var41)
                        )) {
                        boolean var97 = false;
                     } else {
                        var41 = var3;
                        var4 = var52;
                        this.postResult = var55;
                        boolean var96 = false;
                     }
                  }
               }

               boolean var98 = false;
            }

            if (var4 != null) {
               this.rotationTimer.reset();
               boolean var105 = false;
               this.rotationVector = var41;
               this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
               return var4;
            }

            if (this.strictDirection.getValue()) {
               for(EnumFacing var53 : EnumFacing.values()) {
                  Vec3d var39 = new Vec3d(
                     (double)var1.getX() + 0.5 + (double)var53.getDirectionVec().getX() * 0.5,
                     (double)var1.getY() + 0.5 + (double)var53.getDirectionVec().getY() * 0.5,
                     (double)var1.getZ() + 0.5 + (double)var53.getDirectionVec().getZ() * 0.5
                  );
                  if (var41 != null
                     && !(
                        mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var39)
                           < mc.player.getPositionVector().add(0.0, (double)mc.player.getEyeHeight(), 0.0).distanceTo(var41)
                     )) {
                     boolean var100 = false;
                  } else {
                     var41 = var39;
                     var4 = var53;
                  }

                  boolean var101 = false;
               }

               if (var4 != null) {
                  this.rotationTimer.reset();
                  boolean var104 = false;
                  this.rotationVector = var41;
                  this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
                  return var4;
               }
            }
         }

         if ((double)var1.getY() > mc.player.posY + (double)mc.player.getEyeHeight()) {
            this.rotationTimer.reset();
            boolean var103 = false;
            this.rotationVector = new Vec3d((double)var1.getX() + 0.5, (double)var1.getY() + 1.0, (double)var1.getZ() + 0.5);
            this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
            return EnumFacing.DOWN;
         } else {
            this.rotationTimer.reset();
            boolean var102 = false;
            this.rotationVector = new Vec3d((double)var1.getX() + 0.5, (double)var1.getY() + 1.0, (double)var1.getZ() + 0.5);
            this.rotations = RotationManager.calculateAngle(mc.player.getPositionEyes(1.0F), this.rotationVector);
            return EnumFacing.UP;
         }
      } else {
         return null;
      }
   }

   private boolean lambda$new$60(CrystalBot.TargetingMode var1) {
      boolean var10000;
      if (this.setting.getValue() == CrystalBot.Pages.Calculation) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean shouldArmorBreak(EntityPlayer var1) {
      if (!this.armorBreaker.getValue()) {
         return false;
      } else {
         for(int var2 = 3; var2 >= 0; --var2) {
            ItemStack var3 = (ItemStack)var1.inventory.armorInventory.get(var2);
            if (var3.getItem().getDurabilityForDisplay(var3) > (double)this.depletion.getValue().floatValue()) {
               return true;
            }

            boolean var10000 = false;
            var10000 = false;
         }

         return false;
      }
   }

   public static enum ACAntiWeakness {
      NORMAL,
      OFF,
      SILENT;
      private static final CrystalBot.ACAntiWeakness[] $VALUES = new CrystalBot.ACAntiWeakness[]{OFF, NORMAL, CrystalBot.ACAntiWeakness.SILENT};
   }

   public static enum ACSwapMode {
      SILENT,
      OFF,
      NORMAL;
      private static final CrystalBot.ACSwapMode[] $VALUES = new CrystalBot.ACSwapMode[]{OFF, CrystalBot.ACSwapMode.NORMAL, SILENT};
   }

   public static enum ConfirmMode {
      SEMI,
      FULL,
      OFF;
      private static final CrystalBot.ConfirmMode[] $VALUES = new CrystalBot.ConfirmMode[]{CrystalBot.ConfirmMode.OFF, SEMI, CrystalBot.ConfirmMode.FULL};
   }

   public static enum DirectionMode {
      NORMAL,
      STRICT,
      VANILLA;
      private static final CrystalBot.DirectionMode[] $VALUES = new CrystalBot.DirectionMode[]{
         CrystalBot.DirectionMode.VANILLA, CrystalBot.DirectionMode.NORMAL, CrystalBot.DirectionMode.STRICT
      };
   }

   private static class InstantThread implements Runnable {
      private static CrystalBot.InstantThread INSTANCE;
      private CrystalBot DeltaCrystal;

      @Override
      public void run() {
         if (CrystalBot.access$000(this.DeltaCrystal).get()) {
            label22: {
               try {
                  Thread.sleep((long)(CrystalBot.access$100() * 40.0F));
               } catch (InterruptedException var2) {
                  CrystalBot.access$200(this.DeltaCrystal).interrupt();
                  break label22;
               }

               boolean var10000 = false;
            }

            if (!CrystalBot.access$000(this.DeltaCrystal).get()) {
               return;
            }

            CrystalBot.access$000(this.DeltaCrystal).set(false);
            if (CrystalBot.access$300(this.DeltaCrystal).get()) {
               return;
            }

            CrystalBot.access$400(this.DeltaCrystal);
         }
      }

      static CrystalBot.InstantThread getInstance(CrystalBot var0) {
         if (INSTANCE == null) {
            INSTANCE = new CrystalBot.InstantThread();
            INSTANCE.DeltaCrystal = var0;
         }

         return INSTANCE;
      }
   }

   public static enum Pages {
      Place,
      Render,
      Calculation,
      Break,
      General;
      private static final CrystalBot.Pages[] $VALUES = new CrystalBot.Pages[]{
         CrystalBot.Pages.General, Place, CrystalBot.Pages.Break, CrystalBot.Pages.Calculation, Render
      };
   }

   public static enum RenderMode {
      STATIC,
      FADE,
      GLIDE;

      private static final CrystalBot.RenderMode[] $VALUES = new CrystalBot.RenderMode[]{STATIC, FADE, GLIDE};
   }

   private static enum RotationMode {
      TRACK,
      INTERACT,
      OFF;
      private static final CrystalBot.RotationMode[] $VALUES = new CrystalBot.RotationMode[]{
         CrystalBot.RotationMode.OFF, TRACK, CrystalBot.RotationMode.INTERACT
      };
   }

   public static enum SyncMode {
      STRICT,
      MERGE;
      private static final CrystalBot.SyncMode[] $VALUES = new CrystalBot.SyncMode[]{STRICT, CrystalBot.SyncMode.MERGE};
   }

   public static enum TargetRenderMode {
      JELLO,
      OLD,
      OFF;
      private static final CrystalBot.TargetRenderMode[] $VALUES = new CrystalBot.TargetRenderMode[]{
         CrystalBot.TargetRenderMode.OLD, CrystalBot.TargetRenderMode.JELLO, CrystalBot.TargetRenderMode.OFF
      };
   }

   private static enum TargetingMode {
      ALL,
      NEAREST,
      SMART;

      private static final CrystalBot.TargetingMode[] $VALUES = new CrystalBot.TargetingMode[]{ALL, SMART, NEAREST};
   }

   private static enum TimingMode {
      SEQUENTIAL,
      ADAPTIVE,
      VANILLA;
      private static final CrystalBot.TimingMode[] $VALUES = new CrystalBot.TimingMode[]{
         CrystalBot.TimingMode.SEQUENTIAL, CrystalBot.TimingMode.ADAPTIVE, CrystalBot.TimingMode.VANILLA
      };
   }

   private static enum YawStepMode {
      OFF,
      FULL,
      SEMI;

      private static final CrystalBot.YawStepMode[] $VALUES = new CrystalBot.YawStepMode[]{OFF, SEMI, FULL};
   }

   private static class currentPos {
      private float renderTime;
      private BlockPos renderBlock;

      public currentPos(BlockPos var1, float var2) {
         this.renderBlock = var1;
         this.renderTime = var2;
      }

      public float getRenderTime() {
         return this.renderTime;
      }

      public BlockPos renderBlock() {
         return this.renderBlock;
      }

      public void setPos(BlockPos var1) {
         this.renderBlock = var1;
      }

      public void setRenderTime(float var1) {
         this.renderTime = var1;
      }
   }
}
