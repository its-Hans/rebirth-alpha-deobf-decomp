package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

public class PacketExp extends Module {
   public final Setting<Bind> throwBind;
   public final Setting<Boolean> allowGui;
   public final Setting<Boolean> down;
   private final Setting<Integer> delay = this.add(new Setting<>("Delay", 1, 0, 5));
   private final Timer delayTimer;
   private final Setting<PacketExp.Mode> mode;
   public static PacketExp INSTANCE;
   public final Setting<Boolean> checkDura;

   public boolean isThrow() {
      if (this.isOff()) {
         return false;
      } else if (!this.allowGui.getValue() && mc.currentScreen != null) {
         return false;
      } else if (InventoryUtil.findHotbarClass(ItemExpBottle.class) == -1) {
         return false;
      } else {
         if (this.checkDura.getValue()) {
            ItemStack var1 = mc.player.inventoryContainer.getSlot(5).getStack();
            ItemStack var2 = mc.player.inventoryContainer.getSlot(6).getStack();
            ItemStack var3 = mc.player.inventoryContainer.getSlot(7).getStack();
            ItemStack var4 = mc.player.inventoryContainer.getSlot(8).getStack();
            if ((var1.isEmpty || EntityUtil.getDamagePercent(var1) >= 100)
               && (var2.isEmpty || EntityUtil.getDamagePercent(var2) >= 100)
               && (var3.isEmpty || EntityUtil.getDamagePercent(var3) >= 100)
               && (var4.isEmpty || EntityUtil.getDamagePercent(var4) >= 100)) {
               return false;
            }
         }

         if (this.mode.getValue() == PacketExp.Mode.Middle && Mouse.isButtonDown(2)) {
            return true;
         } else {
            boolean var10000;
            if (this.mode.getValue() == PacketExp.Mode.Key && this.throwBind.getValue().isDown()) {
               var10000 = true;
               boolean var10001 = false;
            } else {
               var10000 = false;
            }

            return var10000;
         }
      }
   }

   @Override
   public String getInfo() {
      return this.mode.getValue().name();
   }

   private boolean lambda$new$0(Bind var1) {
      boolean var10000;
      if (this.mode.getValue() == PacketExp.Mode.Key) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public PacketExp() {
      super("PacketExp", "Robot module", Category.COMBAT);
      this.down = this.add(new Setting<>("Down", true));
      this.allowGui = this.add(new Setting<>("allowGui", false));
      this.checkDura = this.add(new Setting<>("CheckDura", true));
      this.mode = this.add(new Setting<>("Mode", PacketExp.Mode.Key));
      this.throwBind = this.add(new Setting<>("ThrowBind", new Bind(-1), this::lambda$new$0));
      this.delayTimer = new Timer();
      INSTANCE = this;
   }

   @Override
   public void onTick() {
      if (this.isThrow() && this.delayTimer.passedMs((long)(this.delay.getValue() * 20))) {
         this.throwExp();
      }
   }

   public void throwExp() {
      int var1 = mc.player.inventory.currentItem;
      int var2 = InventoryUtil.findHotbarClass(ItemExpBottle.class);
      if (var2 != -1) {
         mc.player.connection.sendPacket(new CPacketHeldItemChange(var2));
         mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
         mc.player.connection.sendPacket(new CPacketHeldItemChange(var1));
         this.delayTimer.reset();
         boolean var10000 = false;
      }
   }

   @SubscribeEvent
   public void RotateEvent(MotionEvent var1) {
      if (!fullNullCheck()) {
         if (this.down.getValue()) {
            if (this.isThrow()) {
               var1.setPitch(90.0F);
            }
         }
      }
   }

   protected static enum Mode {
      Key,
      Middle;
      private static final PacketExp.Mode[] $VALUES = new PacketExp.Mode[]{PacketExp.Mode.Key, PacketExp.Mode.Middle};
   }
}
