package me.rebirthclient.mod.modules.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.MovementUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.movement.AutoCenter;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class Surround extends Module {
   private final Setting<Boolean> moveDisable;
   public final Setting<Float> safeHealth;
   private final Setting<Boolean> breakCrystal;
   private final Setting<Boolean> jumpDisable;
   private final Setting<Boolean> packet;
   private final Setting<Integer> multiPlace;
   private final Setting<Boolean> isMoving;
   private final Setting<Boolean> center;
   double startZ;
   private final Setting<Boolean> onlyGround;
   private final Setting<Integer> delay;
   BlockPos startPos;
   private final Setting<Boolean> inMoving;
   final Timer timer;
   public static Surround INSTANCE = new Surround();
   int progress;
   double startX;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> extend;
   private final Setting<Boolean> strictDisable;
   public final Setting<Boolean> enableInHole = this.add(new Setting<>("EnableInHole", false));
   double startY;

   private boolean isGod(BlockPos var1, EnumFacing var2) {
      if (mc.world.getBlockState(var1).getBlock() == Blocks.BEDROCK) {
         return true;
      } else {
         for(EnumFacing var6 : EnumFacing.VALUES) {
            if (var6 == var2.getOpposite()) {
               boolean var10000 = false;
            } else if (mc.world.getBlockState(var1.offset(var6)).getBlock() != Blocks.BEDROCK) {
               return false;
            }

            boolean var7 = false;
         }

         return true;
      }
   }

   static boolean checkSelf(BlockPos var0) {
      Entity var1 = null;

      for(Entity var3 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var0))) {
         if (var3 == mc.player) {
            if (var1 != null) {
               boolean var10000 = false;
            } else {
               var1 = var3;
               boolean var4 = false;
            }
         }
      }

      boolean var5;
      if (var1 != null) {
         var5 = true;
         boolean var10001 = false;
      } else {
         var5 = false;
      }

      return var5;
   }

   @Override
   public void onTick() {
      if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         this.progress = 0;
         BlockPos var1 = EntityUtil.getPlayerPos();
         if (this.startPos != null
            && (
               EntityUtil.getPlayerPos().equals(this.startPos)
                  || !this.moveDisable.getValue()
                  || !this.strictDisable.getValue()
                  || this.isMoving.getValue() && !MovementUtil.isMoving()
            )
            && (
               !(mc.player.getDistance(this.startX, this.startY, this.startZ) > 1.3)
                  || !this.moveDisable.getValue()
                  || this.strictDisable.getValue()
                  || this.isMoving.getValue() && !MovementUtil.isMoving()
            )
            && (
               !this.jumpDisable.getValue()
                  || !(this.startY - mc.player.posY > 0.5) && !(this.startY - mc.player.posY < -0.5)
                  || this.inMoving.getValue() && !MovementUtil.isMoving()
            )) {
            if (InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN) == -1) {
               this.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Obsidian?")));
               this.disable();
            } else if (!this.onlyGround.getValue() || mc.player.onGround) {
               for(EnumFacing var5 : EnumFacing.VALUES) {
                  if (var5 == EnumFacing.UP) {
                     boolean var22 = false;
                  } else if (this.isGod(var1.offset(var5), var5)) {
                     boolean var21 = false;
                  } else {
                     BlockPos var6 = var1.offset(var5);
                     if (BlockUtil.canPlaceEnum(var6)) {
                        this.placeBlock(var6);
                        boolean var10000 = false;
                     } else if (BlockUtil.canReplace(var6)) {
                        this.placeBlock(var6.down());
                     }

                     if (checkSelf(var6) && this.extend.getValue()) {
                        for(EnumFacing var10 : EnumFacing.VALUES) {
                           if (var10 == EnumFacing.UP) {
                              boolean var19 = false;
                           } else {
                              BlockPos var11 = var6.offset(var10);
                              if (checkSelf(var11)) {
                                 for(EnumFacing var15 : EnumFacing.VALUES) {
                                    if (var15 == EnumFacing.UP) {
                                       boolean var17 = false;
                                    } else {
                                       this.placeBlock(var11);
                                       BlockPos var16 = var11.offset(var15);
                                       BlockPos var10001;
                                       if (BlockUtil.canPlaceEnum(var16)) {
                                          var10001 = var16;
                                          boolean var10002 = false;
                                       } else {
                                          var10001 = var16.down();
                                       }

                                       this.placeBlock(var10001);
                                    }

                                    boolean var18 = false;
                                 }
                              }

                              BlockPos var24;
                              if (BlockUtil.canPlaceEnum(var11)) {
                                 var24 = var11;
                                 boolean var25 = false;
                              } else {
                                 var24 = var11.down();
                              }

                              this.placeBlock(var24);
                           }

                           boolean var20 = false;
                        }
                     }
                  }

                  boolean var23 = false;
               }
            }
         } else {
            this.disable();
         }
      }
   }

   private boolean lambda$new$3(Boolean var1) {
      return this.jumpDisable.isOpen();
   }

   @Override
   public void onEnable() {
      this.startPos = EntityUtil.getPlayerPos();
      this.startX = mc.player.posX;
      this.startY = mc.player.posY;
      this.startZ = mc.player.posZ;
      if (this.center.getValue() && InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN) != -1) {
         AutoCenter.INSTANCE.enable();
      }
   }

   private boolean lambda$new$0(Float var1) {
      return this.breakCrystal.isOpen();
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.moveDisable.isOpen();
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.moveDisable.isOpen();
   }

   public Surround() {
      super("Surround", "Surrounds you with Obsidian", Category.COMBAT);
      this.timer = new Timer();
      this.delay = this.add(new Setting<>("Delay", 50, 0, 500));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 8));
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.packet = this.add(new Setting<>("Packet", true));
      this.breakCrystal = this.add(new Setting<>("BreakCrystal", true).setParent());
      this.safeHealth = this.add(new Setting<>("SafeHealth", 16.0F, 0.0F, 36.0F, this::lambda$new$0));
      this.center = this.add(new Setting<>("Center", true));
      this.extend = this.add(new Setting<>("Extend", true));
      this.onlyGround = this.add(new Setting<>("OnlyGround", true));
      this.moveDisable = this.add(new Setting<>("MoveDisable", true).setParent());
      this.strictDisable = this.add(new Setting<>("StrictDisable", false, this::lambda$new$1));
      this.isMoving = this.add(new Setting<>("isMoving", true, this::lambda$new$2));
      this.jumpDisable = this.add(new Setting<>("JumpDisable", true).setParent());
      this.inMoving = this.add(new Setting<>("inMoving", true, this::lambda$new$3));
      this.startX = 0.0;
      this.startY = 0.0;
      this.startZ = 0.0;
      this.progress = 0;
      this.startPos = null;
      INSTANCE = this;
   }

   private void placeBlock(BlockPos var1) {
      if (BlockUtil.canPlace3(var1)) {
         if (this.breakCrystal.getValue() && EntityUtil.getHealth(mc.player) >= this.safeHealth.getValue() || BlockUtil.canPlace(var1)) {
            if (this.progress < this.multiPlace.getValue()) {
               int var2 = mc.player.inventory.currentItem;
               if (InventoryUtil.findHotbarClass(BlockObsidian.class) != -1) {
                  if (this.breakCrystal.getValue() && EntityUtil.getHealth(mc.player) >= this.safeHealth.getValue()) {
                     CombatUtil.attackCrystal(var1, this.rotate.getValue(), false);
                  }

                  InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockObsidian.class));
                  EnumHand var10001 = EnumHand.MAIN_HAND;
                  boolean var10002 = this.rotate.getValue();
                  boolean var10003 = this.packet.getValue();
                  boolean var10004;
                  if (this.breakCrystal.getValue() && EntityUtil.getHealth(mc.player) >= this.safeHealth.getValue()) {
                     var10004 = true;
                     boolean var10005 = false;
                  } else {
                     var10004 = false;
                  }

                  BlockUtil.placeBlock(var1, var10001, var10002, var10003, var10004, false);
                  InventoryUtil.doSwap(var2);
                  ++this.progress;
                  this.timer.reset();
                  boolean var10000 = false;
               }
            }
         }
      }
   }
}
