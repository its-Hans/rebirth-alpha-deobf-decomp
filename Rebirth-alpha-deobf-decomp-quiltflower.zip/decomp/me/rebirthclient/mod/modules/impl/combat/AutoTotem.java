package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.client.CPacketConfirmTransaction;

public class AutoTotem extends Module {
   private final Setting<Boolean> crystal;
   private final Setting<Float> health = this.add(new Setting<>("Health", 16.0F, 0.0F, 36.0F));
   private final Setting<Boolean> mainHand = this.add(new Setting<>("MainHand", false));

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (!this.mainHand.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      if (mc.player.getHealth() + mc.player.getAbsorptionAmount() > this.health.getValue()) {
         if (!mc.player.getHeldItemOffhand().getItem().equals(Items.END_CRYSTAL) && this.crystal.getValue() && !this.mainHand.getValue()) {
            int var3 = InventoryUtil.findItemInventorySlot(Items.END_CRYSTAL, true, true);
            if (var3 != -1) {
               boolean var5 = mc.player.getHeldItemOffhand().getItem().equals(Items.AIR);
               mc.playerController.windowClick(0, var3, 0, ClickType.PICKUP, mc.player);
               boolean var12 = false;
               mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);
               var12 = false;
               if (!var5) {
                  mc.playerController.windowClick(0, var3, 0, ClickType.PICKUP, mc.player);
                  var12 = false;
               }
            }
         }
      } else if (!mc.player.getHeldItemOffhand().getItem().equals(Items.TOTEM_OF_UNDYING)
         && !mc.player.getHeldItemMainhand().getItem().equals(Items.TOTEM_OF_UNDYING)) {
         int var1 = InventoryUtil.findItemInventorySlot(Items.TOTEM_OF_UNDYING, true, true);
         if (var1 != -1) {
            if (!this.mainHand.getValue()) {
               boolean var2 = mc.player.getHeldItemOffhand().getItem().equals(Items.AIR);
               mc.playerController.windowClick(0, var1, 0, ClickType.PICKUP, mc.player);
               boolean var10000 = false;
               mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);
               var10000 = false;
               if (!var2) {
                  mc.playerController.windowClick(0, var1, 0, ClickType.PICKUP, mc.player);
                  var10000 = false;
               }

               var10000 = false;
            } else {
               InventoryUtil.switchToHotbarSlot(0, false);
               if (mc.player.inventory.getStackInSlot(0).getItem().equals(Items.TOTEM_OF_UNDYING)) {
                  return;
               }

               boolean var4 = mc.player.getHeldItemMainhand().getItem().equals(Items.AIR);
               mc.playerController.windowClick(0, var1, 0, ClickType.PICKUP, mc.player);
               boolean var9 = false;
               mc.playerController.windowClick(0, 36, 0, ClickType.PICKUP, mc.player);
               var9 = false;
               if (!var4) {
                  mc.playerController.windowClick(0, var1, 0, ClickType.PICKUP, mc.player);
                  var9 = false;
               }
            }

            mc.player
               .connection
               .sendPacket(
                  new CPacketConfirmTransaction(mc.player.inventoryContainer.windowId, mc.player.openContainer.getNextTransactionID(mc.player.inventory), true)
               );
         }
      }
   }

   public AutoTotem() {
      super("AutoTotem", "AutoTotem", Category.COMBAT);
      this.crystal = this.add(new Setting<>("Crystal", true, this::lambda$new$0));
   }
}
