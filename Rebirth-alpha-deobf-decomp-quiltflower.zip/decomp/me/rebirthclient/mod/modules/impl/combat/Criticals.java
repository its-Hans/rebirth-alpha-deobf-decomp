package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockWeb;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Criticals extends Module {
   private final Timer delayTimer;
   private final Setting<Boolean> onlySword;
   private final Setting<Boolean> webs;
   private final Setting<Boolean> onlyAura;
   private final Setting<Integer> delay;
   private final Setting<Criticals.Mode> mode = this.add(new Setting<>("Mode", Criticals.Mode.PACKET));
   public static Criticals INSTANCE;

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == Criticals.Mode.NCP) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      String var10000;
      if (this.mode.getValue() == Criticals.Mode.NCP) {
         var10000 = String.valueOf(this.mode.getValue());
         boolean var10001 = false;
      } else {
         var10000 = Managers.TEXT.normalizeCases(this.mode.getValue());
      }

      return var10000;
   }

   public Criticals() {
      super("Criticals", "Always do as much damage as you can!", Category.COMBAT);
      this.webs = this.add(new Setting<>("Webs", false, this::lambda$new$0));
      this.onlyAura = this.add(new Setting<>("OnlyAura", false));
      this.onlySword = this.add(new Setting<>("OnlySword", true));
      this.delay = this.add(new Setting<>("Delay", 100, 0, 1000));
      this.delayTimer = new Timer();
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            if (Aura.target != null || !this.onlyAura.getValue()) {
               if (!this.onlySword.getValue() || mc.player.getHeldItemMainhand().item instanceof ItemSword) {
                  if (this.delayTimer.passedMs((long)this.delay.getValue().intValue())) {
                     if (var1.getPacket() instanceof CPacketUseEntity
                        && ((CPacketUseEntity)var1.getPacket()).getAction() == Action.ATTACK
                        && mc.player.onGround
                        && mc.player.collidedVertically
                        && !mc.player.isInLava()
                        && !mc.player.isInWater()) {
                        Entity var2 = ((CPacketUseEntity)var1.getPacket()).getEntityFromWorld(mc.world);
                        if (var2 instanceof EntityEnderCrystal || var2 == null) {
                           return;
                        }

                        this.delayTimer.reset();
                        boolean var10000 = false;
                        switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$combat$Criticals$Mode[this.mode.getValue().ordinal()]) {
                           case 1:
                              mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.0625101, mc.player.posZ, false));
                              mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                              mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.0125, mc.player.posZ, false));
                              mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                              var10000 = false;
                              break;
                           case 2:
                              if (this.webs.getValue() && mc.world.getBlockState(new BlockPos(mc.player)).getBlock() instanceof BlockWeb) {
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.0625101, mc.player.posZ, false));
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.0125, mc.player.posZ, false));
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                                 var10000 = false;
                              } else {
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.11, mc.player.posZ, false));
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.1100013579, mc.player.posZ, false));
                                 mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 1.3579E-6, mc.player.posZ, false));
                              }
                        }

                        mc.player.onCriticalHit(var2);
                     }
                  }
               }
            }
         }
      }
   }

   private static enum Mode {
      PACKET,
      NCP;

      private static final Criticals.Mode[] $VALUES = new Criticals.Mode[]{PACKET, NCP};
   }
}
