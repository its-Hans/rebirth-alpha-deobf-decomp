package me.rebirthclient.mod.modules.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Burrow extends Module {
   private final Setting<Boolean> placeDisable = this.add(new Setting<>("PlaceDisable", false));
   private final Setting<Double> offsetY;
   private final Timer timedOut;
   private final Setting<Boolean> wait = this.add(new Setting<>("Wait", true));
   private final Setting<Boolean> aboveHead;
   public final Setting<Float> safeHealth;
   private final Setting<Double> offsetX;
   public static Burrow INSTANCE;
   private final Setting<Boolean> airCheck;
   private final Setting<Double> offsetZ;
   private final Setting<Boolean> smartOffset;
   private boolean shouldWait;
   private final Setting<Boolean> debug;
   private final Setting<Boolean> switchBypass = this.add(new Setting<>("SwitchBypass", true));
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private final Setting<Boolean> onlyGround = this.add(new Setting<>("OnlyGround", true).setParent());
   private final Setting<Integer> timeOut;
   private final Setting<Integer> multiPlace;
   int progress;
   private final Setting<Integer> delay;
   private final Timer timer;
   private final Setting<Boolean> breakCrystal;
   private final Setting<Boolean> center;

   @Override
   public void onUpdate() {
      this.progress = 0;
      int var1;
      if (!this.switchBypass.getValue()) {
         if (InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN)) != -1) {
            var1 = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.OBSIDIAN));
            boolean var10000 = false;
         } else {
            var1 = InventoryUtil.getItemHotbar(Item.getItemFromBlock(Blocks.ENDER_CHEST));
            boolean var27 = false;
         }
      } else if (InventoryUtil.findItemInventorySlot(Item.getItemFromBlock(Blocks.OBSIDIAN), false, true) != -1) {
         var1 = InventoryUtil.findItemInventorySlot(Item.getItemFromBlock(Blocks.OBSIDIAN), false, true);
         boolean var28 = false;
      } else {
         var1 = InventoryUtil.findItemInventorySlot(Item.getItemFromBlock(Blocks.ENDER_CHEST), false, true);
      }

      if (var1 == -1) {
         this.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Obsidian/Ender Chest ?")));
         this.disable();
      } else if (this.timedOut.passedMs((long)this.timeOut.getValue().intValue())) {
         this.disable();
      } else {
         BlockPos var2 = EntityUtil.getPlayerPos();
         if (!this.canPlace(new BlockPos(mc.player.posX + 0.3, mc.player.posY + 0.5, mc.player.posZ + 0.3))
            && !this.canPlace(new BlockPos(mc.player.posX - 0.3, mc.player.posY + 0.5, mc.player.posZ + 0.3))
            && !this.canPlace(new BlockPos(mc.player.posX + 0.3, mc.player.posY + 0.5, mc.player.posZ - 0.3))
            && !this.canPlace(new BlockPos(mc.player.posX - 0.3, mc.player.posY + 0.5, mc.player.posZ - 0.3))) {
            if (this.debug.getValue()) {
               this.sendMessage("cant place");
            }

            if (!this.shouldWait) {
               this.disable();
            }
         } else if (!mc.player.isInLava() && !mc.player.isInWater() && !mc.player.isInWeb) {
            if (this.onlyGround.getValue()) {
               if (!mc.player.onGround) {
                  if (this.debug.getValue()) {
                     this.sendMessage("player not on ground");
                  }

                  return;
               }

               if (this.airCheck.getValue() && isAir(EntityUtil.getPlayerPos().down())) {
                  if (this.debug.getValue()) {
                     this.sendMessage("player in air");
                  }

                  return;
               }
            }

            if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
               if (this.breakCrystal.getValue() && EntityUtil.getHealth(mc.player) >= this.safeHealth.getValue()) {
                  if (this.debug.getValue()) {
                     this.sendMessage("try break crystal");
                  }

                  CombatUtil.attackCrystal(var2, this.rotate.getValue(), false);
                  CombatUtil.attackCrystal(new BlockPos(mc.player.posX + 0.3, mc.player.posY + 0.5, mc.player.posZ + 0.3), this.rotate.getValue(), false);
                  CombatUtil.attackCrystal(new BlockPos(mc.player.posX + 0.3, mc.player.posY + 0.5, mc.player.posZ - 0.3), this.rotate.getValue(), false);
                  CombatUtil.attackCrystal(new BlockPos(mc.player.posX - 0.3, mc.player.posY + 0.5, mc.player.posZ + 0.3), this.rotate.getValue(), false);
                  CombatUtil.attackCrystal(new BlockPos(mc.player.posX - 0.3, mc.player.posY + 0.5, mc.player.posZ - 0.3), this.rotate.getValue(), false);
               }

               this.timer.reset();
               this.shouldWait = false;
               BlockPos var3 = EntityUtil.getPlayerPos().up(2);
               if (!Trapped(var3)
                  && !Trapped(var3.add(1, 0, 0))
                  && !Trapped(var3.add(-1, 0, 0))
                  && !Trapped(var3.add(0, 0, 1))
                  && !Trapped(var3.add(0, 0, -1))
                  && !Trapped(var3.add(1, 0, -1))
                  && !Trapped(var3.add(-1, 0, -1))
                  && !Trapped(var3.add(1, 0, 1))
                  && !Trapped(var3.add(-1, 0, 1))) {
                  if (this.debug.getValue()) {
                     this.sendMessage("fake jump");
                  }

                  mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.4199999868869781, mc.player.posZ, false));
                  mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.7531999805212017, mc.player.posZ, false));
                  mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 0.9999957640154541, mc.player.posZ, false));
                  mc.player.connection.sendPacket(new Position(mc.player.posX, mc.player.posY + 1.1661092609382138, mc.player.posZ, false));
               } else {
                  if (!this.aboveHead.getValue()) {
                     if (!this.shouldWait) {
                        this.disable();
                     }

                     return;
                  }

                  boolean var4 = false;
                  if (checkSelf(var2) && !canReplace(var2)) {
                     this.gotoPos(var2);
                     if (this.debug.getValue()) {
                        this.sendMessage(
                           String.valueOf(
                              new StringBuilder()
                                 .append("moved to center ")
                                 .append((double)var2.getX() + 0.5 - mc.player.posX)
                                 .append(" ")
                                 .append((double)var2.getZ() + 0.5 - mc.player.posZ)
                           )
                        );
                        boolean var38 = false;
                     }
                  } else {
                     for(EnumFacing var9 : EnumFacing.VALUES) {
                        if (var9 != EnumFacing.UP) {
                           if (var9 == EnumFacing.DOWN) {
                              boolean var29 = false;
                           } else {
                              BlockPos var5 = var2.offset(var9);
                              if (checkSelf(var5) && !canReplace(var5)) {
                                 this.gotoPos(var5);
                                 var4 = true;
                                 if (this.debug.getValue()) {
                                    this.sendMessage(
                                       String.valueOf(
                                          new StringBuilder()
                                             .append("moved to block ")
                                             .append((double)var5.getX() + 0.5 - mc.player.posX)
                                             .append(" ")
                                             .append((double)var5.getZ() + 0.5 - mc.player.posZ)
                                       )
                                    );
                                    boolean var31 = false;
                                 }
                                 break;
                              }
                           }
                        }

                        boolean var30 = false;
                     }

                     if (!var4) {
                        for(EnumFacing var23 : EnumFacing.VALUES) {
                           if (var23 != EnumFacing.UP) {
                              if (var23 == EnumFacing.DOWN) {
                                 boolean var32 = false;
                              } else {
                                 BlockPos var11 = var2.offset(var23);
                                 if (checkSelf(var11)) {
                                    this.gotoPos(var11);
                                    var4 = true;
                                    if (this.debug.getValue()) {
                                       this.sendMessage(
                                          String.valueOf(
                                             new StringBuilder()
                                                .append("moved to entity ")
                                                .append((double)var11.getX() + 0.5 - mc.player.posX)
                                                .append(" ")
                                                .append((double)var11.getZ() + 0.5 - mc.player.posZ)
                                          )
                                       );
                                       boolean var34 = false;
                                    }
                                    break;
                                 }
                              }
                           }

                           boolean var33 = false;
                        }

                        if (!var4) {
                           if (!this.center.getValue()) {
                              if (!this.shouldWait) {
                                 this.disable();
                              }

                              return;
                           }

                           for(EnumFacing var24 : EnumFacing.VALUES) {
                              if (var24 != EnumFacing.UP) {
                                 if (var24 == EnumFacing.DOWN) {
                                    boolean var35 = false;
                                 } else {
                                    BlockPos var12 = var2.offset(var24);
                                    if (canReplace(var12) && canReplace(var12.up())) {
                                       this.gotoPos(var12);
                                       if (this.debug.getValue()) {
                                          this.sendMessage(
                                             String.valueOf(
                                                new StringBuilder()
                                                   .append("moved to air ")
                                                   .append((double)var12.getX() + 0.5 - mc.player.posX)
                                                   .append(" ")
                                                   .append((double)var12.getZ() + 0.5 - mc.player.posZ)
                                             )
                                          );
                                       }

                                       var4 = true;
                                       boolean var37 = false;
                                       break;
                                    }
                                 }
                              }

                              boolean var36 = false;
                           }

                           if (!var4) {
                              if (!this.shouldWait) {
                                 this.disable();
                              }

                              return;
                           }
                        }
                     }
                  }

                  boolean var39 = false;
               }

               int var10 = mc.player.inventory.currentItem;
               if (!this.switchBypass.getValue()) {
                  InventoryUtil.doSwap(var1);
                  boolean var40 = false;
               } else {
                  mc.playerController.windowClick(0, var1, var10, ClickType.SWAP, mc.player);
                  boolean var41 = false;
               }

               this.placeBlock(var2);
               this.placeBlock(new BlockPos(mc.player.posX + 0.3, mc.player.posY + 0.5, mc.player.posZ + 0.3));
               this.placeBlock(new BlockPos(mc.player.posX + 0.3, mc.player.posY + 0.5, mc.player.posZ - 0.3));
               this.placeBlock(new BlockPos(mc.player.posX - 0.3, mc.player.posY + 0.5, mc.player.posZ + 0.3));
               this.placeBlock(new BlockPos(mc.player.posX - 0.3, mc.player.posY + 0.5, mc.player.posZ - 0.3));
               if (!this.switchBypass.getValue()) {
                  InventoryUtil.doSwap(var10);
                  boolean var42 = false;
               } else {
                  mc.playerController.windowClick(0, var1, var10, ClickType.SWAP, mc.player);
                  boolean var43 = false;
               }

               if (this.smartOffset.getValue()) {
                  double var13 = 0.0;
                  BlockPos var18 = null;

                  for(BlockPos var25 : BlockUtil.getBox(6.0F)) {
                     if (this.canGoto(var25)) {
                        if (mc.player.getDistance((double)var25.getX() + 0.5, (double)var25.getY() + 0.5, (double)var25.getZ() + 0.5) <= 3.0) {
                           boolean var44 = false;
                        } else {
                           if (var18 == null
                              || mc.player.getDistance((double)var25.getX() + 0.5, (double)var25.getY() + 0.5, (double)var25.getZ() + 0.5) < var13) {
                              var18 = var25;
                              var13 = mc.player.getDistance((double)var25.getX() + 0.5, (double)var25.getY() + 0.5, (double)var25.getZ() + 0.5);
                           }

                           boolean var45 = false;
                        }
                     }
                  }

                  if (var18 != null) {
                     mc.player.connection.sendPacket(new Position((double)var18.getX() + 0.5, (double)var18.getY(), (double)var18.getZ() + 0.5, false));
                     boolean var49 = false;
                  } else {
                     for(BlockPos var26 : BlockUtil.getBox(6.0F)) {
                        if (this.canGoto(var26)) {
                           if (mc.player.getDistance((double)var26.getX() + 0.5, (double)var26.getY() + 0.5, (double)var26.getZ() + 0.5) <= 2.0) {
                              boolean var46 = false;
                           } else {
                              if (var18 == null
                                 || mc.player.getDistance((double)var26.getX() + 0.5, (double)var26.getY() + 0.5, (double)var26.getZ() + 0.5) < var13) {
                                 var18 = var26;
                                 var13 = mc.player.getDistance((double)var26.getX() + 0.5, (double)var26.getY() + 0.5, (double)var26.getZ() + 0.5);
                              }

                              boolean var47 = false;
                           }
                        }
                     }

                     if (var18 != null) {
                        mc.player.connection.sendPacket(new Position((double)var18.getX() + 0.5, (double)var18.getY(), (double)var18.getZ() + 0.5, false));
                        boolean var48 = false;
                     } else {
                        mc.player.connection.sendPacket(new Position(mc.player.posX, -7.0, mc.player.posZ, false));
                     }
                  }

                  boolean var50 = false;
               } else {
                  mc.player
                     .connection
                     .sendPacket(
                        new Position(
                           mc.player.posX + this.offsetX.getValue(), mc.player.posY + this.offsetY.getValue(), mc.player.posZ + this.offsetZ.getValue(), false
                        )
                     );
               }

               if (this.placeDisable.getValue()) {
                  this.disable();
               }
            }
         } else {
            if (this.debug.getValue()) {
               this.sendMessage("player stuck");
            }
         }
      }
   }

   private static boolean isAir(BlockPos var0) {
      return mc.world.isAirBlock(var0);
   }

   private boolean lambda$new$3(Double var1) {
      boolean var10000;
      if (!this.smartOffset.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Float var1) {
      return this.breakCrystal.isOpen();
   }

   private boolean canGoto(BlockPos var1) {
      boolean var10000;
      if (isAir(var1) && isAir(var1.up())) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.onlyGround.isOpen();
   }

   private boolean lambda$new$4(Double var1) {
      boolean var10000;
      if (!this.smartOffset.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Double var1) {
      boolean var10000;
      if (!this.smartOffset.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.aboveHead.isOpen();
   }

   private void gotoPos(BlockPos var1) {
      if (Math.abs((double)var1.getX() + 0.5 - mc.player.posX) < Math.abs((double)var1.getZ() + 0.5 - mc.player.posZ)) {
         mc.player
            .connection
            .sendPacket(new Position(mc.player.posX, mc.player.posY + 0.2, mc.player.posZ + ((double)var1.getZ() + 0.5 - mc.player.posZ), true));
         boolean var10000 = false;
      } else {
         mc.player
            .connection
            .sendPacket(new Position(mc.player.posX + ((double)var1.getX() + 0.5 - mc.player.posX), mc.player.posY + 0.2, mc.player.posZ, true));
      }
   }

   private static boolean checkSelf(BlockPos var0) {
      Vec3d[] var1 = EntityUtil.getVarOffsets(0, 0, 0);

      for(Vec3d var5 : var1) {
         BlockPos var6 = new BlockPos(var0).add(var5.x, var5.y, var5.z);

         for(Entity var8 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var6))) {
            if (var8 == mc.player) {
               return true;
            }

            boolean var10000 = false;
         }

         boolean var9 = false;
      }

      return false;
   }

   @Override
   public void onEnable() {
      this.timedOut.reset();
      boolean var10000 = false;
      this.shouldWait = this.wait.getValue();
   }

   public Burrow() {
      super("Burrow", "unknown", Category.COMBAT);
      this.airCheck = this.add(new Setting<>("AirCheck", true, this::lambda$new$0));
      this.aboveHead = this.add(new Setting<>("AboveHead", true).setParent());
      this.center = this.add(new Setting<>("Center", false, this::lambda$new$1));
      this.breakCrystal = this.add(new Setting<>("BreakCrystal", true).setParent());
      this.safeHealth = this.add(new Setting<>("SafeHealth", 16.0F, 0.0F, 36.0F, this::lambda$new$2));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 4));
      this.timeOut = this.add(new Setting<>("TimeOut", 500, 0, 2000));
      this.delay = this.add(new Setting<>("delay", 300, 0, 1000));
      this.smartOffset = this.add(new Setting<>("SmartOffset", true));
      this.offsetX = this.add(new Setting<>("OffsetX", -7.0, -14.0, 14.0, this::lambda$new$3));
      this.offsetY = this.add(new Setting<>("OffsetY", -7.0, -14.0, 14.0, this::lambda$new$4));
      this.offsetZ = this.add(new Setting<>("OffsetZ", -7.0, -14.0, 14.0, this::lambda$new$5));
      this.debug = this.add(new Setting<>("Debug", false));
      this.progress = 0;
      this.timer = new Timer();
      this.timedOut = new Timer();
      this.shouldWait = false;
      INSTANCE = this;
   }

   public static boolean canReplace(BlockPos var0) {
      return mc.world.getBlockState(var0).getMaterial().isReplaceable();
   }

   private boolean checkEntity(BlockPos var1) {
      for(Entity var3 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var1))) {
         if (!var3.isDead && !(var3 instanceof EntityItem) && !(var3 instanceof EntityXPOrb) && !(var3 instanceof EntityExpBottle)) {
            if (!(var3 instanceof EntityArrow)) {
               if (var3 instanceof EntityEnderCrystal) {
                  if (!this.breakCrystal.getValue() || EntityUtil.getHealth(mc.player) < this.safeHealth.getValue()) {
                     return true;
                  }
               } else if (var3 != mc.player) {
                  return true;
               }

               boolean var4 = false;
            } else {
               boolean var10000 = false;
            }
         }
      }

      return false;
   }

   @Override
   public void onDisable() {
      this.timer.reset();
      this.shouldWait = false;
   }

   private boolean canPlace(BlockPos var1) {
      if (!BlockUtil.canBlockFacing(var1)) {
         return false;
      } else if (!canReplace(var1)) {
         return false;
      } else {
         boolean var10000;
         if (!this.checkEntity(var1)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private void placeBlock(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (this.canPlace(var1)) {
            BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), true, this.breakCrystal.getValue(), false);
            ++this.progress;
         }
      }
   }

   private static boolean Trapped(BlockPos var0) {
      boolean var10000;
      if (!mc.world.isAirBlock(var0) && checkSelf(var0.down(2))) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }
}
