package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class AutoCity extends Module {
   public static EntityPlayer target;
   private final Setting<Float> range;
   public final Setting<Boolean> burrow = this.add(new Setting<>("MineBurrow", true));
   private final Setting<Boolean> keyMode;
   private final Setting<Bind> keyBind;
   private final Setting<Boolean> toggle;

   private boolean lambda$new$0(Bind var1) {
      return this.keyMode.getValue();
   }

   private boolean canAttack(EntityPlayer var1) {
      if (this.getBlock(new BlockPos(var1.posX + 1.2, var1.posY, var1.posZ)) == Blocks.AIR) {
         boolean var10000 = true;
         boolean var10001 = false;
      } else {
         boolean var2 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX + 1.2, var1.posY + 1.0, var1.posZ)) == Blocks.AIR) {
         boolean var29 = true;
         boolean var10002 = false;
      } else {
         boolean var30 = false;
      }

      boolean var3 = false;
      if (this.getBlock(new BlockPos(var1.posX - 1.2, var1.posY, var1.posZ)) == Blocks.AIR) {
         var3 = true;
         boolean var31 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX - 1.2, var1.posY + 1.0, var1.posZ)) == Blocks.AIR) {
         boolean var32 = true;
         boolean var60 = false;
      } else {
         boolean var33 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX, var1.posY, var1.posZ + 1.2)) == Blocks.AIR) {
         var3 = true;
         boolean var34 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX, var1.posY + 1.0, var1.posZ + 1.2)) == Blocks.AIR) {
         boolean var35 = true;
         boolean var61 = false;
      } else {
         boolean var36 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX, var1.posY, var1.posZ - 1.2)) == Blocks.AIR) {
         var3 = true;
         boolean var37 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX, var1.posY + 1.0, var1.posZ - 1.2)) == Blocks.AIR) {
         boolean var38 = true;
         boolean var62 = false;
      } else {
         boolean var39 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX + 2.2, var1.posY + 1.0, var1.posZ)) == Blocks.AIR) {
         var3 = true;
         boolean var40 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX + 2.2, var1.posY, var1.posZ)) == Blocks.AIR) {
         boolean var41 = true;
         boolean var63 = false;
      } else {
         boolean var42 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX + 1.2, var1.posY, var1.posZ)) == Blocks.AIR) {
         boolean var43 = true;
         boolean var64 = false;
      } else {
         boolean var44 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX - 2.2, var1.posY + 1.0, var1.posZ)) == Blocks.AIR) {
         var3 = true;
         boolean var45 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX - 2.2, var1.posY, var1.posZ)) == Blocks.AIR) {
         boolean var46 = true;
         boolean var65 = false;
      } else {
         boolean var47 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX - 1.2, var1.posY, var1.posZ)) == Blocks.AIR) {
         boolean var48 = true;
         boolean var66 = false;
      } else {
         boolean var49 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX, var1.posY + 1.0, var1.posZ + 2.2)) == Blocks.AIR) {
         var3 = true;
         boolean var50 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX, var1.posY, var1.posZ + 2.2)) == Blocks.AIR) {
         boolean var51 = true;
         boolean var67 = false;
      } else {
         boolean var52 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX, var1.posY, var1.posZ + 1.2)) == Blocks.AIR) {
         boolean var53 = true;
         boolean var68 = false;
      } else {
         boolean var54 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX, var1.posY + 1.0, var1.posZ - 2.2)) == Blocks.AIR) {
         var3 = true;
         boolean var55 = false;
      } else {
         var3 = false;
      }

      if (this.getBlock(new BlockPos(var1.posX, var1.posY, var1.posZ - 2.2)) == Blocks.AIR) {
         boolean var56 = true;
         boolean var69 = false;
      } else {
         boolean var57 = false;
      }

      var3 = false;
      if (this.getBlock(new BlockPos(var1.posX, var1.posY, var1.posZ - 1.2)) == Blocks.AIR) {
         boolean var58 = true;
         boolean var70 = false;
      } else {
         boolean var59 = false;
      }

      var3 = false;
      return false;
   }

   @Override
   public String getInfo() {
      return target != null ? target.getName() : null;
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (!this.keyMode.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public AutoCity() {
      super("AutoCity", "Automatically break the enemy's surround", Category.COMBAT);
      this.range = this.add(new Setting<>("Range", 5.0F, 1.0F, 8.0F));
      this.keyMode = this.add(new Setting<>("KeyMode", true));
      this.keyBind = this.add(new Setting<>("Enable", new Bind(-1), this::lambda$new$0));
      this.toggle = this.add(new Setting<>("Toggle", false, this::lambda$new$1));
   }

   private void mineBlock(BlockPos var1) {
      CombatUtil.mineBlock(var1);
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   @Override
   public void onUpdate() {
      if (!this.keyMode.getValue() || this.keyBind.getValue().isDown()) {
         target = CombatUtil.getTarget((double)this.range.getValue().floatValue(), 10.0);
         if (target != null) {
            BlockPos var1 = new BlockPos(target.posX, target.posY + 0.5, target.posZ);
            if (!mc.world.isAirBlock(var1) && this.burrow.getValue()) {
               this.mineBlock(var1);
               boolean var36 = false;
            } else if (!mc.world.isAirBlock(new BlockPos(target.posX + 0.3, target.posY + 0.5, target.posZ + 0.3)) && this.burrow.getValue()) {
               this.mineBlock(new BlockPos(target.posX + 0.3, target.posY + 0.5, target.posZ + 0.3));
               boolean var35 = false;
            } else if (!mc.world.isAirBlock(new BlockPos(target.posX + 0.3, target.posY + 0.5, target.posZ + 0.3)) && this.burrow.getValue()) {
               this.mineBlock(new BlockPos(target.posX + 0.3, target.posY + 0.5, target.posZ - 0.3));
               boolean var34 = false;
            } else if (!mc.world.isAirBlock(new BlockPos(target.posX + 0.3, target.posY + 0.5, target.posZ + 0.3)) && this.burrow.getValue()) {
               this.mineBlock(new BlockPos(target.posX - 0.3, target.posY + 0.5, target.posZ + 0.3));
               boolean var33 = false;
            } else if (!mc.world.isAirBlock(new BlockPos(target.posX + 0.3, target.posY + 0.5, target.posZ + 0.3)) && this.burrow.getValue()) {
               this.mineBlock(new BlockPos(target.posX - 0.3, target.posY + 0.5, target.posZ - 0.3));
               boolean var32 = false;
            } else if (!this.canAttack(target)) {
               if (this.getBlock(var1.add(0, 1, 2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, 1));
                  boolean var31 = false;
               } else if (this.getBlock(var1.add(0, 1, -2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, -1));
                  boolean var30 = false;
               } else if (this.getBlock(var1.add(2, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(2, 0, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(1, 0, 0));
                  boolean var29 = false;
               } else if (this.getBlock(var1.add(-2, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-2, 0, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-1, 0, 0));
                  boolean var28 = false;
               } else if (this.getBlock(var1.add(2, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(2, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(2, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(2, 0, 0));
                  boolean var27 = false;
               } else if (this.getBlock(var1.add(-2, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-2, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-2, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-2, 0, 0));
                  boolean var26 = false;
               } else if (this.getBlock(var1.add(0, 1, -2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -2)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, -2)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, -2));
                  boolean var25 = false;
               } else if (this.getBlock(var1.add(0, 1, 2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 2)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, 2)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, 2));
                  boolean var24 = false;
               } else if (this.getBlock(var1.add(2, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(2, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(2, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(2, 0, 0));
                  boolean var23 = false;
               } else if (this.getBlock(var1.add(-2, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-2, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-2, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-2, 0, 0));
                  boolean var22 = false;
               } else if (this.getBlock(var1.add(0, 1, -2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -2)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, -2)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, -2));
                  boolean var21 = false;
               } else if (this.getBlock(var1.add(0, 1, 2)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 2)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, 2)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, 2));
                  boolean var20 = false;
               } else if (this.getBlock(var1.add(0, 2, 1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 1, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 1, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, 1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 1, 1));
                  boolean var19 = false;
               } else if (this.getBlock(var1.add(0, 2, 1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 1, 1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, 1));
                  boolean var18 = false;
               } else if (this.getBlock(var1.add(0, 2, -1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 1, -1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 0, -1));
                  boolean var17 = false;
               } else if (this.getBlock(var1.add(1, 2, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(1, 0, 0));
                  boolean var16 = false;
               } else if (this.getBlock(var1.add(-1, 2, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 1, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-1, 0, 0));
                  boolean var15 = false;
               } else if (this.getBlock(var1.add(1, 2, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 1, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 1, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(1, 1, 0));
                  boolean var14 = false;
               } else if (this.getBlock(var1.add(-1, 2, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 1, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 1, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-1, 1, 0));
                  boolean var13 = false;
               } else if (this.getBlock(var1.add(0, 2, -1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 1, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 1, -1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 1, -1));
                  boolean var12 = false;
               } else if (this.getBlock(var1.add(1, 2, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 1, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(1, 1, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(1, 1, 0));
                  boolean var11 = false;
               } else if (this.getBlock(var1.add(-1, 2, 0)) == Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 1, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-1, 1, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-1, 1, 0));
                  boolean var10 = false;
               } else if (this.getBlock(var1.add(0, 2, -1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 1, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, -1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 1, -1));
                  boolean var9 = false;
               } else if (this.getBlock(var1.add(0, 2, 1)) == Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 1, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, 1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 1, 1));
                  boolean var8 = false;
               } else if (this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-2, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-2, 1, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-2, 1, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-2, 1, 0));
                  boolean var7 = false;
               } else if (this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(2, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(2, 1, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(2, 1, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(2, 1, 0));
                  boolean var6 = false;
               } else if (this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, 2)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, 2)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 1, 2)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 1, 2));
                  boolean var5 = false;
               } else if (this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 0, -2)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, -2)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 1, -2)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 1, -2));
                  boolean var4 = false;
               } else if (this.getBlock(var1.add(-1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-1, 1, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(-1, 2, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(-1, 2, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(-1, 2, 0));
                  boolean var3 = false;
               } else if (this.getBlock(var1.add(1, 0, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(1, 1, 0)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(1, 2, 0)) != Blocks.AIR
                  && this.getBlock(var1.add(1, 2, 0)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(1, 2, 0));
                  boolean var2 = false;
               } else if (this.getBlock(var1.add(0, 0, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, 1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 2, 1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 2, 1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 2, 1));
                  boolean var10000 = false;
               } else if (this.getBlock(var1.add(0, 0, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 1, -1)) != Blocks.BEDROCK
                  && this.getBlock(var1.add(0, 2, -1)) != Blocks.AIR
                  && this.getBlock(var1.add(0, 2, -1)) != Blocks.BEDROCK) {
                  this.mineBlock(var1.add(0, 2, -1));
               }
            }

            if (this.toggle.getValue() && !this.keyMode.getValue()) {
               this.disable();
            }
         }
      }
   }
}
