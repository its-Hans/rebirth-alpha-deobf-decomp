package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketConfirmTransaction;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.client.CPacketUseEntity.Action;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiWeak extends Module {
   private final Setting<AntiWeak.SwapMode> swapMode;
   private final Setting<Boolean> onlyCrystal;
   private int lastSlot;
   private final Setting<Boolean> testSync;
   private final Timer delayTimer;
   private final Setting<Boolean> always;
   private final Setting<Integer> delay = this.add(new Setting<>("Delay", 100, 0, 500));
   private CPacketUseEntity packet;
   private final Setting<Boolean> sync;

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.swapMode.getValue() == AntiWeak.SwapMode.Bypass) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            if (mc.player.isPotionActive(MobEffects.WEAKNESS)) {
               if (!(mc.player.getHeldItemMainhand().item instanceof ItemSword)) {
                  if (this.delayTimer.passedMs((long)this.delay.getValue().intValue())) {
                     if (var1.getPacket() instanceof CPacketUseEntity && ((CPacketUseEntity)var1.getPacket()).getAction() == Action.ATTACK) {
                        Entity var2 = ((CPacketUseEntity)var1.getPacket()).getEntityFromWorld(mc.world);
                        if (var2 == null || !(var2 instanceof EntityEnderCrystal) && this.onlyCrystal.getValue()) {
                           return;
                        }

                        this.packet = var1.getPacket();
                        this.doAnti();
                        this.delayTimer.reset();
                        boolean var10000 = false;
                        var1.setCanceled(true);
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      this.update();
   }

   @Override
   public void onUpdate() {
      this.update();
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.swapMode.getValue() == AntiWeak.SwapMode.Bypass) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      return this.swapMode.getValue().name();
   }

   @Override
   public void onTick() {
      this.update();
   }

   public AntiWeak() {
      super("AntiWeak", "anti weak", Category.COMBAT);
      this.swapMode = this.add(new Setting<>("SwapMode", AntiWeak.SwapMode.Bypass));
      this.onlyCrystal = this.add(new Setting<>("OnlyCrystal", true));
      this.testSync = this.add(new Setting<>("TestSync", true, this::lambda$new$0));
      this.sync = this.add(new Setting<>("Sync", false, this::lambda$new$1).setParent());
      this.always = this.add(new Setting<>("Always", false, this::lambda$new$2));
      this.lastSlot = -1;
      this.delayTimer = new Timer();
      this.packet = null;
   }

   private void doAnti() {
      if (this.packet != null) {
         int var1;
         if (this.swapMode.getValue() != AntiWeak.SwapMode.Bypass) {
            var1 = InventoryUtil.findHotbarBlock(ItemSword.class);
            boolean var10000 = false;
         } else {
            var1 = InventoryUtil.findClassInventorySlot(ItemSword.class, true);
         }

         if (var1 != -1) {
            int var2 = mc.player.inventory.currentItem;
            if (this.swapMode.getValue() != AntiWeak.SwapMode.Bypass) {
               InventoryUtil.doSwap(var1);
               boolean var3 = false;
            } else {
               mc.playerController.windowClick(0, var1, var2, ClickType.SWAP, mc.player);
               boolean var4 = false;
            }

            mc.player.connection.sendPacket(this.packet);
            if (this.swapMode.getValue() != AntiWeak.SwapMode.Bypass) {
               if (this.swapMode.getValue() != AntiWeak.SwapMode.Normal) {
                  InventoryUtil.doSwap(var2);
                  boolean var5 = false;
               }
            } else {
               mc.playerController.windowClick(0, var1, var2, ClickType.SWAP, mc.player);
               boolean var6 = false;
               if (this.sync.getValue() && this.always.getValue()) {
                  PacketExp.INSTANCE.throwExp();
               }

               this.lastSlot = var1;
               if (this.testSync.getValue()) {
                  mc.player
                     .connection
                     .sendPacket(
                        new CPacketConfirmTransaction(
                           mc.player.inventoryContainer.windowId, mc.player.openContainer.getNextTransactionID(mc.player.inventory), true
                        )
                     );
               }
            }
         }
      }
   }

   private void update() {
      if (this.lastSlot != -1 && !this.always.getValue() && this.sync.getValue()) {
         if (!(((ItemStack)mc.player.inventoryContainer.getInventory().get(this.lastSlot)).getItem() instanceof ItemSword)) {
            PacketExp.INSTANCE.throwExp();
            this.lastSlot = -1;
         }
      }
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.sync.isOpen() && this.swapMode.getValue() == AntiWeak.SwapMode.Bypass) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum SwapMode {
      Normal,
      Bypass,
      Silent;
      private static final AntiWeak.SwapMode[] $VALUES = new AntiWeak.SwapMode[]{Normal, AntiWeak.SwapMode.Silent, Bypass};
   }
}
