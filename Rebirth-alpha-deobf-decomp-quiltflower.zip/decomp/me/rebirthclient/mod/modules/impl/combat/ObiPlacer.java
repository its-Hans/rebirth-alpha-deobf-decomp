package me.rebirthclient.mod.modules.impl.combat;

import java.awt.Color;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.DamageUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class ObiPlacer extends Module {
   private final Timer delayTimer;
   public final Setting<Boolean> render = this.add(new Setting<>("Render", true).setParent());
   private final Timer renderTimer;
   BlockPos placePos;
   private final Setting<Boolean> rotate;
   public final Setting<Integer> outlineAlpha;
   private final Setting<Float> minDmg;
   public final Setting<Integer> boxAlpha;
   private final Setting<Float> placeRange;
   public final Setting<Boolean> box;
   private final Setting<Integer> renderTime;
   public final Setting<Boolean> outline = this.add(new Setting<>("Outline", true, this::lambda$new$0).setParent());
   private final Setting<Boolean> packet;
   private final Setting<Color> color;
   private final Setting<Integer> shrinkTime;
   private final Setting<Integer> placeDelay;
   private final Setting<Float> range;
   private FadeUtils shrinkTimer;
   private final Setting<Float> wallsRange;

   private boolean checkEntity(BlockPos var1) {
      for(Entity var3 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var1))) {
         if (!var3.isDead) {
            if (!(var3 instanceof EntityEnderCrystal)) {
               return true;
            }

            boolean var10000 = false;
         }
      }

      return false;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (this.placePos != null
         && !this.renderTimer.passedMs((long)this.renderTime.getValue().intValue())
         && !this.renderTimer.passedMs((long)this.renderTime.getValue().intValue())
         && this.render.getValue()) {
         if (mc.world.getBlockState(this.placePos).getBlock() != Blocks.AIR) {
            if (mc.world.getBlockState(this.placePos).getBlock() != Blocks.FIRE) {
               AxisAlignedBB var2 = mc.world
                  .getBlockState(this.placePos)
                  .getSelectedBoundingBox(mc.world, this.placePos)
                  .grow(this.shrinkTimer.easeInQuad() / 2.0 - 1.0);
               if (this.outline.getValue()) {
                  RenderUtil.drawBBBox(var2, this.color.getValue(), this.outlineAlpha.getValue());
               }

               if (this.box.getValue()) {
                  RenderUtil.drawBBFill(var2, this.color.getValue(), this.boxAlpha.getValue());
               }
            }
         }
      }
   }

   private BlockPos getPlaceTarget(Entity var1) {
      for(BlockPos var3 : BlockUtil.getBox(5.0F, EntityUtil.getEntityPos(var1).down())) {
         if (!this.canPlaceCrystal(var3)) {
            boolean var10000 = false;
         } else if (CatCrystal.behindWall(var3)) {
            boolean var10 = false;
         } else if (mc.player.getDistance((double)var3.getX() + 0.5, (double)var3.getY() + 0.5, (double)var3.getZ() + 0.5)
            > (double)this.placeRange.getValue().floatValue()) {
            boolean var11 = false;
         } else {
            float var4 = DamageUtil.calculateDamage(var3.down(), var1);
            if (var4 > this.minDmg.getValue()) {
               return null;
            }

            boolean var12 = false;
         }
      }

      BlockPos var7 = null;
      float var8 = 0.0F;

      for(BlockPos var5 : BlockUtil.getBox(this.range.getValue())) {
         if (mc.world.isAirBlock(var5) && mc.world.isAirBlock(var5.up())) {
            if (!mc.world.isAirBlock(var5.up(2))) {
               boolean var22 = false;
            } else if (mc.player.getDistance((double)var5.getX() + 0.5, (double)var5.getY() + 0.5, (double)var5.getZ() + 0.5)
               > (double)this.placeRange.getValue().floatValue()) {
               boolean var21 = false;
            } else if (this.checkEntity(var5.up())) {
               boolean var20 = false;
            } else if (this.checkEntity(var5.up(2))) {
               boolean var19 = false;
            } else if (!BlockUtil.canPlace(var5)) {
               boolean var18 = false;
            } else if ((double)var5.getY() > (double)new BlockPos(var1.posX, var1.posY + 0.5, var1.posZ).getY() - 0.5) {
               boolean var17 = false;
            } else {
               float var6 = DamageUtil.calculateDamage(var5, var1);
               if (!(var6 < this.minDmg.getValue())) {
                  if (mc.player.getDistanceSq(var5) >= MathUtil.square((double)this.wallsRange.getValue().floatValue())
                     && BlockUtil.rayTracePlaceCheck(var5, true, 1.0F)) {
                     boolean var16 = false;
                  } else if (var7 == null) {
                     var8 = var6;
                     var7 = var5;
                     boolean var13 = false;
                  } else if (var6 < var8) {
                     boolean var14 = false;
                  } else {
                     var8 = var6;
                     var7 = var5;
                     boolean var15 = false;
                  }
               }
            }
         }
      }

      return var7;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.render.isOpen();
   }

   private void placeBlock(BlockPos var1) {
      if (BlockUtil.canPlace(var1)) {
         int var2 = mc.player.inventory.currentItem;
         if (InventoryUtil.findHotbarClass(BlockObsidian.class) != -1) {
            InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockObsidian.class));
            BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            InventoryUtil.doSwap(var2);
         }
      }
   }

   private boolean lambda$new$4(Color var1) {
      return this.render.isOpen();
   }

   @Override
   public String getInfo() {
      if (fullNullCheck()) {
         return null;
      } else {
         EntityPlayer var1 = CombatUtil.getTarget((double)this.range.getValue().floatValue());
         return var1 != null ? var1.getName() : null;
      }
   }

   private boolean lambda$new$5(Integer var1) {
      return this.render.isOpen();
   }

   private boolean lambda$new$6(Integer var1) {
      return this.render.isOpen();
   }

   private boolean canPlaceCrystal(BlockPos var1) {
      BlockPos var2 = var1.down();
      BlockPos var3 = var2.up();
      BlockPos var4 = var2.up(2);
      boolean var10000;
      if ((this.getBlock(var2) == Blocks.BEDROCK || this.getBlock(var2) == Blocks.OBSIDIAN)
         && this.getBlock(var3) == Blocks.AIR
         && this.getBlock(var4) == Blocks.AIR
         && !this.checkEntity(var4)
         && !this.checkEntity(var3)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Integer var1) {
      boolean var10000;
      if (this.render.isOpen() && this.box.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public ObiPlacer() {
      super("ObiPlacer", "auto place obi of crystal", Category.COMBAT);
      this.outlineAlpha = this.add(new Setting<>("OutlineAlpha", 150, 0, 255, this::lambda$new$1));
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$2).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 70, 0, 255, this::lambda$new$3));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255), this::lambda$new$4).hideAlpha());
      this.renderTime = this.add(new Setting<>("RenderTime", 3000, 0, 5000, this::lambda$new$5));
      this.shrinkTime = this.add(new Setting<>("ShrinkTime", 600, 0, 5000, this::lambda$new$6));
      this.shrinkTimer = new FadeUtils((long)this.shrinkTime.getValue().intValue());
      this.delayTimer = new Timer();
      this.renderTimer = new Timer();
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.packet = this.add(new Setting<>("Packet", true));
      this.range = this.add(new Setting<>("Range", 6.0F, 0.0F, 10.0F));
      this.wallsRange = this.add(new Setting<>("WallsRange", 3.5F, 0.0F, 10.0F));
      this.placeDelay = this.add(new Setting<>("PlaceDelay", 100, 0, 2000));
      this.minDmg = this.add(new Setting<>("MinDmg", 6.0F, 0.0F, 10.0F));
      this.placeRange = this.add(new Setting<>("PlaceRange", 4.0F, 1.0F, 6.0F));
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.render.isOpen();
   }

   @Override
   public void onUpdate() {
      EntityPlayer var1 = CombatUtil.getTarget((double)this.range.getValue().floatValue());
      if (this.delayTimer.passedMs((long)this.placeDelay.getValue().intValue()) && var1 != null) {
         this.placePos = this.getPlaceTarget(var1);
         if (this.placePos != null && BlockUtil.canPlace(this.placePos)) {
            this.shrinkTimer = new FadeUtils((long)this.shrinkTime.getValue().intValue());
            this.delayTimer.reset();
            boolean var10000 = false;
            this.renderTimer.reset();
            var10000 = false;
            this.placeBlock(this.placePos);
         }
      }
   }

   private boolean lambda$new$1(Integer var1) {
      boolean var10000;
      if (this.render.isOpen() && this.outline.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }
}
