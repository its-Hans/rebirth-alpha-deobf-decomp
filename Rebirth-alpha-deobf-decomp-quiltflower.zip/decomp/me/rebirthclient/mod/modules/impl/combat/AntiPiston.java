package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AntiPiston extends Module {
   public final Setting<Boolean> packet;
   private final Setting<Boolean> onlyBurrow;
   public final Setting<Boolean> helper;
   public final Setting<Boolean> trap;
   private final Setting<Boolean> whenDouble;
   private final Setting<Double> maxSelfSpeed;
   public final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   public static AntiPiston INSTANCE;

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   @Override
   public void onUpdate() {
      if (!fullNullCheck() && mc.player.onGround && !(Managers.SPEED.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue())) {
         this.block();
      }
   }

   private void placeBlock(BlockPos var1) {
      if (canPlace(var1)) {
         int var2 = mc.player.inventory.currentItem;
         if (InventoryUtil.findHotbarClass(BlockObsidian.class) != -1) {
            InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockObsidian.class));
            BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            InventoryUtil.doSwap(var2);
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.onlyBurrow.isOpen();
   }

   public static boolean canPlace(BlockPos var0) {
      if (!BlockUtil.canBlockFacing(var0)) {
         return false;
      } else if (!BlockUtil.canReplace(var0)) {
         return false;
      } else {
         boolean var10000;
         if (!BlockUtil.checkEntity(var0)) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   public AntiPiston() {
      super("AntiPiston", "Trap self when piston kick", Category.COMBAT);
      this.packet = this.add(new Setting<>("Packet", true));
      this.maxSelfSpeed = this.add(new Setting<>("MaxSelfSpeed", 6.0, 1.0, 30.0));
      this.helper = this.add(new Setting<>("Helper", true));
      this.trap = this.add(new Setting<>("Trap", true).setParent());
      this.onlyBurrow = this.add(new Setting<>("OnlyBurrow", true, this::lambda$new$0).setParent());
      this.whenDouble = this.add(new Setting<>("WhenDouble", true, this::lambda$new$1));
      INSTANCE = this;
   }

   private void block() {
      BlockPos var1 = EntityUtil.getPlayerPos();
      if (this.getBlock(var1.up(2)) != Blocks.OBSIDIAN && this.getBlock(var1.up(2)) != Blocks.BEDROCK) {
         int var2 = 0;
         if (this.whenDouble.getValue()) {
            for(EnumFacing var6 : EnumFacing.VALUES) {
               if (var6 != EnumFacing.DOWN) {
                  if (var6 == EnumFacing.UP) {
                     boolean var10000 = false;
                  } else if (this.getBlock(var1.offset(var6).up()) instanceof BlockPistonBase) {
                     if (((EnumFacing)mc.world.getBlockState(var1.offset(var6).up()).getValue(BlockDirectional.FACING)).getOpposite() != var6) {
                        boolean var15 = false;
                     } else {
                        ++var2;
                     }
                  }
               }

               boolean var16 = false;
            }
         }

         for(EnumFacing var14 : EnumFacing.VALUES) {
            if (var14 != EnumFacing.DOWN) {
               if (var14 == EnumFacing.UP) {
                  boolean var21 = false;
               } else if (this.getBlock(var1.offset(var14).up()) instanceof BlockPistonBase) {
                  if (((EnumFacing)mc.world.getBlockState(var1.offset(var14).up()).getValue(BlockDirectional.FACING)).getOpposite() != var14) {
                     boolean var20 = false;
                  } else {
                     this.placeBlock(var1.up().offset(var14, -1));
                     if (this.trap.getValue() && (this.getBlock(var1) != Blocks.AIR || !this.onlyBurrow.getValue() || var2 >= 2)) {
                        this.placeBlock(var1.up(2));
                        if (!BlockUtil.canPlaceEnum(var1.up(2))) {
                           for(EnumFacing var10 : EnumFacing.VALUES) {
                              if (canPlace(var1.offset(var10).up(2))) {
                                 this.placeBlock(var1.offset(var10).up(2));
                                 boolean var18 = false;
                                 break;
                              }

                              boolean var17 = false;
                           }
                        }
                     }

                     if (!BlockUtil.canPlaceEnum(var1.up().offset(var14, -1)) && this.helper.getValue()) {
                        if (BlockUtil.canPlaceEnum(var1.offset(var14, -1))) {
                           this.placeBlock(var1.offset(var14, -1));
                           boolean var19 = false;
                        } else {
                           this.placeBlock(var1.offset(var14, -1).down());
                        }
                     }
                  }
               }
            }

            boolean var22 = false;
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.trap.isOpen();
   }
}
