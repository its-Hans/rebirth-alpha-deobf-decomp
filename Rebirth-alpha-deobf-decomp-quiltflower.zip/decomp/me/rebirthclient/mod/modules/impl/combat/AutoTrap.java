package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.BreakManager;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoTrap extends Module {
   private final Setting<Boolean> antiStep;
   private final Setting<Boolean> packet;
   public EntityPlayer target;
   private final Setting<AutoTrap.Mode> mode;
   private final Setting<Boolean> legs;
   private final Setting<Boolean> facing;
   private final Setting<Boolean> chest;
   private final Setting<Boolean> extend;
   private final Setting<Double> maxSelfSpeed;
   public static AutoTrap INSTANCE;
   private final Setting<Boolean> autoDisable;
   final Timer timer = new Timer();
   int progress;
   private final Setting<AutoTrap.TargetMode> targetMod;
   private final Setting<Boolean> selfGround;
   private final Setting<Integer> multiPlace;
   private final Setting<Float> placeRange;
   private final Setting<Boolean> onlyGround;
   private final Setting<Boolean> head;
   private final Setting<Float> range;
   private final Setting<Double> maxTargetSpeed;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private final Setting<Integer> delay;

   private void placeBlock(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (BlockUtil.canPlace(var1)) {
            if (!(
               mc.player.getDistance((double)var1.getX() + 0.5, (double)var1.getY() + 0.5, (double)var1.getZ() + 0.5)
                  > (double)this.placeRange.getValue().floatValue()
            )) {
               int var2 = mc.player.inventory.currentItem;
               if (InventoryUtil.findHotbarClass(BlockObsidian.class) != -1) {
                  InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockObsidian.class));
                  BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                  InventoryUtil.doSwap(var2);
                  this.timer.reset();
                  boolean var10000 = false;
                  ++this.progress;
               }
            }
         }
      }
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Piston && this.chest.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean placePiston(BlockPos var1, EnumFacing var2) {
      if (this.progress >= this.multiPlace.getValue()) {
         return false;
      } else if (!BlockUtil.canPlace(var1)) {
         return false;
      } else if (mc.player.getDistance((double)var1.getX() + 0.5, (double)var1.getY() + 0.5, (double)var1.getZ() + 0.5)
         > (double)this.placeRange.getValue().floatValue()) {
         return false;
      } else {
         int var3 = mc.player.inventory.currentItem;
         if (InventoryUtil.findHotbarClass(BlockPistonBase.class) == -1) {
            return false;
         } else {
            EnumFacing var4 = BlockUtil.getFirstFacing(var1);
            if (var4 == null) {
               return false;
            } else {
               InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockPistonBase.class));
               if (this.facing.getValue()) {
                  AutoPush.pistonFacing(var2);
                  BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, false, this.packet.getValue());
                  BlockPos var5 = var1.offset(var4);
                  EnumFacing var6 = var4.getOpposite();
                  Vec3d var7 = new Vec3d(var5).add(0.5, 0.5, 0.5).add(new Vec3d(var6.getDirectionVec()).scale(0.5));
                  if (this.rotate.getValue()) {
                     EntityUtil.faceVector(var7);
                  }

                  boolean var10000 = false;
               } else {
                  BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
               }

               InventoryUtil.doSwap(var3);
               this.timer.reset();
               boolean var8 = false;
               ++this.progress;
               return true;
            }
         }
      }
   }

   private void doAuto(BlockPos var1) {
      if (InventoryUtil.findHotbarClass(BlockPistonBase.class) == -1) {
         this.doTrap(var1);
      } else {
         for(EnumFacing var5 : EnumFacing.VALUES) {
            if (var5 != EnumFacing.UP) {
               if (var5 == EnumFacing.DOWN) {
                  boolean var10000 = false;
               } else if (mc.world.getBlockState(var1.up().offset(var5)).getBlock() instanceof BlockPistonBase) {
                  return;
               }
            }

            boolean var10 = false;
         }

         for(EnumFacing var9 : EnumFacing.VALUES) {
            if (var9 != EnumFacing.UP) {
               if (var9 == EnumFacing.DOWN) {
                  boolean var11 = false;
               } else if (BlockUtil.canPlace(var1.up().offset(var9))) {
                  this.placePiston(var1.up().offset(var9), var9);
                  boolean var13 = false;
                  return;
               }
            }

            boolean var12 = false;
         }

         this.doTrap(var1);
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Piston) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Piston) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void doPiston(BlockPos var1) {
      if (!(mc.world.getBlockState(var1.south()).getBlock() instanceof BlockPistonBase)
         && !(mc.world.getBlockState(var1.south(-1)).getBlock() instanceof BlockPistonBase)
         && !this.placePiston(var1.south(), EnumFacing.SOUTH)) {
         this.placePiston(var1.south(-1), EnumFacing.SOUTH.getOpposite());
         boolean var10000 = false;
      }

      if (!(mc.world.getBlockState(var1.east()).getBlock() instanceof BlockPistonBase)
         && !(mc.world.getBlockState(var1.east(-1)).getBlock() instanceof BlockPistonBase)
         && !this.placePiston(var1.east(), EnumFacing.EAST)) {
         this.placePiston(var1.east(-1), EnumFacing.EAST.getOpposite());
         boolean var2 = false;
      }
   }

   @Override
   public String getInfo() {
      return this.target != null
         ? String.valueOf(new StringBuilder().append(this.target.getName()).append(", ").append(this.mode.getValue().name()))
         : this.mode.getValue().name();
   }

   private void doTrap(BlockPos var1) {
      if (this.antiStep.getValue() && BreakManager.isMine(var1.add(0, 2, 0))) {
         this.placeBlock(var1.add(0, 3, 0));
      }

      if (this.extend.getValue()) {
         BlockPos var2 = var1.add(0.1, 0.0, 0.1);
         if (this.checkEntity(new BlockPos(var2)) != null) {
            this.placeBlock(var2.up(2));
         }

         var2 = var1.add(-0.1, 0.0, 0.1);
         if (this.checkEntity(new BlockPos(var2)) != null) {
            this.placeBlock(var2.up(2));
         }

         var2 = var1.add(0.1, 0.0, -0.1);
         if (this.checkEntity(new BlockPos(var2)) != null) {
            this.placeBlock(var2.up(2));
         }

         var2 = var1.add(-0.1, 0.0, -0.1);
         if (this.checkEntity(new BlockPos(var2)) != null) {
            this.placeBlock(var2.up(2));
         }
      }

      boolean var11 = false;
      if (this.head.getValue() && mc.world.getBlockState(var1.add(0, 2, 0)).getBlock() == Blocks.AIR) {
         if (BlockUtil.canPlace4(var1.up(2))) {
            this.placeBlock(var1.up(2));
         }

         if (!BlockUtil.canPlace4(var1.up(2))) {
            var11 = true;
         }
      }

      if (this.chest.getValue() && (!this.onlyGround.getValue() || this.target.onGround) || var11) {
         for(EnumFacing var6 : EnumFacing.VALUES) {
            if (var6 != EnumFacing.DOWN) {
               if (var6 == EnumFacing.UP) {
                  boolean var10000 = false;
               } else {
                  BlockPos var7 = var1.offset(var6).up();
                  this.placeBlock(var7);
                  if (!BlockUtil.canPlace4(var1.up(2)) && BlockUtil.canReplace(var1.up(2))) {
                     this.placeBlock(var7.up());
                  }

                  if (!BlockUtil.canBlockFacing(var7) && BlockUtil.canReplace(var7)) {
                     this.placeBlock(var7.down());
                  }
               }
            }

            boolean var17 = false;
         }
      }

      if (this.legs.getValue()) {
         for(EnumFacing var15 : EnumFacing.VALUES) {
            if (var15 != EnumFacing.DOWN) {
               if (var15 == EnumFacing.UP) {
                  boolean var18 = false;
               } else {
                  BlockPos var16 = var1.offset(var15);
                  if (!BlockUtil.isAir(var16.up())) {
                     boolean var19 = false;
                  } else {
                     this.placeBlock(var16);
                     if (!BlockUtil.canBlockFacing(var16)) {
                        this.placeBlock(var16.down());
                     }
                  }
               }
            }

            boolean var20 = false;
         }
      }
   }

   private void trapTarget(EntityPlayer var1) {
      if (this.mode.getValue() == AutoTrap.Mode.Trap) {
         this.doTrap(EntityUtil.getEntityPos(var1));
         boolean var10000 = false;
      } else if (this.mode.getValue() == AutoTrap.Mode.Piston) {
         this.doPiston(EntityUtil.getEntityPos(var1).up());
         boolean var2 = false;
      } else {
         this.doAuto(EntityUtil.getEntityPos(var1));
      }
   }

   private Entity checkEntity(BlockPos var1) {
      Entity var2 = null;

      for(Entity var4 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var1))) {
         if (var4 instanceof EntityPlayer) {
            if (var4 == mc.player) {
               boolean var10000 = false;
            } else {
               var2 = var4;
               boolean var5 = false;
            }
         }
      }

      return var2;
   }

   @Override
   public void onTick() {
      this.progress = 0;
      if (this.selfGround.getValue() && !mc.player.onGround) {
         this.target = null;
         if (this.autoDisable.getValue()) {
            this.disable();
         }
      } else if (Managers.SPEED.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue()) {
         this.target = null;
         if (this.autoDisable.getValue()) {
            this.disable();
         }
      } else if (!this.timer.passedMs((long)this.delay.getValue().intValue())) {
         this.target = null;
      } else {
         if (this.targetMod.getValue() == AutoTrap.TargetMode.Single) {
            this.target = CombatUtil.getTarget((double)this.range.getValue().floatValue(), this.maxTargetSpeed.getMaxValue());
            if (this.target == null) {
               return;
            }

            this.trapTarget(this.target);
            boolean var10000 = false;
         } else if (this.targetMod.getValue() == AutoTrap.TargetMode.Multi) {
            boolean var1 = false;

            for(EntityPlayer var3 : mc.world.playerEntities) {
               if (!(Managers.SPEED.getPlayerSpeed(var3) > this.maxTargetSpeed.getValue())) {
                  if (EntityUtil.invalid(var3, (double)this.range.getValue().floatValue())) {
                     boolean var4 = false;
                  } else {
                     var1 = true;
                     this.target = var3;
                     this.trapTarget(this.target);
                     boolean var5 = false;
                  }
               }
            }

            if (!var1) {
               if (this.autoDisable.getValue()) {
                  this.disable();
               }

               this.target = null;
            }
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Piston) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public AutoTrap() {
      super("AutoTrap", "Automatically trap the enemy", Category.COMBAT);
      this.packet = this.add(new Setting<>("Packet", true));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 8));
      this.autoDisable = this.add(new Setting<>("AutoDisable", true));
      this.range = this.add(new Setting<>("Range", 5.0F, 1.0F, 8.0F));
      this.targetMod = this.add(new Setting<>("TargetMode", AutoTrap.TargetMode.Single));
      this.mode = this.add(new Setting<>("Mode", AutoTrap.Mode.Trap));
      this.antiStep = this.add(new Setting<>("AntiStep", false, this::lambda$new$0));
      this.extend = this.add(new Setting<>("Extend", true, this::lambda$new$1));
      this.head = this.add(new Setting<>("Head", true, this::lambda$new$2));
      this.chest = this.add(new Setting<>("Chest", true, this::lambda$new$3).setParent());
      this.onlyGround = this.add(new Setting<>("OnlyGround", true, this::lambda$new$4));
      this.legs = this.add(new Setting<>("Legs", false, this::lambda$new$5));
      this.facing = this.add(new Setting<>("Facing", false, this::lambda$new$6));
      this.delay = this.add(new Setting<>("Delay", 50, 0, 300));
      this.placeRange = this.add(new Setting<>("PlaceRange", 4.0F, 1.0F, 6.0F));
      this.maxTargetSpeed = this.add(new Setting<>("MaxTargetSpeed", 4.0, 1.0, 30.0));
      this.selfGround = this.add(new Setting<>("SelfGround", true));
      this.maxSelfSpeed = this.add(new Setting<>("MaxSelfSpeed", 6.0, 1.0, 30.0));
      this.progress = 0;
      INSTANCE = this;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Piston) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Piston) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() != AutoTrap.Mode.Trap) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Mode {
      Auto,
      Piston,
      Trap;
      private static final AutoTrap.Mode[] $VALUES = new AutoTrap.Mode[]{AutoTrap.Mode.Trap, Piston, Auto};
   }

   public static enum TargetMode {
      Multi,
      Single;

      private static final AutoTrap.TargetMode[] $VALUES = new AutoTrap.TargetMode[]{Single, Multi};
   }
}
