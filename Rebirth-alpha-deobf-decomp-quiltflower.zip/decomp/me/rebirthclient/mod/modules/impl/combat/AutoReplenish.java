package me.rebirthclient.mod.modules.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.asm.accessors.IGuiShulkerBox;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.render.PlaceRender;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.client.gui.inventory.GuiShulkerBox;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoReplenish extends Module {
   public final Setting<Boolean> rotate;
   private final Setting<Boolean> autoDisable = this.add(new Setting<>("AutoDisable", true));
   private final Setting<Integer> endChest;
   private final Setting<Integer> crystal;
   public final Setting<Boolean> packet;
   public static final List<Block> shulkers = Arrays.asList(
      Blocks.BLACK_SHULKER_BOX,
      Blocks.BLUE_SHULKER_BOX,
      Blocks.BROWN_SHULKER_BOX,
      Blocks.CYAN_SHULKER_BOX,
      Blocks.GRAY_SHULKER_BOX,
      Blocks.GREEN_SHULKER_BOX,
      Blocks.LIGHT_BLUE_SHULKER_BOX,
      Blocks.LIME_SHULKER_BOX,
      Blocks.MAGENTA_SHULKER_BOX,
      Blocks.ORANGE_SHULKER_BOX,
      Blocks.PINK_SHULKER_BOX,
      Blocks.PURPLE_SHULKER_BOX,
      Blocks.RED_SHULKER_BOX,
      Blocks.SILVER_SHULKER_BOX,
      Blocks.WHITE_SHULKER_BOX,
      Blocks.YELLOW_SHULKER_BOX
   );
   private final Setting<Boolean> place;
   private final Setting<Boolean> take;
   private final Setting<Boolean> open;
   private final Setting<Integer> piston;
   private final Setting<Integer> exp;
   BlockPos placePos;
   private final Setting<Integer> totem;
   private final Setting<Float> minRange;
   private final Setting<Float> range;
   private final Setting<Integer> web;
   private final Setting<Boolean> smart;
   private final Setting<Integer> redStoneBlock;
   int[] stealCountList;
   private final Setting<Integer> gapple;

   private boolean lambda$new$6(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public int findShulker() {
      AtomicInteger var1 = new AtomicInteger(-1);
      shulkers.forEach(AutoReplenish::lambda$findShulker$9);
      return var1.get();
   }

   private boolean lambda$new$2(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static void placeShulker(BlockPos var0, boolean var1, boolean var2) {
      EnumFacing var3 = EnumFacing.DOWN;
      BlockPos var4 = var0.offset(var3);
      EnumFacing var5 = var3.getOpposite();
      Vec3d var6 = new Vec3d(var4).add(0.5, 0.5, 0.5).add(new Vec3d(var5.getDirectionVec()).scale(0.5));
      Block var7 = mc.world.getBlockState(var4).getBlock();
      boolean var8 = false;
      if (!SneakManager.isSneaking && (BlockUtil.canUseList.contains(var7) || BlockUtil.shulkerList.contains(var7))) {
         mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
         var8 = true;
      }

      if (var1) {
         EntityUtil.faceVector(var6);
      }

      PlaceRender.PlaceMap.put(var0, new PlaceRender.placePosition(var0));
      boolean var10000 = false;
      BlockUtil.rightClickBlock(var4, var6, EnumHand.MAIN_HAND, var5, var2);
      if (var8) {
         mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
      }
   }

   private boolean lambda$new$1(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void update() {
      this.stealCountList[0] = this.crystal.getValue() - this.getItemCount(Items.END_CRYSTAL);
      this.stealCountList[1] = this.exp.getValue() - this.getItemCount(Items.EXPERIENCE_BOTTLE);
      this.stealCountList[2] = this.totem.getValue() - this.getItemCount(Items.TOTEM_OF_UNDYING);
      this.stealCountList[3] = this.gapple.getValue() - this.getItemCount(Items.GOLDEN_APPLE);
      this.stealCountList[4] = this.endChest.getValue() - this.getItemCount(Item.getItemFromBlock(Blocks.ENDER_CHEST));
      this.stealCountList[5] = this.web.getValue() - this.getItemCount(Item.getItemFromBlock(Blocks.WEB));
      this.stealCountList[6] = this.redStoneBlock.getValue() - this.getItemCount(Item.getItemFromBlock(Blocks.REDSTONE_BLOCK));
      this.stealCountList[7] = this.piston.getValue() - this.getPistonCount();
   }

   public static void openShulker(BlockPos var0, boolean var1, boolean var2) {
      EnumFacing var3 = EnumFacing.DOWN;
      var0 = var0.up();
      BlockPos var4 = var0.offset(var3);
      EnumFacing var5 = var3.getOpposite();
      Vec3d var6 = new Vec3d(var4).add(0.5, 0.5, 0.5).add(new Vec3d(var5.getDirectionVec()).scale(0.5));
      if (var1) {
         EntityUtil.faceVector(var6);
      }

      mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
      BlockUtil.rightClickBlock(var4, var6, EnumHand.MAIN_HAND, var5, var2);
   }

   public AutoReplenish() {
      super("AutoReplenish", "Auto place shulker and replenish", Category.COMBAT);
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.packet = this.add(new Setting<>("Packet", true));
      this.place = this.add(new Setting<>("Place", true));
      this.open = this.add(new Setting<>("Open", true));
      this.range = this.add(new Setting<>("Range", 4.0F, 0.0F, 6.0F));
      this.minRange = this.add(new Setting<>("MinRange", 1.0F, 0.0F, 3.0F));
      this.take = this.add(new Setting<>("Take", true).setParent());
      this.smart = this.add(new Setting<>("Smart", true, this::lambda$new$0).setParent());
      this.crystal = this.add(new Setting<>("Crystal", 6, 0, 20, this::lambda$new$1));
      this.exp = this.add(new Setting<>("Exp", 6, 0, 20, this::lambda$new$2));
      this.totem = this.add(new Setting<>("Totem", 6, 0, 30, this::lambda$new$3));
      this.gapple = this.add(new Setting<>("Gapple", 3, 0, 10, this::lambda$new$4));
      this.endChest = this.add(new Setting<>("EndChest", 1, 0, 5, this::lambda$new$5));
      this.web = this.add(new Setting<>("Web", 1, 0, 5, this::lambda$new$6));
      this.redStoneBlock = this.add(new Setting<>("RedStoneBlock", 1, 0, 5, this::lambda$new$7));
      this.piston = this.add(new Setting<>("Piston", 1, 0, 5, this::lambda$new$8));
      this.stealCountList = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
      this.placePos = null;
   }

   private boolean lambda$new$8(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      this.update();
      if (mc.currentScreen instanceof GuiShulkerBox) {
         if (!this.take.getValue()) {
            if (this.autoDisable.getValue()) {
               this.disable();
            }
         } else {
            GuiShulkerBox var5 = (GuiShulkerBox)mc.currentScreen;
            IInventory var6 = ((IGuiShulkerBox)var5).getInventory();

            for(int var3 = 0; var3 < ((IInventory)Objects.requireNonNull(var6)).getSizeInventory(); ++var3) {
               ItemStack var4 = var6.getStackInSlot(var3);
               if (!var4.isEmpty) {
                  if (!this.smart.getValue()) {
                     mc.playerController.windowClick(var5.inventorySlots.windowId, var3, 0, ClickType.QUICK_MOVE, mc.player);
                     boolean var11 = false;
                  }

                  if (this.needSteal(((IGuiShulkerBox)var5).getInventory().getStackInSlot(var3).getItem())) {
                     mc.playerController.windowClick(var5.inventorySlots.windowId, var3, 0, ClickType.QUICK_MOVE, mc.player);
                     boolean var12 = false;
                  }
               }

               boolean var13 = false;
            }

            if (this.autoDisable.getValue()) {
               this.disable();
            }
         }
      } else {
         if (this.open.getValue()) {
            if (this.placePos != null) {
               if (shulkers.contains(mc.world.getBlockState(this.placePos).getBlock())) {
                  openShulker(this.placePos, this.rotate.getValue(), this.packet.getValue());
                  boolean var10000 = false;
               }
            } else {
               for(BlockPos var2 : BlockUtil.getBox(this.range.getValue())) {
                  if (!BlockUtil.isAir(var2.up())) {
                     boolean var7 = false;
                  } else {
                     if (shulkers.contains(mc.world.getBlockState(var2).getBlock())) {
                        openShulker(var2, this.rotate.getValue(), this.packet.getValue());
                        boolean var9 = false;
                        break;
                     }

                     boolean var8 = false;
                  }
               }

               boolean var10 = false;
            }
         } else if (!this.take.getValue()) {
            if (this.autoDisable.getValue()) {
               this.disable();
            }

            return;
         }
      }
   }

   private boolean needSteal(Item var1) {
      if (var1.equals(Items.END_CRYSTAL) && this.stealCountList[0] > 0) {
         int[] var9 = this.stealCountList;
         var9[0]--;
         return true;
      } else if (var1.equals(Items.EXPERIENCE_BOTTLE) && this.stealCountList[1] > 0) {
         int[] var8 = this.stealCountList;
         var8[1]--;
         return true;
      } else if (var1.equals(Items.TOTEM_OF_UNDYING) && this.stealCountList[2] > 0) {
         int[] var7 = this.stealCountList;
         var7[2]--;
         return true;
      } else if (var1.equals(Items.GOLDEN_APPLE) && this.stealCountList[3] > 0) {
         int[] var6 = this.stealCountList;
         var6[3]--;
         return true;
      } else if (var1.equals(Item.getItemFromBlock(Blocks.ENDER_CHEST)) && this.stealCountList[4] > 0) {
         int[] var5 = this.stealCountList;
         var5[4]--;
         return true;
      } else if (var1.equals(Item.getItemFromBlock(Blocks.WEB)) && this.stealCountList[5] > 0) {
         int[] var4 = this.stealCountList;
         var4[5]--;
         return true;
      } else if (var1.equals(Item.getItemFromBlock(Blocks.REDSTONE_BLOCK)) && this.stealCountList[6] > 0) {
         int[] var3 = this.stealCountList;
         var3[6]--;
         return true;
      } else if ((var1 == Item.getItemFromBlock(Blocks.PISTON) || var1 == Item.getItemFromBlock(Blocks.STICKY_PISTON)) && this.stealCountList[7] > 0) {
         int[] var2 = this.stealCountList;
         var2[7]--;
         return true;
      } else {
         return false;
      }
   }

   private static void lambda$findShulker$9(AtomicInteger var0, Block var1) {
      if (InventoryUtil.findHotbarBlock(var1) != -1) {
         var0.set(InventoryUtil.findHotbarBlock(var1));
      }
   }

   private int getPistonCount() {
      int var1 = 0;
      if (mc.player.getHeldItemOffhand().getItem() == Item.getItemFromBlock(Blocks.PISTON)
         || mc.player.getHeldItemOffhand().getItem() == Item.getItemFromBlock(Blocks.STICKY_PISTON)) {
         ++var1;
      }

      for(int var2 = 1; var2 < 5; ++var2) {
         ItemStack var3 = ((Slot)mc.player.inventoryContainer.inventorySlots.get(var2)).getStack();
         if (var3.getItem() != Item.getItemFromBlock(Blocks.STICKY_PISTON) && var3.getItem() != Item.getItemFromBlock(Blocks.STICKY_PISTON)) {
            boolean var10000 = false;
         } else {
            ++var1;
         }

         boolean var6 = false;
      }

      for(Entry var5 : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
         if (((ItemStack)var5.getValue()).getItem() == Item.getItemFromBlock(Blocks.STICKY_PISTON)
            || ((ItemStack)var5.getValue()).getItem() == Item.getItemFromBlock(Blocks.PISTON)) {
            if (var5.getKey() == 45) {
               boolean var7 = false;
            } else {
               ++var1;
               boolean var8 = false;
            }
         }
      }

      return var1;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.take.isOpen();
   }

   private boolean lambda$new$5(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onEnable() {
      this.placePos = null;
      int var1 = mc.player.inventory.currentItem;
      if (this.place.getValue()) {
         if (this.findShulker() == -1) {
            this.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("No Shulker Found")));
         } else {
            InventoryUtil.doSwap(this.findShulker());
            double var2 = 100.0;
            BlockPos var4 = null;

            for(BlockPos var6 : BlockUtil.getBox(this.range.getValue())) {
               if (!BlockUtil.isAir(var6.up())) {
                  boolean var9 = false;
               } else if (mc.player.getDistance((double)var6.getX() + 0.5, (double)var6.getY(), (double)var6.getZ() + 0.5)
                  < (double)this.minRange.getValue().floatValue()) {
                  boolean var8 = false;
               } else if (!BlockUtil.canPlaceShulker(var6)) {
                  boolean var7 = false;
               } else {
                  if (var4 == null || mc.player.getDistance((double)var6.getX() + 0.5, (double)var6.getY(), (double)var6.getZ() + 0.5) < var2) {
                     var2 = mc.player.getDistance((double)var6.getX() + 0.5, (double)var6.getY(), (double)var6.getZ() + 0.5);
                     var4 = var6;
                  }

                  boolean var10000 = false;
               }
            }

            if (var4 != null) {
               placeShulker(var4, this.rotate.getValue(), this.packet.getValue());
               this.placePos = var4;
            }

            InventoryUtil.doSwap(var1);
         }
      }
   }

   private boolean lambda$new$4(Integer var1) {
      boolean var10000;
      if (this.take.isOpen() && this.smart.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private int getItemCount(Item var1) {
      int var2 = 0;
      if (mc.player.getHeldItemOffhand().getItem() == var1) {
         ++var2;
      }

      for(int var3 = 1; var3 < 5; ++var3) {
         ItemStack var4 = ((Slot)mc.player.inventoryContainer.inventorySlots.get(var3)).getStack();
         if (var4.getItem() != var1) {
            boolean var10000 = false;
         } else {
            ++var2;
         }

         boolean var7 = false;
      }

      for(Entry var6 : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
         if (((ItemStack)var6.getValue()).getItem() == var1) {
            if (var6.getKey() == 45) {
               boolean var8 = false;
            } else {
               ++var2;
               boolean var9 = false;
            }
         }
      }

      return var2;
   }
}
