package me.rebirthclient.mod.modules.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.Arrays;
import java.util.List;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class SelfWeb extends Module {
   private final Setting<Integer> enemyRange;
   public final List<Block> blackList = Arrays.asList(
      Blocks.ENDER_CHEST,
      Blocks.CHEST,
      Blocks.TRAPPED_CHEST,
      Blocks.CRAFTING_TABLE,
      Blocks.ANVIL,
      Blocks.BREWING_STAND,
      Blocks.HOPPER,
      Blocks.DROPPER,
      Blocks.DISPENSER
   );
   private boolean sneak;
   private int newSlot;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private final Setting<Boolean> smart = this.add(new Setting<>("Smart", false).setParent());

   @Override
   public void onDisable() {
      if (mc.player != null && this.sneak) {
         mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
         this.sneak = false;
      }
   }

   private boolean lambda$new$0(Integer var1) {
      return this.smart.isOpen();
   }

   private boolean canBeClicked(BlockPos var1) {
      return BlockUtil.getBlock(var1).canCollideCheck(BlockUtil.getState(var1), false);
   }

   private EntityPlayer getClosestTarget() {
      if (mc.world.playerEntities.isEmpty()) {
         return null;
      } else {
         EntityPlayer var1 = null;

         for(EntityPlayer var3 : mc.world.playerEntities) {
            if (var3 == mc.player) {
               boolean var7 = false;
            } else if (!EntityUtil.isLiving(var3)) {
               boolean var6 = false;
            } else if (var3.getHealth() <= 0.0F) {
               boolean var5 = false;
            } else if (var1 != null && mc.player.getDistance(var3) > mc.player.getDistance(var1)) {
               boolean var4 = false;
            } else {
               var1 = var3;
               boolean var10000 = false;
            }
         }

         return var1;
      }
   }

   @Override
   public void onEnable() {
      if (mc.player != null) {
         this.newSlot = this.getHotbarItem();
         if (this.newSlot == -1) {
            this.sendMessage(
               String.valueOf(
                  new StringBuilder().append("[").append(this.getName()).append("] ").append(ChatFormatting.RED).append("No Webs in hotbar. disabling...")
               )
            );
            this.disable();
         }
      }
   }

   private boolean isSafe() {
      BlockPos var1 = this.getFloorPos();
      boolean var10000;
      if (mc.world.getBlockState(var1.east()).getBlock() != Blocks.AIR
         && mc.world.getBlockState(var1.west()).getBlock() != Blocks.AIR
         && mc.world.getBlockState(var1.north()).getBlock() != Blocks.AIR
         && mc.world.getBlockState(var1.south()).getBlock() != Blocks.AIR
         && mc.world.getBlockState(var1).getBlock() == Blocks.AIR) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void placeBlock(BlockPos var1) {
      if (mc.world.getBlockState(var1).getMaterial().isReplaceable()) {
         if (this.checkForNeighbours(var1)) {
            for(EnumFacing var5 : EnumFacing.values()) {
               BlockPos var6 = var1.offset(var5);
               EnumFacing var7 = var5.getOpposite();
               if (this.canBeClicked(var6)) {
                  if (this.blackList.contains(mc.world.getBlockState(var6).getBlock())) {
                     mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
                     this.sneak = true;
                  }

                  Vec3d var8 = new Vec3d(var6).add(0.5, 0.5, 0.5).add(new Vec3d(var7.getDirectionVec()).scale(0.5));
                  if (this.rotate.getValue()) {
                     Managers.ROTATIONS.lookAtVec3dPacket(var8);
                  }

                  mc.playerController.processRightClickBlock(mc.player, mc.world, var6, var7, var8, EnumHand.MAIN_HAND);
                  boolean var10 = false;
                  mc.player.swingArm(EnumHand.MAIN_HAND);
                  return;
               }

               boolean var10000 = false;
               var10000 = false;
            }
         }
      }
   }

   @Override
   public void onUpdate() {
      if (!fullNullCheck()) {
         if (this.smart.getValue()) {
            EntityPlayer var1 = this.getClosestTarget();
            if (var1 == null) {
               return;
            }

            if (Managers.FRIENDS.isFriend(var1.getName())) {
               return;
            }

            if (mc.player.getDistance(var1) < (float)this.enemyRange.getValue().intValue() && this.isSafe()) {
               int var2 = mc.player.inventory.currentItem;
               InventoryUtil.doSwap(this.newSlot);
               this.placeBlock(this.getFloorPos());
               InventoryUtil.doSwap(var2);
            }

            boolean var10000 = false;
         } else {
            int var3 = mc.player.inventory.currentItem;
            InventoryUtil.doSwap(this.newSlot);
            this.placeBlock(this.getFloorPos());
            InventoryUtil.doSwap(var3);
            this.disable();
         }
      }
   }

   private boolean checkForNeighbours(BlockPos var1) {
      if (!this.hasNeighbour(var1)) {
         for(EnumFacing var5 : EnumFacing.values()) {
            BlockPos var6 = var1.offset(var5);
            if (this.hasNeighbour(var6)) {
               return true;
            }

            boolean var10000 = false;
         }

         return false;
      } else {
         return true;
      }
   }

   public SelfWeb() {
      super("SelfWeb", "Places webs at your feet", Category.COMBAT);
      this.enemyRange = this.add(new Setting<>("EnemyRange", 4, 0, 8, this::lambda$new$0));
      this.newSlot = -1;
   }

   private int getHotbarItem() {
      for(int var1 = 0; var1 < 9; ++var1) {
         ItemStack var2 = mc.player.inventory.getStackInSlot(var1);
         if (var2.getItem() == Item.getItemById(30)) {
            return var1;
         }

         boolean var10000 = false;
      }

      return -1;
   }

   private boolean hasNeighbour(BlockPos var1) {
      for(EnumFacing var5 : EnumFacing.values()) {
         BlockPos var6 = var1.offset(var5);
         if (!mc.world.getBlockState(var6).getMaterial().isReplaceable()) {
            return true;
         }

         boolean var10000 = false;
      }

      return false;
   }

   private BlockPos getFloorPos() {
      return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
   }
}
