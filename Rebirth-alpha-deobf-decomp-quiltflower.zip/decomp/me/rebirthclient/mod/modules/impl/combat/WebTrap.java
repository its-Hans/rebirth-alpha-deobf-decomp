package me.rebirthclient.mod.modules.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockWeb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class WebTrap extends Module {
   private final Setting<Double> range = this.add(new Setting<>("Range", 5.0, 0.0, 7.0));
   private final Setting<Boolean> face;
   private final Setting<Boolean> line;
   public static boolean isPlacing;
   private final Setting<Boolean> packet;
   private int lastHotbarSlot;
   private final Setting<Boolean> feet;
   private final Timer timer;
   private boolean didPlace;
   private BlockPos startPos;
   private final Map<BlockPos, Long> renderBlocks;
   private final Setting<Boolean> disable;
   private boolean isSneaking;
   private final Setting<Integer> delay = this.add(new Setting<>("TickDelay", 50, 0, 250));
   private final Setting<Boolean> raytrace;
   private final Setting<Integer> blocksPerPlace = this.add(new Setting<>("BPT", 1, 1, 30));
   private final Setting<Boolean> render;
   private final Timer renderTimer;
   private EntityPlayer target;
   private int placements;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> box;

   private static double lambda$placeList$4(Vec3d var0) {
      return var0.y;
   }

   public WebTrap() {
      super("WebTrap", "Traps other players in webs", Category.COMBAT);
      this.packet = this.add(new Setting<>("Packet", false));
      this.disable = this.add(new Setting<>("AutoDisable", false));
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.raytrace = this.add(new Setting<>("Raytrace", false));
      this.feet = this.add(new Setting<>("Feet", true));
      this.face = this.add(new Setting<>("Face", false));
      this.render = this.add(new Setting<>("Render", true).setParent());
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$0));
      this.line = this.add(new Setting<>("Line", true, this::lambda$new$1));
      this.timer = new Timer();
      this.renderBlocks = new ConcurrentHashMap<>();
      this.renderTimer = new Timer();
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.render.isOpen();
   }

   private EntityPlayer getTarget(double var1) {
      EntityPlayer var3 = null;
      double var4 = Math.pow(var1, 2.0) + 1.0;

      for(EntityPlayer var7 : mc.world.playerEntities) {
         if (EntityUtil.isValid(var7, var1) && !var7.isInWeb) {
            if (Managers.SPEED.getPlayerSpeed(var7) > 30.0) {
               boolean var10000 = false;
            } else if (var3 == null) {
               var3 = var7;
               var4 = mc.player.getDistanceSq(var7);
               boolean var8 = false;
            } else if (!(mc.player.getDistanceSq(var7) < var4)) {
               boolean var9 = false;
            } else {
               var3 = var7;
               var4 = mc.player.getDistanceSq(var7);
               boolean var10 = false;
            }
         }
      }

      return var3;
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.render.isOpen();
   }

   private void lambda$onRender3D$2(BlockPos var1, Long var2) {
      short var3 = 255;
      byte var4 = 80;
      if (System.currentTimeMillis() - var2 > 400L) {
         this.renderTimer.reset();
         boolean var10000 = false;
         this.renderBlocks.remove(var1);
         var10000 = false;
         var10000 = false;
      } else {
         long var5 = System.currentTimeMillis() - var2 - 100L;
         double var7 = MathUtil.normalize((double)var5, 0.0, 500.0);
         var7 = MathHelper.clamp(var7, 0.0, 1.0);
         var7 = -var7 + 1.0;
         int var9 = (int)(var7 * (double)var3);
         int var10 = (int)(var7 * (double)var4);
         RenderUtil.drawBoxESP(
            new BlockPos(var1),
            Managers.COLORS.getCurrent(),
            true,
            new Color(255, 255, 255, var9),
            0.7F,
            this.line.getValue(),
            this.box.getValue(),
            var10,
            true,
            0.0
         );
      }
   }

   @SubscribeEvent
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled()) {
         if (var1.getPacket() instanceof SPacketBlockChange && this.renderBlocks.containsKey(((SPacketBlockChange)var1.getPacket()).getBlockPosition())) {
            this.renderTimer.reset();
            boolean var10000 = false;
            if (((SPacketBlockChange)var1.getPacket()).getBlockState().getBlock() != Blocks.AIR && this.renderTimer.passedMs(400L)) {
               this.renderBlocks.remove(((SPacketBlockChange)var1.getPacket()).getBlockPosition());
               var10000 = false;
            }
         }
      }
   }

   @Override
   public void onDisable() {
      isPlacing = false;
      this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
      InventoryUtil.doSwap(this.lastHotbarSlot);
   }

   private void doWebTrap() {
      List var1 = this.getPlacements();
      this.placeList(var1);
   }

   @Override
   public void onEnable() {
      if (!fullNullCheck()) {
         this.startPos = EntityUtil.getRoundedPos(mc.player);
         this.lastHotbarSlot = mc.player.inventory.currentItem;
      }
   }

   @Override
   public void onTick() {
      this.doTrap();
   }

   private boolean check() {
      isPlacing = false;
      this.didPlace = false;
      this.placements = 0;
      int var1 = InventoryUtil.findHotbarClass(BlockWeb.class);
      if (this.isOff()) {
         return true;
      } else if (this.disable.getValue() && !this.startPos.equals(EntityUtil.getRoundedPos(mc.player))) {
         this.disable();
         return true;
      } else if (var1 == -1) {
         this.sendMessage(
            String.valueOf(
               new StringBuilder().append("[").append(this.getName()).append("] ").append(ChatFormatting.RED).append("No webs in hotbar. disabling...")
            )
         );
         this.disable();
         return true;
      } else {
         if (mc.player.inventory.currentItem != this.lastHotbarSlot && mc.player.inventory.currentItem != var1) {
            this.lastHotbarSlot = mc.player.inventory.currentItem;
         }

         this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
         this.target = this.getTarget(this.range.getValue());
         boolean var10000;
         if (this.target != null && this.timer.passedMs((long)this.delay.getValue().intValue())) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var10001 = false;
         }

         return var10000;
      }
   }

   @Override
   public String getInfo() {
      return this.target != null ? this.target.getName() : null;
   }

   private void placeList(List<Vec3d> var1) {
      var1.sort(WebTrap::lambda$placeList$3);
      var1.sort(Comparator.comparingDouble(WebTrap::lambda$placeList$4));

      for(Vec3d var3 : var1) {
         BlockPos var4 = new BlockPos(var3);
         int var5 = BlockUtil.getPlaceAbility(var4, this.raytrace.getValue());
         if (var5 != 3 && var5 != 1) {
            boolean var8 = false;
         } else {
            int var6 = InventoryUtil.findHotbarClass(BlockWeb.class);
            InventoryUtil.doSwap(var6);
            this.renderBlocks.put(var4, System.currentTimeMillis());
            boolean var10000 = false;
            this.placeBlock(var4);
            InventoryUtil.doSwap(this.lastHotbarSlot);
            var10000 = false;
         }
      }
   }

   private List<Vec3d> getPlacements() {
      ArrayList var1 = new ArrayList();
      Vec3d var2 = this.target.getPositionVector();
      if (this.feet.getValue()) {
         var1.add(var2);
         boolean var10000 = false;
      }

      if (this.face.getValue()) {
         var1.add(var2.add(0.0, 1.0, 0.0));
         boolean var3 = false;
      }

      return var1;
   }

   private void placeBlock(BlockPos var1) {
      if (this.placements < this.blocksPerPlace.getValue() && mc.player.getDistanceSq(var1) <= MathUtil.square(6.0)) {
         isPlacing = true;
         Managers.INTERACTIONS.placeBlock(var1, this.rotate.getValue(), this.packet.getValue(), false, true);
         this.didPlace = true;
         ++this.placements;
      }
   }

   private static int lambda$placeList$3(Vec3d var0, Vec3d var1) {
      return Double.compare(mc.player.getDistanceSq(var1.x, var1.y, var1.z), mc.player.getDistanceSq(var0.x, var0.y, var0.z));
   }

   private void doTrap() {
      if (!this.check()) {
         this.doWebTrap();
         if (this.didPlace) {
            this.timer.reset();
            boolean var10000 = false;
         }
      }
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (this.render.getValue()) {
         this.renderTimer.reset();
         boolean var10000 = false;
         this.renderBlocks.forEach(this::lambda$onRender3D$2);
      }
   }
}
