package me.rebirthclient.mod.modules.impl.combat;

import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.CrystalUtil;
import me.rebirthclient.api.util.DamageUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class CatCrystal extends Module {
   private final Setting<Boolean> onlyFood;
   private final Setting<Boolean> slowFace;
   private final Setting<Boolean> Break;
   private final Setting<Integer> boxAlpha;
   private final Timer faceTimer;
   private final Setting<Color> color;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> outline;
   private final Setting<Boolean> terrainIgnore;
   private final Setting<Double> extraPlaceDamage;
   private final Setting<Integer> slowDelay;
   private final Setting<Boolean> collision;
   private final Setting<Boolean> text;
   private final Timer noPosTimer;
   private EntityPlayer displayTarget;
   private final Setting<Double> breakMaxSelf;
   private final Setting<Boolean> box;
   private float lastYaw;
   private AxisAlignedBB lastBB;
   private float lastPitch;
   private final Setting<Integer> maxDura;
   private final Setting<Double> slowMinDamage;
   private final Setting<Integer> outlineAlpha;
   private final Setting<Integer> placeDelay;
   private final Setting<Boolean> breakOnlyHasCrystal;
   private final Setting<Integer> breakDelay;
   private final Setting<Integer> fadeTime;
   private final Setting<Boolean> render;
   private final Setting<Double> targetRange;
   private final Setting<Integer> updateDelay;
   private final Setting<Double> placeMinDamage;
   private final Timer placeTimer;
   private BigDecimal lastDamage;
   private final Setting<Integer> animationTime;
   private final Setting<Boolean> noUsing;
   private final Setting<Integer> maxTarget;
   private BlockPos renderPos;
   private final Setting<Double> preferBreakDamage;
   private final Setting<CatCrystal.Pages> page = this.add(new Setting<>("Page", CatCrystal.Pages.General));
   private final Setting<Double> antiSuicide;
   public static CatCrystal INSTANCE;
   private final Setting<Integer> predictTicks;
   private final Setting<Double> breakMinDamage;
   private final Timer delayTimer;
   private final Setting<Boolean> armorBreaker;
   private final Setting<Integer> startTime;
   private final FadeUtils fadeUtils;
   private int lastHotbar;
   private final Setting<Boolean> place;
   private final Setting<Integer> switchCooldown;
   private AxisAlignedBB nowBB;
   private final FadeUtils animation;
   private final Setting<Float> crystalRange;
   private final Setting<Double> armorBreakerDamage;
   private final Setting<Boolean> extraPlace;
   private final Setting<Double> placeRange;
   private final Setting<Double> breakRange;
   private final Setting<Double> placeMaxSelf;
   private final Setting<CatCrystal.SwapMode> autoSwap;
   private final Setting<Double> wallRange;
   public static BlockPos lastPos;
   private final Timer switchTimer;

   private boolean lambda$new$25(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$33(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      return this.displayTarget != null ? this.displayTarget.getName() : null;
   }

   public static boolean behindWall(BlockPos var0) {
      RayTraceResult var1 = mc.world
         .rayTraceBlocks(
            new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
            new Vec3d((double)var0.getX() + 0.5, (double)var0.getY() - 0.5, (double)var0.getZ() + 0.5)
         );
      if (var1 != null
         && var1.sideHit != null
         && mc.world
               .rayTraceBlocks(
                  new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
                  new Vec3d((double)var0.getX() + 0.5, (double)var0.getY(), (double)var0.getZ() + 0.5),
                  false,
                  true,
                  false
               )
            == null) {
         return false;
      } else {
         boolean var10000;
         if (mc.player.getDistance((double)var0.getX() + 0.5, (double)var0.getY(), (double)var0.getZ() + 0.5) > INSTANCE.wallRange.getValue()) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private boolean lambda$new$32(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public CatCrystal() {
      super("CatCrystal", "ez", Category.COMBAT);
      this.rotate = this.add(new Setting<>("Rotate", true, this::lambda$new$0));
      this.noUsing = this.add(new Setting<>("NoUsing", true, this::lambda$new$1).setParent());
      this.onlyFood = this.add(new Setting<>("OnlyFood", false, this::lambda$new$2));
      this.switchCooldown = this.add(new Setting<>("SwitchCooldown", 100, 0, 1000, this::lambda$new$3));
      this.antiSuicide = this.add(new Setting<>("AntiSuicide", 3.0, 0.0, 10.0, this::lambda$new$4));
      this.wallRange = this.add(new Setting<>("WallRange", 3.0, 0.0, 6.0, this::lambda$new$5));
      this.maxTarget = this.add(new Setting<>("MaxTarget", 3, 1, 6, this::lambda$new$6));
      this.crystalRange = this.add(new Setting<>("CrystalRange", 6.0F, 0.0F, 16.0F, this::lambda$new$7));
      this.targetRange = this.add(new Setting<>("TargetRange", 6.0, 0.0, 16.0, this::lambda$new$8));
      this.updateDelay = this.add(new Setting<>("UpdateDelay", 50, 0, 1000, this::lambda$new$9));
      this.place = this.add(new Setting<>("Place", true, this::lambda$new$10));
      this.placeDelay = this.add(new Setting<>("PlaceDelay", 300, 0, 1000, this::lambda$new$11));
      this.placeRange = this.add(new Setting<>("PlaceRange", 5.0, 0.0, 6, this::lambda$new$12));
      this.placeMinDamage = this.add(new Setting<>("PlaceMin", 5.0, 0.0, 36.0, this::lambda$new$13));
      this.placeMaxSelf = this.add(new Setting<>("PlaceMaxSelf", 12.0, 0.0, 36.0, this::lambda$new$14));
      this.autoSwap = this.add(new Setting<>("AutoSwap", CatCrystal.SwapMode.OFF, this::lambda$new$15));
      this.extraPlace = this.add(new Setting<>("ExtraPlace", true, this::lambda$new$16).setParent());
      this.extraPlaceDamage = this.add(new Setting<>("ExtraDamage", 8.0, 0.0, 36.0, this::lambda$new$17));
      this.Break = this.add(new Setting<>("Break", true, this::lambda$new$18));
      this.breakDelay = this.add(new Setting<>("BreakDelay", 300, 0, 1000, this::lambda$new$19));
      this.breakRange = this.add(new Setting<>("BreakRange", 5.0, 0.0, 6.0, this::lambda$new$20));
      this.breakMinDamage = this.add(new Setting<>("BreakMin", 4.0, 0.0, 36.0, this::lambda$new$21));
      this.breakMaxSelf = this.add(new Setting<>("SelfBreak", 12.0, 0.0, 36.0, this::lambda$new$22));
      this.preferBreakDamage = this.add(new Setting<>("PreferBreak", 8.0, 0.0, 36.0, this::lambda$new$23));
      this.breakOnlyHasCrystal = this.add(new Setting<>("OnlyHasCrystal", false, this::lambda$new$24));
      this.render = this.add(new Setting<>("Render", true, this::lambda$new$25));
      this.outline = this.add(new Setting<>("Outline", true, this::lambda$new$26).setParent());
      this.outlineAlpha = this.add(new Setting<>("OutlineAlpha", 150, 0, 255, this::lambda$new$27));
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$28).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 70, 0, 255, this::lambda$new$29));
      this.text = this.add(new Setting<>("DamageText", true, this::lambda$new$30));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255), this::lambda$new$31).hideAlpha());
      this.animationTime = this.add(new Setting<>("AnimationTime", 500, 0, 3000, this::lambda$new$32));
      this.startTime = this.add(new Setting<>("StartFadeTime", 300, 0, 2000, this::lambda$new$33));
      this.fadeTime = this.add(new Setting<>("FadeTime", 300, 0, 2000, this::lambda$new$34));
      this.predictTicks = this.add(new Setting<>("PredictTicks", 4, 0, 10, this::lambda$new$35));
      this.collision = this.add(new Setting<>("Collision", false, this::lambda$new$36));
      this.terrainIgnore = this.add(new Setting<>("TerrainIgnore", false, this::lambda$new$37));
      this.slowFace = this.add(new Setting<>("SlowFace", true, this::lambda$new$38).setParent());
      this.slowDelay = this.add(new Setting<>("SlowDelay", 600, 0, 2000, this::lambda$new$39));
      this.slowMinDamage = this.add(new Setting<>("SlowMin", 3.0, 0.0, 36.0, this::lambda$new$40));
      this.armorBreaker = this.add(new Setting<>("ArmorBreaker", true, this::lambda$new$41).setParent());
      this.maxDura = this.add(new Setting<>("MaxDura", 8, 0, 100, this::lambda$new$42));
      this.armorBreakerDamage = this.add(new Setting<>("BreakerDamage", 3.0, 0.0, 36.0, this::lambda$new$43));
      this.switchTimer = new Timer();
      this.delayTimer = new Timer();
      this.placeTimer = new Timer();
      this.faceTimer = new Timer();
      this.lastYaw = 0.0F;
      this.lastPitch = 0.0F;
      this.lastHotbar = -1;
      this.noPosTimer = new Timer();
      this.renderPos = null;
      this.lastBB = null;
      this.nowBB = null;
      this.fadeUtils = new FadeUtils(500L);
      this.animation = new FadeUtils(500L);
      INSTANCE = this;
   }

   private boolean lambda$new$27(Integer var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$30(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$40(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Misc && this.slowFace.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$20(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break && this.Break.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$35(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Predict) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void doBreak(EntityEnderCrystal var1, double var2) {
      this.faceTimer.reset();
      boolean var10000 = false;
      if (this.Break.getValue()) {
         lastPos = EntityUtil.getEntityPos(var1);
         float[] var4 = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(var1.posX, var1.posY + 0.25, var1.posZ));
         this.lastYaw = var4[0];
         this.lastPitch = var4[1];
         this.lastDamage = BigDecimal.valueOf(var2).setScale(1, RoundingMode.UP);
         if (CombatUtil.breakTimer.passedMs((long)this.breakDelay.getValue().intValue())) {
            CombatUtil.breakTimer.reset();
            var10000 = false;
            mc.player.connection.sendPacket(new CPacketUseEntity(var1));
            mc.player.swingArm(EnumHand.MAIN_HAND);
            if (this.rotate.getValue()) {
               EntityUtil.faceXYZ(var1.posX, var1.posY + 0.25, var1.posZ);
            }

            if (this.placeTimer.passedMs((long)this.placeDelay.getValue().intValue())
               && this.extraPlace.getValue()
               && !(var2 < this.extraPlaceDamage.getValue())) {
               this.placeTimer.reset();
               var10000 = false;
               if (mc.player.getHeldItemMainhand().getItem().equals(Items.END_CRYSTAL) || mc.player.getHeldItemOffhand().getItem().equals(Items.END_CRYSTAL)) {
                  BlockUtil.placeCrystal(lastPos, this.rotate.getValue());
                  var10000 = false;
               } else if (this.findCrystal()) {
                  int var5 = mc.player.inventory.currentItem;
                  int var6 = -1;
                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.NORMAL || this.autoSwap.getValue() == CatCrystal.SwapMode.SILENT) {
                     var6 = InventoryUtil.findItemInHotbar(Items.END_CRYSTAL);
                     if (var6 == -1) {
                        return;
                     }

                     InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.END_CRYSTAL));
                  }

                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.BYPASS) {
                     var6 = InventoryUtil.findItemInventorySlot(Items.END_CRYSTAL, true, true);
                     if (var6 == -1) {
                        return;
                     }

                     mc.playerController.windowClick(0, var6, var5, ClickType.SWAP, mc.player);
                     var10000 = false;
                  }

                  BlockUtil.placeCrystal(lastPos, this.rotate.getValue());
                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.SILENT && var6 != -1) {
                     InventoryUtil.doSwap(var5);
                  }

                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.BYPASS && var6 != -1) {
                     mc.playerController.windowClick(0, var6, var5, ClickType.SWAP, mc.player);
                     var10000 = false;
                  }
               }
            }
         }
      }
   }

   private boolean lambda$new$39(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Misc && this.slowFace.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$43(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Misc && this.armorBreaker.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onUpdateWalk(UpdateWalkingPlayerEvent var1) {
      this.update();
   }

   private boolean lambda$new$38(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Misc) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$28(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$31(Color var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private double getPlaceDamage(EntityPlayer var1) {
      if (this.slowFace.getValue() && this.faceTimer.passedMs((long)this.slowDelay.getValue().intValue())) {
         return this.slowMinDamage.getValue();
      } else {
         if (this.armorBreaker.getValue()) {
            ItemStack var2 = var1.inventoryContainer.getSlot(5).getStack();
            ItemStack var3 = var1.inventoryContainer.getSlot(6).getStack();
            ItemStack var4 = var1.inventoryContainer.getSlot(7).getStack();
            ItemStack var5 = var1.inventoryContainer.getSlot(8).getStack();
            if (!var2.isEmpty && EntityUtil.getDamagePercent(var2) <= this.maxDura.getValue()
               || !var3.isEmpty && EntityUtil.getDamagePercent(var3) <= this.maxDura.getValue()
               || !var4.isEmpty && EntityUtil.getDamagePercent(var4) <= this.maxDura.getValue()
               || !var5.isEmpty && EntityUtil.getDamagePercent(var5) <= this.maxDura.getValue()) {
               return this.armorBreakerDamage.getValue();
            }
         }

         return this.placeMinDamage.getValue();
      }
   }

   private boolean lambda$new$36(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Predict) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$17(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue() && this.extraPlace.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$42(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Misc && this.armorBreaker.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$23(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break && this.Break.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$24(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break && this.Break.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$29(Integer var1) {
      boolean var10000;
      if (this.box.isOpen() && this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$22(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break && this.Break.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (var1.getPacket() instanceof CPacketHeldItemChange && ((CPacketHeldItemChange)var1.getPacket()).getSlotId() != this.lastHotbar) {
            this.lastHotbar = ((CPacketHeldItemChange)var1.getPacket()).getSlotId();
            this.switchTimer.reset();
            boolean var10000 = false;
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$41(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Misc) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void doPlace(BlockPos var1) {
      if (this.place.getValue()) {
         if (!mc.player.getHeldItemMainhand().getItem().equals(Items.END_CRYSTAL)
            && !mc.player.getHeldItemOffhand().getItem().equals(Items.END_CRYSTAL)
            && !this.findCrystal()) {
            lastPos = null;
         } else {
            lastPos = var1;
            RayTraceResult var2 = mc.world
               .rayTraceBlocks(
                  new Vec3d(mc.player.posX, mc.player.posY + (double)mc.player.getEyeHeight(), mc.player.posZ),
                  new Vec3d((double)var1.getX() + 0.5, (double)var1.getY() - 0.5, (double)var1.getZ() + 0.5)
               );
            EnumFacing var10000;
            if (var2 != null && var2.sideHit != null) {
               var10000 = var2.sideHit;
            } else {
               var10000 = EnumFacing.UP;
               boolean var10001 = false;
            }

            EnumFacing var3 = var10000;
            var1 = var1.down();
            this.lastDamage = BigDecimal.valueOf(
                  (double)CrystalUtil.calculateDamage(
                     var1, this.displayTarget, this.predictTicks.getValue(), this.collision.getValue(), this.terrainIgnore.getValue()
                  )
               )
               .setScale(1, RoundingMode.UP);
            EnumFacing var4 = var3.getOpposite();
            Vec3d var5 = new Vec3d(var1.up()).add(0.5, 0.5, 0.5).add(new Vec3d(var4.getDirectionVec()).scale(0.5));
            float[] var6 = EntityUtil.getLegitRotations(var5);
            this.lastYaw = var6[0];
            this.lastPitch = var6[1];
            if (this.placeTimer.passedMs((long)this.placeDelay.getValue().intValue())) {
               this.placeTimer.reset();
               boolean var10 = false;
               if (mc.player.getHeldItemMainhand().getItem().equals(Items.END_CRYSTAL) || mc.player.getHeldItemOffhand().getItem().equals(Items.END_CRYSTAL)) {
                  BlockUtil.placeCrystal(var1.up(), this.rotate.getValue());
                  boolean var13 = false;
               } else if (this.findCrystal()) {
                  int var7 = mc.player.inventory.currentItem;
                  int var8 = -1;
                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.NORMAL || this.autoSwap.getValue() == CatCrystal.SwapMode.SILENT) {
                     var8 = InventoryUtil.findItemInHotbar(Items.END_CRYSTAL);
                     if (var8 == -1) {
                        return;
                     }

                     InventoryUtil.doSwap(var8);
                  }

                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.BYPASS) {
                     var8 = InventoryUtil.findItemInventorySlot(Items.END_CRYSTAL, true, true);
                     if (var8 == -1) {
                        return;
                     }

                     mc.playerController.windowClick(0, var8, var7, ClickType.SWAP, mc.player);
                     boolean var11 = false;
                  }

                  BlockUtil.placeCrystal(var1.up(), this.rotate.getValue());
                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.SILENT && var8 != -1) {
                     InventoryUtil.doSwap(var7);
                  }

                  if (this.autoSwap.getValue() == CatCrystal.SwapMode.BYPASS && var8 != -1) {
                     mc.playerController.windowClick(0, var8, var7, ClickType.SWAP, mc.player);
                     boolean var12 = false;
                  }
               }
            }
         }
      }
   }

   private boolean lambda$new$11(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onUpdate() {
      this.update();
   }

   private boolean lambda$new$21(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break && this.Break.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$26(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$18(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void update() {
      if (!fullNullCheck()) {
         this.fadeUtils.setLength((long)this.fadeTime.getValue().intValue());
         if (lastPos != null) {
            this.lastBB = mc.world.getBlockState(new BlockPos(lastPos.down())).getSelectedBoundingBox(mc.world, new BlockPos(lastPos.down()));
            this.noPosTimer.reset();
            boolean var10000 = false;
            if (this.nowBB == null) {
               this.nowBB = this.lastBB;
            }

            if (this.renderPos == null || !this.renderPos.equals(lastPos)) {
               FadeUtils var20 = this.animation;
               long var10001;
               if (this.animationTime.getValue() <= 0) {
                  var10001 = 0L;
                  boolean var10002 = false;
               } else {
                  var10001 = (long)(
                     (
                           Math.abs(this.nowBB.minX - this.lastBB.minX)
                              + Math.abs(this.nowBB.minY - this.lastBB.minY)
                              + Math.abs(this.nowBB.minZ - this.lastBB.minZ)
                        )
                        * (double)this.animationTime.getValue().intValue()
                  );
               }

               var20.setLength(var10001);
               this.animation.reset();
               this.renderPos = lastPos;
            }
         }

         if (!this.noPosTimer.passedMs((long)this.startTime.getValue().intValue())) {
            this.fadeUtils.reset();
         }

         double var1 = this.animation.easeInQuad();
         if (this.nowBB != null && this.lastBB != null) {
            if (Math.abs(this.nowBB.minX - this.lastBB.minX) + Math.abs(this.nowBB.minY - this.lastBB.minY) + Math.abs(this.nowBB.minZ - this.lastBB.minZ)
               > 5.0) {
               this.nowBB = this.lastBB;
            }

            this.nowBB = new AxisAlignedBB(
               this.nowBB.minX + (this.lastBB.minX - this.nowBB.minX) * var1,
               this.nowBB.minY + (this.lastBB.minY - this.nowBB.minY) * var1,
               this.nowBB.minZ + (this.lastBB.minZ - this.nowBB.minZ) * var1,
               this.nowBB.maxX + (this.lastBB.maxX - this.nowBB.maxX) * var1,
               this.nowBB.maxY + (this.lastBB.maxY - this.nowBB.maxY) * var1,
               this.nowBB.maxZ + (this.lastBB.maxZ - this.nowBB.maxZ) * var1
            );
         }

         if (this.delayTimer.passedMs((long)this.updateDelay.getValue().intValue())) {
            if (!this.noUsing.getValue() || !EntityUtil.isEating() && (!mc.player.isHandActive() || this.onlyFood.getValue())) {
               if (!this.switchTimer.passedMs((long)this.switchCooldown.getValue().intValue())) {
                  lastPos = null;
               } else if (this.breakOnlyHasCrystal.getValue()
                  && !mc.player.getHeldItemMainhand().getItem().equals(Items.END_CRYSTAL)
                  && !mc.player.getHeldItemOffhand().getItem().equals(Items.END_CRYSTAL)
                  && !this.findCrystal()) {
                  lastPos = null;
               } else {
                  this.delayTimer.reset();
                  int var3 = 0;
                  EntityEnderCrystal var4 = null;
                  float var5 = 0.0F;
                  BlockPos var6 = null;
                  float var7 = 0.0F;
                  EntityPlayer var8 = null;
                  EntityPlayer var9 = null;

                  for(EntityPlayer var11 : mc.world.playerEntities) {
                     if (EntityUtil.invalid(var11, this.targetRange.getValue())) {
                        boolean var38 = false;
                     } else {
                        if (var3 >= this.maxTarget.getValue()) {
                           boolean var37 = false;
                           break;
                        }

                        ++var3;

                        for(Entity var13 : mc.world.loadedEntityList) {
                           if (!(var13 instanceof EntityEnderCrystal)) {
                              boolean var28 = false;
                           } else if (var11.getDistance(var13) > this.crystalRange.getValue()) {
                              boolean var27 = false;
                           } else if ((double)mc.player.getDistance(var13) > this.breakRange.getValue()) {
                              boolean var26 = false;
                           } else if (!mc.player.canEntityBeSeen(var13) && (double)mc.player.getDistance(var13) > this.wallRange.getValue()) {
                              boolean var25 = false;
                           } else {
                              float var14 = CrystalUtil.calculateDamage(
                                 (EntityEnderCrystal)var13, var11, this.predictTicks.getValue(), this.collision.getValue(), this.terrainIgnore.getValue()
                              );
                              float var15 = DamageUtil.calculateDamage(var13, mc.player);
                              if ((double)var15 > this.breakMaxSelf.getValue()) {
                                 boolean var24 = false;
                              } else if (this.antiSuicide.getValue() > 0.0
                                 && (double)var15 > (double)(mc.player.getHealth() + mc.player.getAbsorptionAmount()) - this.antiSuicide.getValue()) {
                                 boolean var23 = false;
                              } else if ((double)var14 < this.getBreakDamage(var11)) {
                                 boolean var22 = false;
                              } else {
                                 if (var4 == null || var14 > var5) {
                                    var9 = var11;
                                    var4 = (EntityEnderCrystal)var13;
                                    var5 = var14;
                                 }

                                 boolean var21 = false;
                              }
                           }
                        }

                        if (mc.player.getHeldItemMainhand().getItem().equals(Items.END_CRYSTAL)
                           || mc.player.getHeldItemOffhand().getItem().equals(Items.END_CRYSTAL)
                           || this.findCrystal()) {
                           for(BlockPos var17 : BlockUtil.getBox(this.crystalRange.getValue(), EntityUtil.getEntityPos(var11).down())) {
                              if (!BlockUtil.canPlaceCrystal(var17)) {
                                 boolean var29 = false;
                              } else if (behindWall(var17)) {
                                 boolean var30 = false;
                              } else if (mc.player.getDistance((double)var17.getX() + 0.5, (double)var17.getY(), (double)var17.getZ() + 0.5)
                                 > this.placeRange.getValue()) {
                                 boolean var31 = false;
                              } else {
                                 float var18 = CrystalUtil.calculateDamage(
                                    var17.down(), var11, this.predictTicks.getValue(), this.collision.getValue(), this.terrainIgnore.getValue()
                                 );
                                 float var19 = DamageUtil.calculateDamage(var17.down(), mc.player);
                                 if ((double)var19 > this.placeMaxSelf.getValue()) {
                                    boolean var32 = false;
                                 } else if (this.antiSuicide.getValue() > 0.0
                                    && (double)var19 > (double)(mc.player.getHealth() + mc.player.getAbsorptionAmount()) - this.antiSuicide.getValue()) {
                                    boolean var35 = false;
                                 } else if ((double)var18 < this.getPlaceDamage(var11)) {
                                    boolean var33 = false;
                                 } else {
                                    if (var6 == null || var18 > var7) {
                                       var8 = var11;
                                       var6 = var17;
                                       var7 = var18;
                                    }

                                    boolean var34 = false;
                                 }
                              }
                           }
                        }

                        boolean var36 = false;
                     }
                  }

                  if (var6 == null && var4 == null) {
                     lastPos = null;
                     this.displayTarget = null;
                  } else if (var4 == null) {
                     this.displayTarget = var8;
                     this.doPlace(var6);
                  } else if (var6 == null) {
                     this.displayTarget = var9;
                     this.doBreak(var4, (double)var5);
                  } else {
                     if (!(var5 >= var7) && !((double)var5 >= this.preferBreakDamage.getValue())) {
                        this.displayTarget = var8;
                        this.doPlace(var6);
                     } else {
                        this.displayTarget = var9;
                        this.doBreak(var4, (double)var5);
                        boolean var39 = false;
                     }
                  }
               }
            } else {
               lastPos = null;
            }
         }
      }
   }

   private boolean findCrystal() {
      if (this.autoSwap.getValue() == CatCrystal.SwapMode.OFF) {
         return false;
      } else if (this.autoSwap.getValue() != CatCrystal.SwapMode.NORMAL && this.autoSwap.getValue() != CatCrystal.SwapMode.SILENT) {
         boolean var1;
         if (InventoryUtil.findItemInventorySlot(Items.END_CRYSTAL, true, true) != -1) {
            var1 = true;
            boolean var2 = false;
         } else {
            var1 = false;
         }

         return var1;
      } else {
         boolean var10000;
         if (InventoryUtil.findItemInHotbar(Items.END_CRYSTAL) != -1) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private boolean lambda$new$7(Float var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$14(Double var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$12(Number var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.noUsing.isOpen() && this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onMotion(MotionEvent var1) {
      if (!fullNullCheck()) {
         this.update();
         if (lastPos != null && this.rotate.getValue()) {
            var1.setYaw(this.lastYaw);
            var1.setPitch(this.lastPitch);
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.General) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      this.update();
      if (this.nowBB != null && this.render.getValue() && this.fadeUtils.easeOutQuad() < 1.0) {
         if (this.box.getValue()) {
            RenderUtil.drawBBFill(
               this.nowBB, this.color.getValue(), (int)((double)this.boxAlpha.getValue().intValue() * Math.abs(this.fadeUtils.easeOutQuad() - 1.0))
            );
         }

         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(
               this.nowBB, this.color.getValue(), (int)((double)this.outlineAlpha.getValue().intValue() * Math.abs(this.fadeUtils.easeOutQuad() - 1.0))
            );
         }

         if (this.text.getValue() && lastPos != null) {
            RenderUtil.drawText(this.nowBB, String.valueOf(this.lastDamage));
         }
      }
   }

   private boolean lambda$new$19(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Break && this.Break.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$34(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Render && this.render.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      this.update();
   }

   private boolean lambda$new$37(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Predict) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private double getBreakDamage(EntityPlayer var1) {
      if (this.slowFace.getValue() && this.faceTimer.passedMs((long)this.slowDelay.getValue().intValue())) {
         return this.slowMinDamage.getValue();
      } else {
         if (this.armorBreaker.getValue()) {
            ItemStack var2 = var1.inventoryContainer.getSlot(5).getStack();
            ItemStack var3 = var1.inventoryContainer.getSlot(6).getStack();
            ItemStack var4 = var1.inventoryContainer.getSlot(7).getStack();
            ItemStack var5 = var1.inventoryContainer.getSlot(8).getStack();
            if (!var2.isEmpty && EntityUtil.getDamagePercent(var2) <= this.maxDura.getValue()
               || !var3.isEmpty && EntityUtil.getDamagePercent(var3) <= this.maxDura.getValue()
               || !var4.isEmpty && EntityUtil.getDamagePercent(var4) <= this.maxDura.getValue()
               || !var5.isEmpty && EntityUtil.getDamagePercent(var5) <= this.maxDura.getValue()) {
               return this.armorBreakerDamage.getValue();
            }
         }

         return this.breakMinDamage.getValue();
      }
   }

   private boolean lambda$new$15(CatCrystal.SwapMode var1) {
      boolean var10000;
      if (this.page.getValue() == CatCrystal.Pages.Place && this.place.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Pages {
      General,
      Place,
      Misc,
      Render,
      Break,
      Predict;
      private static final CatCrystal.Pages[] $VALUES = new CatCrystal.Pages[]{
         General, Place, CatCrystal.Pages.Break, Misc, CatCrystal.Pages.Predict, CatCrystal.Pages.Render
      };
   }

   public static enum SwapMode {
      BYPASS,
      NORMAL,
      SILENT,
      OFF;
      private static final CatCrystal.SwapMode[] $VALUES = new CatCrystal.SwapMode[]{CatCrystal.SwapMode.OFF, NORMAL, SILENT, BYPASS};
   }
}
