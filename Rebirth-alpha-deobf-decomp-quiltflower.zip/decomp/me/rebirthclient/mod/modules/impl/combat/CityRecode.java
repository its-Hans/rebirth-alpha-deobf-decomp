package me.rebirthclient.mod.modules.impl.combat;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class CityRecode extends Module {
   private final Setting<Boolean> mineTrap;
   private final Setting<Boolean> prefer;
   private final Setting<Integer> outlineAlpha;
   private static EntityPlayer target;
   private BlockPos breakPos;
   private final Setting<Float> targetRange;
   private final Setting<Boolean> debug;
   private final Setting<Boolean> keyMode;
   private final Setting<Boolean> box;
   private final Setting<Boolean> autoDisable;
   private final Timer renderTimer;
   private final Setting<Integer> boxAlpha;
   private final Setting<Bind> keyBind;
   private FadeUtils shrinkTimer;
   private final Setting<Boolean> mineBurrow = this.add(new Setting<>("MineBurrow", true).setParent());
   private final Setting<Boolean> outline;
   private final List<Block> godBlocks;
   private final Setting<Color> color;
   private final Setting<Integer> shrinkTime;
   private final Setting<Boolean> onlyBurrow = this.add(new Setting<>("OnlyBurrow", false, this::lambda$new$0));
   private final Setting<Double> breakRange;
   private final Setting<Boolean> render;

   public CityRecode() {
      super("CityRecode", "", Category.COMBAT);
      this.mineTrap = this.add(new Setting<>("MineTrap", true).setParent());
      this.prefer = this.add(new Setting<>("Prefer", true, this::lambda$new$1));
      this.render = this.add(new Setting<>("Render", true).setParent());
      this.outline = this.add(new Setting<>("Outline", true, this::lambda$new$2).setParent());
      this.outlineAlpha = this.add(new Setting<>("OutlineAlpha", 150, 0, 255, this::lambda$new$3));
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$4).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 70, 0, 255, this::lambda$new$5));
      this.targetRange = this.add(new Setting<>("TargetRange", 5.0F, 1.0F, 8.0F));
      this.breakRange = this.add(new Setting<>("BreakRange", 4.5, 1.0, 8.0));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255), this::lambda$new$6).hideAlpha());
      this.shrinkTime = this.add(new Setting<>("ShrinkTime", 1200, 0, 3000, this::lambda$new$7));
      this.shrinkTimer = new FadeUtils((long)this.shrinkTime.getValue().intValue());
      this.keyMode = this.add(new Setting<>("KeyMode", true));
      this.keyBind = this.add(new Setting<>("Enable", new Bind(-1), this::lambda$new$8));
      this.autoDisable = this.add(new Setting<>("autoDisable", false, this::lambda$new$9));
      this.debug = this.add(new Setting<>("Debug", false));
      this.renderTimer = new Timer();
      this.godBlocks = Arrays.asList(Blocks.AIR, Blocks.FLOWING_LAVA, Blocks.LAVA, Blocks.FLOWING_WATER, Blocks.WATER, Blocks.BEDROCK);
   }

   private boolean doMineTrap(BlockPos var1, EnumFacing var2) {
      if (!this.isAir(var1.offset(var2)) && this.godBlocks.contains(this.getBlock(var1.offset(var2)))) {
         return false;
      } else if (!this.isAir(var1.offset(var2).up()) && this.godBlocks.contains(this.getBlock(var1.offset(var2).up()))) {
         return false;
      } else if (!this.isAir(var1.offset(var2).up())
         && (this.isAir(var1) || !this.godBlocks.contains(this.getBlock(var1.offset(var2))))
         && !this.godBlocks.contains(this.getBlock(var1.offset(var2).up()))) {
         this.mineBlock(var1.offset(var2).up());
         return true;
      } else {
         return this.MineSurround(var1, var2);
      }
   }

   private boolean lambda$new$5(Integer var1) {
      boolean var10000;
      if (this.render.isOpen() && this.box.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(Boolean var1) {
      return this.render.isOpen();
   }

   private boolean doMine(BlockPos var1) {
      if (!check(var1, target)) {
         return false;
      } else {
         double var2 = 0.0;
         EnumFacing var4 = null;
         if (this.prefer.getValue() && this.mineTrap.getValue()) {
            for(EnumFacing var8 : EnumFacing.VALUES) {
               if (this.doCheck(var1, var8)) {
                  boolean var10000 = false;
               } else {
                  int var9 = 0;
                  if (this.isAir(var1.offset(var8))) {
                     ++var9;
                  }

                  if (this.isAir(var1.offset(var8).up())) {
                     ++var9;
                  }

                  if (var9 < 1) {
                     boolean var67 = false;
                  } else if (var4 == null
                     || mc.player.getDistance((double)var1.offset(var8).getX() + 0.5, target.posY, (double)var1.offset(var8).getZ() + 0.5) < var2) {
                     var2 = mc.player.getDistance((double)var1.offset(var8).getX() + 0.5, target.posY, (double)var1.offset(var8).getZ() + 0.5);
                     var4 = var8;
                  }
               }

               boolean var68 = false;
            }

            if (var4 != null && this.doMineTrap(var1, var4)) {
               return true;
            }

            for(EnumFacing var51 : EnumFacing.VALUES) {
               if (this.doCheck(var1, var51)) {
                  boolean var69 = false;
               } else {
                  int var62 = 0;
                  if (this.isAir(var1.offset(var51))) {
                     ++var62;
                  }

                  if (this.isAir(var1.offset(var51).up())) {
                     ++var62;
                  }

                  if (var62 < 1) {
                     boolean var70 = false;
                  } else if (this.doMineTrap(var1, var51)) {
                     return true;
                  }
               }

               boolean var71 = false;
            }
         }

         var2 = 0.0;
         var4 = null;

         for(EnumFacing var52 : EnumFacing.VALUES) {
            if (check(var1.offset(var52), target)) {
               boolean var72 = false;
            } else if (this.cantMine(var1, var52, 2)) {
               boolean var73 = false;
            } else if (var4 == null
               || mc.player.getDistance((double)var1.offset(var52, 2).getX() + 0.5, target.posY, (double)var1.offset(var52, 2).getZ() + 0.5) < var2) {
               var2 = mc.player.getDistance((double)var1.offset(var52, 2).getX() + 0.5, target.posY, (double)var1.offset(var52, 2).getZ() + 0.5);
               var4 = var52;
            }

            boolean var74 = false;
         }

         if (var4 != null && this.doMineExtend(var1, var4)) {
            return true;
         } else {
            for(EnumFacing var53 : EnumFacing.VALUES) {
               if (check(var1.offset(var53), target)) {
                  boolean var75 = false;
               } else if (this.cantMine(var1, var53, 2)) {
                  boolean var76 = false;
               } else if (this.doMineExtend(var1, var53)) {
                  return true;
               }

               boolean var77 = false;
            }

            if (this.mineTrap.getValue()) {
               for(EnumFacing var54 : EnumFacing.VALUES) {
                  if (this.doCheck(var1, var54)) {
                     boolean var78 = false;
                  } else {
                     int var63 = 0;
                     if (this.isAir(var1.offset(var54))) {
                        ++var63;
                     }

                     if (this.isAir(var1.offset(var54).up())) {
                        ++var63;
                     }

                     if (var63 < 1) {
                        boolean var79 = false;
                     } else if (var4 == null
                        || mc.player.getDistance((double)var1.offset(var54).getX() + 0.5, target.posY, (double)var1.offset(var54).getZ() + 0.5) < var2) {
                        var2 = mc.player.getDistance((double)var1.offset(var54).getX() + 0.5, target.posY, (double)var1.offset(var54).getZ() + 0.5);
                        var4 = var54;
                     }
                  }

                  boolean var80 = false;
               }

               if (var4 != null && this.doMineTrap(var1, var4)) {
                  return true;
               }

               for(EnumFacing var55 : EnumFacing.VALUES) {
                  if (this.doCheck(var1, var55)) {
                     boolean var81 = false;
                  } else {
                     int var64 = 0;
                     if (this.isAir(var1.offset(var55))) {
                        ++var64;
                     }

                     if (this.isAir(var1.offset(var55).up())) {
                        ++var64;
                     }

                     if (var64 < 1) {
                        boolean var82 = false;
                     } else if (this.doMineTrap(var1, var55)) {
                        return true;
                     }
                  }

                  boolean var83 = false;
               }
            }

            if (this.prefer.getValue() && this.mineTrap.getValue() && this.MineTrapSurround(var1)) {
               return true;
            } else {
               var2 = 0.0;
               var4 = null;

               for(EnumFacing var56 : EnumFacing.VALUES) {
                  if (check(var1.offset(var56), target)) {
                     boolean var84 = false;
                  } else if (this.cantMine(var1, var56, 1)) {
                     boolean var85 = false;
                  } else if (var4 == null
                     || mc.player.getDistance((double)var1.offset(var56, 2).getX() + 0.5, target.posY, (double)var1.offset(var56, 2).getZ() + 0.5) < var2) {
                     var2 = mc.player.getDistance((double)var1.offset(var56, 2).getX() + 0.5, target.posY, (double)var1.offset(var56, 2).getZ() + 0.5);
                     var4 = var56;
                  }

                  boolean var86 = false;
               }

               if (var4 != null && this.doMineExtend(var1, var4)) {
                  return true;
               } else {
                  for(EnumFacing var57 : EnumFacing.VALUES) {
                     if (check(var1.offset(var57), target)) {
                        boolean var87 = false;
                     } else if (this.cantMine(var1, var57, 1)) {
                        boolean var88 = false;
                     } else if (this.doMineExtend(var1, var57)) {
                        return true;
                     }

                     boolean var89 = false;
                  }

                  var2 = 0.0;
                  var4 = null;

                  for(EnumFacing var58 : EnumFacing.VALUES) {
                     if (this.doCheckExtend(var1, var58)) {
                        boolean var90 = false;
                     } else if (var4 == null
                        || mc.player.getDistance((double)var1.offset(var58, 2).getX() + 0.5, target.posY, (double)var1.offset(var58, 2).getZ() + 0.5) < var2) {
                        var2 = mc.player.getDistance((double)var1.offset(var58, 2).getX() + 0.5, target.posY, (double)var1.offset(var58, 2).getZ() + 0.5);
                        var4 = var58;
                     }

                     boolean var91 = false;
                  }

                  if (var4 != null && this.doMineExtend(var1, var4)) {
                     return true;
                  } else {
                     for(EnumFacing var59 : EnumFacing.VALUES) {
                        if (this.doCheckExtend(var1, var59)) {
                           boolean var92 = false;
                        } else if (this.doMineExtend(var1, var59)) {
                           return true;
                        }

                        boolean var93 = false;
                     }

                     if (!this.mineTrap.getValue()) {
                        return true;
                     } else {
                        var2 = 0.0;
                        var4 = null;

                        for(EnumFacing var60 : EnumFacing.VALUES) {
                           if (this.doCheck(var1, var60)) {
                              boolean var94 = false;
                           } else {
                              int var65 = 0;
                              if (this.isAir(var1.offset(var60))) {
                                 ++var65;
                              }

                              if (this.isAir(var1.offset(var60).up())) {
                                 ++var65;
                              }

                              if (var65 < 1) {
                                 boolean var95 = false;
                              } else if (var4 == null
                                 || mc.player.getDistance((double)var1.offset(var60).getX() + 0.5, target.posY, (double)var1.offset(var60).getZ() + 0.5)
                                    < var2) {
                                 var2 = mc.player.getDistance((double)var1.offset(var60).getX() + 0.5, target.posY, (double)var1.offset(var60).getZ() + 0.5);
                                 var4 = var60;
                              }
                           }

                           boolean var96 = false;
                        }

                        if (var4 != null && this.doMineTrap(var1, var4)) {
                           return true;
                        } else {
                           for(EnumFacing var61 : EnumFacing.VALUES) {
                              if (this.doCheck(var1, var61)) {
                                 boolean var97 = false;
                              } else {
                                 int var66 = 0;
                                 if (this.isAir(var1.offset(var61))) {
                                    ++var66;
                                 }

                                 if (this.isAir(var1.offset(var61).up())) {
                                    ++var66;
                                 }

                                 if (var66 < 1) {
                                    boolean var98 = false;
                                 } else if (this.doMineTrap(var1, var61)) {
                                    return true;
                                 }
                              }

                              boolean var99 = false;
                           }

                           return this.MineTrapSurround(var1);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.mineTrap.isOpen();
   }

   private boolean MineTrapSurround(BlockPos var1) {
      if (this.debug.getValue()) {
         this.sendMessage("mine trap surround");
      }

      double var2 = 0.0;
      EnumFacing var4 = null;

      for(EnumFacing var8 : EnumFacing.VALUES) {
         if (this.doCheck(var1, var8)) {
            boolean var10000 = false;
         } else if (var4 == null || mc.player.getDistance((double)var1.offset(var8).getX() + 0.5, target.posY, (double)var1.offset(var8).getZ() + 0.5) < var2) {
            var2 = mc.player.getDistance((double)var1.offset(var8).getX() + 0.5, target.posY, (double)var1.offset(var8).getZ() + 0.5);
            var4 = var8;
         }

         boolean var13 = false;
      }

      if (var4 != null && this.doMineTrap(var1, var4)) {
         return true;
      } else {
         for(EnumFacing var12 : EnumFacing.VALUES) {
            if (this.doCheck(var1, var12)) {
               boolean var14 = false;
            } else if (this.doMineTrap(var1, var12)) {
               return true;
            }

            boolean var15 = false;
         }

         return false;
      }
   }

   @Override
   public void onUpdate() {
      if (!this.keyMode.getValue() || this.keyBind.getValue().isDown()) {
         target = CombatUtil.getTarget((double)this.targetRange.getValue().floatValue(), 10.0);
         if (target != null) {
            BlockPos var1 = EntityUtil.getEntityPos(target);
            if (!this.isAir(var1) && this.mineBurrow.getValue()) {
               this.mineBlock(var1);
               boolean var6 = false;
            } else if (!this.isAir(new BlockPos(target.posX + 0.1, target.posY + 0.5, target.posZ + 0.1))
               && this.mineBurrow.getValue()
               && !PacketMine.godBlocks.contains(this.getBlock(new BlockPos(target.posX + 0.1, target.posY + 0.5, target.posZ + 0.1)))) {
               this.mineBlock(new BlockPos(target.posX + 0.1, target.posY + 0.5, target.posZ + 0.1));
               boolean var5 = false;
            } else if (!this.isAir(new BlockPos(target.posX + 0.1, target.posY + 0.5, target.posZ - 0.1))
               && this.mineBurrow.getValue()
               && !PacketMine.godBlocks.contains(this.getBlock(new BlockPos(target.posX + 0.1, target.posY + 0.5, target.posZ - 0.1)))) {
               this.mineBlock(new BlockPos(target.posX + 0.1, target.posY + 0.5, target.posZ - 0.1));
               boolean var4 = false;
            } else if (!this.isAir(new BlockPos(target.posX - 0.1, target.posY + 0.5, target.posZ + 0.1))
               && this.mineBurrow.getValue()
               && !PacketMine.godBlocks.contains(this.getBlock(new BlockPos(target.posX - 0.1, target.posY + 0.5, target.posZ + 0.1)))) {
               this.mineBlock(new BlockPos(target.posX - 0.1, target.posY + 0.5, target.posZ + 0.1));
               boolean var3 = false;
            } else if (!this.isAir(new BlockPos(target.posX - 0.1, target.posY + 0.5, target.posZ - 0.1))
               && this.mineBurrow.getValue()
               && !PacketMine.godBlocks.contains(this.getBlock(new BlockPos(target.posX - 0.1, target.posY + 0.5, target.posZ - 0.1)))) {
               this.mineBlock(new BlockPos(target.posX - 0.1, target.posY + 0.5, target.posZ - 0.1));
               boolean var2 = false;
            } else if ((!this.mineBurrow.getValue() || !this.onlyBurrow.getValue()) && !this.canAttack(target, var1)) {
               if (this.debug.getValue()) {
                  this.sendMessage("do mine surround");
               }

               if (!this.doMine(var1)
                  && !this.doMine(var1.add(0, 0, 1))
                  && !this.doMine(var1.add(0, 0, -1))
                  && !this.doMine(var1.add(1, 0, 0))
                  && !this.doMine(var1.add(-1, 0, 0))
                  && !this.doMine(var1.add(1, 0, 1))
                  && !this.doMine(var1.add(-1, 0, -1))
                  && !this.doMine(var1.add(-1, 0, 1))) {
                  this.doMine(var1.add(1, 0, -1));
                  boolean var10000 = false;
               }
            }
         }
      }
   }

   private boolean canAttack2(EntityPlayer var1, BlockPos var2) {
      for(EnumFacing var6 : EnumFacing.VALUES) {
         if (check(var2.offset(var6), var1)) {
            boolean var10000 = false;
         } else if (var6 != EnumFacing.UP) {
            if (var6 == EnumFacing.DOWN) {
               boolean var7 = false;
            } else if (mc.player.getDistance((double)var2.offset(var6).getX() + 0.5, (double)var2.getY(), (double)var2.offset(var6).getZ() + 0.5)
               > this.breakRange.getValue()) {
               boolean var8 = false;
            } else {
               if (this.isAir(var2.offset(var6)) && this.isAir(var2.offset(var6).up())) {
                  if (this.debug.getValue()) {
                     this.sendMessage("can attack");
                  }

                  return true;
               }

               if (mc.player.getDistance((double)var2.offset(var6, 2).getX() + 0.5, (double)var2.getY(), (double)var2.offset(var6, 2).getZ() + 0.5)
                  > this.breakRange.getValue()) {
                  boolean var9 = false;
               } else if (this.isAir(var2.offset(var6)) && this.isAir(var2.offset(var6, 2)) && this.isAir(var2.offset(var6, 2).up())) {
                  if (this.debug.getValue()) {
                     this.sendMessage("can attack");
                  }

                  return true;
               }
            }
         }

         boolean var10 = false;
      }

      return false;
   }

   private void mineBlock(BlockPos var1) {
      if (this.getBlock(var1) == Blocks.REDSTONE_WIRE) {
         if (this.debug.getValue()) {
            this.sendMessage("redstone!");
         }
      } else {
         if (this.debug.getValue()) {
            this.sendMessage("mine block");
         }

         if (!PacketMine.godBlocks.contains(this.getBlock(var1))) {
            if (!var1.equals(PacketMine.breakPos) && this.renderTimer.passedMs(200L)) {
               this.breakPos = var1;
               this.renderTimer.reset();
               boolean var10000 = false;
               this.shrinkTimer = new FadeUtils((long)this.shrinkTime.getValue().intValue());
            }

            if (this.autoDisable.getValue() && !this.keyMode.getValue()) {
               this.disable();
            }

            CombatUtil.mineBlock(var1);
         }
      }
   }

   private boolean lambda$new$8(Bind var1) {
      return this.keyMode.getValue();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (this.breakPos != null && !this.renderTimer.passedMs((long)this.shrinkTime.getValue().intValue()) && this.render.getValue()) {
         AxisAlignedBB var2 = mc.world
            .getBlockState(this.breakPos)
            .getSelectedBoundingBox(mc.world, this.breakPos)
            .grow(this.shrinkTimer.easeInQuad() / 2.0 - 1.0);
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var2, this.color.getValue(), this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var2, this.color.getValue(), this.boxAlpha.getValue());
         }
      } else {
         this.shrinkTimer = new FadeUtils((long)this.shrinkTime.getValue().intValue());
      }
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   private boolean lambda$new$3(Integer var1) {
      boolean var10000;
      if (this.render.isOpen() && this.outline.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean check(BlockPos var0, EntityPlayer var1) {
      Vec3d[] var2 = EntityUtil.getVarOffsets(0, 0, 0);

      for(Vec3d var6 : var2) {
         BlockPos var7 = new BlockPos(var0).add(var6.x, var6.y, var6.z);

         for(Entity var9 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var7))) {
            if (var9 == var1) {
               return true;
            }

            boolean var10000 = false;
         }

         boolean var10 = false;
      }

      return false;
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.render.isOpen();
   }

   private boolean doMineExtend(BlockPos var1, EnumFacing var2) {
      if (!this.isAir(var1.offset(var2)) && this.godBlocks.contains(this.getBlock(var1.offset(var2)))) {
         return false;
      } else if (!this.isAir(var1.up().offset(var2, 2)) && this.godBlocks.contains(this.getBlock(var1.up().offset(var2, 2)))) {
         return false;
      } else if (!this.isAir(var1.offset(var2, 2)) && this.godBlocks.contains(this.getBlock(var1.offset(var2, 2)))) {
         return false;
      } else if (!this.isAir(var1.offset(var2, 2).up()) && !this.godBlocks.contains(this.getBlock(var1.offset(var2, 2).up()))) {
         this.mineBlock(var1.offset(var2, 2).up());
         return true;
      } else if (!this.isAir(var1.offset(var2, 2)) && !this.godBlocks.contains(this.getBlock(var1.offset(var2, 2)))) {
         this.mineBlock(var1.offset(var2, 2));
         return true;
      } else {
         return this.MineSurround(var1, var2);
      }
   }

   private boolean lambda$new$6(Color var1) {
      return this.render.isOpen();
   }

   @Override
   public String getInfo() {
      return target != null ? target.getName() : null;
   }

   private boolean lambda$new$9(Boolean var1) {
      boolean var10000;
      if (!this.keyMode.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean isAir(BlockPos var1) {
      return this.getBlock(var1) == Blocks.REDSTONE_WIRE ? true : mc.world.isAirBlock(var1);
   }

   private boolean canAttack(EntityPlayer var1, BlockPos var2) {
      if (this.canAttack2(var1, var2)) {
         return true;
      } else if (check(var2.add(0, 0, 1), var1) && this.canAttack2(var1, var2.add(0, 0, 1))) {
         return true;
      } else if (check(var2.add(0, 0, -1), var1) && this.canAttack2(var1, var2.add(0, 0, -1))) {
         return true;
      } else if (check(var2.add(1, 0, 0), var1) && this.canAttack2(var1, var2.add(1, 0, 0))) {
         return true;
      } else if (check(var2.add(-1, 0, 0), var1) && this.canAttack2(var1, var2.add(-1, 0, 0))) {
         return true;
      } else if (check(var2.add(1, 0, 1), var1) && this.canAttack2(var1, var2.add(1, 0, 1))) {
         return true;
      } else if (check(var2.add(1, 0, -1), var1) && this.canAttack2(var1, var2.add(1, 0, -1))) {
         return true;
      } else if (check(var2.add(-1, 0, 1), var1) && this.canAttack2(var1, var2.add(-1, 0, 1))) {
         return true;
      } else {
         boolean var10000;
         if (check(var2.add(-1, 0, -1), var1) && this.canAttack2(var1, var2.add(-1, 0, -1))) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.mineBurrow.isOpen();
   }

   private boolean cantMine(BlockPos var1, EnumFacing var2, int var3) {
      if (var2 != EnumFacing.UP && var2 != EnumFacing.DOWN) {
         if (mc.player.getDistance((double)var1.offset(var2, 2).getX() + 0.5, target.posY, (double)var1.offset(var2, 2).getZ() + 0.5)
            > this.breakRange.getValue()) {
            return true;
         } else {
            int var4 = 0;
            if (this.isAir(var1.offset(var2))) {
               ++var4;
            }

            if (this.isAir(var1.offset(var2, 2))) {
               ++var4;
            }

            if (this.isAir(var1.offset(var2, 2).up())) {
               ++var4;
            }

            boolean var10000;
            if (var4 < var3) {
               var10000 = true;
               boolean var10001 = false;
            } else {
               var10000 = false;
            }

            return var10000;
         }
      } else {
         return true;
      }
   }

   private boolean doCheckExtend(BlockPos var1, EnumFacing var2) {
      if (check(var1.offset(var2), target)) {
         return true;
      } else if (var2 != EnumFacing.UP && var2 != EnumFacing.DOWN) {
         boolean var10000;
         if (mc.player.getDistance((double)var1.offset(var2, 2).getX() + 0.5, target.posY, (double)var1.offset(var2, 2).getZ() + 0.5)
            > this.breakRange.getValue()) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      } else {
         return true;
      }
   }

   private boolean doCheck(BlockPos var1, EnumFacing var2) {
      if (check(var1.offset(var2), target)) {
         return true;
      } else if (var2 != EnumFacing.UP && var2 != EnumFacing.DOWN) {
         boolean var10000;
         if (mc.player.getDistance((double)var1.offset(var2).getX() + 0.5, target.posY, (double)var1.offset(var2).getZ() + 0.5) > this.breakRange.getValue()) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      } else {
         return true;
      }
   }

   private boolean lambda$new$7(Integer var1) {
      return this.render.isOpen();
   }

   private boolean MineSurround(BlockPos var1, EnumFacing var2) {
      if (!this.isAir(var1.offset(var2)) && !this.godBlocks.contains(this.getBlock(var1.offset(var2)))) {
         this.mineBlock(var1.offset(var2));
         return true;
      } else {
         return false;
      }
   }
}
