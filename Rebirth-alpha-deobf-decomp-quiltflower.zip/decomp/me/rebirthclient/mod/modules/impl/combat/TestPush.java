package me.rebirthclient.mod.modules.impl.combat;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class TestPush extends Module {
   private final Timer timer;
   private final Setting<Double> placeRange;
   private final Setting<Boolean> checkCrystal;
   private final Setting<Double> pistonCheck;
   int progress;
   private final Setting<Double> maxTargetSpeed;
   private final Setting<Boolean> targetGround;
   private final Setting<Boolean> pistonPacket;
   private final Setting<Integer> multiPlace;
   private final Setting<Boolean> pullBack;
   private final Setting<Boolean> breakCrystal;
   private EntityPlayer displayTarget;
   private final Setting<Boolean> selfGround;
   private final Setting<Boolean> powerPacket;
   private final Setting<Double> maxSelfSpeed;
   public final Setting<Integer> surroundCheck = this.add(new Setting<>("SurroundCheck", 2, 0, 4));
   public static final List<Block> canPushBlock2 = Arrays.asList(Blocks.AIR, Blocks.STANDING_SIGN, Blocks.WALL_SIGN, Blocks.REDSTONE_WIRE, Blocks.TRIPWIRE);
   private final Setting<Integer> updateDelay = this.add(new Setting<>("PlaceDelay", 100, 0, 500));
   private final Setting<Boolean> onlyBurrow;
   private final Setting<Double> range = this.add(new Setting<>("TargetRange", 6.0, 0.0, 8.0));
   private final Setting<Boolean> noEating;
   public static final List<Block> canPushBlock = Arrays.asList(
      Blocks.AIR, Blocks.ENDER_CHEST, Blocks.STANDING_SIGN, Blocks.WALL_SIGN, Blocks.REDSTONE_WIRE, Blocks.TRIPWIRE
   );
   private final Setting<Boolean> minePower;
   private final Setting<Boolean> autoDisable;

   private boolean lambda$new$0(Boolean var1) {
      return this.pullBack.isOpen();
   }

   private Boolean canPush(EntityPlayer var1) {
      int var2 = 0;
      if (!mc.world.isAirBlock(new BlockPos(var1.posX, var1.posY + 0.5, var1.posZ))) {
         return true;
      } else {
         if (!mc.world.isAirBlock(new BlockPos(var1.posX + 1.0, var1.posY + 0.5, var1.posZ))) {
            ++var2;
         }

         if (!mc.world.isAirBlock(new BlockPos(var1.posX - 1.0, var1.posY + 0.5, var1.posZ))) {
            ++var2;
         }

         if (!mc.world.isAirBlock(new BlockPos(var1.posX, var1.posY + 0.5, var1.posZ + 1.0))) {
            ++var2;
         }

         if (!mc.world.isAirBlock(new BlockPos(var1.posX, var1.posY + 0.5, var1.posZ - 1.0))) {
            ++var2;
         }

         boolean var10000;
         if (var2 > this.surroundCheck.getValue() - 1) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   @Override
   public String getInfo() {
      return this.displayTarget != null ? this.displayTarget.getName() : null;
   }

   public boolean attackCrystal(BlockPos var1) {
      for(Entity var3 : (List)mc.world
         .loadedEntityList
         .stream()
         .filter(TestPush::lambda$attackCrystal$1)
         .sorted(Comparator.comparing(TestPush::lambda$attackCrystal$2))
         .collect(Collectors.toList())) {
         if (var3 instanceof EntityEnderCrystal) {
            double var10000 = var3.getDistance((double)var1.getX(), (double)var1.getY(), (double)var1.getZ());
            byte var10001;
            if (this.checkCrystal.getValue()) {
               var10001 = 4;
               boolean var10002 = false;
            } else {
               var10001 = 2;
            }

            if (var10000 < (double)var10001) {
               CombatUtil.attackCrystal(var3, true, true);
               return true;
            }

            boolean var4 = false;
         }
      }

      return false;
   }

   @Override
   public void onUpdate() {
      this.progress = 0;
      this.displayTarget = null;
      if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) != -1 && InventoryUtil.findHotbarClass(BlockPistonBase.class) != -1) {
         if (this.timer.passedMs((long)this.updateDelay.getValue().intValue())) {
            if (!this.noEating.getValue() || !EntityUtil.isEating()) {
               if (!(Managers.SPEED.getPlayerSpeed(mc.player) > this.maxSelfSpeed.getValue())) {
                  if (!this.selfGround.getValue() || mc.player.onGround) {
                     for(EntityPlayer var2 : mc.world.playerEntities) {
                        if (this.canPush(var2) && EntityUtil.isValid(var2, this.range.getValue()) && (var2.onGround || !this.targetGround.getValue())) {
                           if (Managers.SPEED.getPlayerSpeed(var2) > this.maxTargetSpeed.getValue()) {
                              boolean var10000 = false;
                           } else {
                              if (this.progress >= this.multiPlace.getValue()) {
                                 return;
                              }

                              this.displayTarget = var2;
                              this.doPush(var2);
                              boolean var3 = false;
                           }
                        }
                     }

                     if ((this.displayTarget == null || this.progress == 0) && this.autoDisable.getValue()) {
                        this.disable();
                     }
                  }
               }
            }
         }
      } else {
         if (this.autoDisable.getValue()) {
            this.disable();
         }
      }
   }

   private static boolean lambda$attackCrystal$1(Entity var0) {
      boolean var10000;
      if (var0 instanceof EntityEnderCrystal && !var0.isDead) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean placePower(BlockPos var1, boolean var2) {
      if (this.progress >= this.multiPlace.getValue()) {
         return false;
      } else {
         for(EnumFacing var6 : EnumFacing.VALUES) {
            if (this.getBlock(var1.offset(var6)) == Blocks.REDSTONE_BLOCK) {
               if (this.minePower.getValue()) {
                  CombatUtil.mineBlock(var1.offset(var6));
               }

               if (this.autoDisable.getValue() && var2) {
                  this.disable();
               }

               return true;
            }

            boolean var10000 = false;
         }

         if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) == -1) {
            return true;
         } else {
            EnumFacing var9 = BlockUtil.getBestNeighboring(var1, null);
            if (var9 != null && BlockUtil.canPlace(var1.offset(var9), this.placeRange.getValue())) {
               int var11 = mc.player.inventory.currentItem;
               InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK));
               BlockUtil.placeBlock(var1.offset(var9), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
               InventoryUtil.doSwap(var11);
               ++this.progress;
               this.timer.reset();
               boolean var17 = false;
               return true;
            } else {
               for(EnumFacing var7 : EnumFacing.VALUES) {
                  if (BlockUtil.canPlace(var1.offset(var7), this.placeRange.getValue())) {
                     int var8 = mc.player.inventory.currentItem;
                     InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK));
                     BlockUtil.placeBlock(var1.offset(var7), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
                     InventoryUtil.doSwap(var8);
                     ++this.progress;
                     this.timer.reset();
                     boolean var16 = false;
                     return true;
                  }

                  boolean var14 = false;
                  var14 = false;
               }

               return false;
            }
         }
      }
   }

   private void doPush(EntityPlayer var1) {
      BlockPos var2 = new BlockPos(var1.posX, var1.posY + 0.5, var1.posZ);
      if (this.getBlock(var2.add(0, 2, 0)) != Blocks.AIR) {
         for(EnumFacing var34 : EnumFacing.VALUES) {
            if (var34 != EnumFacing.DOWN) {
               if (var34 == EnumFacing.UP) {
                  boolean var64 = false;
               } else {
                  BlockPos var40 = var2.offset(var34).up();
                  if (this.getBlock(var40) instanceof BlockPistonBase
                     && canPushBlock2.contains(this.getBlock(var40.offset(var34, -2)))
                     && canPushBlock2.contains(this.getBlock(var40.offset(var34, -2).down()))) {
                     if (((EnumFacing)this.getBlockState(var40).getValue(BlockDirectional.FACING)).getOpposite() != var34) {
                        boolean var65 = false;
                     } else {
                        if (this.breakCrystal.getValue()) {
                           this.attackCrystal(var40);
                           boolean var66 = false;
                        }

                        if (this.placePower(var40, true)) {
                           return;
                        }
                     }
                  }
               }
            }

            boolean var67 = false;
         }

         for(EnumFacing var35 : EnumFacing.VALUES) {
            if (var35 != EnumFacing.DOWN) {
               if (var35 == EnumFacing.UP) {
                  boolean var68 = false;
               } else {
                  BlockPos var41 = var2.offset(var35).up();
                  if ((mc.player.posY - (double)var2.getY() <= -1.0 || mc.player.posY - (double)var2.getY() >= 2.0)
                     && BlockUtil.distanceToXZ((double)var41.getX() + 0.5, (double)var41.getZ() + 0.5) < this.pistonCheck.getValue()) {
                     boolean var71 = false;
                  } else if (BlockUtil.canPlace2(var41, this.placeRange.getValue())
                     && canPushBlock2.contains(this.getBlock(var41.offset(var35, -2)))
                     && canPushBlock2.contains(this.getBlock(var41.offset(var35, -2).down()))) {
                     if (this.breakCrystal.getValue()) {
                        this.attackCrystal(var41);
                        boolean var69 = false;
                     }

                     if (!this.downPower(var41)) {
                        boolean var70 = false;
                     } else if (this.placePiston(var35, var41)) {
                        return;
                     }
                  }
               }
            }

            boolean var72 = false;
         }
      } else {
         for(EnumFacing var6 : EnumFacing.VALUES) {
            if (var6 != EnumFacing.DOWN) {
               if (var6 == EnumFacing.UP) {
                  boolean var10000 = false;
               } else {
                  BlockPos var7 = var2.offset(var6).up();
                  if (this.getBlock(var7) instanceof BlockPistonBase
                     && canPushBlock.contains(this.getBlock(var7.offset(var6, -2)))
                     && canPushBlock.contains(this.getBlock(var7.offset(var6, -2).up()))) {
                     if (((EnumFacing)this.getBlockState(var7).getValue(BlockDirectional.FACING)).getOpposite() != var6) {
                        boolean var42 = false;
                     } else {
                        if (this.breakCrystal.getValue()) {
                           this.attackCrystal(var7);
                           boolean var43 = false;
                        }

                        if (this.placePower(var7, true)) {
                           return;
                        }
                     }
                  }
               }
            }

            boolean var44 = false;
         }

         for(EnumFacing var30 : EnumFacing.VALUES) {
            if (var30 != EnumFacing.DOWN) {
               if (var30 == EnumFacing.UP) {
                  boolean var45 = false;
               } else {
                  BlockPos var36 = var2.offset(var30).up();
                  if ((mc.player.posY - (double)var2.getY() <= -1.0 || mc.player.posY - (double)var2.getY() >= 2.0)
                     && BlockUtil.distanceToXZ((double)var36.getX() + 0.5, (double)var36.getZ() + 0.5) < this.pistonCheck.getValue()) {
                     boolean var48 = false;
                  } else if (BlockUtil.canPlace2(var36, this.placeRange.getValue())
                     && canPushBlock.contains(this.getBlock(var36.offset(var30, -2)))
                     && canPushBlock.contains(this.getBlock(var36.offset(var30, -2).up()))) {
                     if (this.breakCrystal.getValue()) {
                        this.attackCrystal(var36);
                        boolean var46 = false;
                     }

                     if (this.downPower(var36)) {
                        if (this.placePiston(var30, var36)) {
                           return;
                        }

                        return;
                     }

                     boolean var47 = false;
                  }
               }
            }

            boolean var49 = false;
         }

         if (canPushBlock.contains(this.getBlock(var2)) && this.onlyBurrow.getValue() || !this.pullBack.getValue()) {
            return;
         }

         for(EnumFacing var31 : EnumFacing.VALUES) {
            if (var31 != EnumFacing.DOWN) {
               if (var31 == EnumFacing.UP) {
                  boolean var52 = false;
               } else {
                  BlockPos var37 = var2.offset(var31).up();
                  if (this.getBlock(var37) instanceof BlockPistonBase
                     && (canPushBlock.contains(this.getBlock(var37.up())) || this.getBlock(var37.up()) == Blocks.REDSTONE_BLOCK)) {
                     if (((EnumFacing)this.getBlockState(var37).getValue(BlockDirectional.FACING)).getOpposite() != var31) {
                        boolean var51 = false;
                     } else {
                        for(EnumFacing var11 : EnumFacing.VALUES) {
                           if (this.getBlock(var37.offset(var11)) == Blocks.REDSTONE_BLOCK) {
                              CombatUtil.mineBlock(var37.offset(var11));
                              if (this.autoDisable.getValue()) {
                                 this.disable();
                              }

                              return;
                           }

                           boolean var50 = false;
                        }
                     }
                  }
               }
            }

            boolean var53 = false;
         }

         for(EnumFacing var32 : EnumFacing.VALUES) {
            if (var32 != EnumFacing.DOWN) {
               if (var32 == EnumFacing.UP) {
                  boolean var54 = false;
               } else {
                  BlockPos var38 = var2.offset(var32).up();
                  if (this.getBlock(var38) instanceof BlockPistonBase
                     && (canPushBlock.contains(this.getBlock(var38.up())) || this.getBlock(var38.up()) == Blocks.REDSTONE_BLOCK)) {
                     if (((EnumFacing)this.getBlockState(var38).getValue(BlockDirectional.FACING)).getOpposite() != var32) {
                        boolean var55 = false;
                     } else {
                        if (this.breakCrystal.getValue()) {
                           this.attackCrystal(var38);
                           boolean var56 = false;
                        }

                        if (this.placePower(var38, false)) {
                           return;
                        }
                     }
                  }
               }
            }

            boolean var57 = false;
         }

         for(EnumFacing var33 : EnumFacing.VALUES) {
            if (var33 != EnumFacing.DOWN) {
               if (var33 == EnumFacing.UP) {
                  boolean var58 = false;
               } else {
                  BlockPos var39 = var2.offset(var33).up();
                  if ((mc.player.posY - (double)var2.getY() <= -1.0 || mc.player.posY - (double)var2.getY() >= 2.0)
                     && BlockUtil.distanceToXZ((double)var39.getX() + 0.5, (double)var39.getZ() + 0.5) < this.pistonCheck.getValue()) {
                     boolean var61 = false;
                  } else if (BlockUtil.canPlace2(var39, this.placeRange.getValue())
                     && (canPushBlock.contains(this.getBlock(var39.up())) || this.getBlock(var39.up()) == Blocks.REDSTONE_BLOCK)) {
                     if (this.breakCrystal.getValue()) {
                        this.attackCrystal(var39);
                        boolean var59 = false;
                     }

                     if (!this.downPower(var39)) {
                        boolean var60 = false;
                     } else if (this.placePiston(var33, var39)) {
                        return;
                     }
                  }
               }
            }

            boolean var62 = false;
         }

         boolean var63 = false;
      }
   }

   private boolean downPower(BlockPos var1) {
      if (!BlockUtil.canPlaceEnum(var1)) {
         if (this.progress >= this.multiPlace.getValue()) {
            return false;
         }

         if (!BlockUtil.canPlace(var1.add(0, -1, 0), this.placeRange.getValue())) {
            return false;
         }

         if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) == -1) {
            return false;
         }

         int var2 = mc.player.inventory.currentItem;
         InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK));
         BlockUtil.placeBlock(var1.add(0, -1, 0), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
         InventoryUtil.doSwap(var2);
         ++this.progress;
         this.timer.reset();
         boolean var10000 = false;
      }

      return true;
   }

   private static Float lambda$attackCrystal$2(Entity var0) {
      return mc.player.getDistance(var0);
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   public TestPush() {
      super("TestPush", "2b2t.xin", Category.COMBAT);
      this.placeRange = this.add(new Setting<>("PlaceRange", 6.0, 0.0, 8.0));
      this.pistonCheck = this.add(new Setting<>("AntiDisturb", 2.6, 0.0, 8.0));
      this.autoDisable = this.add(new Setting<>("AutoDisable", true));
      this.noEating = this.add(new Setting<>("NoEating", true));
      this.minePower = this.add(new Setting<>("MinePower", true));
      this.pullBack = this.add(new Setting<>("PullBack", true).setParent());
      this.onlyBurrow = this.add(new Setting<>("OnlyBurrow", true, this::lambda$new$0));
      this.targetGround = this.add(new Setting<>("TargetGround", false));
      this.pistonPacket = this.add(new Setting<>("PistonPacket", false));
      this.powerPacket = this.add(new Setting<>("PowerPacket", true));
      this.checkCrystal = this.add(new Setting<>("CheckCrystal", true));
      this.breakCrystal = this.add(new Setting<>("BreakCrystal", true));
      this.selfGround = this.add(new Setting<>("SelfGround", true));
      this.maxSelfSpeed = this.add(new Setting<>("MaxSelfSpeed", 6.0, 1.0, 30.0));
      this.maxTargetSpeed = this.add(new Setting<>("MaxTargetSpeed", 4.0, 1.0, 15.0));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 2, 1, 8));
      this.timer = new Timer();
      this.progress = 0;
   }

   private IBlockState getBlockState(BlockPos var1) {
      return mc.world.getBlockState(var1);
   }

   private boolean placePiston(EnumFacing var1, BlockPos var2) {
      if (!BlockUtil.canPlace(var2, this.placeRange.getValue())) {
         return false;
      } else if (this.progress >= this.multiPlace.getValue()) {
         return false;
      } else if (InventoryUtil.findHotbarBlock(BlockPistonBase.class) == -1) {
         return false;
      } else {
         AutoPush.pistonFacing(var1);
         int var3 = mc.player.inventory.currentItem;
         InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(BlockPistonBase.class));
         BlockUtil.placeBlock(var2, EnumHand.MAIN_HAND, false, this.pistonPacket.getValue());
         InventoryUtil.doSwap(var3);
         ++this.progress;
         this.timer.reset();
         boolean var10000 = false;
         EntityUtil.facePlacePos(var2);
         this.placePower(var2, true);
         var10000 = false;
         return true;
      }
   }
}
