package me.rebirthclient.mod.modules.impl.combat;

import java.awt.Color;
import java.util.Random;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.events.impl.UpdateWalkingPlayerEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.RotationManager;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class Aura extends Module {
   private final Setting<Boolean> onlyGhasts;
   private final Setting<Boolean> weaponOnly;
   public static Entity target;
   private final Setting<Boolean> neutrals;
   private final Setting<Float> yawStep;
   private final Setting<Float> maxCps;
   private final Timer timer;
   private final Setting<Boolean> whileEating;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> oneEight;
   private final Setting<Boolean> others;
   private final Setting<Color> targetColor;
   private final Setting<Boolean> fovCheck;
   private final Setting<Boolean> multi32k;
   private final Setting<Float> wallRange;
   public final Setting<Float> range;
   private final Setting<Boolean> randomPitch;
   private final Setting<Boolean> tpsSync;
   private final Setting<Float> angle;
   public static Aura INSTANCE;
   private final Setting<Float> randomDelay;
   private final Setting<Boolean> hostiles;
   private final Setting<Integer> time32k;
   private final Setting<Aura.RenderMode> render;
   private final Setting<Boolean> delay32k;
   private final Setting<Aura.TargetMode> targetMode;
   private final Setting<Integer> packetAmount32k;
   private final Setting<Boolean> lookBack;
   private final Setting<Float> amplitude;
   private final Setting<Boolean> animals;
   private final Setting<Boolean> swing;
   private final Setting<Float> minCps;
   private final Setting<Float> pitchAdd;
   private final Setting<Boolean> packet;
   private final Setting<Boolean> armorBreak;
   private final Setting<Boolean> players;
   private final Setting<Aura.Page> page = this.add(new Setting<>("Settings", Aura.Page.GLOBAL));
   private final Setting<Boolean> stopSprint;
   private final Setting<Boolean> sneak;
   private final Setting<Boolean> projectiles;

   private boolean isInFov(Entity var1, float var2) {
      double var3 = var1.posX - mc.player.posX;
      double var5 = var1.posZ - mc.player.posZ;
      double var7 = Math.atan2(var3, var5) * (180.0 / Math.PI);
      var7 = -var7;
      var2 = (float)((double)var2 * 0.5);
      double var9 = (((double)mc.player.rotationYaw - var7) % 360.0 + 540.0) % 360.0 - 180.0;
      boolean var10000;
      if ((!(var9 > 0.0) || !(var9 < (double)var2)) && (!((double)(-var2) < var9) || !(var9 < 0.0))) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private void teekayAttack(Entity var1) {
      for(int var2 = 0; var2 < this.packetAmount32k.getValue(); ++var2) {
         this.startEntityAttackThread(var1, var2 * this.time32k.getValue());
         boolean var10000 = false;
      }
   }

   private boolean lambda$new$28(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void lambda$startEntityAttackThread$36(int var1, Entity var2) {
      Timer var3 = new Timer();
      var3.reset();
      boolean var10000 = false;
      long var6 = (long)var1;

      label13: {
         try {
            Thread.sleep(var6);
         } catch (InterruptedException var5) {
            Thread.currentThread().interrupt();
            break label13;
         }

         var10000 = false;
      }

      Managers.INTERACTIONS.attackEntity(var2, true, this.swing.getValue());
   }

   @SubscribeEvent
   public void onUpdateWalkingPlayerEvent(UpdateWalkingPlayerEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getStage() == 0 && this.rotate.getValue() && target != null) {
            float[] var2 = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), target.getPositionEyes(mc.getRenderPartialTicks()));
            float[] var3 = Managers.ROTATIONS.injectYawStep(var2, this.yawStep.getValue());
            RotationManager var10000 = Managers.ROTATIONS;
            float var10001 = var3[0];
            float var10002 = var3[1] + this.pitchAdd.getValue();
            float var10003;
            if (this.randomPitch.getValue()) {
               var10003 = (float)Math.random() * this.amplitude.getValue();
               boolean var10004 = false;
            } else {
               var10003 = 0.0F;
            }

            var10000.setRotations(var10001, var10002 + var10003);
         }

         this.doAura();
         if (this.rotate.getValue() && this.lookBack.getValue()) {
            Managers.ROTATIONS.resetRotations();
         }
      }
   }

   private boolean lambda$new$8(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.rotate.isOpen() && this.randomPitch.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.rotate.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$14(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.fovCheck.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$32(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$30(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$22(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.oneEight.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (target != null) {
         if (this.render.getValue() == Aura.RenderMode.OLD) {
            RenderUtil.drawEntityBoxESP(target, this.targetColor.getValue(), true, new Color(255, 255, 255, 130), 0.7F, true, true, 35);
            boolean var10000 = false;
         } else if (this.render.getValue() == Aura.RenderMode.JELLO) {
            double var2 = 1500.0;
            double var4 = (double)System.currentTimeMillis() % var2;
            boolean var33;
            if (var4 > var2 / 2.0) {
               var33 = true;
               boolean var10001 = false;
            } else {
               var33 = false;
            }

            boolean var6 = var33;
            double var7 = var4 / (var2 / 2.0);
            if (!var6) {
               var7 = 1.0 - var7;
               var33 = false;
            } else {
               --var7;
            }

            var7 = this.easeInOutQuad(var7);
            mc.entityRenderer.disableLightmap();
            GL11.glPushMatrix();
            GL11.glDisable(3553);
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(2848);
            GL11.glEnable(3042);
            GL11.glDisable(2929);
            GL11.glDisable(2884);
            GL11.glShadeModel(7425);
            mc.entityRenderer.disableLightmap();
            double var9 = (double)target.width;
            double var11 = (double)target.height + 0.1;
            double var13 = target.lastTickPosX + (target.posX - target.lastTickPosX) * (double)mc.getRenderPartialTicks() - mc.renderManager.viewerPosX;
            double var15 = target.lastTickPosY
               + (target.posY - target.lastTickPosY) * (double)mc.getRenderPartialTicks()
               - mc.renderManager.viewerPosY
               + var11 * var7;
            double var17 = target.lastTickPosZ + (target.posZ - target.lastTickPosZ) * (double)mc.getRenderPartialTicks() - mc.renderManager.viewerPosZ;
            double var35 = var11 / 3.0;
            double var38;
            if (var7 > 0.5) {
               var38 = 1.0 - var7;
               boolean var10002 = false;
            } else {
               var38 = var7;
            }

            double var36 = var35 * var38;
            byte var39;
            if (var6) {
               var39 = -1;
               boolean var40 = false;
            } else {
               var39 = 1;
            }

            double var19 = var36 * (double)var39;

            for(int var21 = 0; var21 < 360; var21 += 5) {
               Color var22 = this.targetColor.getValue();
               double var23 = var13 - Math.sin((double)var21 * Math.PI / 180.0) * var9;
               double var25 = var17 + Math.cos((double)var21 * Math.PI / 180.0) * var9;
               double var27 = var13 - Math.sin((double)(var21 - 5) * Math.PI / 180.0) * var9;
               double var29 = var17 + Math.cos((double)(var21 - 5) * Math.PI / 180.0) * var9;
               GL11.glBegin(7);
               GL11.glColor4f(
                  (float)ColorUtil.pulseColor(var22, 200, 1).getRed() / 255.0F,
                  (float)ColorUtil.pulseColor(var22, 200, 1).getGreen() / 255.0F,
                  (float)ColorUtil.pulseColor(var22, 200, 1).getBlue() / 255.0F,
                  0.0F
               );
               GL11.glVertex3d(var23, var15 + var19, var25);
               GL11.glVertex3d(var27, var15 + var19, var29);
               GL11.glColor4f(
                  (float)ColorUtil.pulseColor(var22, 200, 1).getRed() / 255.0F,
                  (float)ColorUtil.pulseColor(var22, 200, 1).getGreen() / 255.0F,
                  (float)ColorUtil.pulseColor(var22, 200, 1).getBlue() / 255.0F,
                  200.0F
               );
               GL11.glVertex3d(var27, var15, var29);
               GL11.glVertex3d(var23, var15, var25);
               GL11.glEnd();
               GL11.glBegin(2);
               GL11.glVertex3d(var27, var15, var29);
               GL11.glVertex3d(var23, var15, var25);
               GL11.glEnd();
               var33 = false;
            }

            GL11.glEnable(2884);
            GL11.glShadeModel(7424);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glEnable(2929);
            GL11.glDisable(2848);
            GL11.glDisable(3042);
            GL11.glEnable(3553);
            GL11.glPopMatrix();
         }
      }
   }

   private boolean lambda$new$7(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.rotate.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$12(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$29(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public String getInfo() {
      String var1 = Managers.TEXT.normalizeCases(this.targetMode.getValue());
      String var10000;
      if (target instanceof EntityPlayer) {
         var10000 = String.valueOf(new StringBuilder().append(", ").append(target.getName()));
         boolean var10001 = false;
      } else {
         var10000 = "";
      }

      String var2 = var10000;
      return String.valueOf(new StringBuilder().append(var1).append(var2));
   }

   private boolean lambda$new$23(Aura.RenderMode var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void doAura() {
      if (this.weaponOnly.getValue() && !EntityUtil.isHoldingWeapon(mc.player)) {
         target = null;
      } else {
         int var6;
         if (this.oneEight.getValue() || EntityUtil.isHolding32k(mc.player) && !this.delay32k.getValue()) {
            float var7 = MathUtil.randomBetween(this.minCps.getValue(), this.maxCps.getValue()) - (float)new Random().nextInt(10);
            float var15 = (float)(new Random().nextInt(10) * 100);
            float var17;
            if (this.tpsSync.getValue()) {
               var17 = Managers.SERVER.getTpsFactor();
               boolean var18 = false;
            } else {
               var17 = 1.0F;
            }

            var6 = (int)(var7 + var15 * var17);
            boolean var16 = false;
         } else {
            float var10000 = (float)EntityUtil.getHitCoolDown(mc.player);
            float var10001 = (float)Math.random() * this.randomDelay.getValue() * 100.0F;
            float var10002;
            if (this.tpsSync.getValue()) {
               var10002 = Managers.SERVER.getTpsFactor();
               boolean var10003 = false;
            } else {
               var10002 = 1.0F;
            }

            var6 = (int)(var10000 + var10001 * var10002);
         }

         int var1 = var6;
         if (this.timer.passedMs((long)var1)
            && (
               this.whileEating.getValue()
                  || !mc.player.isHandActive()
                  || mc.player.getHeldItemOffhand().getItem().equals(Items.SHIELD) && mc.player.getActiveHand() == EnumHand.OFF_HAND
            )) {
            target = this.getTarget();
            if (target != null) {
               if (EntityUtil.isHolding32k(mc.player) && !this.delay32k.getValue()) {
                  if (this.multi32k.getValue()) {
                     for(EntityPlayer var5 : mc.world.playerEntities) {
                        if (EntityUtil.isValid(var5, (double)this.range.getValue().floatValue())) {
                           this.teekayAttack(var5);
                        }

                        boolean var12 = false;
                     }

                     boolean var13 = false;
                  } else {
                     this.teekayAttack(target);
                  }

                  this.timer.reset();
                  boolean var14 = false;
               } else {
                  if (this.armorBreak.getValue()) {
                     mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 9, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
                     boolean var8 = false;
                     Managers.INTERACTIONS.attackEntity(target, this.packet.getValue(), this.swing.getValue());
                     mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 9, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
                     var8 = false;
                     Managers.INTERACTIONS.attackEntity(target, this.packet.getValue(), this.swing.getValue());
                     var8 = false;
                  } else {
                     boolean var2 = SneakManager.isSneaking;
                     boolean var3 = mc.player.isSprinting();
                     if (this.sneak.getValue()) {
                        if (var2) {
                           mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
                        }

                        if (var3) {
                           mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SPRINTING));
                        }
                     }

                     Managers.INTERACTIONS.attackEntity(target, this.packet.getValue(), this.swing.getValue());
                     if (this.sneak.getValue()) {
                        if (var3) {
                           mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SPRINTING));
                        }

                        if (var2) {
                           mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
                        }
                     }

                     if (this.stopSprint.getValue()) {
                        mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SPRINTING));
                     }
                  }

                  this.timer.reset();
                  boolean var11 = false;
               }
            }
         }
      }
   }

   private boolean lambda$new$35(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$24(Color var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.render.getValue() != Aura.RenderMode.OFF) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.rotate.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$27(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$19(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public Aura() {
      super("KnifeBot", "Attacks entities in radius", Category.COMBAT);
      this.range = this.add(new Setting<>("Range", 6.0F, 0.1F, 7.0F, this::lambda$new$0));
      this.targetMode = this.add(new Setting<>("Filter", Aura.TargetMode.DISTANCE, this::lambda$new$1));
      this.wallRange = this.add(new Setting<>("WallRange", 3.0F, 0.1F, 7.0F, this::lambda$new$2));
      this.rotate = this.add(new Setting<>("Rotate", true, this::lambda$new$3).setParent());
      this.lookBack = this.add(new Setting<>("LookBack", true, this::lambda$new$4));
      this.yawStep = this.add(new Setting<>("YawStep", 0.3F, 0.1F, 1.0F, this::lambda$new$5));
      this.pitchAdd = this.add(new Setting<>("PitchAdd", 0.0F, 0.0F, 25.0F, this::lambda$new$6));
      this.randomPitch = this.add(new Setting<>("RandomizePitch", false, this::lambda$new$7));
      this.amplitude = this.add(new Setting<>("Amplitude", 3.0F, -5.0F, 5.0F, this::lambda$new$8));
      this.oneEight = this.add(new Setting<>("OneEight", false, this::lambda$new$9).setParent());
      this.minCps = this.add(new Setting<>("MinCps", 6.0F, 0.0F, 20.0F, this::lambda$new$10));
      this.maxCps = this.add(new Setting<>("MaxCps", 9.0F, 0.0F, 20.0F, this::lambda$new$11));
      this.randomDelay = this.add(new Setting<>("RandomDelay", 0.0F, 0.0F, 5.0F, this::lambda$new$12));
      this.fovCheck = this.add(new Setting<>("FovCheck", false, this::lambda$new$13).setParent());
      this.angle = this.add(new Setting<>("Angle", 180.0F, 0.0F, 180.0F, this::lambda$new$14));
      this.stopSprint = this.add(new Setting<>("StopSprint", true, this::lambda$new$15));
      this.armorBreak = this.add(new Setting<>("ArmorBreak", false, this::lambda$new$16));
      this.whileEating = this.add(new Setting<>("WhileEating", true, this::lambda$new$17));
      this.weaponOnly = this.add(new Setting<>("WeaponOnly", true, this::lambda$new$18));
      this.tpsSync = this.add(new Setting<>("TpsSync", true, this::lambda$new$19));
      this.packet = this.add(new Setting<>("Packet", false, this::lambda$new$20));
      this.swing = this.add(new Setting<>("Swing", true, this::lambda$new$21));
      this.sneak = this.add(new Setting<>("Sneak", false, this::lambda$new$22));
      this.render = this.add(new Setting<>("Render", Aura.RenderMode.JELLO, this::lambda$new$23));
      this.targetColor = this.add(new Setting<>("TargetColor", new Color(255, 255, 255, 255), this::lambda$new$24));
      this.players = this.add(new Setting<>("Players", true, this::lambda$new$25));
      this.animals = this.add(new Setting<>("Animals", false, this::lambda$new$26));
      this.neutrals = this.add(new Setting<>("Neutrals", false, this::lambda$new$27));
      this.others = this.add(new Setting<>("Others", false, this::lambda$new$28));
      this.projectiles = this.add(new Setting<>("Projectiles", false, this::lambda$new$29));
      this.hostiles = this.add(new Setting<>("Hostiles", true, this::lambda$new$30).setParent());
      this.onlyGhasts = this.add(new Setting<>("OnlyGhasts", false, this::lambda$new$31));
      this.delay32k = this.add(new Setting<>("32kDelay", false, this::lambda$new$32));
      this.packetAmount32k = this.add(new Setting<>("32kPackets", 2, this::lambda$new$33));
      this.time32k = this.add(new Setting<>("32kTime", 5, 1, 50, this::lambda$new$34));
      this.multi32k = this.add(new Setting<>("Multi32k", false, this::lambda$new$35));
      this.timer = new Timer();
      INSTANCE = this;
   }

   private boolean lambda$new$17(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$33(Integer var1) {
      boolean var10000;
      if (!this.delay32k.getValue() && this.page.getValue() == Aura.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$18(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void startEntityAttackThread(Entity var1, int var2) {
      new Thread(this::lambda$startEntityAttackThread$36).start();
   }

   private double easeInOutQuad(double var1) {
      double var10000;
      if (var1 < 0.5) {
         var10000 = 2.0 * var1 * var1;
         boolean var10001 = false;
      } else {
         var10000 = 1.0 - Math.pow(-2.0 * var1 + 2.0, 2.0) / 2.0;
      }

      return var10000;
   }

   private boolean lambda$new$21(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Aura.TargetMode var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$25(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$20(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$31(Boolean var1) {
      boolean var10000;
      if (this.hostiles.isOpen() && this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private Entity getTarget() {
      Entity var1 = null;
      double var2 = 0.0;
      double var4 = 36.0;

      for(Entity var7 : mc.world.loadedEntityList) {
         if (this.players.getValue() && var7 instanceof EntityPlayer
            || this.animals.getValue() && EntityUtil.isPassive(var7)
            || this.neutrals.getValue() && EntityUtil.isNeutralMob(var7)
            || this.hostiles.getValue() && EntityUtil.isMobAggressive(var7)
            || this.hostiles.getValue() && this.onlyGhasts.getValue() && var7 instanceof EntityGhast
            || this.others.getValue() && EntityUtil.isVehicle(var7)
            || this.projectiles.getValue() && EntityUtil.isProjectile(var7)) {
            if (EntityUtil.invalid(var7, (double)this.range.getValue().floatValue())) {
               boolean var13 = false;
               continue;
            }

            if (!mc.player.canEntityBeSeen(var7)
               && !EntityUtil.isFeetVisible(var7)
               && mc.player.getDistanceSq(var7) > MathUtil.square((double)this.wallRange.getValue().floatValue())) {
               boolean var12 = false;
               continue;
            }

            if (this.fovCheck.getValue() && !this.isInFov(var7, (float)this.angle.getValue().intValue())) {
               boolean var11 = false;
               continue;
            }

            if (var1 == null) {
               var1 = var7;
               var2 = (double)mc.player.getDistance(var7);
               var4 = (double)EntityUtil.getHealth(var7);
               boolean var10000 = false;
            } else {
               if (var7 instanceof EntityPlayer && EntityUtil.isArmorLow((EntityPlayer)var7, 10)) {
                  var1 = var7;
                  boolean var10 = false;
                  break;
               }

               if (this.targetMode.getValue() == Aura.TargetMode.HEALTH && (double)EntityUtil.getHealth(var7) < var4) {
                  var1 = var7;
                  var2 = (double)mc.player.getDistance(var7);
                  var4 = (double)EntityUtil.getHealth(var7);
                  boolean var9 = false;
                  continue;
               }

               if (this.targetMode.getValue() == Aura.TargetMode.DISTANCE && (double)mc.player.getDistance(var7) < var2) {
                  var1 = var7;
                  var2 = (double)mc.player.getDistance(var7);
                  var4 = (double)EntityUtil.getHealth(var7);
               }
            }
         }

         boolean var8 = false;
      }

      return var1;
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.rotate.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      if (target != null && EntityUtil.invalid(target, (double)this.range.getValue().floatValue())) {
         target = null;
      }

      if (!this.rotate.getValue()) {
         this.doAura();
      }

      if (this.maxCps.getValue() < this.minCps.getValue()) {
         this.maxCps.setValue(this.minCps.getValue());
      }
   }

   private boolean lambda$new$15(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$34(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$26(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.TARGETS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Float var1) {
      boolean var10000;
      if (this.page.getValue() == Aura.Page.GLOBAL && this.oneEight.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static enum Page {
      GLOBAL,
      ADVANCED,
      TARGETS;
      private static final Aura.Page[] $VALUES = new Aura.Page[]{Aura.Page.GLOBAL, Aura.Page.TARGETS, Aura.Page.ADVANCED};
   }

   private static enum RenderMode {
      JELLO,
      OFF,
      OLD;
      private static final Aura.RenderMode[] $VALUES = new Aura.RenderMode[]{Aura.RenderMode.OLD, JELLO, Aura.RenderMode.OFF};
   }

   private static enum TargetMode {
      HEALTH,
      DISTANCE;

      private static final Aura.TargetMode[] $VALUES = new Aura.TargetMode[]{DISTANCE, HEALTH};
   }
}
