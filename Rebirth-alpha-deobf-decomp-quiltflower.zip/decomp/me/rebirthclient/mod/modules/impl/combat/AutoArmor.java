package me.rebirthclient.mod.modules.impl.combat;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.exploit.XCarry;
import me.rebirthclient.mod.modules.impl.movement.ElytraFly;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import org.lwjgl.input.Keyboard;

public class AutoArmor extends Module {
   private final Setting<Integer> maxThreshold;
   private final Setting<Integer> delay;
   private final Setting<Boolean> save;
   private final Setting<Bind> elytraBind;
   private final Setting<Integer> actions;
   private final Setting<Boolean> autoMend = this.add(new Setting<>("AutoMend", false).setParent());
   private final List<Integer> doneSlots;
   private final Setting<Integer> saveThreshold;
   private final Timer timer;
   private final Setting<Integer> bootsThreshold;
   private final Setting<Bind> noHelmBind;
   private final Setting<Boolean> updateController;
   private final Setting<Boolean> tps;
   private final Setting<Boolean> shiftClick;
   private final Setting<Integer> chestThreshold;
   private final Setting<Integer> legThreshold;
   private boolean helmOff;
   private final Setting<Boolean> autoElytra;
   private final Setting<Integer> closestEnemy = this.add(new Setting<>("EnemyRange", 8, 1, 20, this::lambda$new$0));
   private final Queue<InventoryUtil.QueuedTask> queuedTaskList;
   private boolean elytraOn;
   private final Setting<Integer> helmetThreshold = this.add(new Setting<>("Helmet%", 80, 1, 100, this::lambda$new$1));
   private final Timer elytraTimer;
   private final Setting<Boolean> curse;

   private boolean lambda$new$7(Bind var1) {
      boolean var10000;
      if (!this.autoElytra.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Integer var1) {
      return this.autoMend.isOpen();
   }

   private boolean isSafe() {
      EntityPlayer var1 = EntityUtil.getClosestEnemy((double)this.closestEnemy.getValue().intValue());
      if (var1 == null) {
         return true;
      } else {
         boolean var10000;
         if (mc.player.getDistanceSq(var1) >= MathUtil.square((double)this.closestEnemy.getValue().intValue())) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   @Override
   public void onLogout() {
      this.queuedTaskList.clear();
      this.doneSlots.clear();
   }

   private void takeOffSlot(int var1) {
      if (this.queuedTaskList.isEmpty()) {
         int var2 = -1;

         for(int var4 : InventoryUtil.findEmptySlots(XCarry.INSTANCE.isOn())) {
            if (this.doneSlots.contains(var2)) {
               boolean var10000 = false;
            } else {
               var2 = var4;
               this.doneSlots.add(var4);
               boolean var5 = false;
               var5 = false;
            }
         }

         if (var2 != -1) {
            if ((var2 >= 5 || var2 <= 0) && this.shiftClick.getValue()) {
               this.queuedTaskList.add(new InventoryUtil.QueuedTask(var1, true));
               boolean var10 = false;
            } else {
               this.queuedTaskList.add(new InventoryUtil.QueuedTask(var1));
               boolean var7 = false;
               this.queuedTaskList.add(new InventoryUtil.QueuedTask(var2));
               var7 = false;
               var7 = false;
            }

            if (this.updateController.getValue()) {
               this.queuedTaskList.add(new InventoryUtil.QueuedTask());
               boolean var11 = false;
            }
         }
      }
   }

   private boolean lambda$new$6(Integer var1) {
      return this.save.isOpen();
   }

   private void getSlotOn(int var1, int var2) {
      if (this.queuedTaskList.isEmpty()) {
         this.doneSlots.remove(Integer.valueOf(var2));
         boolean var10000 = false;
         if ((var2 >= 5 || var2 <= 0) && this.shiftClick.getValue()) {
            this.queuedTaskList.add(new InventoryUtil.QueuedTask(var2, true));
            var10000 = false;
         } else {
            this.queuedTaskList.add(new InventoryUtil.QueuedTask(var2));
            var10000 = false;
            this.queuedTaskList.add(new InventoryUtil.QueuedTask(var1));
            var10000 = false;
            var10000 = false;
         }

         if (this.updateController.getValue()) {
            this.queuedTaskList.add(new InventoryUtil.QueuedTask());
            var10000 = false;
         }
      }
   }

   private boolean lambda$new$4(Integer var1) {
      return this.autoMend.isOpen();
   }

   @SubscribeEvent
   public void onKeyInput(KeyInputEvent var1) {
      if (!fullNullCheck()) {
         if (Keyboard.getEventKeyState()
            && !(mc.currentScreen instanceof Gui)
            && this.elytraBind.getValue().getKey() == Keyboard.getEventKey()
            && !this.autoElytra.getValue()) {
            boolean var10001;
            if (!this.elytraOn) {
               var10001 = true;
               boolean var10002 = false;
            } else {
               var10001 = false;
            }

            this.elytraOn = var10001;
         }

         if (Keyboard.getEventKeyState() && !(mc.currentScreen instanceof Gui) && this.noHelmBind.getValue().getKey() == Keyboard.getEventKey()) {
            boolean var2;
            if (!this.helmOff) {
               var2 = true;
               boolean var3 = false;
            } else {
               var2 = false;
            }

            this.helmOff = var2;
         }
      }
   }

   @Override
   public void onTick() {
      if (!(mc.currentScreen instanceof GuiContainer) || mc.currentScreen instanceof GuiInventory) {
         if (this.autoElytra.getValue()) {
            boolean var10001;
            if (!mc.player.onGround && ElytraFly.INSTANCE.isOn()) {
               var10001 = true;
               boolean var10002 = false;
            } else {
               var10001 = false;
            }

            this.elytraOn = var10001;
            boolean var10000 = false;
         } else if (this.elytraBind.getValue().getKey() == -1) {
            this.elytraOn = false;
         }

         if (this.queuedTaskList.isEmpty()) {
            boolean var21;
            if ((!InventoryUtil.holdingItem(ItemExpBottle.class) || !mc.gameSettings.keyBindUseItem.isKeyDown()) && !PacketExp.INSTANCE.isThrow()) {
               var21 = false;
            } else {
               var21 = true;
               boolean var48 = false;
            }

            boolean var6 = var21;
            if (this.autoMend.getValue() && var6 && (this.isSafe() || EntityUtil.isSafe(mc.player, 1, false))) {
               ItemStack var7 = mc.player.inventoryContainer.getSlot(5).getStack();
               ItemStack var8 = mc.player.inventoryContainer.getSlot(6).getStack();
               ItemStack var9 = mc.player.inventoryContainer.getSlot(7).getStack();
               ItemStack var10 = mc.player.inventoryContainer.getSlot(8).getStack();
               if (!var7.isEmpty && EntityUtil.getDamagePercent(var7) < this.maxThreshold.getValue()
                  || !var8.isEmpty && EntityUtil.getDamagePercent(var8) < this.maxThreshold.getValue()
                  || !var9.isEmpty && EntityUtil.getDamagePercent(var9) < this.maxThreshold.getValue()
                  || !var10.isEmpty && EntityUtil.getDamagePercent(var10) < this.maxThreshold.getValue()) {
                  if (!var7.isEmpty && EntityUtil.getDamagePercent(var7) >= this.helmetThreshold.getValue()) {
                     this.takeOffSlot(5);
                  }

                  if (!var8.isEmpty && EntityUtil.getDamagePercent(var8) >= this.chestThreshold.getValue()) {
                     this.takeOffSlot(6);
                  }

                  if (!var9.isEmpty && EntityUtil.getDamagePercent(var9) >= this.legThreshold.getValue()) {
                     this.takeOffSlot(7);
                  }

                  if (!var10.isEmpty && EntityUtil.getDamagePercent(var10) >= this.bootsThreshold.getValue()) {
                     this.takeOffSlot(8);
                  }

                  return;
               }
            }

            if (this.save.getValue()) {
               ItemStack var15 = mc.player.inventoryContainer.getSlot(5).getStack();
               if (this.save.getValue() && !var15.isEmpty && EntityUtil.getDamagePercent(var15) <= this.saveThreshold.getValue()) {
                  this.takeOffSlot(5);
               }

               ItemStack var17 = mc.player.inventoryContainer.getSlot(6).getStack();
               if (this.save.getValue() && !var17.isEmpty && EntityUtil.getDamagePercent(var17) <= this.saveThreshold.getValue()) {
                  this.takeOffSlot(6);
               }

               ItemStack var19 = mc.player.inventoryContainer.getSlot(7).getStack();
               if (this.save.getValue() && !var19.isEmpty && EntityUtil.getDamagePercent(var19) <= this.saveThreshold.getValue()) {
                  this.takeOffSlot(7);
               }

               ItemStack var20 = mc.player.inventoryContainer.getSlot(8).getStack();
               if (this.save.getValue() && !var20.isEmpty && EntityUtil.getDamagePercent(var20) <= this.saveThreshold.getValue()) {
                  this.takeOffSlot(8);
               }
            }

            label226: {
               ItemStack var16 = mc.player.inventoryContainer.getSlot(5).getStack();
               if (!this.helmOff && var16.getItem() == Items.AIR) {
                  int var4 = InventoryUtil.findArmorSlot(EntityEquipmentSlot.HEAD, this.curse.getValue(), XCarry.INSTANCE.isOn());
                  if (var4 != -1) {
                     this.getSlotOn(5, var4);
                     var21 = false;
                     break label226;
                  }
               }

               if (this.helmOff && var16.getItem() != Items.AIR) {
                  this.takeOffSlot(5);
               }
            }

            ItemStack var5 = mc.player.inventoryContainer.getSlot(6).getStack();
            if (var5.getItem() == Items.AIR) {
               if (this.queuedTaskList.isEmpty()) {
                  if (this.elytraOn && this.elytraTimer.passedMs(500L)) {
                     int var18 = InventoryUtil.findItemInventorySlot(Items.ELYTRA, false, XCarry.INSTANCE.isOn());
                     if (var18 != -1) {
                        if ((var18 >= 5 || var18 <= 1) && this.shiftClick.getValue()) {
                           this.queuedTaskList.add(new InventoryUtil.QueuedTask(var18, true));
                           var21 = false;
                        } else {
                           this.queuedTaskList.add(new InventoryUtil.QueuedTask(var18));
                           var21 = false;
                           this.queuedTaskList.add(new InventoryUtil.QueuedTask(6));
                           var21 = false;
                           var21 = false;
                        }

                        if (this.updateController.getValue()) {
                           this.queuedTaskList.add(new InventoryUtil.QueuedTask());
                           var21 = false;
                        }

                        this.elytraTimer.reset();
                        var21 = false;
                     }

                     var21 = false;
                  } else if (!this.elytraOn) {
                     int var14 = InventoryUtil.findArmorSlot(EntityEquipmentSlot.CHEST, this.curse.getValue(), XCarry.INSTANCE.isOn());
                     if (var14 != -1) {
                        this.getSlotOn(6, var14);
                        var21 = false;
                     }
                  }
               }
            } else if (this.elytraOn && var5.getItem() != Items.ELYTRA && this.elytraTimer.passedMs(500L)) {
               if (this.queuedTaskList.isEmpty()) {
                  int var13 = InventoryUtil.findItemInventorySlot(Items.ELYTRA, false, XCarry.INSTANCE.isOn());
                  if (var13 != -1) {
                     this.queuedTaskList.add(new InventoryUtil.QueuedTask(var13));
                     var21 = false;
                     this.queuedTaskList.add(new InventoryUtil.QueuedTask(6));
                     var21 = false;
                     this.queuedTaskList.add(new InventoryUtil.QueuedTask(var13));
                     var21 = false;
                     if (this.updateController.getValue()) {
                        this.queuedTaskList.add(new InventoryUtil.QueuedTask());
                        var21 = false;
                     }
                  }

                  this.elytraTimer.reset();
                  var21 = false;
                  var21 = false;
               }
            } else if (!this.elytraOn && var5.getItem() == Items.ELYTRA && this.elytraTimer.passedMs(500L) && this.queuedTaskList.isEmpty()) {
               int var3 = InventoryUtil.findItemInventorySlot(Items.DIAMOND_CHESTPLATE, false, XCarry.INSTANCE.isOn());
               if (var3 == -1) {
                  var3 = InventoryUtil.findItemInventorySlot(Items.IRON_CHESTPLATE, false, XCarry.INSTANCE.isOn());
                  if (var3 == -1) {
                     var3 = InventoryUtil.findItemInventorySlot(Items.GOLDEN_CHESTPLATE, false, XCarry.INSTANCE.isOn());
                     if (var3 == -1) {
                        var3 = InventoryUtil.findItemInventorySlot(Items.CHAINMAIL_CHESTPLATE, false, XCarry.INSTANCE.isOn());
                        if (var3 == -1) {
                           var3 = InventoryUtil.findItemInventorySlot(Items.LEATHER_CHESTPLATE, false, XCarry.INSTANCE.isOn());
                        }
                     }
                  }
               }

               if (var3 != -1) {
                  this.queuedTaskList.add(new InventoryUtil.QueuedTask(var3));
                  var21 = false;
                  this.queuedTaskList.add(new InventoryUtil.QueuedTask(6));
                  var21 = false;
                  this.queuedTaskList.add(new InventoryUtil.QueuedTask(var3));
                  var21 = false;
                  if (this.updateController.getValue()) {
                     this.queuedTaskList.add(new InventoryUtil.QueuedTask());
                     var21 = false;
                  }
               }

               this.elytraTimer.reset();
               var21 = false;
            }

            mc.player.inventoryContainer.getSlot(7).getStack();
            var21 = false;
            if (mc.player.inventoryContainer.getSlot(7).getStack().getItem() == Items.AIR) {
               int var2 = InventoryUtil.findArmorSlot(EntityEquipmentSlot.LEGS, this.curse.getValue(), XCarry.INSTANCE.isOn());
               if (var2 != -1) {
                  this.getSlotOn(7, var2);
               }
            }

            mc.player.inventoryContainer.getSlot(8).getStack();
            var21 = false;
            if (mc.player.inventoryContainer.getSlot(8).getStack().getItem() == Items.AIR) {
               int var1 = InventoryUtil.findArmorSlot(EntityEquipmentSlot.FEET, this.curse.getValue(), XCarry.INSTANCE.isOn());
               if (var1 != -1) {
                  this.getSlotOn(8, var1);
               }
            }
         }

         Timer var44 = this.timer;
         float var49 = (float)this.delay.getValue().intValue();
         float var50;
         if (this.tps.getValue()) {
            var50 = Managers.SERVER.getTpsFactor();
            boolean var10003 = false;
         } else {
            var50 = 1.0F;
         }

         if (var44.passedMs((long)((int)(var49 * var50)))) {
            if (!this.queuedTaskList.isEmpty()) {
               for(int var11 = 0; var11 < this.actions.getValue(); ++var11) {
                  InventoryUtil.QueuedTask var12 = this.queuedTaskList.poll();
                  if (var12 == null) {
                     boolean var45 = false;
                  } else {
                     var12.run();
                  }

                  boolean var46 = false;
               }
            }

            this.timer.reset();
            boolean var47 = false;
         }
      }
   }

   @Override
   public String getInfo() {
      return this.elytraOn ? "Elytra" : null;
   }

   private boolean lambda$new$0(Integer var1) {
      return this.autoMend.isOpen();
   }

   public AutoArmor() {
      super("AutoArmor", "Puts Armor on for you", Category.COMBAT);
      this.chestThreshold = this.add(new Setting<>("Chest%", 80, 1, 100, this::lambda$new$2));
      this.legThreshold = this.add(new Setting<>("Legs%", 80, 1, 100, this::lambda$new$3));
      this.bootsThreshold = this.add(new Setting<>("Boots%", 80, 1, 100, this::lambda$new$4));
      this.maxThreshold = this.add(new Setting<>("Max%", 90, 1, 100, this::lambda$new$5));
      this.save = this.add(new Setting<>("Save", false).setParent());
      this.saveThreshold = this.add(new Setting<>("Save%", 5, 1, 10, this::lambda$new$6));
      this.delay = this.add(new Setting<>("Delay", 50, 0, 500));
      this.actions = this.add(new Setting<>("Actions", 3, 1, 12));
      this.curse = this.add(new Setting<>("CurseOfBinding", false));
      this.tps = this.add(new Setting<>("TpsSync", true));
      this.updateController = this.add(new Setting<>("Update", true));
      this.shiftClick = this.add(new Setting<>("ShiftClick", false));
      this.autoElytra = this.add(new Setting<>("AutoElytra", true));
      this.elytraBind = this.add(new Setting<>("Elytra", new Bind(-1), this::lambda$new$7));
      this.noHelmBind = this.add(new Setting<>("NoHelmet", new Bind(-1)));
      this.timer = new Timer();
      this.elytraTimer = new Timer();
      this.queuedTaskList = new ConcurrentLinkedQueue<>();
      this.doneSlots = new ArrayList<>();
   }

   private boolean lambda$new$2(Integer var1) {
      return this.autoMend.isOpen();
   }

   @Override
   public void onDisable() {
      this.queuedTaskList.clear();
      this.doneSlots.clear();
      this.elytraOn = false;
      this.helmOff = false;
   }

   private boolean lambda$new$1(Integer var1) {
      return this.autoMend.isOpen();
   }

   @Override
   public void onLogin() {
      this.timer.reset();
      boolean var10000 = false;
      this.elytraTimer.reset();
      var10000 = false;
   }

   private boolean lambda$new$3(Integer var1) {
      return this.autoMend.isOpen();
   }
}
