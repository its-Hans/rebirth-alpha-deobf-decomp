package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class AntiBurrow extends Module {
   public final Setting<Boolean> packet;
   private final Setting<AntiBurrow.Block> blockSetting = this.add(new Setting<>("Block", AntiBurrow.Block.RedStone));
   private final Setting<Boolean> onlyGround;
   public EntityPlayer target;
   private final Timer timer;
   private final Setting<Integer> multiPlace;
   private final Setting<Float> range;
   public final Setting<Integer> delay;
   public final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private int progress;

   @Override
   public String getInfo() {
      return this.target != null ? this.target.getName() : null;
   }

   public boolean canPlace(BlockPos var1) {
      if (BlockUtil.canBlockReplace(var1.down())) {
         return false;
      } else if (!BlockUtil.canReplace(var1)) {
         return false;
      } else if (!CombatSetting.INSTANCE.strictPlace.getValue()) {
         return true;
      } else {
         for(EnumFacing var3 : BlockUtil.getPlacableFacings(var1, true, CombatSetting.INSTANCE.checkRaytrace.getValue())) {
            if (BlockUtil.canClick(var1.offset(var3))) {
               return true;
            }

            boolean var10000 = false;
         }

         return false;
      }
   }

   private boolean checkEntity(BlockPos var1) {
      for(Entity var3 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var1))) {
         if (var3 instanceof EntityPlayer) {
            if (var3 != mc.player) {
               return true;
            }

            boolean var10000 = false;
         }
      }

      return false;
   }

   public AntiBurrow() {
      super("AntiBurrow", "put something under foot", Category.COMBAT);
      this.packet = this.add(new Setting<>("Packet", true));
      this.delay = this.add(new Setting<>("Delay", 50, 0, 500));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 4));
      this.timer = new Timer();
      this.onlyGround = this.add(new Setting<>("SelfGround", true));
      this.range = this.add(new Setting<>("Range", 5.0F, 1.0F, 6.0F));
      this.progress = 0;
   }

   private void placeBlock(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (this.checkEntity(var1)) {
            if (this.canPlace(var1)) {
               int var2 = mc.player.inventory.currentItem;
               if (this.blockSetting.getValue() != AntiBurrow.Block.Button
                  || InventoryUtil.findHotbarBlock(Blocks.STONE_BUTTON) == -1 && InventoryUtil.findHotbarBlock(Blocks.WOODEN_BUTTON) == -1) {
                  if (this.blockSetting.getValue() != AntiBurrow.Block.RedStone || InventoryUtil.findItemInHotbar(Items.REDSTONE) == -1) {
                     return;
                  }

                  InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.REDSTONE));
                  BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                  boolean var4 = false;
               } else {
                  if (InventoryUtil.findHotbarBlock(Blocks.STONE_BUTTON) != -1) {
                     InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.STONE_BUTTON));
                     boolean var10000 = false;
                  } else {
                     InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.WOODEN_BUTTON));
                  }

                  BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                  boolean var3 = false;
               }

               ++this.progress;
               InventoryUtil.doSwap(var2);
               this.timer.reset();
               boolean var5 = false;
            }
         }
      }
   }

   @Override
   public void onTick() {
      if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         this.target = CombatUtil.getTarget((double)this.range.getValue().floatValue());
         if (this.target != null) {
            if (!this.onlyGround.getValue() || mc.player.onGround) {
               this.progress = 0;
               this.placeBlock(new BlockPos(this.target.posX + 0.2, this.target.posY + 0.5, this.target.posZ + 0.2));
               this.placeBlock(new BlockPos(this.target.posX - 0.2, this.target.posY + 0.5, this.target.posZ + 0.2));
               this.placeBlock(new BlockPos(this.target.posX - 0.2, this.target.posY + 0.5, this.target.posZ - 0.2));
               this.placeBlock(new BlockPos(this.target.posX + 0.2, this.target.posY + 0.5, this.target.posZ - 0.2));
            }
         }
      }
   }

   private static enum Block {
      RedStone,
      Button;

      private static final AntiBurrow.Block[] $VALUES = new AntiBurrow.Block[]{Button, RedStone};
   }
}
