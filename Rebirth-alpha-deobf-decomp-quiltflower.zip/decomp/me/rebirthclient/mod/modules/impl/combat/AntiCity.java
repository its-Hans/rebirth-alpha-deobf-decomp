package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.impl.BreakManager;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AntiCity extends Module {
   private final Setting<Integer> multiPlace;
   private int progress;
   private final Setting<Boolean> rotate = this.add(new Setting<>("Rotate", true));
   private final Setting<Integer> delay;
   private final Setting<Boolean> breakCrystal;
   private final Setting<AntiCity.Mode> mode;
   private final Setting<Boolean> eatingPause;
   private final Setting<Boolean> packet = this.add(new Setting<>("Packet", true));
   final Timer delayTimer;
   private final Setting<Boolean> onlySurround;

   @Override
   public String getInfo() {
      return this.mode.getValue().name();
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.breakCrystal.isOpen();
   }

   @Override
   public void onTick() {
      if ((Surround.INSTANCE.isOn() || !this.onlySurround.getValue()) && this.delayTimer.passedMs((long)this.delay.getValue().intValue())) {
         this.progress = 0;
         BlockPos var1 = EntityUtil.getPlayerPos();

         for(EnumFacing var5 : EnumFacing.VALUES) {
            if (var5 != EnumFacing.DOWN) {
               if (var5 == EnumFacing.UP) {
                  boolean var12 = false;
               } else if (this.getBlock(var1.offset(var5)) == Blocks.OBSIDIAN
                  && (BreakManager.isMine(var1.offset(var5)) || BlockUtil.checkEntity(var1.offset(var5)))) {
                  if (this.mode.getValue() == AntiCity.Mode.Single) {
                     this.placeBlock(var1.offset(var5, 2));
                     boolean var11 = false;
                  } else {
                     for(EnumFacing var9 : EnumFacing.VALUES) {
                        if (var9 != EnumFacing.DOWN) {
                           if (var9 == EnumFacing.UP) {
                              boolean var10000 = false;
                           } else {
                              this.placeBlock(var1.offset(var5).offset(var9));
                           }
                        }

                        boolean var10 = false;
                     }

                     if (this.mode.getValue() == AntiCity.Mode.Full) {
                        this.placeBlock(var1.offset(var5).up());
                     }
                  }
               }
            }

            boolean var13 = false;
         }
      }
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   public AntiCity() {
      super("AntiCity", "test", Category.COMBAT);
      this.breakCrystal = this.add(new Setting<>("AttackCrystal", true).setParent());
      this.eatingPause = this.add(new Setting<>("EatingPause", true, this::lambda$new$0));
      this.onlySurround = this.add(new Setting<>("OnlySurround", true));
      this.delay = this.add(new Setting<>("Delay", 100, 0, 1000));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 8));
      this.mode = this.add(new Setting<>("Mode", AntiCity.Mode.Semi));
      this.delayTimer = new Timer();
      this.progress = 0;
   }

   private void placeBlock(BlockPos var1) {
      if (!BlockUtil.canPlace(var1)) {
         if (this.breakCrystal.getValue()) {
            CombatUtil.attackCrystal(var1, this.rotate.getValue(), this.eatingPause.getValue());
         }
      } else if (this.progress < this.multiPlace.getValue()) {
         int var2 = mc.player.inventory.currentItem;
         if (InventoryUtil.findHotbarClass(BlockObsidian.class) != -1) {
            InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockObsidian.class));
            BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
            InventoryUtil.doSwap(var2);
            this.delayTimer.reset();
            boolean var10000 = false;
            ++this.progress;
         }
      }
   }

   public static enum Mode {
      Full,
      Single,
      Semi;
      private static final AntiCity.Mode[] $VALUES = new AntiCity.Mode[]{AntiCity.Mode.Single, AntiCity.Mode.Semi, AntiCity.Mode.Full};
   }
}
