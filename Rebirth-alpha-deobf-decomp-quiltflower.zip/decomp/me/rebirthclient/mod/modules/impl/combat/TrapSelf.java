package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.movement.AutoCenter;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.BlockButton;
import net.minecraft.block.BlockObsidian;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class TrapSelf extends Module {
   private final Setting<Boolean> trapHead;
   public static TrapSelf INSTANCE;
   int progress;
   private BlockPos startPos;
   public final Setting<Float> safeHealth;
   private final Setting<Boolean> headButton;
   private final Setting<Boolean> packet;
   private final Setting<Integer> delay;
   private final Setting<Boolean> trapBody;
   private final Setting<Boolean> breakCrystal;
   private final Setting<Integer> multiPlace;
   private final Setting<Boolean> rotate;
   final Timer timer = new Timer();
   private final Setting<Boolean> eatingPause;
   private final Setting<Boolean> center;

   @Override
   public void onEnable() {
      this.startPos = EntityUtil.getPlayerPos();
      if (this.center.getValue()) {
         AutoCenter.INSTANCE.enable();
      }
   }

   @Override
   public void onTick() {
      if (!this.startPos.equals(EntityUtil.getPlayerPos())) {
         this.disable();
      } else if (this.timer.passedMs((long)this.delay.getValue().intValue())) {
         this.progress = 0;
         if (InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN) == -1) {
            this.disable();
         } else {
            BlockPos var1 = EntityUtil.getPlayerPos();
            if (this.trapBody.getValue()) {
               this.placeBlock(var1.add(1, 0, 0));
               this.placeBlock(var1.add(1, 1, 0));
               this.placeBlock(var1.add(-1, 0, 0));
               this.placeBlock(var1.add(-1, 1, 0));
               this.placeBlock(var1.add(0, 0, 1));
               this.placeBlock(var1.add(0, 1, 1));
               this.placeBlock(var1.add(0, 0, -1));
               this.placeBlock(var1.add(0, 1, -1));
               if (!BlockUtil.canBlockFacing(var1.add(0, 0, -1))) {
                  this.placeBlock(var1.add(0, -1, -1));
               }

               if (!BlockUtil.canBlockFacing(var1.add(0, 0, 1))) {
                  this.placeBlock(var1.add(0, -1, 1));
               }

               if (!BlockUtil.canBlockFacing(var1.add(1, 0, 0))) {
                  this.placeBlock(var1.add(1, -1, 0));
               }

               if (!BlockUtil.canBlockFacing(var1.add(-1, 0, 0))) {
                  this.placeBlock(var1.add(-1, -1, 0));
               }
            }

            if (this.trapHead.getValue()) {
               if (!BlockUtil.canPlace4(var1.add(0, 2, 0))) {
                  this.placeBlock(var1.add(0, 2, -1));
                  this.placeBlock(var1.add(0, 2, 1));
                  this.placeBlock(var1.add(-1, 2, 0));
                  this.placeBlock(var1.add(1, 2, 0));
               }

               this.placeBlock(var1.add(0, 2, 0));
            }
         }
      }
   }

   private boolean lambda$new$0(Float var1) {
      return this.breakCrystal.isOpen();
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.breakCrystal.isOpen();
   }

   public TrapSelf() {
      super("TrapSelf", "One Self Trap", Category.COMBAT);
      this.delay = this.add(new Setting<>("Delay", 50, 0, 500));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 8));
      this.breakCrystal = this.add(new Setting<>("BreakCrystal", true).setParent());
      this.safeHealth = this.add(new Setting<>("SafeHealth", 16.0F, 0.0F, 36.0F, this::lambda$new$0));
      this.eatingPause = this.add(new Setting<>("eatingPause", true, this::lambda$new$1));
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.packet = this.add(new Setting<>("Packet", true));
      this.center = this.add(new Setting<>("Center", true));
      this.trapBody = this.add(new Setting<>("TrapBody", true));
      this.trapHead = this.add(new Setting<>("TrapHead", false).setParent());
      this.headButton = this.add(new Setting<>("useButton", false, this::lambda$new$2));
      this.progress = 0;
      INSTANCE = this;
   }

   private void placeBlock(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (BlockUtil.canPlace3(var1)) {
            if (this.breakCrystal.getValue() && EntityUtil.getHealth(mc.player) >= this.safeHealth.getValue() || BlockUtil.canPlace(var1)) {
               if (this.breakCrystal.getValue() && EntityUtil.getHealth(mc.player) >= this.safeHealth.getValue()) {
                  CombatUtil.attackCrystal(var1, this.rotate.getValue(), false);
               }

               int var2 = mc.player.inventory.currentItem;
               int var3;
               if (var1.equals(EntityUtil.getPlayerPos().up(2)) && this.headButton.getValue()) {
                  if (InventoryUtil.findHotbarClass(BlockObsidian.class) == -1 && InventoryUtil.findHotbarClass(BlockButton.class) == -1) {
                     return;
                  }

                  if (InventoryUtil.findHotbarClass(BlockButton.class) != -1) {
                     var3 = InventoryUtil.findHotbarClass(BlockButton.class);
                     boolean var10000 = false;
                  } else {
                     var3 = InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN);
                     boolean var4 = false;
                  }
               } else {
                  if (InventoryUtil.findHotbarClass(BlockObsidian.class) == -1) {
                     return;
                  }

                  var3 = InventoryUtil.findHotbarBlock(Blocks.OBSIDIAN);
               }

               InventoryUtil.doSwap(var3);
               BlockUtil.placeBlock(
                  var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue(), this.breakCrystal.getValue(), this.eatingPause.getValue()
               );
               InventoryUtil.doSwap(var2);
               ++this.progress;
               this.timer.reset();
               boolean var5 = false;
            }
         }
      }
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.trapHead.isOpen();
   }
}
