package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.CombatUtil;
import me.rebirthclient.api.util.DamageUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.render.PlaceRender;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class PistonCrystal extends Module {
   private final Setting<Boolean> fire;
   private final Setting<Float> placeRange;
   private final Setting<Boolean> onlyGround;
   private final Setting<Integer> updateDelay;
   private final Timer timer;
   private final Setting<Boolean> packet;
   private EntityPlayer target;
   private final Setting<Boolean> onlyStatic;
   private final Setting<Boolean> autoDisable = this.add(new Setting<>("AutoDisable", true));
   private final Setting<Float> range;
   private final Setting<Boolean> noEating = this.add(new Setting<>("NoEating", true));

   private boolean doPlacePiston(BlockPos var1) {
      for(EnumFacing var5 : EnumFacing.VALUES) {
         if (var5 != EnumFacing.DOWN) {
            if (var5 == EnumFacing.UP) {
               boolean var10000 = false;
            } else if (this.placePiston(var1, var5)) {
               return true;
            }
         }

         boolean var6 = false;
      }

      return false;
   }

   @Override
   public String getInfo() {
      return this.target != null ? this.target.getName() : null;
   }

   private Block getBlock(BlockPos var1) {
      return mc.world.getBlockState(var1).getBlock();
   }

   public PistonCrystal() {
      super("PistonCrystal", "in strict", Category.COMBAT);
      this.placeRange = this.add(new Setting<>("PlaceRange", 5.0F, 1.0F, 8.0F));
      this.range = this.add(new Setting<>("Range", 4.0F, 1.0F, 8.0F));
      this.packet = this.add(new Setting<>("Packet", true));
      this.fire = this.add(new Setting<>("Fire", true));
      this.onlyGround = this.add(new Setting<>("pauseAir", true));
      this.onlyStatic = this.add(new Setting<>("pauseMoving", true));
      this.updateDelay = this.add(new Setting<>("UpdateDelay", 100, 0, 500));
      this.target = null;
      this.timer = new Timer();
   }

   @Override
   public void onTick() {
      if (this.autoDisable.getValue() && AutoTrap.INSTANCE.isOff()) {
         this.disable();
      } else if (!this.noEating.getValue() || !EntityUtil.isEating()) {
         if (this.timer.passedMs((long)this.updateDelay.getValue().intValue())) {
            boolean var10000 = this.onlyStatic.getValue();
            boolean var10001;
            if (!mc.player.onGround) {
               var10001 = true;
               boolean var10002 = false;
            } else {
               var10001 = false;
            }

            if (!PullCrystal.check(var10000, var10001, this.onlyGround.getValue())) {
               this.target = this.getTarget((double)this.range.getValue().floatValue());
               if (this.target != null) {
                  this.timer.reset();
                  var10000 = false;
                  BlockPos var1 = EntityUtil.getEntityPos(this.target);
                  if (this.checkCrystal(var1.up(0))) {
                     CombatUtil.attackCrystal(var1.up(0), true, true);
                  }

                  if (this.checkCrystal(var1.up(1))) {
                     CombatUtil.attackCrystal(var1.up(1), true, true);
                  }

                  if (this.checkCrystal(var1.up(2))) {
                     CombatUtil.attackCrystal(var1.up(2), true, true);
                  }

                  if (!this.doPistonActive(var1.up(2))) {
                     if (!this.doPistonActive(var1.up())) {
                        if (!this.doPlaceCrystal(var1.up(2))) {
                           if (!this.doPlaceCrystal(var1.up())) {
                              if (!this.doPlacePiston(var1.up(2))) {
                                 this.doPlacePiston(var1.up());
                                 var10000 = false;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean placeCrystal(BlockPos var1, EnumFacing var2) {
      if (!BlockUtil.canPlaceCrystal(var1.offset(var2), (double)this.placeRange.getValue().floatValue())) {
         return false;
      } else if (!this.hasPiston(var1, var2)) {
         return false;
      } else if (InventoryUtil.findItemInHotbar(Items.END_CRYSTAL) == -1) {
         return false;
      } else {
         int var3 = mc.player.inventory.currentItem;
         InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.END_CRYSTAL));
         BlockUtil.placeCrystal(var1.offset(var2), true);
         InventoryUtil.doSwap(var3);
         return true;
      }
   }

   private EntityPlayer getTarget(double var1) {
      EntityPlayer var3 = null;
      double var4 = var1;

      for(EntityPlayer var7 : mc.world.playerEntities) {
         if (EntityUtil.invalid(var7, var1)) {
            boolean var10000 = false;
         } else if (this.getBlock(var7.getPosition()) == Blocks.OBSIDIAN) {
            boolean var8 = false;
         } else if (var3 == null) {
            var3 = var7;
            var4 = mc.player.getDistanceSq(var7);
            boolean var9 = false;
         } else if (mc.player.getDistanceSq(var7) >= var4) {
            boolean var10 = false;
         } else {
            var3 = var7;
            var4 = mc.player.getDistanceSq(var7);
            boolean var11 = false;
         }
      }

      return var3;
   }

   private boolean doPistonActive(BlockPos var1) {
      for(EnumFacing var5 : EnumFacing.VALUES) {
         if (var5 != EnumFacing.DOWN) {
            if (var5 == EnumFacing.UP) {
               boolean var10000 = false;
            } else if (BlockUtil.posHasCrystal(var1.offset(var5))) {
               this.doFire(var1, var5);
               if (this.doRedStone(var1.offset(var5, 3), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 3).up(), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 2), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 2).up(), var5)) {
                  return true;
               }

               double var6 = (double)(var1.offset(var5).getX() - var1.getX());
               double var8 = (double)(var1.offset(var5).getZ() - var1.getZ());
               if (this.doRedStone(var1.offset(var5, 3).add(var8, 0.0, var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 3).add(-var8, 0.0, -var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 3).add(var8, 1.0, var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 3).add(-var8, 1.0, -var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 2).add(var8, 0.0, var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 2).add(-var8, 0.0, -var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 2).add(var8, 1.0, var6), var5)) {
                  return true;
               }

               if (this.doRedStone(var1.offset(var5, 2).add(-var8, 1.0, -var6), var5)) {
                  return true;
               }
            }
         }

         boolean var10 = false;
      }

      return false;
   }

   private boolean tryPlacePiston(BlockPos var1, EnumFacing var2) {
      if (!BlockUtil.canPlace(var1, (double)this.placeRange.getValue().floatValue()) && !(this.getBlock(var1) instanceof BlockPistonBase)) {
         return false;
      } else if (InventoryUtil.findHotbarClass(BlockPistonBase.class) == -1) {
         return false;
      } else if ((mc.player.posY - (double)var1.getY() <= -2.0 || mc.player.posY - (double)var1.getY() >= 3.0)
         && BlockUtil.distanceToXZ((double)var1.getX() + 0.5, (double)var1.getZ() + 0.5) < 2.6) {
         return false;
      } else if (!mc.world.isAirBlock(var1.offset(var2, -1))
         && this.getBlock(var1.offset(var2, -1)) != Blocks.FIRE
         && this.getBlock(var1.offset(var2.getOpposite())) != Blocks.PISTON_EXTENSION) {
         return false;
      } else if (!BlockUtil.canPlace(var1, (double)this.placeRange.getValue().floatValue())) {
         return this.isPiston(var1, var2);
      } else {
         EnumFacing var3 = BlockUtil.getFirstFacing(var1);
         if (var3 == null) {
            return false;
         } else {
            int var4 = mc.player.inventory.currentItem;
            AutoPush.pistonFacing(var2);
            InventoryUtil.doSwap(InventoryUtil.findHotbarClass(BlockPistonBase.class));
            BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, false, this.packet.getValue());
            InventoryUtil.doSwap(var4);
            BlockPos var5 = var1.offset(var3);
            EnumFacing var6 = var3.getOpposite();
            Vec3d var7 = new Vec3d(var5).add(0.5, 0.5, 0.5).add(new Vec3d(var6.getDirectionVec()).scale(0.5));
            EntityUtil.faceVector(var7);
            return true;
         }
      }
   }

   private boolean hasPiston(BlockPos var1, EnumFacing var2) {
      if (this.isPiston(var1.offset(var2, 3), var2)) {
         return true;
      } else if (this.isPiston(var1.offset(var2, 3).up(), var2)) {
         return true;
      } else if (this.isPiston(var1.offset(var2, 2), var2)) {
         return true;
      } else if (this.isPiston(var1.offset(var2, 2).up(), var2)) {
         return true;
      } else {
         double var3 = (double)(var1.offset(var2).getX() - var1.getX());
         double var5 = (double)(var1.offset(var2).getZ() - var1.getZ());
         if (this.isPiston(var1.offset(var2, 3).add(var5, 0.0, var3), var2)) {
            return true;
         } else if (this.isPiston(var1.offset(var2, 3).add(-var5, 0.0, -var3), var2)) {
            return true;
         } else if (this.isPiston(var1.offset(var2, 3).add(var5, 1.0, var3), var2)) {
            return true;
         } else if (this.isPiston(var1.offset(var2, 3).add(-var5, 1.0, -var3), var2)) {
            return true;
         } else if (this.isPiston(var1.offset(var2, 2).add(var5, 0.0, var3), var2)) {
            return true;
         } else if (this.isPiston(var1.offset(var2, 2).add(-var5, 0.0, -var3), var2)) {
            return true;
         } else {
            return this.isPiston(var1.offset(var2, 2).add(var5, 1.0, var3), var2) ? true : this.isPiston(var1.offset(var2, 2).add(-var5, 1.0, -var3), var2);
         }
      }
   }

   private boolean placePiston(BlockPos var1, EnumFacing var2) {
      if (!BlockUtil.canPlaceCrystal(var1.offset(var2), (double)this.placeRange.getValue().floatValue())) {
         return false;
      } else if (this.tryPlacePiston(var1.offset(var2, 3), var2)) {
         return true;
      } else if (this.tryPlacePiston(var1.offset(var2, 3).up(), var2)) {
         return true;
      } else if (this.tryPlacePiston(var1.offset(var2, 2), var2)) {
         return true;
      } else if (this.tryPlacePiston(var1.offset(var2, 2).up(), var2)) {
         return true;
      } else {
         double var3 = (double)(var1.offset(var2).getX() - var1.getX());
         double var5 = (double)(var1.offset(var2).getZ() - var1.getZ());
         if (this.tryPlacePiston(var1.offset(var2, 3).add(var5, 0.0, var3), var2)) {
            return true;
         } else if (this.tryPlacePiston(var1.offset(var2, 3).add(-var5, 0.0, -var3), var2)) {
            return true;
         } else if (this.tryPlacePiston(var1.offset(var2, 3).add(var5, 1.0, var3), var2)) {
            return true;
         } else if (this.tryPlacePiston(var1.offset(var2, 3).add(-var5, 1.0, -var3), var2)) {
            return true;
         } else if (this.tryPlacePiston(var1.offset(var2, 2).add(var5, 0.0, var3), var2)) {
            return true;
         } else if (this.tryPlacePiston(var1.offset(var2, 2).add(-var5, 0.0, -var3), var2)) {
            return true;
         } else {
            return this.tryPlacePiston(var1.offset(var2, 2).add(var5, 1.0, var3), var2)
               ? true
               : this.tryPlacePiston(var1.offset(var2, 2).add(-var5, 1.0, -var3), var2);
         }
      }
   }

   public static void placeFire(BlockPos var0, EnumHand var1, boolean var2, boolean var3) {
      EnumFacing var4 = EnumFacing.DOWN;
      BlockPos var5 = var0.offset(var4);
      EnumFacing var6 = var4.getOpposite();
      Vec3d var7 = new Vec3d(var5).add(0.5, 0.5, 0.5).add(new Vec3d(var6.getDirectionVec()).scale(0.5));
      if (var2) {
         EntityUtil.faceVector(var7);
      }

      PlaceRender.PlaceMap.put(var0, new PlaceRender.placePosition(var0));
      boolean var10000 = false;
      BlockUtil.rightClickBlock(var5, var7, var1, var6, var3);
   }

   private boolean doPlaceCrystal(BlockPos var1) {
      for(EnumFacing var5 : EnumFacing.VALUES) {
         if (var5 != EnumFacing.DOWN) {
            if (var5 == EnumFacing.UP) {
               boolean var10000 = false;
            } else if (this.placeCrystal(var1, var5)) {
               return true;
            }
         }

         boolean var6 = false;
      }

      return false;
   }

   private void doFire(BlockPos var1, EnumFacing var2) {
      if (this.fire.getValue()) {
         if (InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL) != -1) {
            int var3 = mc.player.inventory.currentItem;

            for(EnumFacing var7 : EnumFacing.VALUES) {
               if (var7 != EnumFacing.DOWN) {
                  if (var7 == EnumFacing.UP) {
                     boolean var10000 = false;
                  } else if (var1.offset(var7).equals(var1.offset(var2))) {
                     boolean var12 = false;
                  } else if (mc.world.getBlockState(var1.offset(var7)).getBlock() == Blocks.FIRE) {
                     return;
                  }
               }

               boolean var13 = false;
            }

            for(EnumFacing var11 : EnumFacing.VALUES) {
               if (var11 != EnumFacing.DOWN) {
                  if (var11 == EnumFacing.UP) {
                     boolean var14 = false;
                  } else if (var1.offset(var11).equals(var1.offset(var2))) {
                     boolean var15 = false;
                  } else if (var1.offset(var11).equals(var1.offset(var2, -1))) {
                     boolean var16 = false;
                  } else if (canFire(var1.offset(var11))) {
                     InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL));
                     placeFire(var1.offset(var11), EnumHand.MAIN_HAND, true, this.packet.getValue());
                     InventoryUtil.doSwap(var3);
                     return;
                  }
               }

               boolean var17 = false;
            }

            if (canFire(var1.offset(var2, -1))) {
               InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL));
               placeFire(var1.offset(var2, -1), EnumHand.MAIN_HAND, true, this.packet.getValue());
               InventoryUtil.doSwap(var3);
            } else {
               if (canFire(var1.offset(var2, 1))) {
                  InventoryUtil.doSwap(InventoryUtil.findItemInHotbar(Items.FLINT_AND_STEEL));
                  placeFire(var1.offset(var2, 1), EnumHand.MAIN_HAND, true, this.packet.getValue());
                  InventoryUtil.doSwap(var3);
               }
            }
         }
      }
   }

   private boolean isPiston(BlockPos var1, EnumFacing var2) {
      if (!(mc.world.getBlockState(var1).getBlock() instanceof BlockPistonBase)) {
         return false;
      } else if (((EnumFacing)mc.world.getBlockState(var1).getValue(BlockDirectional.FACING)).getOpposite() != var2) {
         return false;
      } else {
         boolean var10000;
         if (!mc.world.isAirBlock(var1.offset(var2, -1))
            && this.getBlock(var1.offset(var2, -1)) != Blocks.FIRE
            && this.getBlock(var1.offset(var2.getOpposite())) != Blocks.PISTON_EXTENSION) {
            var10000 = false;
         } else {
            var10000 = true;
            boolean var10001 = false;
         }

         return var10000;
      }
   }

   private boolean checkCrystal(BlockPos var1) {
      for(Entity var3 : mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(var1))) {
         if (var3 instanceof EntityEnderCrystal) {
            float var4 = DamageUtil.calculateDamage(var3, this.target);
            if (var4 > 6.0F) {
               return true;
            }
         }

         boolean var10000 = false;
      }

      return false;
   }

   private static boolean canFire(BlockPos var0) {
      if (BlockUtil.canReplace(var0.down())) {
         return false;
      } else if (!mc.world.isAirBlock(var0)) {
         return false;
      } else {
         for(EnumFacing var2 : BlockUtil.getPlacableFacings(var0, true, CombatSetting.INSTANCE.checkRaytrace.getValue())) {
            if (BlockUtil.canClick(var0.offset(var2))) {
               if (var2 == EnumFacing.DOWN) {
                  return true;
               }

               boolean var10000 = false;
            }
         }

         return false;
      }
   }

   private boolean doRedStone(BlockPos var1, EnumFacing var2) {
      if (!(this.getBlock(var1) instanceof BlockPistonBase)) {
         return false;
      } else if (((EnumFacing)mc.world.getBlockState(var1).getValue(BlockDirectional.FACING)).getOpposite() != var2) {
         return false;
      } else if (!mc.world.isAirBlock(var1.offset(var2, -1))
         && this.getBlock(var1.offset(var2, -1)) != Blocks.FIRE
         && this.getBlock(var1.offset(var2.getOpposite())) != Blocks.PISTON_EXTENSION) {
         return false;
      } else {
         for(EnumFacing var6 : EnumFacing.VALUES) {
            if (this.getBlock(var1.offset(var6)) == Blocks.REDSTONE_BLOCK) {
               return true;
            }

            boolean var10000 = false;
         }

         if (InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK) == -1) {
            return false;
         } else {
            int var9 = mc.player.inventory.currentItem;
            EnumFacing var10 = BlockUtil.getBestNeighboring(var1, var2);
            if (var10 != null) {
               InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK));
               BlockUtil.placeBlock(var1.offset(var10), EnumHand.MAIN_HAND, true, this.packet.getValue());
               InventoryUtil.doSwap(var9);
               return true;
            } else {
               for(EnumFacing var8 : EnumFacing.VALUES) {
                  if (BlockUtil.canPlace(var1.offset(var8), (double)this.placeRange.getValue().floatValue())) {
                     InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.REDSTONE_BLOCK));
                     BlockUtil.placeBlock(var1.offset(var8), EnumHand.MAIN_HAND, true, this.packet.getValue());
                     InventoryUtil.doSwap(var9);
                     return true;
                  }

                  boolean var13 = false;
                  var13 = false;
               }

               return false;
            }
         }
      }
   }
}
