package me.rebirthclient.mod.modules.impl.combat;

import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AnvilAura extends Module {
   public final Setting<Boolean> rotate;
   private final Setting<Integer> multiPlace;
   public final Setting<Float> targetRange = this.add(new Setting<>("TargetRange", 5.0F, 0.0F, 10.0F));
   private final Timer delayTimer;
   private int progress;
   public final Setting<Boolean> packet;
   private final Setting<Integer> delay;
   private final Setting<Double> maxTargetSpeed;
   public final Setting<Float> placeRange = this.add(new Setting<>("PlaceRange", 5.0F, 0.0F, 10.0F));

   public AnvilAura() {
      super("AnvilAura", "Useless", Category.COMBAT);
      this.rotate = this.add(new Setting<>("Rotate", true));
      this.packet = this.add(new Setting<>("Packet", true));
      this.delay = this.add(new Setting<>("Delay", 50, 0, 2000));
      this.multiPlace = this.add(new Setting<>("MultiPlace", 1, 1, 8));
      this.maxTargetSpeed = this.add(new Setting<>("MaxTargetSpeed", 10.0, 0.0, 30.0));
      this.delayTimer = new Timer();
      this.progress = 0;
   }

   @Override
   public void onTick() {
      if (this.delayTimer.passedMs((long)this.delay.getValue().intValue())) {
         this.progress = 0;

         for(EntityPlayer var2 : mc.world.playerEntities) {
            if (!(Managers.SPEED.getPlayerSpeed(var2) > this.maxTargetSpeed.getValue())) {
               if (EntityUtil.invalid(var2, (double)this.targetRange.getValue().floatValue())) {
                  boolean var9 = false;
               } else {
                  BlockPos var3 = EntityUtil.getEntityPos(var2);
                  if (!mc.world.isAirBlock(var3.up())) {
                     boolean var8 = false;
                  } else {
                     int var4 = 10;

                     while(true) {
                        if (var4 > 1) {
                           if (!this.checkAnvil(var3.up(var4), var3.up())) {
                              boolean var6 = false;
                              var6 = false;
                              --var4;
                              continue;
                           }

                           this.placeAnvil(var3.up(var4));
                           boolean var10000 = false;
                        }

                        boolean var5 = false;
                        break;
                     }
                  }
               }
            }
         }
      }
   }

   private boolean canPlace(BlockPos var1) {
      if (!BlockUtil.canPlace(var1)) {
         return false;
      } else {
         boolean var10000;
         if (!(
            mc.player.getDistance((double)var1.getX() + 0.5, (double)var1.getY(), (double)var1.getZ() + 0.5) > (double)this.placeRange.getValue().floatValue()
         )) {
            var10000 = true;
            boolean var10001 = false;
         } else {
            var10000 = false;
         }

         return var10000;
      }
   }

   private void placeAnvil(BlockPos var1) {
      if (this.progress < this.multiPlace.getValue()) {
         if (InventoryUtil.findHotbarBlock(Blocks.ANVIL) != -1) {
            if (this.canPlace(var1)) {
               int var2 = mc.player.inventory.currentItem;
               this.delayTimer.reset();
               boolean var10000 = false;
               ++this.progress;
               InventoryUtil.doSwap(InventoryUtil.findHotbarBlock(Blocks.ANVIL));
               BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
               InventoryUtil.doSwap(var2);
            }
         }
      }
   }

   private boolean checkAnvil(BlockPos var1, BlockPos var2) {
      if (!this.canPlace(var1)) {
         return false;
      } else {
         for(int var3 = 0; var3 < var1.getY() - var2.getY(); ++var3) {
            if (!mc.world.isAirBlock(var1.down(var3))) {
               return false;
            }

            boolean var10000 = false;
         }

         return true;
      }
   }
}
