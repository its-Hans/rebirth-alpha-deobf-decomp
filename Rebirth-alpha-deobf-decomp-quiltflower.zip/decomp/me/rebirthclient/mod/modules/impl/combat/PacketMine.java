package me.rebirthclient.mod.modules.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import me.rebirthclient.api.events.impl.BlockEvent;
import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PacketMine extends Module {
   private final Timer delayTimer;
   public final Setting<Boolean> godCancel;
   public static final List<Block> godBlocks = Arrays.asList(
      Blocks.COMMAND_BLOCK, Blocks.FLOWING_LAVA, Blocks.LAVA, Blocks.FLOWING_WATER, Blocks.WATER, Blocks.BEDROCK, Blocks.BARRIER
   );
   public static PacketMine INSTANCE;
   private final Setting<Boolean> debug;
   private final Setting<Boolean> instant;
   private final Setting<Boolean> box;
   public static BlockPos breakPos;
   private final Setting<Boolean> restart;
   private final Setting<Boolean> outline;
   private int breakNumber;
   private final Setting<Boolean> swing;
   private final Setting<Boolean> allowWeb;
   private final Setting<Integer> outlineAlpha;
   private final Setting<Integer> time;
   private final Setting<Boolean> doubleBreak;
   private final Timer mineTimer;
   private final Setting<Float> fillStart;
   private final Timer firstTimer;
   private final Setting<Boolean> switchReset;
   private final Setting<PacketMine.Mode> animationMode;
   private final Setting<Boolean> render;
   private final Setting<Boolean> text;
   private final Setting<Bind> enderChest;
   int lastSlot;
   private final Setting<PacketMine.ColorMode> textColorMode;
   private boolean startMine;
   private FadeUtils animationTime;
   private final Setting<Float> range;
   private final Setting<Float> boxExtend;
   private final Setting<Boolean> onlyGround;
   private final Setting<Boolean> wait;
   private final Setting<Integer> maxBreak;
   private boolean first;
   private final Setting<Color> textColor;
   private final Setting<Color> color;
   private final Setting<Boolean> rotate;
   private final Setting<Float> boxStart;
   private final Setting<PacketMine.ColorMode> colorMode;
   public final Setting<Boolean> hotBar;
   private final Setting<Float> damage;
   private final Setting<Boolean> mineAir;
   private final Setting<Integer> boxAlpha;
   private final Setting<Integer> delay = this.add(new Setting<>("Delay", 100, 0, 1000));

   @Override
   public void onTick() {
      if (breakPos == null) {
         this.breakNumber = 0;
         this.startMine = false;
      } else if (!mc.player.isCreative()
         && !(
            mc.player.getDistance((double)breakPos.getX() + 0.5, (double)breakPos.getY() + 0.5, (double)breakPos.getZ() + 0.5)
               > (double)this.range.getValue().floatValue()
         )
         && this.breakNumber <= this.maxBreak.getValue() - 1
         && (this.wait.getValue() || !mc.world.isAirBlock(breakPos) || this.instant.getValue())) {
         if (godBlocks.contains(mc.world.getBlockState(breakPos).getBlock())) {
            if (this.godCancel.getValue()) {
               breakPos = null;
               this.startMine = false;
            }
         } else {
            if (mc.world.isAirBlock(breakPos)) {
               if (this.enderChest.getValue().isDown() && BlockUtil.canPlace(breakPos)) {
                  int var1 = InventoryUtil.findHotbarBlock(Blocks.ENDER_CHEST);
                  if (var1 != -1) {
                     int var2 = mc.player.inventory.currentItem;
                     InventoryUtil.doSwap(var1);
                     BlockUtil.placeBlock(breakPos, EnumHand.MAIN_HAND, this.rotate.getValue(), true);
                     InventoryUtil.doSwap(var2);
                  }
               }

               this.breakNumber = 0;
            }

            if (this.first) {
               if (this.firstTimer.passedMs(300L)) {
                  mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                  this.first = false;
               }
            } else if (this.delayTimer.passedMs((long)this.delay.getValue().intValue())) {
               if (this.startMine) {
                  if (mc.world.isAirBlock(breakPos)) {
                     return;
                  }

                  if (this.onlyGround.getValue() && !mc.player.onGround && (!this.allowWeb.getValue() || !mc.player.isInWeb)) {
                     return;
                  }

                  if (PullCrystal.INSTANCE.isOn()
                     && breakPos.equals(PullCrystal.powerPos)
                     && PullCrystal.crystalPos != null
                     && !BlockUtil.posHasCrystal(PullCrystal.crystalPos)) {
                     return;
                  }

                  int var4 = this.getTool(breakPos);
                  if (var4 == -1) {
                     var4 = mc.player.inventory.currentItem + 36;
                  }

                  if (this.mineTimer
                     .passedMs(
                        (long)(
                           1.0F
                              / getBlockStrength(breakPos, (ItemStack)mc.player.inventoryContainer.getInventory().get(var4))
                              / 20.0F
                              * 1000.0F
                              * this.damage.getValue()
                        )
                     )) {
                     int var6 = mc.player.inventory.currentItem;
                     boolean var10000;
                     if (var6 + 36 != var4) {
                        var10000 = true;
                        boolean var10001 = false;
                     } else {
                        var10000 = false;
                     }

                     boolean var3 = var10000;
                     if (var3) {
                        if (this.hotBar.getValue()) {
                           InventoryUtil.doSwap(var4 - 36);
                           var10000 = false;
                        } else {
                           mc.playerController.windowClick(0, var4, var6, ClickType.SWAP, mc.player);
                           var10000 = false;
                        }
                     }

                     if (this.rotate.getValue()) {
                        EntityUtil.facePosFacing(breakPos, BlockUtil.getRayTraceFacing(breakPos));
                     }

                     if (this.swing.getValue()) {
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                     }

                     mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                     if (var3) {
                        if (this.hotBar.getValue()) {
                           InventoryUtil.doSwap(var6);
                           var10000 = false;
                        } else {
                           mc.playerController.windowClick(0, var4, var6, ClickType.SWAP, mc.player);
                           var10000 = false;
                        }
                     }

                     ++this.breakNumber;
                     this.delayTimer.reset();
                     var10000 = false;
                  }

                  boolean var12 = false;
               } else {
                  if (!this.mineAir.getValue() && mc.world.isAirBlock(breakPos)) {
                     return;
                  }

                  int var5 = this.getTool(breakPos);
                  if (var5 == -1) {
                     var5 = mc.player.inventory.currentItem + 36;
                  }

                  this.animationTime = new FadeUtils(
                     (long)(
                        1.0F
                           / getBlockStrength(breakPos, (ItemStack)mc.player.inventoryContainer.getInventory().get(var5))
                           / 20.0F
                           * 1000.0F
                           * this.damage.getValue()
                     )
                  );
                  this.mineTimer.reset();
                  boolean var13 = false;
                  if (this.swing.getValue()) {
                     mc.player.swingArm(EnumHand.MAIN_HAND);
                  }

                  mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                  this.delayTimer.reset();
                  var13 = false;
               }
            }
         }
      } else {
         this.startMine = false;
         this.breakNumber = 0;
         breakPos = null;
      }
   }

   private boolean lambda$new$5(PacketMine.Mode var1) {
      return this.render.isOpen();
   }

   private boolean lambda$new$14(Boolean var1) {
      return this.render.isOpen();
   }

   @Override
   public void onDisable() {
      this.startMine = false;
      breakPos = null;
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (!this.instant.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(Float var1) {
      boolean var10000;
      if (this.render.isOpen() && this.animationMode.getValue() == PacketMine.Mode.Custom) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void onSend(PacketEvent.Send var1) {
      if (!fullNullCheck() && !mc.player.isCreative() && this.debug.getValue() && var1.getPacket() instanceof CPacketPlayerDigging) {
         this.sendMessage(((CPacketPlayerDigging)var1.getPacket()).getAction().name());
      }
   }

   @SubscribeEvent
   public void onMotion(MotionEvent var1) {
      if (!fullNullCheck()) {
         if (!this.onlyGround.getValue() || mc.player.onGround || this.allowWeb.getValue() && mc.player.isInWeb) {
            if (this.rotate.getValue() && breakPos != null && !mc.world.isAirBlock(breakPos) && this.time.getValue() > 0) {
               int var2 = this.getTool(breakPos);
               if (var2 == -1) {
                  var2 = mc.player.inventory.currentItem + 36;
               }

               float var3 = 1.0F
                     / getBlockStrength(breakPos, (ItemStack)mc.player.inventoryContainer.getInventory().get(var2))
                     / 20.0F
                     * 1000.0F
                     * this.damage.getValue()
                  - (float)this.time.getValue().intValue();
               if (var3 <= 0.0F || this.mineTimer.passedMs((long)var3)) {
                  facePosFacing(breakPos, BlockUtil.getRayTraceFacing(breakPos), var1);
               }
            }
         }
      }
   }

   private boolean lambda$new$3(Boolean var1) {
      return this.onlyGround.getValue();
   }

   private boolean lambda$new$10(PacketMine.ColorMode var1) {
      boolean var10000;
      if (this.render.isOpen() && this.text.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static float getBlockStrength(BlockPos var0, ItemStack var1) {
      IBlockState var2 = mc.world.getBlockState(var0);
      float var3 = var2.getBlockHardness(mc.world, var0);
      if (var3 < 0.0F) {
         return 0.0F;
      } else {
         return !canBreak(var0) ? getDigSpeed(var2, var1) / var3 / 100.0F : getDigSpeed(var2, var1) / var3 / 30.0F;
      }
   }

   private boolean lambda$new$15(Integer var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.render.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static void facePosFacing(BlockPos var0, EnumFacing var1, MotionEvent var2) {
      Vec3d var3 = new Vec3d(var0).add(0.5, 0.5, 0.5).add(new Vec3d(var1.getDirectionVec()).scale(0.5));
      faceVector(var3, var2);
   }

   private boolean lambda$new$11(Color var1) {
      boolean var10000;
      if (this.render.isOpen() && this.text.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static float getDestroySpeed(IBlockState var0, ItemStack var1) {
      float var2 = 1.0F;
      if (var1 != null && !var1.isEmpty()) {
         var2 *= var1.getDestroySpeed(var0);
      }

      return var2;
   }

   private boolean lambda$new$6(Float var1) {
      boolean var10000;
      if (this.render.isOpen() && this.animationMode.getValue() == PacketMine.Mode.Custom) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck() && !mc.player.isCreative()) {
         if (var1.getPacket() instanceof CPacketHeldItemChange) {
            if (((CPacketHeldItemChange)var1.getPacket()).getSlotId() != this.lastSlot) {
               this.lastSlot = ((CPacketHeldItemChange)var1.getPacket()).getSlotId();
               if (this.switchReset.getValue()) {
                  this.startMine = false;
                  this.mineTimer.reset();
                  boolean var2 = false;
                  this.animationTime.reset();
               }
            }
         } else if (var1.getPacket() instanceof CPacketPlayerDigging) {
            if (((CPacketPlayerDigging)var1.getPacket()).getAction() == Action.START_DESTROY_BLOCK) {
               if (breakPos == null || !((CPacketPlayerDigging)var1.getPacket()).getPosition().equals(breakPos)) {
                  var1.setCanceled(true);
                  return;
               }

               this.startMine = true;
               boolean var10000 = false;
            } else if (((CPacketPlayerDigging)var1.getPacket()).getAction() == Action.STOP_DESTROY_BLOCK) {
               if (breakPos == null || !((CPacketPlayerDigging)var1.getPacket()).getPosition().equals(breakPos)) {
                  var1.setCanceled(true);
                  return;
               }

               if (!this.instant.getValue()) {
                  this.startMine = false;
               }
            }
         }
      }
   }

   private boolean lambda$new$9(Boolean var1) {
      return this.render.isOpen();
   }

   private boolean lambda$new$16(PacketMine.ColorMode var1) {
      return this.render.isOpen();
   }

   private boolean lambda$new$4(Integer var1) {
      return this.rotate.isOpen();
   }

   private boolean lambda$new$12(Boolean var1) {
      return this.render.isOpen();
   }

   private static void faceVector(Vec3d var0, MotionEvent var1) {
      float[] var2 = EntityUtil.getLegitRotations(var0);
      var1.setRotation(var2[0], var2[1]);
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!mc.player.isCreative() && breakPos != null) {
         if (this.debug.getValue()) {
            RenderUtil.drawBBFill(new AxisAlignedBB(breakPos.offset(BlockUtil.getRayTraceFacing(breakPos))), new Color(255, 255, 255), 70);
         }

         if (this.render.getValue()) {
            if (mc.world.isAirBlock(breakPos) && !this.wait.getValue() && !this.instant.getValue()) {
               return;
            }

            if (godBlocks.contains(mc.world.getBlockState(breakPos).getBlock())) {
               BlockPos var10001 = breakPos;
               Color var10003;
               if (this.colorMode.getValue() == PacketMine.ColorMode.Custom) {
                  var10003 = this.color.getValue();
                  boolean var10004 = false;
               } else {
                  var10003 = new Color(255, 0, 0, 255);
               }

               this.draw(var10001, 1.0, var10003, true);
               if (this.text.getValue()) {
                  AxisAlignedBB var2 = mc.world.getBlockState(breakPos).getSelectedBoundingBox(mc.world, breakPos);
                  RenderUtil.drawText(var2, String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("GodBlock")));
                  boolean var10000 = false;
               }
            } else {
               int var7 = this.getTool(breakPos);
               if (var7 == -1) {
                  var7 = mc.player.inventory.currentItem + 36;
               }

               this.animationTime
                  .setLength(
                     (long)(
                        1.0F
                           / getBlockStrength(breakPos, (ItemStack)mc.player.inventoryContainer.getInventory().get(var7))
                           / 20.0F
                           * 1000.0F
                           * this.damage.getValue()
                     )
                  );
               BlockPos var10 = breakPos;
               double var10002;
               if (mc.world.isAirBlock(breakPos)) {
                  var10002 = 1.0;
                  boolean var15 = false;
               } else {
                  var10002 = this.animationTime.easeOutQuad();
               }

               Color var16;
               if (this.colorMode.getValue() == PacketMine.ColorMode.Custom) {
                  var16 = this.color.getValue();
                  boolean var20 = false;
               } else {
                  var16 = new Color((int)(255.0 * Math.abs(this.animationTime.easeOutQuad() - 1.0)), (int)(255.0 * this.animationTime.easeOutQuad()), 0);
               }

               this.draw(var10, var10002, var16, mc.world.isAirBlock(breakPos));
               if (this.text.getValue()) {
                  AxisAlignedBB var3 = mc.world.getBlockState(breakPos).getSelectedBoundingBox(mc.world, breakPos);
                  if (!mc.world.isAirBlock(breakPos)) {
                     if ((float)((int)this.mineTimer.getPassedTimeMs())
                        < 1.0F
                           / getBlockStrength(breakPos, (ItemStack)mc.player.inventoryContainer.getInventory().get(var7))
                           / 20.0F
                           * 1000.0F
                           * this.damage.getValue()) {
                        double var4 = (double)this.mineTimer.getPassedTimeMs()
                           / (double)(
                              1.0F
                                 / getBlockStrength(breakPos, (ItemStack)mc.player.inventoryContainer.getInventory().get(var7))
                                 / 20.0F
                                 * 1000.0F
                                 * this.damage.getValue()
                                 / 100.0F
                           );
                        DecimalFormat var6 = new DecimalFormat("0.0");
                        String var11 = String.valueOf(new StringBuilder().append(var6.format(var4)).append("%"));
                        Color var12;
                        if (this.textColorMode.getValue() == PacketMine.ColorMode.Progress) {
                           var12 = new Color(
                              (int)(255.0 * Math.abs(this.animationTime.easeOutQuad() - 1.0)), (int)(255.0 * this.animationTime.easeOutQuad()), 0, 255
                           );
                           boolean var17 = false;
                        } else {
                           var12 = this.textColor.getValue();
                        }

                        RenderUtil.drawText(var3, var11, var12);
                        boolean var8 = false;
                     } else {
                        Color var13;
                        if (this.textColorMode.getValue() == PacketMine.ColorMode.Progress) {
                           var13 = new Color(0, 255, 0, 255);
                           boolean var18 = false;
                        } else {
                           var13 = this.textColor.getValue();
                        }

                        RenderUtil.drawText(var3, "100.0%", var13);
                        boolean var9 = false;
                     }
                  } else {
                     Color var14;
                     if (this.textColorMode.getValue() == PacketMine.ColorMode.Progress) {
                        var14 = new Color(0, 255, 0, 255);
                        boolean var19 = false;
                     } else {
                        var14 = this.textColor.getValue();
                     }

                     RenderUtil.drawText(var3, "Waiting", var14);
                  }
               }
            }
         }
      }
   }

   private boolean lambda$new$8(Float var1) {
      boolean var10000;
      if (this.render.isOpen() && this.animationMode.getValue() == PacketMine.Mode.Custom) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private int getTool(BlockPos var1) {
      if (this.hotBar.getValue()) {
         int var8 = -1;
         float var9 = 1.0F;

         for(int var10 = 0; var10 < 9; ++var10) {
            ItemStack var11 = mc.player.inventory.getStackInSlot(var10);
            if (var11 != ItemStack.EMPTY) {
               float var12 = (float)EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, var11);
               float var13 = var11.getDestroySpeed(mc.world.getBlockState(var1));
               if (var12 + var13 > var9) {
                  var9 = var12 + var13;
                  var8 = 36 + var10;
               }
            }

            boolean var14 = false;
         }

         return var8;
      } else {
         AtomicInteger var2 = new AtomicInteger();
         var2.set(-1);
         float var3 = 1.0F;

         for(Entry var5 : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
            if (!(((ItemStack)var5.getValue()).getItem() instanceof ItemAir)) {
               float var6 = (float)EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, (ItemStack)var5.getValue());
               float var7 = ((ItemStack)var5.getValue()).getDestroySpeed(mc.world.getBlockState(var1));
               if (var6 + var7 > var3) {
                  var3 = var6 + var7;
                  var2.set(var5.getKey());
               }
            }

            boolean var10000 = false;
         }

         return var2.get();
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (!this.instant.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.wait.isOpen();
   }

   @SubscribeEvent
   public void onClickBlock(BlockEvent var1) {
      if (!fullNullCheck() && !mc.player.isCreative()) {
         var1.setCanceled(true);
         if (!godBlocks.contains(mc.world.getBlockState(var1.getBlockPos()).getBlock()) || !this.godCancel.getValue()) {
            if (!var1.getBlockPos().equals(breakPos)) {
               breakPos = var1.getBlockPos();
               this.mineTimer.reset();
               boolean var10000 = false;
               this.animationTime.reset();
               if (!godBlocks.contains(mc.world.getBlockState(var1.getBlockPos()).getBlock())) {
                  if (this.restart.getValue() && !this.instant.getValue()) {
                     this.first = true;
                  }

                  this.firstTimer.reset();
                  var10000 = false;
                  mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                  if (this.doubleBreak.getValue()) {
                     mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                     mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                  }

                  if (this.swing.getValue()) {
                     mc.player.swingArm(EnumHand.MAIN_HAND);
                  }

                  this.breakNumber = 0;
               }
            }
         }
      }
   }

   public void draw(BlockPos var1, double var2, Color var4, boolean var5) {
      if (this.animationMode.getValue() != PacketMine.Mode.Both && this.animationMode.getValue() != PacketMine.Mode.Custom) {
         AxisAlignedBB var14;
         if (this.animationMode.getValue() == PacketMine.Mode.InToOut) {
            var14 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
            boolean var20 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.Up) {
            AxisAlignedBB var15 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            var14 = new AxisAlignedBB(var15.minX, var15.minY, var15.minZ, var15.maxX, var15.minY + (var15.maxY - var15.minY) * var2, var15.maxZ);
            boolean var21 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.Down) {
            AxisAlignedBB var16 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            var14 = new AxisAlignedBB(var16.minX, var16.maxY - (var16.maxY - var16.minY) * var2, var16.minZ, var16.maxX, var16.maxY, var16.maxZ);
            boolean var22 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.OutToIn) {
            var14 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(-Math.abs(var2 / 2.0 - 1.0));
            boolean var23 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.None) {
            var14 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            boolean var24 = false;
         } else {
            AxisAlignedBB var17 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
            AxisAlignedBB var8 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            if (this.animationMode.getValue() == PacketMine.Mode.Horizontal) {
               var14 = new AxisAlignedBB(var8.minX, var17.minY, var8.minZ, var8.maxX, var17.maxY, var8.maxZ);
               boolean var25 = false;
            } else {
               var14 = new AxisAlignedBB(var17.minX, var8.minY, var17.minZ, var17.maxX, var8.maxY, var17.maxZ);
            }
         }

         if (var5) {
            var14 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
         }

         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var14, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var14, var4, this.boxAlpha.getValue());
            boolean var26 = false;
         }
      } else if (this.animationMode.getValue() == PacketMine.Mode.Custom) {
         if (var5) {
            AxisAlignedBB var6 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            if (this.outline.getValue()) {
               RenderUtil.drawBBBox(var6, var4, this.outlineAlpha.getValue());
            }

            if (this.box.getValue()) {
               RenderUtil.drawBBFill(var6, var4, this.boxAlpha.getValue());
               boolean var10000 = false;
            }
         } else {
            AxisAlignedBB var10 = mc.world
               .getBlockState(var1)
               .getSelectedBoundingBox(mc.world, var1)
               .grow((double)(-this.fillStart.getValue()) - var2 * (double)(1.0F - this.fillStart.getValue()));
            double var7 = var2 + (double)this.boxExtend.getValue().floatValue();
            if (var7 > 1.0) {
               var7 = 1.0;
            }

            AxisAlignedBB var9 = mc.world
               .getBlockState(var1)
               .getSelectedBoundingBox(mc.world, var1)
               .grow((double)(-this.boxStart.getValue()) - var7 * (double)(1.0F - this.boxStart.getValue()));
            if (this.outline.getValue()) {
               RenderUtil.drawBBBox(var9, var4, this.outlineAlpha.getValue());
            }

            if (this.box.getValue()) {
               RenderUtil.drawBBFill(var10, var4, this.boxAlpha.getValue());
            }

            boolean var18 = false;
         }
      } else if (var5) {
         AxisAlignedBB var11 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var11, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var11, var4, this.boxAlpha.getValue());
            boolean var19 = false;
         }
      } else {
         AxisAlignedBB var12 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var12, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var12, var4, this.boxAlpha.getValue());
         }

         var12 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(-Math.abs(var2 / 2.0 - 1.0));
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var12, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var12, var4, this.boxAlpha.getValue());
         }
      }
   }

   public PacketMine() {
      super("PacketMine", "1", Category.COMBAT);
      this.damage = this.add(new Setting<>("Damage", 0.7F, 0.0F, 2.0F));
      this.range = this.add(new Setting<>("Range", 7.0F, 3.0F, 10.0F));
      this.maxBreak = this.add(new Setting<>("MaxBreak", 2, 1, 20));
      this.instant = this.add(new Setting<>("Instant", false));
      this.restart = this.add(new Setting<>("ReStart", true, this::lambda$new$0));
      this.wait = this.add(new Setting<>("Wait", true, this::lambda$new$1).setParent());
      this.mineAir = this.add(new Setting<>("MineAir", true, this::lambda$new$2));
      this.godCancel = this.add(new Setting<>("GodCancel", true));
      this.hotBar = this.add(new Setting<>("HotBar", false));
      this.onlyGround = this.add(new Setting<>("OnlyGround", true).setParent());
      this.allowWeb = this.add(new Setting<>("AllowWeb", true, this::lambda$new$3));
      this.doubleBreak = this.add(new Setting<>("DoubleBreak", true));
      this.swing = this.add(new Setting<>("Swing", true));
      this.rotate = this.add(new Setting<>("Rotate", true).setParent());
      this.time = this.add(new Setting<>("Time", 100, 0, 2000, this::lambda$new$4));
      this.switchReset = this.add(new Setting<>("SwitchReset", false));
      this.render = this.add(new Setting<>("Render", true).setParent());
      this.animationMode = this.add(new Setting<>("AnimationMode", PacketMine.Mode.Up, this::lambda$new$5));
      this.fillStart = this.add(new Setting<>("FillStart", 0.2F, 0.0F, 1.0F, this::lambda$new$6));
      this.boxStart = this.add(new Setting<>("BoxStart", 0.4F, 0.0F, 1.0F, this::lambda$new$7));
      this.boxExtend = this.add(new Setting<>("BoxExtend", 0.2F, 0.0F, 1.0F, this::lambda$new$8));
      this.text = this.add(new Setting<>("Text", true, this::lambda$new$9).setParent());
      this.textColorMode = this.add(new Setting<>("TextMode", PacketMine.ColorMode.Progress, this::lambda$new$10));
      this.textColor = this.add(new Setting<>("TextColor", new Color(255, 255, 255, 255), this::lambda$new$11).hideAlpha());
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$12).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 100, 0, 255, this::lambda$new$13));
      this.outline = this.add(new Setting<>("Outline", true, this::lambda$new$14).setParent());
      this.outlineAlpha = this.add(new Setting<>("OutlineAlpha", 100, 0, 255, this::lambda$new$15));
      this.colorMode = this.add(new Setting<>("ColorMode", PacketMine.ColorMode.Progress, this::lambda$new$16));
      this.color = this.add(new Setting<>("Color", new Color(189, 212, 255), this::lambda$new$17).hideAlpha());
      this.enderChest = this.add(new Setting<>("EnderChest", new Bind(-1)));
      this.debug = this.add(new Setting<>("Debug", false));
      this.mineTimer = new Timer();
      this.animationTime = new FadeUtils(1000L);
      this.startMine = false;
      this.breakNumber = 0;
      this.delayTimer = new Timer();
      this.first = false;
      this.firstTimer = new Timer();
      this.lastSlot = -1;
      INSTANCE = this;
   }

   private boolean lambda$new$13(Integer var1) {
      boolean var10000;
      if (this.box.isOpen() && this.render.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean canBreak(BlockPos var0) {
      IBlockState var1 = mc.world.getBlockState(var0);
      Block var2 = var1.getBlock();
      boolean var10000;
      if (var2.getBlockHardness(var1, mc.world, var0) != -1.0F) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static float getDigSpeed(IBlockState var0, ItemStack var1) {
      float var2 = getDestroySpeed(var0, var1);
      if (var2 > 1.0F) {
         int var3 = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, var1);
         if (var3 > 0 && !var1.isEmpty()) {
            var2 = (float)((double)var2 + StrictMath.pow((double)var3, 2.0) + 1.0);
         }
      }

      if (mc.player.isPotionActive(MobEffects.HASTE)) {
         var2 *= 1.0F + (float)(mc.player.getActivePotionEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
      }

      if (mc.player.isPotionActive(MobEffects.MINING_FATIGUE)) {
         float var4;
         switch(mc.player.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
            case 0:
               var4 = 0.3F;
               boolean var6 = false;
               break;
            case 1:
               var4 = 0.09F;
               boolean var5 = false;
               break;
            case 2:
               var4 = 0.0027F;
               boolean var10000 = false;
               break;
            case 3:
            default:
               var4 = 8.1E-4F;
         }

         var2 *= var4;
      }

      if (mc.player.isInsideOfMaterial(Material.WATER) && !EnchantmentHelper.getAquaAffinityModifier(mc.player)) {
         var2 /= 5.0F;
      }

      float var7;
      if (var2 < 0.0F) {
         var7 = 0.0F;
         boolean var10001 = false;
      } else {
         var7 = var2;
      }

      return var7;
   }

   private boolean lambda$new$17(Color var1) {
      boolean var10000;
      if (this.render.isOpen() && this.colorMode.getValue() == PacketMine.ColorMode.Custom) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum ColorMode {
      Progress,
      Custom;
      private static final PacketMine.ColorMode[] $VALUES = new PacketMine.ColorMode[]{PacketMine.ColorMode.Custom, PacketMine.ColorMode.Progress};
   }

   public static enum Mode {
      Both,
      InToOut,
      None,
      Down,
      Custom,
      OutToIn,
      Up,
      Horizontal,
      Vertical;
      private static final PacketMine.Mode[] $VALUES = new PacketMine.Mode[]{
         Down, PacketMine.Mode.Up, InToOut, PacketMine.Mode.OutToIn, Both, PacketMine.Mode.Vertical, PacketMine.Mode.Horizontal, PacketMine.Mode.Custom, None
      };
   }
}
