package me.rebirthclient.mod.modules.impl.player;

import java.text.DecimalFormat;
import java.util.Random;
import me.rebirthclient.api.events.impl.BreakBlockEvent;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemFood;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Finish;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Announcer extends Module {
   private final Setting<Double> delay;
   private int eaten;
   private double lastPositionZ;
   private final Setting<Boolean> breakBlock;
   private int broken;
   private double lastPositionX;
   private double lastPositionY;
   private final Timer delayTimer;
   private final Setting<Boolean> eat;
   private final Setting<Boolean> move = this.add(new Setting<>("Move", true));

   public Announcer() {
      super("Announcer", "announces yo shit", Category.PLAYER);
      this.breakBlock = this.add(new Setting<>("Break", true));
      this.eat = this.add(new Setting<>("Eat", true));
      this.delay = this.add(new Setting<>("Delay", 10.0, 1.0, 30.0));
      this.delayTimer = new Timer();
   }

   @Override
   public void onUpdate() {
      if (!fullNullCheck() && spawnCheck()) {
         double var1 = this.lastPositionX - mc.player.lastTickPosX;
         double var3 = this.lastPositionY - mc.player.lastTickPosY;
         double var5 = this.lastPositionZ - mc.player.lastTickPosZ;
         double var7 = Math.sqrt(var1 * var1 + var3 * var3 + var5 * var5);
         if (this.move.getValue() && var7 >= 1.0 && var7 <= 1000.0 && this.delayTimer.passedS(this.delay.getValue())) {
            mc.player.sendChatMessage(this.getWalkMessage().replace("{blocks}", new DecimalFormat("0.00").format(var7)));
            this.lastPositionX = mc.player.lastTickPosX;
            this.lastPositionY = mc.player.lastTickPosY;
            this.lastPositionZ = mc.player.lastTickPosZ;
            this.delayTimer.reset();
            boolean var10000 = false;
         }
      }
   }

   private String getEatMessage() {
      String[] var1 = new String[]{"I just ate {amount} {name}!"};
      return var1[new Random().nextInt(var1.length)];
   }

   @SubscribeEvent
   public void onBreakBlock(BreakBlockEvent var1) {
      if (!fullNullCheck() && spawnCheck()) {
         int var2 = MathUtil.randomBetween(1, 6);
         ++this.broken;
         if (this.breakBlock.getValue() && this.broken >= var2 && this.delayTimer.passedS(this.delay.getValue())) {
            mc.player
               .sendChatMessage(
                  this.getBreakMessage()
                     .replace("{amount}", String.valueOf(this.broken))
                     .replace("{name}", BlockUtil.getBlock(var1.getPos()).getLocalizedName())
               );
            this.broken = 0;
            this.delayTimer.reset();
            boolean var10000 = false;
         }
      }
   }

   private String getBreakMessage() {
      String[] var1 = new String[]{"I just destroyed {amount} {name}!"};
      return var1[new Random().nextInt(var1.length)];
   }

   private String getWalkMessage() {
      String[] var1 = new String[]{"I just flew over {blocks} blocks!"};
      return var1[new Random().nextInt(var1.length)];
   }

   @SubscribeEvent
   public void onUseItem(Finish var1) {
      if (!fullNullCheck() && spawnCheck()) {
         int var2 = MathUtil.randomBetween(1, 6);
         if (this.eat.getValue() && var1.getEntity() == mc.player && var1.getItem().getItem() instanceof ItemFood
            || var1.getItem().getItem() instanceof ItemAppleGold) {
            ++this.eaten;
            if (this.eaten >= var2 && this.delayTimer.passedS(this.delay.getValue())) {
               mc.player
                  .sendChatMessage(this.getEatMessage().replace("{amount}", String.valueOf(this.eaten)).replace("{name}", var1.getItem().getDisplayName()));
               this.eaten = 0;
               this.delayTimer.reset();
               boolean var10000 = false;
            }
         }
      }
   }

   @Override
   public void onEnable() {
      this.eaten = 0;
      this.broken = 0;
      this.delayTimer.reset();
      boolean var10000 = false;
   }
}
