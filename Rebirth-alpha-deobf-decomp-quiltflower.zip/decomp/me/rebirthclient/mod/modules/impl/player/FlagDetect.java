package me.rebirthclient.mod.modules.impl.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.CopyOfPlayer;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.api.util.render.entity.StaticModelPlayer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.exploit.Clip;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class FlagDetect extends Module {
   private final Setting<Boolean> chams;
   private final Setting<Color> color;
   private final Setting<Boolean> notify = this.add(new Setting<>("ChatNotify", true));
   private CopyOfPlayer player;
   private final Setting<Integer> fadeTime;
   private final Setting<Color> lineColor;

   private boolean lambda$new$0(Integer var1) {
      return this.chams.isOpen();
   }

   @Override
   public void onRender3D(Render3DEvent var1) {
      if (!fullNullCheck() && this.chams.getValue() && this.player != null) {
         EntityPlayer var2 = this.player.getPlayer();
         StaticModelPlayer var3 = this.player.getModel();
         double var4 = this.player.getX() - mc.getRenderManager().viewerPosX;
         double var6 = this.player.getY() - mc.getRenderManager().viewerPosY;
         double var8 = this.player.getZ() - mc.getRenderManager().viewerPosZ;
         GL11.glPushMatrix();
         GL11.glPushAttrib(1048575);
         GL11.glDisable(3553);
         GL11.glDisable(2896);
         GL11.glDisable(2929);
         GL11.glEnable(2848);
         GL11.glEnable(3042);
         GlStateManager.blendFunc(770, 771);
         GlStateManager.translate(var4, var6, var8);
         GlStateManager.rotate(180.0F - var3.getYaw(), 0.0F, 1.0F, 0.0F);
         Color var10 = this.color.getValue();
         Color var10000;
         if (this.lineColor.booleanValue) {
            var10000 = this.lineColor.getValue();
            boolean var10001 = false;
         } else {
            var10000 = this.color.getValue();
         }

         Color var11 = var10000;
         float var12 = (float)var10.getAlpha();
         float var13 = (float)var11.getAlpha();
         float var14 = var12 / (float)(this.fadeTime.getValue() * 100);
         float var15 = var13 / (float)(this.fadeTime.getValue() * 100);
         int var16 = MathHelper.clamp(
            (int)(var14 * (float)(this.player.getTime() + (long)(this.fadeTime.getValue() * 100) - System.currentTimeMillis())), 0, (int)var12
         );
         int var17 = MathHelper.clamp(
            (int)(var15 * (float)(this.player.getTime() + (long)(this.fadeTime.getValue() * 100) - System.currentTimeMillis())), 0, (int)var13
         );
         Color var18 = ColorUtil.injectAlpha(var10, var16);
         Color var19 = ColorUtil.injectAlpha(var11, var17);
         GlStateManager.enableRescaleNormal();
         GlStateManager.scale(-1.0F, -1.0F, 1.0F);
         double var20 = var2.getEntityBoundingBox().maxX - var2.getRenderBoundingBox().minX + 1.0;
         double var22 = var2.getEntityBoundingBox().maxZ - var2.getEntityBoundingBox().minZ + 1.0;
         GlStateManager.scale(var20, (double)var2.height, var22);
         GlStateManager.translate(0.0F, -1.501F, 0.0F);
         RenderUtil.glColor(var18);
         GL11.glPolygonMode(1032, 6914);
         var3.render(0.0625F);
         RenderUtil.glColor(var19);
         GL11.glLineWidth(0.8F);
         GL11.glPolygonMode(1032, 6913);
         var3.render(0.0625F);
         GL11.glPopAttrib();
         GL11.glPopMatrix();
         if (this.player.getTime() + (long)(this.fadeTime.getValue() * 100) < System.currentTimeMillis()) {
            this.player = null;
         }
      }
   }

   private boolean lambda$new$1(Color var1) {
      return this.chams.isOpen();
   }

   public FlagDetect() {
      super("FlagDetect", "Detects & notifies you when your player is being flagged", Category.PLAYER);
      this.chams = this.add(new Setting<>("Chams", true).setParent());
      this.fadeTime = this.add(new Setting<>("FadeTime", 15, 1, 50, this::lambda$new$0));
      this.color = this.add(new Setting<>("Color", new Color(190, 0, 0, 100), this::lambda$new$1));
      this.lineColor = this.add(new Setting<>("LineColor", new Color(255, 255, 255, 120), this::lambda$new$2).injectBoolean(false));
   }

   private boolean lambda$new$2(Color var1) {
      return this.chams.isOpen();
   }

   @SubscribeEvent
   public void onPacket(PacketEvent var1) {
      if (!fullNullCheck() && spawnCheck() && !Clip.INSTANCE.isOn() && var1.getPacket() instanceof SPacketPlayerPosLook) {
         if (this.notify.getValue()) {
            this.sendMessageWithID(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("Server lagged you back!")), -123);
         }

         if (this.chams.getValue()) {
            this.player = new CopyOfPlayer(
               EntityUtil.getCopiedPlayer(mc.player),
               System.currentTimeMillis(),
               mc.player.posX,
               mc.player.posY,
               mc.player.posZ,
               Integer.valueOf("slim".hashCode()).equals(mc.player.getSkinType().hashCode())
            );
         }
      }
   }
}
