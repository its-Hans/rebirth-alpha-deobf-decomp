package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.combat.PacketExp;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import org.lwjgl.input.Mouse;

public class KeyPearl extends Module {
   private final Setting<Boolean> noPlayerTrace;
   private boolean clicked;
   private final Setting<Boolean> sync;
   private final Setting<Boolean> testSync;
   private final Setting<KeyPearl.Mode> mode = this.add(new Setting<>("Mode", KeyPearl.Mode.Middle));
   private final Setting<Boolean> inventory;

   private boolean lambda$new$1(Boolean var1) {
      return this.inventory.isOpen();
   }

   @Override
   public void onEnable() {
      if (!fullNullCheck() && this.mode.getValue() == KeyPearl.Mode.Key) {
         this.throwPearl();
         this.disable();
      }
   }

   @Override
   public String getInfo() {
      return this.mode.getValue().name();
   }

   public KeyPearl() {
      super("KeyPearl", "Throws a pearl", Category.PLAYER);
      this.noPlayerTrace = this.add(new Setting<>("NoPlayerTrace", true));
      this.inventory = this.add(new Setting<>("Inventory", true).setParent());
      this.sync = this.add(new Setting<>("Sync", true, this::lambda$new$0));
      this.testSync = this.add(new Setting<>("TestSync", true, this::lambda$new$1));
   }

   @Override
   public void onTick() {
      if (this.mode.getValue() == KeyPearl.Mode.Middle) {
         if (Mouse.isButtonDown(2) && mc.currentScreen == null) {
            this.clicked = true;
            boolean var10000 = false;
         } else if (this.clicked) {
            this.throwPearl();
            this.clicked = false;
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.inventory.isOpen();
   }

   private void throwPearl() {
      if (this.noPlayerTrace.getValue()) {
         RayTraceResult var1 = mc.objectMouseOver;
         if (var1 != null && var1.typeOfHit == Type.ENTITY && var1.entityHit instanceof EntityPlayer) {
            return;
         }
      }

      int var2 = InventoryUtil.findHotbarClass(ItemEnderPearl.class);
      boolean var10000;
      if (mc.player.getHeldItemOffhand().getItem() == Items.ENDER_PEARL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      boolean var3 = var10000;
      if (mc.player.getHeldItemOffhand().getItem() == Items.ENDER_PEARL) {
         var10000 = true;
         boolean var17 = false;
      } else {
         var10000 = false;
      }

      boolean var4 = var10000;
      if (var2 == -1 && !var3 && !var4) {
         if (this.inventory.getValue()) {
            var2 = InventoryUtil.findClassInventorySlot(ItemEnderPearl.class, false);
            if (var2 != -1) {
               mc.playerController.windowClick(0, var2, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
               var10000 = false;
               mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
               var10000 = false;
               mc.playerController.windowClick(0, var2, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
               var10000 = false;
               if (this.sync.getValue()) {
                  PacketExp.INSTANCE.throwExp();
               }

               if (this.testSync.getValue()) {
                  mc.playerController.windowClick(0, var2, 0, ClickType.PICKUP, mc.player);
                  var10000 = false;
                  mc.playerController.windowClick(0, var2, 0, ClickType.PICKUP, mc.player);
                  var10000 = false;
                  mc.playerController.windowClick(0, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
                  var10000 = false;
                  mc.playerController.windowClick(0, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
                  var10000 = false;
               }
            }
         }
      } else {
         int var5 = mc.player.inventory.currentItem;
         if (!var3 && !var4) {
            InventoryUtil.switchToHotbarSlot(var2, false);
         }

         PlayerControllerMP var8 = mc.playerController;
         EntityPlayerSP var18 = mc.player;
         WorldClient var10002 = mc.world;
         EnumHand var10003;
         if (var3) {
            var10003 = EnumHand.OFF_HAND;
            boolean var10004 = false;
         } else {
            var10003 = EnumHand.MAIN_HAND;
         }

         var8.processRightClick(var18, var10002, var10003);
         var10000 = false;
         if (!var3 && !var4) {
            InventoryUtil.switchToHotbarSlot(var5, false);
         }
      }
   }

   private static enum Mode {
      Middle,
      Key;
      private static final KeyPearl.Mode[] $VALUES = new KeyPearl.Mode[]{KeyPearl.Mode.Key, Middle};
   }
}
