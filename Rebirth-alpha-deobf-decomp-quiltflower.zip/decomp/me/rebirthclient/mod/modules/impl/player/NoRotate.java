package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoRotate extends Module {
   @SubscribeEvent(
      priority = EventPriority.HIGH
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!var1.isCanceled() && !fullNullCheck()) {
         if (var1.getStage() == 0 && var1.getPacket() instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook var2 = var1.getPacket();
            var2.yaw = mc.player.rotationYaw;
            var2.pitch = mc.player.rotationPitch;
         }
      }
   }

   public NoRotate() {
      super("NoRotate", "Dangerous to use might desync you", Category.PLAYER);
   }
}
