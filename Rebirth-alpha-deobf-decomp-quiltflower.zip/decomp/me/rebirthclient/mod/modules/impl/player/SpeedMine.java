package me.rebirthclient.mod.modules.impl.player;

import java.awt.Color;
import me.rebirthclient.api.events.impl.BlockEvent;
import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.combat.PacketMine;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketConfirmTransaction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerDigging.Action;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SpeedMine extends Module {
   private final Setting<Float> startDamage;
   private final Setting<PacketMine.ColorMode> colorMode;
   private final Setting<Boolean> outline;
   private static float mineDamage;
   private final Setting<PacketMine.Mode> animationMode;
   private final Setting<Integer> outlineAlpha;
   private final Setting<Float> boxExtend;
   private final Setting<Integer> boxAlpha;
   private final Setting<Float> boxStart;
   private final Setting<Boolean> strictReMine;
   private BlockPos minePosition;
   private final Setting<SpeedMine.Mode> mode = this.register(new Setting<>("Mode", SpeedMine.Mode.Packet));
   private final Setting<Boolean> rotate;
   private final Setting<Color> color;
   private EnumFacing mineFacing;
   private final Setting<Boolean> box;
   private final Setting<Float> fillStart;
   private final Setting<Boolean> strict;
   private final Setting<Float> endDamage;
   private int mineBreaks;
   private final Setting<Boolean> render;
   private final Setting<Float> range;

   public void draw(BlockPos var1, double var2, Color var4) {
      if (var2 > 1.0) {
         var2 = 1.0;
      }

      if (this.animationMode.getValue() != PacketMine.Mode.Both && this.animationMode.getValue() != PacketMine.Mode.Custom) {
         AxisAlignedBB var11;
         if (this.animationMode.getValue() == PacketMine.Mode.InToOut) {
            var11 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
            boolean var15 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.Up) {
            AxisAlignedBB var12 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            var11 = new AxisAlignedBB(var12.minX, var12.minY, var12.minZ, var12.maxX, var12.minY + (var12.maxY - var12.minY) * var2, var12.maxZ);
            boolean var16 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.Down) {
            AxisAlignedBB var13 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            var11 = new AxisAlignedBB(var13.minX, var13.maxY - (var13.maxY - var13.minY) * var2, var13.minZ, var13.maxX, var13.maxY, var13.maxZ);
            boolean var17 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.OutToIn) {
            var11 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(-Math.abs(var2 / 2.0 - 1.0));
            boolean var18 = false;
         } else if (this.animationMode.getValue() == PacketMine.Mode.None) {
            var11 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            boolean var19 = false;
         } else {
            AxisAlignedBB var14 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
            AxisAlignedBB var7 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1);
            if (this.animationMode.getValue() == PacketMine.Mode.Horizontal) {
               var11 = new AxisAlignedBB(var7.minX, var14.minY, var7.minZ, var7.maxX, var14.maxY, var7.maxZ);
               boolean var20 = false;
            } else {
               var11 = new AxisAlignedBB(var14.minX, var7.minY, var14.minZ, var14.maxX, var7.maxY, var14.maxZ);
            }
         }

         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var11, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var11, var4, this.boxAlpha.getValue());
            boolean var21 = false;
         }
      } else if (this.animationMode.getValue() == PacketMine.Mode.Custom) {
         AxisAlignedBB var5 = mc.world
            .getBlockState(var1)
            .getSelectedBoundingBox(mc.world, var1)
            .grow((double)(-this.fillStart.getValue()) - var2 * (double)(1.0F - this.fillStart.getValue()));
         double var6 = var2 + (double)this.boxExtend.getValue().floatValue();
         if (var6 > 1.0) {
            var6 = 1.0;
         }

         AxisAlignedBB var8 = mc.world
            .getBlockState(var1)
            .getSelectedBoundingBox(mc.world, var1)
            .grow((double)(-this.boxStart.getValue()) - var6 * (double)(1.0F - this.boxStart.getValue()));
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var8, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var5, var4, this.boxAlpha.getValue());
         }

         boolean var10000 = false;
      } else {
         AxisAlignedBB var9 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(var2 / 2.0 - 0.5);
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var9, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var9, var4, this.boxAlpha.getValue());
         }

         var9 = mc.world.getBlockState(var1).getSelectedBoundingBox(mc.world, var1).grow(-Math.abs(var2 / 2.0 - 1.0));
         if (this.outline.getValue()) {
            RenderUtil.drawBBBox(var9, var4, this.outlineAlpha.getValue());
         }

         if (this.box.getValue()) {
            RenderUtil.drawBBFill(var9, var4, this.boxAlpha.getValue());
         }
      }
   }

   @SubscribeEvent
   public void onEntitySync(MotionEvent var1) {
      if (this.rotate.getValue() && (double)mineDamage > 0.95 && this.minePosition != null) {
         float[] var2 = MathUtil.calcAngle(mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(this.minePosition.add(0.5, 0.5, 0.5)));
         var1.setYaw(var2[0]);
         var1.setPitch(var2[1]);
      }
   }

   private boolean lambda$new$5(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public float getBlockStrength(IBlockState var1, BlockPos var2) {
      float var3 = var1.getBlockHardness(mc.world, var2);
      if (var3 < 0.0F) {
         return 0.0F;
      } else {
         return !this.canBreak(var2) ? this.getDigSpeed(var1) / var3 / 100.0F : this.getDigSpeed(var1) / var3 / 30.0F;
      }
   }

   private boolean lambda$new$15(PacketMine.ColorMode var1) {
      boolean var10000;
      if (this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (var1.getPacket() instanceof CPacketHeldItemChange && this.strict.getValue()) {
         mineDamage = 0.0F;
      }
   }

   private boolean lambda$new$1(Float var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Damage) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Color var1) {
      boolean var10000;
      if (this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet && this.colorMode.getValue() == PacketMine.ColorMode.Custom) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Boolean var1) {
      boolean var10000;
      if (this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private int getTool(BlockPos var1) {
      int var2 = -1;
      float var3 = 1.0F;

      for(int var4 = 0; var4 < 9; ++var4) {
         ItemStack var5 = mc.player.inventory.getStackInSlot(var4);
         if (var5 != ItemStack.EMPTY) {
            float var6 = (float)EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, var5);
            float var7 = var5.getDestroySpeed(mc.world.getBlockState(var1));
            if (var6 + var7 > var3) {
               var3 = var6 + var7;
               var2 = var4;
            }
         }

         boolean var10000 = false;
      }

      return var2;
   }

   private ItemStack getTool2(IBlockState var1) {
      ItemStack var2 = null;
      float var3 = 1.0F;

      for(int var4 = 0; var4 < 9; ++var4) {
         ItemStack var5 = mc.player.inventory.getStackInSlot(var4);
         if (var5 != ItemStack.EMPTY) {
            float var6 = (float)EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, var5);
            float var7 = var5.getDestroySpeed(var1);
            if (var6 + var7 > var3) {
               var3 = var6 + var7;
               var2 = var5;
            }
         }

         boolean var10000 = false;
      }

      return var2;
   }

   private boolean lambda$new$3(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$9(Float var1) {
      boolean var10000;
      if (this.render.isOpen() && this.animationMode.getValue() == PacketMine.Mode.Custom && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public SpeedMine() {
      super("SpeedMine", "Allows you to dig-quickly", Category.PLAYER);
      this.startDamage = this.register(new Setting<>("StartDamage", 0.1F, 0.0F, 1.0F, this::lambda$new$0));
      this.endDamage = this.register(new Setting<>("EndDamage", 0.9F, 0.0F, 1.0F, this::lambda$new$1));
      this.range = this.register(new Setting<>("Range", 6.2F, 3.0F, 10.0F, this::lambda$new$2));
      this.rotate = this.register(new Setting<>("Rotate", false, this::lambda$new$3));
      this.strict = this.register(new Setting<>("Strict", false, this::lambda$new$4));
      this.strictReMine = this.register(new Setting<>("StrictBreak", false, this::lambda$new$5));
      this.render = this.add(new Setting<>("Render", true, this::lambda$new$6).setParent());
      this.animationMode = this.add(new Setting<>("AnimationMode", PacketMine.Mode.Up, this::lambda$new$7));
      this.fillStart = this.add(new Setting<>("FillStart", 0.2F, 0.0F, 1.0F, this::lambda$new$8));
      this.boxStart = this.add(new Setting<>("BoxStart", 0.4F, 0.0F, 1.0F, this::lambda$new$9));
      this.boxExtend = this.add(new Setting<>("BoxExtend", 0.2F, 0.0F, 1.0F, this::lambda$new$10));
      this.box = this.add(new Setting<>("Box", true, this::lambda$new$11).setParent());
      this.boxAlpha = this.add(new Setting<>("BoxAlpha", 100, 0, 255, this::lambda$new$12));
      this.outline = this.add(new Setting<>("Outline", true, this::lambda$new$13).setParent());
      this.outlineAlpha = this.add(new Setting<>("OutlineAlpha", 100, 0, 255, this::lambda$new$14));
      this.colorMode = this.add(new Setting<>("ColorMode", PacketMine.ColorMode.Progress, this::lambda$new$15));
      this.color = this.add(new Setting<>("Color", new Color(189, 212, 255), this::lambda$new$16).hideAlpha());
   }

   private boolean lambda$new$12(Integer var1) {
      boolean var10000;
      if (this.box.isOpen() && this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Float var1) {
      boolean var10000;
      if (this.render.isOpen() && this.animationMode.getValue() == PacketMine.Mode.Custom && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Float var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Damage) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onUpdate() {
      if (!mc.player.capabilities.isCreativeMode) {
         if (this.minePosition != null) {
            double var1 = mc.player
               .getDistance((double)this.minePosition.getX() + 0.5, (double)this.minePosition.getY() + 0.5, (double)this.minePosition.getZ() + 0.5);
            if (this.mineBreaks >= 2 && this.strictReMine.getValue()
               || var1 > (double)this.range.getValue().floatValue()
               || mc.world.isAirBlock(this.minePosition)) {
               this.minePosition = null;
               this.mineFacing = null;
               mineDamage = 0.0F;
               this.mineBreaks = 0;
            }
         }

         if (this.mode.getValue() == SpeedMine.Mode.Damage) {
            if (mc.playerController.curBlockDamageMP < this.startDamage.getValue()) {
               mc.playerController.curBlockDamageMP = this.startDamage.getValue();
            }

            if (mc.playerController.curBlockDamageMP >= this.endDamage.getValue()) {
               mc.playerController.curBlockDamageMP = 1.0F;
               boolean var10000 = false;
            }
         } else if (this.mode.getValue() == SpeedMine.Mode.Packet) {
            if (this.minePosition != null) {
               if (mineDamage >= 1.0F) {
                  int var5 = mc.player.inventory.currentItem;
                  int var2 = this.getTool(this.minePosition);
                  if (var2 == -1) {
                     return;
                  }

                  if (this.strict.getValue()) {
                     short var3 = mc.player.openContainer.getNextTransactionID(mc.player.inventory);
                     ItemStack var4 = mc.player.openContainer.slotClick(var2, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
                     mc.player
                        .connection
                        .sendPacket(
                           new CPacketClickWindow(mc.player.inventoryContainer.windowId, var2, mc.player.inventory.currentItem, ClickType.SWAP, var4, var3)
                        );
                     boolean var8 = false;
                  } else {
                     mc.player.connection.sendPacket(new CPacketHeldItemChange(var2));
                  }

                  mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, this.minePosition, this.mineFacing));
                  mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.ABORT_DESTROY_BLOCK, this.minePosition, EnumFacing.UP));
                  if (this.strict.getValue()) {
                     mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, this.minePosition, this.mineFacing));
                  }

                  mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.STOP_DESTROY_BLOCK, this.minePosition, this.mineFacing));
                  if (var5 != -1) {
                     if (this.strict.getValue()) {
                        short var6 = mc.player.openContainer.getNextTransactionID(mc.player.inventory);
                        ItemStack var7 = mc.player.openContainer.slotClick(var2, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
                        mc.player
                           .connection
                           .sendPacket(
                              new CPacketClickWindow(mc.player.inventoryContainer.windowId, var2, mc.player.inventory.currentItem, ClickType.SWAP, var7, var6)
                           );
                        mc.player.connection.sendPacket(new CPacketConfirmTransaction(mc.player.inventoryContainer.windowId, var6, true));
                        boolean var9 = false;
                     } else {
                        mc.player.connection.sendPacket(new CPacketHeldItemChange(var5));
                     }
                  }

                  mineDamage = 0.0F;
                  ++this.mineBreaks;
               }

               mineDamage += this.getBlockStrength(mc.world.getBlockState(this.minePosition), this.minePosition);
               boolean var10 = false;
            } else {
               mineDamage = 0.0F;
            }
         }
      }
   }

   private boolean lambda$new$14(Integer var1) {
      boolean var10000;
      if (this.outline.isOpen() && this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$7(PacketMine.Mode var1) {
      boolean var10000;
      if (this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean canBreak(BlockPos var1) {
      IBlockState var2 = mc.world.getBlockState(var1);
      Block var3 = var2.getBlock();
      boolean var10000;
      if (var3.getBlockHardness(var2, mc.world, var1) != -1.0F) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onDisable() {
      this.minePosition = null;
      this.mineFacing = null;
      mineDamage = 0.0F;
      this.mineBreaks = 0;
   }

   public float getDestroySpeed(IBlockState var1) {
      float var2 = 1.0F;
      if (this.getTool2(var1) != null && !this.getTool2(var1).isEmpty()) {
         var2 *= this.getTool2(var1).getDestroySpeed(var1);
      }

      return var2;
   }

   private boolean lambda$new$2(Float var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   @Override
   public void onRender3D(Render3DEvent var1) {
      if (this.mode.getValue() == SpeedMine.Mode.Packet && this.minePosition != null && !mc.world.isAirBlock(this.minePosition)) {
         double var2 = (double)mineDamage;
         if (var2 <= 0.0) {
            var2 = 0.0;
            boolean var10000 = false;
         } else if (var2 >= 1.0) {
            var2 = 1.0;
         }

         BlockPos var10001 = this.minePosition;
         double var10002 = (double)mineDamage;
         Color var10003;
         if (this.colorMode.getValue() == PacketMine.ColorMode.Custom) {
            var10003 = this.color.getValue();
            boolean var10004 = false;
         } else {
            var10003 = new Color((int)(255.0 * Math.abs(var2 - 1.0)), (int)(255.0 * var2), 0);
         }

         this.draw(var10001, var10002, var10003);
      }
   }

   private boolean lambda$new$10(Float var1) {
      boolean var10000;
      if (this.render.isOpen() && this.animationMode.getValue() == PacketMine.Mode.Custom && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onLeftClickBlock(BlockEvent var1) {
      if (!mc.player.capabilities.isCreativeMode && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var1.setCanceled(true);
         if (this.canBreak(var1.getBlockPos()) && !var1.getBlockPos().equals(this.minePosition)) {
            this.minePosition = var1.getBlockPos();
            this.mineFacing = var1.getEnumFacing();
            mineDamage = 0.0F;
            this.mineBreaks = 0;
            if (this.minePosition != null && this.mineFacing != null) {
               mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.START_DESTROY_BLOCK, this.minePosition, this.mineFacing));
               mc.player.connection.sendPacket(new CPacketPlayerDigging(Action.ABORT_DESTROY_BLOCK, this.minePosition, EnumFacing.UP));
            }
         }
      }
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public float getDigSpeed(IBlockState var1) {
      float var2 = this.getDestroySpeed(var1);
      if (var2 > 1.0F) {
         ItemStack var3 = this.getTool2(var1);
         int var4 = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, var3);
         if (var4 > 0 && !var3.isEmpty()) {
            var2 = (float)((double)var2 + StrictMath.pow((double)var4, 2.0) + 1.0);
         }
      }

      if (mc.player.isPotionActive(MobEffects.HASTE)) {
         var2 *= 1.0F + (float)(mc.player.getActivePotionEffect(MobEffects.HASTE).getAmplifier() + 1) * 0.2F;
      }

      if (mc.player.isPotionActive(MobEffects.MINING_FATIGUE)) {
         float var5;
         switch(mc.player.getActivePotionEffect(MobEffects.MINING_FATIGUE).getAmplifier()) {
            case 0:
               var5 = 0.3F;
               boolean var7 = false;
               break;
            case 1:
               var5 = 0.09F;
               boolean var6 = false;
               break;
            case 2:
               var5 = 0.0027F;
               boolean var10000 = false;
               break;
            case 3:
            default:
               var5 = 8.1E-4F;
         }

         var2 *= var5;
      }

      if (mc.player.isInsideOfMaterial(Material.WATER) && !EnchantmentHelper.getAquaAffinityModifier(mc.player)) {
         var2 /= 5.0F;
      }

      if (!mc.player.onGround) {
         var2 /= 5.0F;
      }

      float var8;
      if (var2 < 0.0F) {
         var8 = 0.0F;
         boolean var10001 = false;
      } else {
         var8 = var2;
      }

      return var8;
   }

   private boolean lambda$new$13(Boolean var1) {
      boolean var10000;
      if (this.render.isOpen() && this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Boolean var1) {
      boolean var10000;
      if (this.mode.getValue() == SpeedMine.Mode.Packet) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Mode {
      Damage,
      Packet;
      private static final SpeedMine.Mode[] $VALUES = new SpeedMine.Mode[]{SpeedMine.Mode.Packet, SpeedMine.Mode.Damage};
   }
}
