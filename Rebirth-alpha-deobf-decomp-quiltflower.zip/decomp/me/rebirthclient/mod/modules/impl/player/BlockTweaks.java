package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickBlock;
import net.minecraftforge.event.world.BlockEvent.BreakEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BlockTweaks extends Module {
   public Setting<Boolean> autoTool;
   private int lastHotbarSlot;
   public Setting<Boolean> noFriendAttack = this.add(new Setting<>("NoFriendAttack", false));
   public Setting<Boolean> noGhost;
   private int currentTargetSlot;
   public static BlockTweaks INSTANCE;
   private boolean switched;

   private void removeGlitchBlocks(BlockPos var1) {
      for(int var2 = -4; var2 <= 4; ++var2) {
         for(int var3 = -4; var3 <= 4; ++var3) {
            for(int var4 = -4; var4 <= 4; ++var4) {
               BlockPos var5 = new BlockPos(var1.getX() + var2, var1.getY() + var3, var1.getZ() + var4);
               if (mc.world.getBlockState(var5).getBlock().equals(Blocks.AIR)) {
                  mc.playerController.processRightClickBlock(mc.player, mc.world, var5, EnumFacing.DOWN, new Vec3d(0.5, 0.5, 0.5), EnumHand.MAIN_HAND);
                  boolean var10000 = false;
               }

               boolean var6 = false;
            }

            boolean var7 = false;
         }

         boolean var8 = false;
      }
   }

   public BlockTweaks() {
      super("BlockTweaks", "Some tweaks for blocks", Category.PLAYER);
      this.autoTool = this.add(new Setting<>("AutoTool", false));
      this.noGhost = this.add(new Setting<>("NoGlitchBlocks", false));
      this.lastHotbarSlot = -1;
      this.switched = false;
      this.currentTargetSlot = -1;
      INSTANCE = this;
   }

   @Override
   public void onUpdate() {
      if (mc.player.inventory.currentItem != this.lastHotbarSlot && mc.player.inventory.currentItem != this.currentTargetSlot) {
         this.lastHotbarSlot = mc.player.inventory.currentItem;
      }

      if (!mc.gameSettings.keyBindAttack.isKeyDown() && this.switched) {
         this.equip(this.lastHotbarSlot, false);
      }
   }

   private void equip(int var1, boolean var2) {
      if (var1 != -1) {
         if (var1 != mc.player.inventory.currentItem) {
            this.lastHotbarSlot = mc.player.inventory.currentItem;
         }

         this.currentTargetSlot = var1;
         mc.player.inventory.currentItem = var1;
         this.switched = var2;
      }
   }

   @SubscribeEvent
   public void onBreak(BreakEvent var1) {
      if (!fullNullCheck() && this.noGhost.getValue()) {
         if (!(mc.player.getHeldItemMainhand().getItem() instanceof ItemBlock)) {
            this.removeGlitchBlocks(mc.player.getPosition());
         }
      }
   }

   @Override
   public void onDisable() {
      if (this.switched) {
         this.equip(this.lastHotbarSlot, false);
      }

      this.lastHotbarSlot = -1;
      this.currentTargetSlot = -1;
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (this.noFriendAttack.getValue() && var1.getPacket() instanceof CPacketUseEntity) {
            Entity var2 = ((CPacketUseEntity)var1.getPacket()).getEntityFromWorld(mc.world);
            if (var2 != null && Managers.FRIENDS.isFriend(var2.getName())) {
               var1.setCanceled(true);
            }
         }
      }
   }

   @SubscribeEvent
   public void onBlockInteract(LeftClickBlock var1) {
      if (this.autoTool.getValue() && !fullNullCheck()) {
         this.equipBestTool(mc.world.getBlockState(var1.getPos()));
      }
   }

   private void equipBestTool(IBlockState var1) {
      int var2 = -1;
      double var3 = 0.0;

      for(int var5 = 0; var5 < 9; ++var5) {
         ItemStack var6 = mc.player.inventory.getStackInSlot(var5);
         if (!var6.isEmpty) {
            float var7 = var6.getDestroySpeed(var1);
            if (var7 > 1.0F) {
               double var10000 = (double)var7;
               int var8 = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, var6);
               double var10001;
               if (var8 > 0) {
                  var10001 = Math.pow((double)var8, 2.0) + 1.0;
                  boolean var10002 = false;
               } else {
                  var10001 = 0.0;
               }

               float var9 = (float)(var10000 + var10001);
               if ((double)var9 > var3) {
                  var3 = (double)var9;
                  var2 = var5;
               }
            }
         }

         boolean var10 = false;
      }

      this.equip(var2, true);
   }
}
