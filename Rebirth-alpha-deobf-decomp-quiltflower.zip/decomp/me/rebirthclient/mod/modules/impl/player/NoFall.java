package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoFall extends Module {
   private final Setting<Integer> distance = this.add(new Setting<>("Distance", 3, 0, 50));
   public static NoFall INSTANCE = new NoFall();

   @Override
   public String getInfo() {
      return "Packet";
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (var1.getPacket() instanceof CPacketPlayer) {
            for(ItemStack var3 : mc.player.getArmorInventoryList()) {
               if (var3.getItem() instanceof ItemElytra) {
                  return;
               }

               boolean var10000 = false;
            }

            if (mc.player.isElytraFlying()) {
               return;
            }

            if (mc.player.fallDistance >= (float)this.distance.getValue().intValue()) {
               CPacketPlayer var4 = var1.getPacket();
               var4.onGround = true;
            }
         }
      }
   }

   public NoFall() {
      super("NoFall", "Prevents fall damage", Category.PLAYER);
      INSTANCE = this;
   }
}
