package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoFish extends Module {
   @SubscribeEvent(
      priority = EventPriority.HIGHEST
   )
   public void onReceivePacket(PacketEvent.Receive var1) {
      if (!fullNullCheck()) {
         if (!var1.isCanceled()) {
            if (var1.getPacket() instanceof SPacketSoundEffect) {
               SPacketSoundEffect var2 = var1.getPacket();
               if (var2.getCategory() == SoundCategory.NEUTRAL
                  && var2.getSound() == SoundEvents.ENTITY_BOBBER_SPLASH
                  && mc.player.getHeldItemMainhand().getItem() == Items.FISHING_ROD) {
                  mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                  mc.player.swingArm(EnumHand.MAIN_HAND);
                  mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                  mc.player.swingArm(EnumHand.MAIN_HAND);
               }
            }
         }
      }
   }

   public AutoFish() {
      super("AutoFish", "auto fishing", Category.PLAYER);
   }
}
