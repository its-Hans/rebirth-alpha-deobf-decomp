package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.TurnEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Bind;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.EntityViewRenderEvent.CameraSetup;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FreeLook extends Module {
   boolean enabled;
   private float dPitch;
   private float dYaw;
   public final Setting<Bind> bind = this.add(new Setting<>("Bind", new Bind(-1)));

   @SubscribeEvent
   public void onTurn(TurnEvent var1) {
      if (mc.gameSettings.thirdPersonView > 0 && this.enabled) {
         this.dYaw = (float)((double)this.dYaw + (double)var1.getYaw() * 0.15);
         this.dPitch = (float)((double)this.dPitch - (double)var1.getPitch() * 0.15);
         this.dPitch = MathHelper.clamp(this.dPitch, -90.0F, 90.0F);
         var1.setCanceled(true);
      }
   }

   @Override
   public void onDisable() {
      this.enabled = false;
      mc.gameSettings.thirdPersonView = 0;
   }

   @Override
   public void onTick() {
      if (mc.currentScreen == null && this.bind.getValue().isDown()) {
         if (!this.enabled) {
            this.dYaw = 0.0F;
            this.dPitch = 0.0F;
            mc.gameSettings.thirdPersonView = 1;
         }

         this.enabled = true;
         boolean var10000 = false;
      } else {
         if (this.enabled) {
            mc.gameSettings.thirdPersonView = 0;
         }

         this.enabled = false;
      }

      if (mc.gameSettings.thirdPersonView != 1 && this.enabled) {
         this.enabled = false;
         mc.gameSettings.thirdPersonView = 0;
      }
   }

   public FreeLook() {
      super("FreeLook", "Rotate your camera and not your player in 3rd person", Category.PLAYER);
      this.enabled = false;
   }

   @SubscribeEvent
   public void onCameraSetup(CameraSetup var1) {
      if (mc.gameSettings.thirdPersonView > 0 && this.enabled) {
         var1.setYaw(var1.getYaw() + this.dYaw);
         var1.setPitch(var1.getPitch() + this.dPitch);
      }
   }
}
