package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public class AutoFuck extends Module {
   public AutoFuck() {
      super("AutoFuck", "auto fuck!!", Category.PLAYER);
   }

   @Override
   public void onTick() {
      KeyBinding var10000 = mc.gameSettings.keyBindSneak;
      boolean var10001;
      if (mc.player.isSneaking() && !GameSettings.isKeyDown(mc.gameSettings.keyBindSneak)) {
         var10001 = false;
      } else {
         var10001 = true;
         boolean var10002 = false;
      }

      var10000.pressed = var10001;
   }

   @Override
   public void onDisable() {
      mc.gameSettings.keyBindSneak.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindSneak);
   }
}
