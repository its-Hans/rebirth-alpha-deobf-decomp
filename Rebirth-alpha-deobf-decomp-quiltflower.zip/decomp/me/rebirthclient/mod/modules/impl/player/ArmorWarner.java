package me.rebirthclient.mod.modules.impl.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.HashMap;
import java.util.Map;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class ArmorWarner extends Module {
   private final Setting<Boolean> notifySelf;
   private final Setting<Boolean> notification;
   private final Setting<Integer> armorThreshold = this.add(new Setting<>("Armor%", 20, 1, 100));
   private final Map<EntityPlayer, Integer> entityArmorArraylist;

   @Override
   public void onUpdate() {
      for(EntityPlayer var2 : mc.world.playerEntities) {
         if (!var2.isDead) {
            if (!Managers.FRIENDS.isFriend(var2.getName())) {
               boolean var13 = false;
            } else {
               for(ItemStack var4 : var2.inventory.armorInventory) {
                  if (var4 == ItemStack.EMPTY) {
                     boolean var10000 = false;
                  } else {
                     int var5 = EntityUtil.getDamagePercent(var4);
                     if (var5 <= this.armorThreshold.getValue() && !this.entityArmorArraylist.containsKey(var2)) {
                        if (var2 == mc.player && this.notifySelf.getValue()) {
                           this.sendMessage(
                              String.valueOf(
                                 new StringBuilder().append(ChatFormatting.RED).append("Your ").append(this.getArmorPieceName(var4)).append(" low dura!")
                              )
                           );
                        }

                        if (Managers.FRIENDS.isFriend(var2.getName()) && this.notification.getValue() && var2 != mc.player) {
                           mc.player
                              .sendChatMessage(
                                 String.valueOf(
                                    new StringBuilder()
                                       .append("/msg ")
                                       .append(var2.getName())
                                       .append(" Yo, ")
                                       .append(var2.getName())
                                       .append(", ur ")
                                       .append(this.getArmorPieceName(var4))
                                       .append(" low dura!")
                                 )
                              );
                        }

                        this.entityArmorArraylist.put(var2, var2.inventory.armorInventory.indexOf(var4));
                        boolean var6 = false;
                     }

                     if (this.entityArmorArraylist.containsKey(var2) && this.entityArmorArraylist.get(var2) == var2.inventory.armorInventory.indexOf(var4)) {
                        if (var5 <= this.armorThreshold.getValue()) {
                           boolean var7 = false;
                        } else {
                           this.entityArmorArraylist.remove(var2);
                           boolean var8 = false;
                           var8 = false;
                        }
                     }
                  }
               }

               if (this.entityArmorArraylist.containsKey(var2)) {
                  if (var2.inventory.armorInventory.get(this.entityArmorArraylist.get(var2)) != ItemStack.EMPTY) {
                     boolean var10 = false;
                  } else {
                     this.entityArmorArraylist.remove(var2);
                     boolean var11 = false;
                     var11 = false;
                  }
               }
            }
         }
      }
   }

   public ArmorWarner() {
      super("ArmorWarner", "Notifies when your armor is low durability", Category.PLAYER);
      this.notifySelf = this.add(new Setting<>("Self", true));
      this.notification = this.add(new Setting<>("Friends", true));
      this.entityArmorArraylist = new HashMap<>();
   }

   private String getArmorPieceName(ItemStack var1) {
      if (var1.getItem() == Items.DIAMOND_HELMET
         || var1.getItem() == Items.GOLDEN_HELMET
         || var1.getItem() == Items.IRON_HELMET
         || var1.getItem() == Items.CHAINMAIL_HELMET
         || var1.getItem() == Items.LEATHER_HELMET) {
         return "helmet is";
      } else if (var1.getItem() == Items.DIAMOND_CHESTPLATE
         || var1.getItem() == Items.GOLDEN_CHESTPLATE
         || var1.getItem() == Items.IRON_CHESTPLATE
         || var1.getItem() == Items.CHAINMAIL_CHESTPLATE
         || var1.getItem() == Items.LEATHER_CHESTPLATE) {
         return "chest is";
      } else {
         return var1.getItem() != Items.DIAMOND_LEGGINGS
               && var1.getItem() != Items.GOLDEN_LEGGINGS
               && var1.getItem() != Items.IRON_LEGGINGS
               && var1.getItem() != Items.CHAINMAIL_LEGGINGS
               && var1.getItem() != Items.LEATHER_LEGGINGS
            ? "boots are"
            : "leggings are";
      }
   }
}
