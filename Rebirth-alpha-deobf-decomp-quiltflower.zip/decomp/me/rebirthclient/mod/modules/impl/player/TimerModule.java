package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.MotionEvent;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.combat.CatCrystal;
import me.rebirthclient.mod.modules.impl.combat.PacketExp;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.network.play.client.CPacketPlayer.Position;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class TimerModule extends Module {
   private int rotationMode;
   private int normalPos;
   public final Setting<Boolean> packetControl;
   private float lastPitch;
   private final Setting<Float> tickNormal = this.add(new Setting<>("Speed", 1.2F, 0.1F, 10.0F));
   private int normalLookPos;
   public final Setting<Boolean> disableWhenCrystal = this.add(new Setting<>("NoCrystal", true));
   private float lastYaw;
   public static TimerModule INSTANCE = new TimerModule();
   private final Timer packetListReset;

   @SubscribeEvent
   public final void RotateEvent(MotionEvent var1) {
      if (!this.disableWhenCrystal.getValue() || CatCrystal.lastPos == null) {
         if (this.packetControl.getValue()) {
            switch(this.rotationMode) {
               case 1:
                  var1.setRotation(this.lastYaw, this.lastPitch);
                  boolean var10000 = false;
                  break;
               case 2:
                  var1.setRotation(this.lastYaw + nextFloat(1.0F, 3.0F), this.lastPitch + nextFloat(1.0F, 3.0F));
            }
         }
      }
   }

   @Override
   public void onEnable() {
      mc.timer.tickLength = 50.0F;
      this.lastYaw = mc.player.rotationYaw;
      this.lastPitch = mc.player.rotationPitch;
      this.packetListReset.reset();
      boolean var10000 = false;
   }

   @Override
   public void onUpdate() {
      if (this.disableWhenCrystal.getValue() && CatCrystal.lastPos != null) {
         mc.timer.tickLength = 50.0F;
      } else {
         if (this.packetListReset.passedMs(1000L)) {
            this.normalPos = 0;
            this.normalLookPos = 0;
            this.rotationMode = 1;
            this.lastYaw = mc.player.rotationYaw;
            this.lastPitch = mc.player.rotationPitch;
            this.packetListReset.reset();
            boolean var10000 = false;
         }

         if (this.lastPitch > 85.0F) {
            this.lastPitch = 85.0F;
         }

         if (PacketExp.INSTANCE.isThrow() && PacketExp.INSTANCE.down.getValue()) {
            this.lastPitch = 85.0F;
         }

         mc.timer.tickLength = 50.0F / this.tickNormal.getValue();
      }
   }

   @Override
   public String getInfo() {
      return String.valueOf(this.tickNormal.getValue());
   }

   public static float nextFloat(float var0, float var1) {
      float var10000;
      if (var0 != var1 && !(var1 - var0 <= 0.0F)) {
         var10000 = (float)((double)var0 + (double)(var1 - var0) * Math.random());
      } else {
         var10000 = var0;
         boolean var10001 = false;
      }

      return var10000;
   }

   @Override
   public void onDisable() {
      mc.timer.tickLength = 50.0F;
   }

   @SubscribeEvent
   public final void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (var1.getPacket() instanceof Position && this.rotationMode == 1) {
            ++this.normalPos;
            if (this.normalPos > 20) {
               this.rotationMode = 2;
               boolean var10000 = false;
            }
         } else if (var1.getPacket() instanceof PositionRotation && this.rotationMode == 2) {
            ++this.normalLookPos;
            if (this.normalLookPos > 20) {
               this.rotationMode = 1;
            }
         }
      }
   }

   public TimerModule() {
      super("Timer", "Timer", Category.PLAYER);
      this.packetControl = this.add(new Setting<>("PacketControl", true));
      this.packetListReset = new Timer();
      INSTANCE = this;
   }
}
