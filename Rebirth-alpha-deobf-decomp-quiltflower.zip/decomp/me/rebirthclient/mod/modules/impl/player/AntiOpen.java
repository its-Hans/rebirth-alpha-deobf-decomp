package me.rebirthclient.mod.modules.impl.player;

import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.api.managers.impl.SneakManager;
import me.rebirthclient.api.util.BlockUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiOpen extends Module {
   public boolean needPacket;
   private CPacketPlayerTryUseItemOnBlock cPacketPlayerTryUseItemOnBlock;
   private final Setting<Boolean> packet = this.add(new Setting<>("Packet", true));

   @Override
   public void onDisable() {
      this.needPacket = false;
   }

   @SubscribeEvent
   public void onPacket(PacketEvent.Send var1) {
      if (!fullNullCheck()
         && this.packet.getValue()
         && var1.getPacket() instanceof CPacketPlayerTryUseItemOnBlock
         && !SneakManager.isSneaking
         && BlockUtil.canUseList.contains(mc.world.getBlockState(((CPacketPlayerTryUseItemOnBlock)var1.getPacket()).getPos()).getBlock())) {
         if (!this.needPacket && !SneakManager.isSneaking) {
            this.cPacketPlayerTryUseItemOnBlock = var1.getPacket();
            var1.setCanceled(true);
            this.needPacket = true;
            boolean var10000 = false;
         } else {
            this.needPacket = false;
         }
      } else {
         if (var1.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            this.needPacket = false;
         }
      }
   }

   @Override
   public void onTick() {
      if (!this.packet.getValue()) {
         if (mc.player.openContainer instanceof ContainerChest) {
            mc.player.closeScreen();
            boolean var10000 = false;
         }
      } else if (this.needPacket && this.cPacketPlayerTryUseItemOnBlock != null) {
         mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.START_SNEAKING));
         mc.player.connection.sendPacket(this.cPacketPlayerTryUseItemOnBlock);
         mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, Action.STOP_SNEAKING));
      }
   }

   public AntiOpen() {
      super("AntiOpen", "Anti Chest", Category.PLAYER);
      this.needPacket = false;
      this.cPacketPlayerTryUseItemOnBlock = null;
   }
}
