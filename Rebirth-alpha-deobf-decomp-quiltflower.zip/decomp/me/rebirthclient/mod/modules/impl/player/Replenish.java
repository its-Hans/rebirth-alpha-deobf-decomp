package me.rebirthclient.mod.modules.impl.player;

import java.util.ArrayList;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class Replenish extends Module {
   private final ArrayList<Item> Hotbar;
   private final Timer timer;
   private final Setting<Integer> delay = this.add(new Setting<>("Delay", 2, 0, 10));
   private final Setting<Integer> stack = this.add(new Setting<>("Stack", 50, 8, 64));

   @Override
   public void onEnable() {
      if (!fullNullCheck()) {
         this.Hotbar.clear();

         for(int var1 = 0; var1 < 9; ++var1) {
            ItemStack var2 = mc.player.inventory.getStackInSlot(var1);
            if (!var2.isEmpty() && !this.Hotbar.contains(var2.getItem())) {
               this.Hotbar.add(var2.getItem());
               boolean var3 = false;
               var3 = false;
            } else {
               this.Hotbar.add(Items.AIR);
               boolean var10000 = false;
            }

            boolean var5 = false;
         }
      }
   }

   private boolean RefillSlotIfNeed(int var1) {
      ItemStack var2 = mc.player.inventory.getStackInSlot(var1);
      if (!var2.isEmpty() && var2.getItem() != Items.AIR) {
         if (!var2.isStackable()) {
            return false;
         } else if (var2.getCount() >= var2.getMaxStackSize()) {
            return false;
         } else if (var2.getCount() >= this.stack.getValue()) {
            return false;
         } else {
            for(int var3 = 9; var3 < 36; ++var3) {
               ItemStack var4 = mc.player.inventory.getStackInSlot(var3);
               if (!var4.isEmpty()) {
                  if (this.CanItemBeMergedWith(var2, var4)) {
                     mc.playerController.windowClick(mc.player.inventoryContainer.windowId, var3, 0, ClickType.QUICK_MOVE, mc.player);
                     boolean var6 = false;
                     mc.playerController.updateController();
                     return true;
                  }

                  boolean var10000 = false;
               }

               boolean var5 = false;
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private boolean CanItemBeMergedWith(ItemStack var1, ItemStack var2) {
      boolean var10000;
      if (var1.getItem() == var2.getItem() && Integer.valueOf(var2.getDisplayName().hashCode()).equals(var1.getDisplayName().hashCode())) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onUpdate() {
      if (mc.currentScreen == null) {
         if (this.timer.passedMs((long)(this.delay.getValue() * 1000))) {
            for(int var1 = 0; var1 < 9; ++var1) {
               if (this.RefillSlotIfNeed(var1)) {
                  this.timer.reset();
                  boolean var3 = false;
                  return;
               }

               boolean var10000 = false;
               var10000 = false;
            }
         }
      }
   }

   public Replenish() {
      super("Replenish", "Replenishes your hotbar", Category.PLAYER);
      this.timer = new Timer();
      this.Hotbar = new ArrayList();
   }
}
