package me.rebirthclient.mod.modules.impl.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.GraphicsEnvironment;
import me.rebirthclient.api.events.impl.ClientEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FontMod extends Module {
   public final Setting<Integer> size;
   public final Setting<Boolean> metrics;
   public final Setting<Boolean> global;
   public final Setting<FontMod.Style> style;
   public final Setting<Boolean> antiAlias;
   private boolean reload;
   public static FontMod INSTANCE;
   public final Setting<String> font = this.add(new Setting<>("Font", "Arial"));

   @Override
   public void onTick() {
      if (this.reload) {
         Managers.TEXT.init();
         this.reload = false;
      }
   }

   public int getFont() {
      switch(null.$SwitchMap$me$rebirthclient$mod$modules$impl$client$FontMod$Style[this.style.getValue().ordinal()]) {
         case 1:
            return 1;
         case 2:
            return 2;
         case 3:
            return 3;
         default:
            return 0;
      }
   }

   public FontMod() {
      super("Fonts", "Custom font for all of the clients text. Use the font command", Category.CLIENT);
      this.antiAlias = this.add(new Setting<>("AntiAlias", true));
      this.metrics = this.add(new Setting<>("Metrics", true));
      this.global = this.add(new Setting<>("Global", false));
      this.size = this.add(new Setting<>("Size", 17, 12, 30));
      this.style = this.add(new Setting<>("Style", FontMod.Style.PLAIN));
      INSTANCE = this;
   }

   private boolean checkFont(String var1) {
      for(String var5 : GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()) {
         if (Integer.valueOf(var1.hashCode()).equals(var5.hashCode())) {
            return true;
         }

         boolean var10000 = false;
      }

      return false;
   }

   @Override
   public String getInfo() {
      return this.font.getValue();
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getStage() == 2) {
            Setting var2 = var1.getSetting();
            if (var2 != null && var2.getMod().equals(this)) {
               if (Integer.valueOf("Font".hashCode()).equals(var2.getName().hashCode()) && !this.checkFont(var2.getPlannedValue().toString())) {
                  this.sendMessage(String.valueOf(new StringBuilder().append(ChatFormatting.RED).append("That font doesn't exist.")));
                  var1.setCanceled(true);
                  return;
               }

               this.reload = true;
            }
         }
      }
   }

   private static enum Style {
      BOLDITALIC,
      ITALIC,
      PLAIN,
      BOLD;

      private static final FontMod.Style[] $VALUES = new FontMod.Style[]{PLAIN, BOLD, ITALIC, BOLDITALIC};
   }
}
