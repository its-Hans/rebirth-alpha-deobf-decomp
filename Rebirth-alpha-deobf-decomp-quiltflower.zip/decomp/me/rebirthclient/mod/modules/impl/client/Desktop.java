package me.rebirthclient.mod.modules.impl.client;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;
import java.util.List;
import java.util.stream.Collectors;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;

public class Desktop extends Module {
   private final List<Entity> knownPlayers;
   private final Setting<Boolean> selfPop;
   private final Setting<Boolean> mention;
   private List<Entity> players;
   final Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
   private final Setting<Boolean> dm;
   private final Setting<Boolean> onlyTabbed;
   final TrayIcon icon = new TrayIcon(this.image, "Rebirth");
   private final Setting<Boolean> visualRange;

   public Desktop() {
      super("Desktop", "Desktop notifications", Category.CLIENT);
      this.onlyTabbed = this.add(new Setting<>("OnlyTabbed", false));
      this.visualRange = this.add(new Setting<>("VisualRange", true));
      this.selfPop = this.add(new Setting<>("TotemPop", true));
      this.mention = this.add(new Setting<>("Mention", true));
      this.dm = this.add(new Setting<>("DM", true));
      this.knownPlayers = new java.util.ArrayList();
   }

   @Override
   public void onEnable() {
      this.addIcon();
   }

   @Override
   public void onUpdate() {
      if (!fullNullCheck() && this.visualRange.getValue()) {
         label58: {
            try {
               if (!Display.isActive() && this.onlyTabbed.getValue()) {
                  return;
               }
            } catch (Exception var5) {
               break label58;
            }

            boolean var10000 = false;
         }

         this.players = mc.world.loadedEntityList.stream().filter(Desktop::lambda$onUpdate$0).collect(Collectors.toList());
         Desktop var6 = this;

         label50: {
            try {
               for(Entity var2 : var6.players) {
                  if (var2 instanceof EntityPlayer
                     && !Integer.valueOf(mc.player.getName().toUpperCase().hashCode()).equals(var2.getName().toUpperCase().hashCode())
                     && !this.knownPlayers.contains(var2)
                     && !Managers.FRIENDS.isFriend(var2.getName())) {
                     this.knownPlayers.add(var2);
                     boolean var7 = false;
                     this.icon
                        .displayMessage(
                           "Rebirth", String.valueOf(new StringBuilder().append(var2.getName()).append(" has entered your visual range!")), MessageType.INFO
                        );
                  }

                  boolean var8 = false;
               }
            } catch (Exception var4) {
               break label50;
            }

            boolean var9 = false;
         }

         var6 = this;

         try {
            var6.knownPlayers.removeIf(this::lambda$onUpdate$1);
            boolean var11 = false;
         } catch (Exception var3) {
            return;
         }

         boolean var12 = false;
      }
   }

   @SubscribeEvent
   public void onClientChatReceived(ClientChatReceivedEvent var1) {
      if (!fullNullCheck()) {
         String var2 = String.valueOf(var1.getMessage());
         if (var2.contains(mc.player.getName()) && this.mention.getValue()) {
            this.icon.displayMessage("Rebirth", "New chat mention!", MessageType.INFO);
         }

         if (var2.contains("whispers:") && this.dm.getValue()) {
            this.icon.displayMessage("Rebirth", "New direct message!", MessageType.INFO);
         }
      }
   }

   @Override
   public void onTotemPop(EntityPlayer var1) {
      if (!fullNullCheck() && var1 == mc.player && this.selfPop.getValue()) {
         this.icon.displayMessage("Rebirth", "You are popping!", MessageType.WARNING);
      }
   }

   @Override
   public void onDisable() {
      this.knownPlayers.clear();
      this.removeIcon();
   }

   private void removeIcon() {
      SystemTray var1 = SystemTray.getSystemTray();
      var1.remove(this.icon);
   }

   private static boolean lambda$onUpdate$0(Entity var0) {
      return var0 instanceof EntityPlayer;
   }

   private void addIcon() {
      SystemTray var1 = SystemTray.getSystemTray();
      this.icon.setImageAutoSize(true);
      this.icon.setToolTip("rebirth alpha");
      SystemTray var10000 = var1;
      TrayIcon var10001 = this.icon;

      try {
         var10000.add(var10001);
      } catch (AWTException var3) {
         var3.printStackTrace();
         return;
      }

      boolean var4 = false;
   }

   private boolean lambda$onUpdate$1(Entity var1) {
      boolean var10000;
      if (var1 instanceof EntityPlayer
         && !Integer.valueOf(mc.player.getName().toUpperCase().hashCode()).equals(var1.getName().toUpperCase().hashCode())
         && !this.players.contains(var1)) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onUnload() {
      this.onDisable();
   }

   @Override
   public void onLoad() {
      if (this.isOn()) {
         this.addIcon();
      }
   }
}
