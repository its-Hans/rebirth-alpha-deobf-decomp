package me.rebirthclient.mod.modules.impl.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.ModuleManager;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.EntityUtil;
import me.rebirthclient.api.util.InventoryUtil;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.math.MathUtil;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.impl.combat.Aura;
import me.rebirthclient.mod.modules.impl.combat.AutoTrap;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class HUD extends Module {
   private final Setting<Boolean> idWatermark;
   private final Setting<Boolean> watermarkVerColor;
   private final Setting<Boolean> greeterNameColor;
   private final Setting<Integer> waterMarkY;
   private final Setting<Boolean> textRadar;
   private final Setting<Boolean> watermarkShort;
   private final Setting<Boolean> watermark;
   public final Setting<Boolean> potionIcons;
   private final Setting<Boolean> armor;
   private final Setting<Boolean> ping;
   public final Setting<Boolean> combatCount;
   private final Setting<HUD.GreeterMode> greeterMode;
   private final Setting<Boolean> direction;
   public final Setting<Boolean> onlyBind;
   private Map<String, Integer> players;
   private final Setting<Boolean> forgeHax;
   private final Setting<String> greeterText;
   private final Setting<Boolean> skeetBar;
   private final Setting<Boolean> tps;
   public final Setting<Boolean> lowerCase;
   private final Setting<HUD.Page> page = this.add(new Setting<>("Page", HUD.Page.GLOBAL));
   private final Setting<Boolean> hideInChat;
   private final Setting<Boolean> time;
   private final Setting<Boolean> arrayListGlow;
   private final Setting<Boolean> arrayListRect;
   public final Setting<ModuleManager.Ordering> ordering;
   public final Setting<Integer> combatCountX;
   public static HUD INSTANCE = new HUD();
   public final Setting<Integer> combatCountY;
   private final Timer timer;
   private final Setting<Boolean> arrayList;
   private final Setting<Boolean> lag;
   private final Setting<Boolean> arrayListLine;
   private final Setting<Boolean> speed;
   private final Setting<Boolean> greeter;
   private int color;
   public final Setting<Integer> lagTime;
   private final Setting<Boolean> jamieArray;
   private final Setting<Boolean> pvp;
   private final Setting<Boolean> grayColors;
   public final Setting<String> watermarkString;
   private final Setting<Boolean> potionColor;
   private final Setting<Boolean> coords;
   private final Setting<Boolean> potions;
   private final Setting<Integer> arrayListOffset;
   private final Setting<Boolean> arrayListRectColor;
   private final Setting<Boolean> jamie;
   private final Setting<Boolean> fps;
   private final Setting<Boolean> renderingUp;
   public final Setting<Boolean> space;

   private boolean lambda$new$5(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$27(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawWelcomer() {
      int var1 = Managers.TEXT.scaledWidth;
      String var10000;
      if (this.greeterNameColor.getValue()) {
         var10000 = String.valueOf(ChatFormatting.WHITE);
         boolean var10001 = false;
      } else {
         var10000 = "";
      }

      String var2 = var10000;
      if (this.lowerCase.getValue()) {
         var10000 = "Welcome, ".toLowerCase();
         boolean var18 = false;
      } else {
         var10000 = "Welcome, ";
      }

      String var3 = var10000;
      if (this.greeterMode.getValue() == HUD.GreeterMode.PLAYER) {
         if (this.greeter.getValue()) {
            var3 = String.valueOf(new StringBuilder().append(var3).append(var2).append(mc.player.getDisplayNameString()));
         }

         if (ClickGui.INSTANCE.rainbow.getValue()) {
            if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.STATIC) {
               Managers.TEXT
                  .drawString(
                     String.valueOf(new StringBuilder().append(var3).append(ChatFormatting.RESET).append(" :')")),
                     (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var3) / 2.0F + 2.0F,
                     2.0F,
                     Managers.COLORS.getRainbow().getRGB(),
                     true
                  );
               boolean var6 = false;
               boolean var7 = false;
            } else if (this.greeterNameColor.getValue()) {
               String var19;
               if (this.lowerCase.getValue()) {
                  var19 = "Welcome,".toLowerCase();
                  boolean var10002 = false;
               } else {
                  var19 = "Welcome,";
               }

               StringBuilder var21 = new StringBuilder();
               String var10003;
               if (FontMod.INSTANCE.isOn()) {
                  var10003 = "";
                  boolean var10004 = false;
               } else {
                  var10003 = " ";
               }

               this.drawDoubleRainbowRollingString(
                  var19,
                  String.valueOf(var21.append(var10003).append(ChatFormatting.WHITE).append(mc.player.getDisplayNameString())),
                  (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var3) / 2.0F + 2.0F,
                  2.0F
               );
               TextManager var8 = Managers.TEXT;
               float var22 = (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var3) / 2.0F + 1.5F + (float)Managers.TEXT.getStringWidth(var3);
               float var24;
               if (FontMod.INSTANCE.isOn()) {
                  var24 = 1.5F;
                  boolean var26 = false;
               } else {
                  var24 = 0.0F;
               }

               var8.drawRollingRainbowString(" :')", var22 - var24, 2.0F, true);
               boolean var9 = false;
            } else {
               TextManager var10 = Managers.TEXT;
               StringBuilder var20 = new StringBuilder();
               String var23;
               if (this.lowerCase.getValue()) {
                  var23 = "Welcome,".toLowerCase();
                  boolean var25 = false;
               } else {
                  var23 = "Welcome, ";
               }

               var10.drawRollingRainbowString(
                  String.valueOf(var20.append(var23).append(mc.player.getDisplayNameString()).append(" :')")),
                  (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var3) / 2.0F + 2.0F,
                  2.0F,
                  true
               );
               boolean var11 = false;
            }
         } else {
            Managers.TEXT
               .drawString(
                  String.valueOf(new StringBuilder().append(var3).append(ChatFormatting.RESET).append(" :')")),
                  (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var3) / 2.0F + 2.0F,
                  2.0F,
                  this.color,
                  true
               );
            boolean var12 = false;
            boolean var13 = false;
         }
      } else {
         String var4 = this.greeterText.getValue();
         if (this.greeter.getValue()) {
            var4 = this.greeterText.getValue();
         }

         if (ClickGui.INSTANCE.rainbow.getValue()) {
            if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.STATIC) {
               Managers.TEXT
                  .drawString(
                     var4, (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var4) / 2.0F + 2.0F, 2.0F, Managers.COLORS.getRainbow().getRGB(), true
                  );
               boolean var14 = false;
               boolean var15 = false;
            } else {
               Managers.TEXT.drawRollingRainbowString(var4, (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var4) / 2.0F + 2.0F, 2.0F, true);
               boolean var16 = false;
            }
         } else {
            Managers.TEXT.drawString(var4, (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var4) / 2.0F + 2.0F, 2.0F, this.color, true);
            boolean var17 = false;
         }
      }
   }

   private boolean lambda$new$37(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$17(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$3(Integer var1) {
      boolean var10000;
      if (this.combatCount.isOpen() && this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Integer var1) {
      boolean var10000;
      if (this.combatCount.isOpen() && this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private String getColoredPotionString(PotionEffect var1) {
      Potion var2 = var1.getPotion();
      return String.valueOf(
         new StringBuilder()
            .append(I18n.format(var2.getName(), new Object[0]))
            .append(" ")
            .append(var1.getAmplifier() + 1)
            .append(" ")
            .append(ChatFormatting.WHITE)
            .append(Potion.getPotionDurationString(var1, 1.0F))
      );
   }

   private static boolean lambda$drawPvPInfo$46(ItemStack var0) {
      boolean var10000;
      if (var0.getItem() == Items.TOTEM_OF_UNDYING) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$11(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$43(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$33(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$34(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$41(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$21(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$8(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$42(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$31(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$36(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$22(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static boolean lambda$onRender2D$45(Module var0) {
      boolean var10000;
      if (var0.isOn() && var0.isDrawn()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onUpdate() {
      if (this.timer.passedMs(500L)) {
         this.players = this.getTextRadarMap();
         this.timer.reset();
         boolean var10000 = false;
      }
   }

   private boolean lambda$new$23(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$26(String var1) {
      boolean var10000;
      if (this.greeter.isOpen() && this.greeterMode.getValue() == HUD.GreeterMode.CUSTOM && this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private int getJamieColor(int var1) {
      int var2 = Managers.MODULES.getEnabledModules().size();
      int var3 = new Color(91, 206, 250).getRGB();
      int var4 = Color.WHITE.getRGB();
      int var5 = new Color(245, 169, 184).getRGB();
      int var6 = var2 / 5;
      if (var1 < var6) {
         return var3;
      } else if (var1 < var6 * 2) {
         return var5;
      } else if (var1 < var6 * 3) {
         return var4;
      } else if (var1 < var6 * 4) {
         return var5;
      } else {
         return var1 < var6 * 5 ? var3 : var3;
      }
   }

   public HUD() {
      super("HUD", "HUD elements drawn on your screen", Category.CLIENT);
      this.potionIcons = this.add(new Setting<>("NoPotionIcons", false, this::lambda$new$0));
      this.combatCount = this.add(new Setting<>("ItemsCount", true, this::lambda$new$1).setParent());
      this.combatCountX = this.add(new Setting<>("X", 125, 0, 300, this::lambda$new$2));
      this.combatCountY = this.add(new Setting<>("Y", 18, 0, 500, this::lambda$new$3));
      this.ordering = this.add(new Setting<>("Ordering", ModuleManager.Ordering.LENGTH, this::lambda$new$4));
      this.lagTime = this.add(new Setting<>("LagTime", 1000, 0, 2000, this::lambda$new$5));
      this.lowerCase = this.add(new Setting<>("LowerCase", false, this::lambda$new$6));
      this.grayColors = this.add(new Setting<>("Gray", true, this::lambda$new$7));
      this.renderingUp = this.add(new Setting<>("RenderingUp", true, this::lambda$new$8));
      this.skeetBar = this.add(new Setting<>("SkeetMode", false, this::lambda$new$9).setParent());
      this.jamie = this.add(new Setting<>("JamieColor", false, this::lambda$new$10));
      this.watermark = this.add(new Setting<>("Watermark", true, this::lambda$new$11).setParent());
      this.watermarkString = this.add(new Setting<>("Text", "Rebirth", this::lambda$new$12));
      this.watermarkShort = this.add(new Setting<>("Shorten", false, this::lambda$new$13));
      this.watermarkVerColor = this.add(new Setting<>("VerColor", true, this::lambda$new$14));
      this.waterMarkY = this.add(new Setting<>("Height", 2, 2, 12, this::lambda$new$15));
      this.idWatermark = this.add(new Setting<>("IdWatermark", true, this::lambda$new$16));
      this.pvp = this.add(new Setting<>("PvpInfo", true, this::lambda$new$17));
      this.textRadar = this.add(new Setting<>("TextRadar", false, this::lambda$new$18));
      this.coords = this.add(new Setting<>("Position(XYZ)", false, this::lambda$new$19));
      this.direction = this.add(new Setting<>("Direction", false, this::lambda$new$20));
      this.armor = this.add(new Setting<>("Armor", false, this::lambda$new$21));
      this.lag = this.add(new Setting<>("LagNotifier", false, this::lambda$new$22));
      this.greeter = this.add(new Setting<>("Welcomer", false, this::lambda$new$23).setParent());
      this.greeterMode = this.add(new Setting<>("Mode", HUD.GreeterMode.PLAYER, this::lambda$new$24));
      this.greeterNameColor = this.add(new Setting<>("NameColor", true, this::lambda$new$25));
      this.greeterText = this.add(new Setting<>("WelcomerText", "i sniff coke and smoke dope i got 2 habbits", this::lambda$new$26));
      this.arrayList = this.add(new Setting<>("ArrayList", true, this::lambda$new$27).setParent());
      this.arrayListOffset = this.add(new Setting<>("Offset", 50, 0, 200, this::lambda$new$28));
      this.space = this.add(new Setting<>("Space", true, this::lambda$new$29));
      this.onlyBind = this.add(new Setting<>("OnlyBind", false, this::lambda$new$30));
      this.jamieArray = this.add(new Setting<>("JamieArray", false, this::lambda$new$31));
      this.forgeHax = this.add(new Setting<>("ForgeHax", false, this::lambda$new$32));
      this.arrayListLine = this.add(new Setting<>("Outline", false, this::lambda$new$33));
      this.arrayListRect = this.add(new Setting<>("Rect", false, this::lambda$new$34));
      this.arrayListRectColor = this.add(new Setting<>("ColorRect", false, this::lambda$new$35));
      this.arrayListGlow = this.add(new Setting<>("Glow", true, this::lambda$new$36));
      this.hideInChat = this.add(new Setting<>("HideInChat", true, this::lambda$new$37));
      this.potions = this.add(new Setting<>("Potions", false, this::lambda$new$38).setParent());
      this.potionColor = this.add(new Setting<>("PotionColor", false, this::lambda$new$39));
      this.ping = this.add(new Setting<>("Ping", false, this::lambda$new$40));
      this.speed = this.add(new Setting<>("Speed", false, this::lambda$new$41));
      this.tps = this.add(new Setting<>("TPS", false, this::lambda$new$42));
      this.fps = this.add(new Setting<>("FPS", false, this::lambda$new$43));
      this.time = this.add(new Setting<>("Time", false, this::lambda$new$44));
      this.timer = new Timer();
      this.players = new HashMap<>();
      INSTANCE = this;
   }

   private boolean lambda$new$19(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$38(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$10(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.skeetBar.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$18(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private Map<String, Integer> getTextRadarMap() {
      Object var1 = new HashMap();
      DecimalFormat var2 = new DecimalFormat("#.#");
      var2.setRoundingMode(RoundingMode.CEILING);
      StringBuilder var3 = new StringBuilder();

      for(EntityPlayer var5 : mc.world.playerEntities) {
         if (!var5.isInvisible()) {
            if (Integer.valueOf(mc.player.getName().hashCode()).equals(var5.getName().hashCode())) {
               boolean var10000 = false;
            } else {
               int var6 = (int)mc.player.getDistance(var5);
               String var7 = var2.format((long)var6);
               if (var6 >= 25) {
                  var3.append(ChatFormatting.GREEN);
                  boolean var8 = false;
                  var8 = false;
               } else if (var6 > 10) {
                  var3.append(ChatFormatting.YELLOW);
                  boolean var10 = false;
                  var10 = false;
               } else {
                  var3.append(ChatFormatting.RED);
                  boolean var12 = false;
               }

               var3.append(var7);
               boolean var13 = false;
               StringBuilder var10001 = new StringBuilder();
               String var10002;
               if (Managers.FRIENDS.isCool(var5.getName())) {
                  var10002 = String.valueOf(new StringBuilder().append(ChatFormatting.GOLD).append("< > ").append(ChatFormatting.RESET));
                  boolean var10003 = false;
               } else {
                  var10002 = "";
               }

               var10001 = var10001.append(var10002);
               ChatFormatting var17;
               if (Managers.FRIENDS.isFriend(var5)) {
                  var17 = ChatFormatting.AQUA;
                  boolean var18 = false;
               } else {
                  var17 = ChatFormatting.RESET;
               }

               var1.put(
                  String.valueOf(
                     var10001.append(var17)
                        .append(var5.getName())
                        .append(" ")
                        .append(ChatFormatting.WHITE)
                        .append("[")
                        .append(ChatFormatting.RESET)
                        .append((Object)var3)
                        .append("m")
                        .append(ChatFormatting.WHITE)
                        .append("] ")
                        .append(ChatFormatting.GREEN)
                  ),
                  (int)mc.player.getDistance(var5)
               );
               var13 = false;
               var3.setLength(0);
               var13 = false;
            }
         }
      }

      if (!var1.isEmpty()) {
         var1 = MathUtil.sortByValue((Map)var1, false);
      }

      return (Map<String, Integer>)var1;
   }

   private boolean lambda$new$7(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$25(Boolean var1) {
      boolean var10000;
      if (this.greeter.isOpen() && this.greeterMode.getValue() == HUD.GreeterMode.PLAYER && this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$30(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawLagOMeter() {
      int var1 = Managers.TEXT.scaledWidth;
      if (Managers.SERVER.isServerNotResponding()) {
         StringBuilder var10000 = new StringBuilder().append(ChatFormatting.RED);
         String var10001;
         if (this.lowerCase.getValue()) {
            var10001 = "Server is lagging for ".toLowerCase();
            boolean var10002 = false;
         } else {
            var10001 = "Server is lagging for ";
         }

         String var2 = String.valueOf(
            var10000.append(var10001).append(MathUtil.round((float)Managers.SERVER.serverRespondingTime() / 1000.0F, 1)).append("s.")
         );
         Managers.TEXT.drawString(var2, (float)var1 / 2.0F - (float)Managers.TEXT.getStringWidth(var2) / 2.0F + 2.0F, 20.0F, this.color, true);
         boolean var3 = false;
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$24(HUD.GreeterMode var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.greeter.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawPvPInfo() {
      float var1 = (float)Managers.TEXT.scaledHeight / 2.0F;
      int var2 = mc.player.inventory.mainInventory.stream().filter(HUD::lambda$drawPvPInfo$46).mapToInt(ItemStack::func_190916_E).sum();
      if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) {
         var2 += mc.player.getHeldItemOffhand().getCount();
      }

      int var3 = Managers.SERVER.getPing();
      EntityPlayer var4 = EntityUtil.getClosestEnemy(7.0);
      StringBuilder var10000 = new StringBuilder();
      ChatFormatting var10001;
      if (var2 != 0) {
         var10001 = ChatFormatting.GREEN;
         boolean var10002 = false;
      } else {
         var10001 = ChatFormatting.RED;
      }

      String var5 = String.valueOf(var10000.append(String.valueOf(var10001)).append(var2));
      ChatFormatting var12;
      if (var4 != null && mc.player.getDistance(var4) <= Aura.INSTANCE.range.getValue()) {
         var12 = ChatFormatting.GREEN;
         boolean var25 = false;
      } else {
         var12 = ChatFormatting.DARK_RED;
      }

      String var8 = String.valueOf(var12);
      ChatFormatting var13;
      if (var4 != null && mc.player.getDistance(var4) <= 5.0F && AutoTrap.INSTANCE.isOn()) {
         var13 = ChatFormatting.GREEN;
         boolean var26 = false;
      } else {
         var13 = ChatFormatting.DARK_RED;
      }

      String var9 = String.valueOf(var13);
      String var10 = "HTR";
      String var11 = "PLR";
      String var6;
      if (var3 < 40) {
         var6 = String.valueOf(ChatFormatting.GREEN);
         boolean var14 = false;
      } else if (var3 < 65) {
         var6 = String.valueOf(ChatFormatting.DARK_GREEN);
         boolean var15 = false;
      } else if (var3 < 80) {
         var6 = String.valueOf(ChatFormatting.YELLOW);
         boolean var16 = false;
      } else if (var3 < 110) {
         var6 = String.valueOf(ChatFormatting.RED);
         boolean var17 = false;
      } else if (var3 < 160) {
         var6 = String.valueOf(ChatFormatting.DARK_RED);
         boolean var18 = false;
      } else {
         var6 = String.valueOf(ChatFormatting.DARK_RED);
      }

      String var7;
      if (EntityUtil.getUnsafeBlocksList(new Vec3d(mc.player.posX, mc.player.posY + 0.5, mc.player.posZ), 0, false).size() != 0) {
         var7 = String.valueOf(ChatFormatting.DARK_RED);
         boolean var19 = false;
      } else {
         var7 = String.valueOf(ChatFormatting.GREEN);
      }

      Managers.TEXT.drawString(String.valueOf(new StringBuilder().append(var8).append(var10)), 2.0F, var1 - 20.0F, this.color, true);
      boolean var20 = false;
      Managers.TEXT.drawString(String.valueOf(new StringBuilder().append(var9).append(var11)), 2.0F, var1 - 10.0F, this.color, true);
      boolean var21 = false;
      Managers.TEXT.drawString(String.valueOf(new StringBuilder().append(var6).append(var3).append(" MS")), 2.0F, var1, this.color, true);
      boolean var22 = false;
      Managers.TEXT.drawString(var5, 2.0F, var1 + 10.0F, this.color, true);
      boolean var23 = false;
      Managers.TEXT.drawString(String.valueOf(new StringBuilder().append(var7).append("LBY")), 2.0F, var1 + 20.0F, this.color, true);
      boolean var24 = false;
   }

   private boolean lambda$new$9(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$39(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.potions.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if (!fullNullCheck()) {
         int var2 = Managers.TEXT.scaledWidth;
         int var3 = Managers.TEXT.scaledHeight;
         this.color = ColorUtil.toRGBA(
            ClickGui.INSTANCE.color.getValue().getRed(), ClickGui.INSTANCE.color.getValue().getGreen(), ClickGui.INSTANCE.color.getValue().getBlue()
         );
         if (this.watermark.getValue()) {
            String var4 = String.valueOf(new StringBuilder().append(this.watermarkString.getValue()).append(" "));
            String var10000;
            if (this.watermarkVerColor.getValue()) {
               var10000 = String.valueOf(ChatFormatting.WHITE);
               boolean var10001 = false;
            } else {
               var10000 = "";
            }

            String var5 = var10000;
            StringBuilder var80 = new StringBuilder().append(var5);
            String var212;
            if (this.watermarkShort.getValue()) {
               var212 = "";
               boolean var10002 = false;
            } else {
               var212 = "alpha";
            }

            String var6 = String.valueOf(var80.append(var212));
            if (ClickGui.INSTANCE.rainbow.getValue()) {
               if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.STATIC) {
                  TextManager var81 = Managers.TEXT;
                  StringBuilder var213 = new StringBuilder();
                  String var300;
                  if (this.lowerCase.getValue()) {
                     var300 = var4.toLowerCase();
                     boolean var10003 = false;
                  } else {
                     var300 = var4;
                  }

                  var81.drawString(
                     String.valueOf(var213.append(var300).append(var6)),
                     2.0F,
                     (float)this.waterMarkY.getValue().intValue(),
                     Managers.COLORS.getRainbow().getRGB(),
                     true
                  );
                  boolean var82 = false;
                  boolean var83 = false;
               } else if (this.watermarkVerColor.getValue()) {
                  if (this.lowerCase.getValue()) {
                     var212 = var4.toLowerCase();
                     boolean var301 = false;
                  } else {
                     var212 = var4;
                  }

                  this.drawDoubleRainbowRollingString(var212, var6, 2.0F, (float)this.waterMarkY.getValue().intValue());
                  boolean var84 = false;
               } else {
                  TextManager var85 = Managers.TEXT;
                  StringBuilder var215 = new StringBuilder();
                  String var302;
                  if (this.lowerCase.getValue()) {
                     var302 = var4.toLowerCase();
                     boolean var410 = false;
                  } else {
                     var302 = var4;
                  }

                  var85.drawRollingRainbowString(String.valueOf(var215.append(var302).append(var6)), 2.0F, (float)this.waterMarkY.getValue().intValue(), true);
                  boolean var86 = false;
               }
            } else {
               TextManager var87 = Managers.TEXT;
               StringBuilder var216 = new StringBuilder();
               String var303;
               if (this.lowerCase.getValue()) {
                  var303 = var4.toLowerCase();
                  boolean var411 = false;
               } else {
                  var303 = var4;
               }

               var87.drawString(String.valueOf(var216.append(var303).append(var6)), 2.0F, (float)this.waterMarkY.getValue().intValue(), this.color, true);
               boolean var88 = false;
            }
         }

         if (this.combatCount.getValue()) {
            this.drawCombatCount();
         }

         Color var29 = new Color(
            ClickGui.INSTANCE.color.getValue().getRed(), ClickGui.INSTANCE.color.getValue().getGreen(), ClickGui.INSTANCE.color.getValue().getBlue()
         );
         if (this.skeetBar.getValue()) {
            if (this.jamie.getValue()) {
               RenderUtil.drawHGradientRect(0.0F, 0.0F, (float)var2 / 5.0F, 1.0F, ColorUtil.toRGBA(0, 180, 255), ColorUtil.toRGBA(255, 180, 255));
               RenderUtil.drawHGradientRect(
                  (float)var2 / 5.0F, 0.0F, (float)var2 / 5.0F * 2.0F, 1.0F, ColorUtil.toRGBA(255, 180, 255), ColorUtil.toRGBA(255, 255, 255)
               );
               RenderUtil.drawHGradientRect(
                  (float)var2 / 5.0F * 2.0F, 0.0F, (float)var2 / 5.0F * 3.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255), ColorUtil.toRGBA(255, 255, 255)
               );
               RenderUtil.drawHGradientRect(
                  (float)var2 / 5.0F * 3.0F, 0.0F, (float)var2 / 5.0F * 4.0F, 1.0F, ColorUtil.toRGBA(255, 255, 255), ColorUtil.toRGBA(255, 180, 255)
               );
               RenderUtil.drawHGradientRect((float)var2 / 5.0F * 4.0F, 0.0F, (float)var2, 1.0F, ColorUtil.toRGBA(255, 180, 255), ColorUtil.toRGBA(0, 180, 255));
            }

            if (ClickGui.INSTANCE.rainbow.getValue() && ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING && !this.jamie.getValue()) {
               int[] var30 = new int[]{1};
               RenderUtil.drawHGradientRect(
                  0.0F,
                  0.0F,
                  (float)var2 / 2.0F,
                  1.0F,
                  ColorUtil.rainbow(var30[0] * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB(),
                  ColorUtil.rainbow(20 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB()
               );
               RenderUtil.drawHGradientRect(
                  (float)var2 / 2.0F,
                  0.0F,
                  (float)var2,
                  1.0F,
                  ColorUtil.rainbow(20 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB(),
                  ColorUtil.rainbow(40 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB()
               );
               var30[0]++;
            }

            if (!ClickGui.INSTANCE.rainbow.getValue() && !this.jamie.getValue()) {
               RenderUtil.drawHGradientRect(
                  0.0F, 0.0F, (float)var2 / 2.0F, 1.0F, ColorUtil.pulseColor(var29, 50, 1000).getRGB(), ColorUtil.pulseColor(var29, 200, 1).getRGB()
               );
               RenderUtil.drawHGradientRect(
                  (float)var2 / 2.0F, 0.0F, (float)var2, 1.0F, ColorUtil.pulseColor(var29, 200, 1).getRGB(), ColorUtil.pulseColor(var29, 50, 1000).getRGB()
               );
            }
         }

         if (this.textRadar.getValue()) {
            int var217;
            if (this.watermark.getValue()) {
               var217 = this.waterMarkY.getValue() + 2;
               boolean var304 = false;
            } else {
               var217 = 2;
            }

            this.drawTextRadar(var217);
         }

         if (this.pvp.getValue()) {
            this.drawPvPInfo();
         }

         this.color = ColorUtil.toRGBA(
            ClickGui.INSTANCE.color.getValue().getRed(), ClickGui.INSTANCE.color.getValue().getGreen(), ClickGui.INSTANCE.color.getValue().getBlue()
         );
         if (this.idWatermark.getValue()) {
            String var31 = "Rebirth ";
            String var33 = "alpha";
            float var7 = (float)Managers.TEXT.scaledHeight / 2.0F - 30.0F;
            if (ClickGui.INSTANCE.rainbow.getValue()) {
               if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.STATIC) {
                  Managers.TEXT
                     .drawString(String.valueOf(new StringBuilder().append(var31).append(var33)), 2.0F, var7, Managers.COLORS.getRainbow().getRGB(), true);
                  boolean var89 = false;
                  var89 = false;
               } else {
                  Managers.TEXT.drawString(var31, 2.0F, var7, -1, true);
                  boolean var91 = false;
                  Managers.TEXT.drawRollingRainbowString(var33, (float)(Managers.TEXT.getStringWidth(var31) + 2), var7, true);
                  var91 = false;
               }
            } else {
               Managers.TEXT
                  .drawString(
                     String.valueOf(new StringBuilder().append(var31).append(ChatFormatting.LIGHT_PURPLE).append(var33)), 2.0F, var7, this.color, true
                  );
               boolean var93 = false;
            }
         }

         int var32 = 20;
         boolean var34 = mc.currentScreen instanceof GuiChat;
         long var35 = Managers.MODULES.modules.stream().filter(HUD::lambda$onRender2D$45).count();
         int var94;
         if (var34 && !this.renderingUp.getValue() && this.arrayListOffset.getValue() < 14) {
            var94 = 14;
            boolean var218 = false;
         } else {
            var94 = this.arrayListOffset.getValue();
         }

         int var9 = var94;
         if (this.jamieArray.getValue()) {
            var94 = ColorUtil.injectAlpha(this.getJamieColor(var32 + 1), 60);
            boolean var219 = false;
         } else if (this.arrayListRectColor.getValue()) {
            if (ClickGui.INSTANCE.rainbow.getValue()) {
               if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                  var94 = ColorUtil.toRGBA(
                     ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRed(),
                     ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getGreen(),
                     ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getBlue(),
                     60
                  );
                  boolean var220 = false;
               } else {
                  var94 = ColorUtil.toRGBA(
                     Managers.COLORS.getRainbow().getRed(), Managers.COLORS.getRainbow().getGreen(), Managers.COLORS.getRainbow().getBlue(), 60
                  );
                  boolean var221 = false;
               }
            } else {
               var94 = ColorUtil.toRGBA(
                  ColorUtil.pulseColor(var29, var32, 14).getRed(),
                  ColorUtil.pulseColor(var29, var32, 14).getGreen(),
                  ColorUtil.pulseColor(var29, var32, 14).getBlue(),
                  60
               );
               boolean var222 = false;
            }
         } else {
            var94 = ColorUtil.toRGBA(10, 10, 10, 60);
         }

         int var10 = var94;
         if (this.jamieArray.getValue()) {
            var94 = ColorUtil.injectAlpha(this.getJamieColor(var32 + 1), 60);
            boolean var223 = false;
         } else if (ClickGui.INSTANCE.rainbow.getValue()) {
            if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
               var94 = ColorUtil.toRGBA(
                  ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRed(),
                  ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getGreen(),
                  ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getBlue(),
                  60
               );
               boolean var224 = false;
            } else {
               var94 = ColorUtil.toRGBA(
                  Managers.COLORS.getRainbow().getRed(), Managers.COLORS.getRainbow().getGreen(), Managers.COLORS.getRainbow().getBlue(), 60
               );
               boolean var225 = false;
            }
         } else {
            var94 = ColorUtil.toRGBA(
               ColorUtil.pulseColor(var29, var32, 14).getRed(),
               ColorUtil.pulseColor(var29, var32, 14).getGreen(),
               ColorUtil.pulseColor(var29, var32, 14).getBlue(),
               60
            );
         }

         int var11 = var94;
         if (this.arrayList.getValue()) {
            if (this.renderingUp.getValue()) {
               if (var34 && this.hideInChat.getValue()) {
                  TextManager var121 = Managers.TEXT;
                  String var244 = String.valueOf(new StringBuilder().append(var35).append(" mods enabled"));
                  float var335 = (float)(var2 - 2 - Managers.TEXT.getStringWidth(String.valueOf(new StringBuilder().append(var35).append(" mods enabled"))));
                  float var428 = (float)(2 + var9);
                  int var500;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var500 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var585 = false;
                     } else {
                        var500 = Managers.COLORS.getRainbow().getRGB();
                        boolean var586 = false;
                     }
                  } else {
                     var500 = this.color;
                  }

                  var121.drawString(var244, var335, var428, var500, true);
                  boolean var122 = false;
                  var122 = false;
               } else if (this.ordering.getValue() == ModuleManager.Ordering.ABC) {
                  for(int var12 = 0; var12 < Managers.MODULES.sortedAbc.size(); ++var12) {
                     String var13 = Managers.MODULES.sortedAbc.get(var12);
                     if (this.forgeHax.getValue()) {
                        var13 = String.valueOf(new StringBuilder().append(Managers.MODULES.sortedAbc.get(var12)).append(ChatFormatting.RESET).append("<"));
                     }

                     if (this.arrayListRect.getValue()) {
                        var94 = var2 - 2;
                        int var226;
                        if (this.lowerCase.getValue()) {
                           var226 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                           boolean var305 = false;
                        } else {
                           var226 = Managers.TEXT.getStringWidth(var13);
                        }

                        var94 = var94 - var226 - 1;
                        if (var9 == 0) {
                           var226 = 0;
                           boolean var306 = false;
                        } else {
                           var226 = 2 + var9;
                        }

                        Gui.drawRect(var94, var226, var2, 2 + var9 + 10, var10);
                     }

                     if (this.arrayListGlow.getValue()) {
                        var94 = var2 - 2;
                        int var228;
                        if (this.lowerCase.getValue()) {
                           var228 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                           boolean var307 = false;
                        } else {
                           var228 = Managers.TEXT.getStringWidth(var13);
                        }

                        double var100 = (double)(var94 - var228 - 1);
                        double var229;
                        if (var9 == 0) {
                           var229 = 0.0;
                           boolean var308 = false;
                        } else {
                           var229 = (double)(2 + var9 - 4);
                        }

                        RenderUtil.drawGlow(var100, var229, (double)var2, (double)(2 + var9 + 15), var11);
                     }

                     if (this.arrayListLine.getValue()) {
                        var94 = var2 - 2;
                        int var230;
                        if (this.lowerCase.getValue()) {
                           var230 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                           boolean var309 = false;
                        } else {
                           var230 = Managers.TEXT.getStringWidth(var13);
                        }

                        var94 = var94 - var230 - 2;
                        if (var9 == 0) {
                           var230 = 0;
                           boolean var310 = false;
                        } else {
                           var230 = 2 + var9 - 1;
                        }

                        int var311 = var2 - 2;
                        int var412;
                        if (this.lowerCase.getValue()) {
                           var412 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                           boolean var10004 = false;
                        } else {
                           var412 = Managers.TEXT.getStringWidth(var13);
                        }

                        var311 = var311 - var412 - 1;
                        var412 = 2 + var9 + 10;
                        int var485;
                        if (this.jamieArray.getValue()) {
                           var485 = this.getJamieColor(var32 - 2);
                           boolean var10005 = false;
                        } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                           if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                              var485 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                              boolean var566 = false;
                           } else {
                              var485 = Managers.COLORS.getRainbow().getRGB();
                              boolean var567 = false;
                           }
                        } else {
                           var485 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                        }

                        Gui.drawRect(var94, var230, var311, var412, var485);
                        int var14 = var12 + 1;
                        if (var14 >= Managers.MODULES.sortedAbc.size()) {
                           var14 = var12;
                        }

                        String var15 = Managers.MODULES.sortedAbc.get(var14);
                        if (this.forgeHax.getValue()) {
                           var15 = String.valueOf(new StringBuilder().append(Managers.MODULES.sortedAbc.get(var14)).append(ChatFormatting.RESET).append("<"));
                        }

                        var94 = var2 - 2;
                        if (this.lowerCase.getValue()) {
                           var230 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                           boolean var313 = false;
                        } else {
                           var230 = Managers.TEXT.getStringWidth(var13);
                        }

                        var94 = var94 - var230 - 2;
                        var230 = 2 + var9 + 1 + 8;
                        if (var14 == var12) {
                           var311 = var2;
                           boolean var414 = false;
                        } else {
                           var311 = var2 - 2;
                           if (this.lowerCase.getValue()) {
                              var412 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                              boolean var486 = false;
                           } else {
                              var412 = Managers.TEXT.getStringWidth(var13);
                           }

                           var311 -= var412;
                           if (this.lowerCase.getValue()) {
                              var412 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                              boolean var487 = false;
                           } else {
                              var412 = Managers.TEXT.getStringWidth(var13);
                           }

                           if (this.lowerCase.getValue()) {
                              var485 = Managers.TEXT.getStringWidth(var15.toLowerCase());
                              boolean var568 = false;
                           } else {
                              var485 = Managers.TEXT.getStringWidth(var15);
                           }

                           var311 = var311 + (var412 - var485) - 1;
                        }

                        var412 = 2 + var9 + 1 + 9;
                        if (this.jamieArray.getValue()) {
                           var485 = this.getJamieColor(var32 - 2);
                           boolean var569 = false;
                        } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                           if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                              var485 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                              boolean var570 = false;
                           } else {
                              var485 = Managers.COLORS.getRainbow().getRGB();
                              boolean var571 = false;
                           }
                        } else {
                           var485 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                        }

                        Gui.drawRect(var94, var230, var311, var412, var485);
                     }

                     TextManager var105 = Managers.TEXT;
                     String var234;
                     if (this.lowerCase.getValue()) {
                        var234 = var13.toLowerCase();
                        boolean var317 = false;
                     } else {
                        var234 = var13;
                     }

                     int var318 = var2 - 2;
                     int var418;
                     if (this.lowerCase.getValue()) {
                        var418 = Managers.TEXT.getStringWidth(var13.toLowerCase());
                        boolean var490 = false;
                     } else {
                        var418 = Managers.TEXT.getStringWidth(var13);
                     }

                     float var319 = (float)(var318 - var418);
                     float var419 = (float)(3 + var9);
                     int var491;
                     if (this.jamieArray.getValue()) {
                        var491 = this.getJamieColor(var32 - 2);
                        boolean var572 = false;
                     } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                        if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                           var491 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                           boolean var573 = false;
                        } else {
                           var491 = Managers.COLORS.getRainbow().getRGB();
                           boolean var574 = false;
                        }
                     } else {
                        var491 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                     }

                     var105.drawString(var234, var319, var419, var491, true);
                     boolean var106 = false;
                     var9 += 10;
                     ++var32;
                     var106 = false;
                  }

                  boolean var108 = false;
               } else {
                  for(int var36 = 0; var36 < Managers.MODULES.sortedLength.size(); ++var36) {
                     Module var40 = Managers.MODULES.sortedLength.get(var36);
                     String var50 = var40.getArrayListInfo();
                     if (this.forgeHax.getValue()) {
                        var50 = String.valueOf(new StringBuilder().append(var50).append(ChatFormatting.RESET).append("<"));
                     }

                     if (this.arrayListRect.getValue()) {
                        var94 = var2 - 2;
                        int var235;
                        if (this.lowerCase.getValue()) {
                           var235 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                           boolean var320 = false;
                        } else {
                           var235 = Managers.TEXT.getStringWidth(var50);
                        }

                        var94 = var94 - var235 - 1;
                        if (var9 == 0) {
                           var235 = 0;
                           boolean var321 = false;
                        } else {
                           var235 = 2 + var9;
                        }

                        Gui.drawRect(var94, var235, var2, 2 + var9 + 10, var10);
                     }

                     if (this.arrayListGlow.getValue()) {
                        var94 = var2 - 2;
                        int var237;
                        if (this.lowerCase.getValue()) {
                           var237 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                           boolean var322 = false;
                        } else {
                           var237 = Managers.TEXT.getStringWidth(var50);
                        }

                        double var112 = (double)(var94 - var237 - 1);
                        double var238;
                        if (var9 == 0) {
                           var238 = 0.0;
                           boolean var323 = false;
                        } else {
                           var238 = (double)(2 + var9 - 4);
                        }

                        RenderUtil.drawGlow(var112, var238, (double)var2, (double)(2 + var9 + 15), var11);
                     }

                     if (this.arrayListLine.getValue()) {
                        var94 = var2 - 2;
                        int var239;
                        if (this.lowerCase.getValue()) {
                           var239 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                           boolean var324 = false;
                        } else {
                           var239 = Managers.TEXT.getStringWidth(var50);
                        }

                        var94 = var94 - var239 - 2;
                        if (var9 == 0) {
                           var239 = 0;
                           boolean var325 = false;
                        } else {
                           var239 = 2 + var9;
                        }

                        int var326 = var2 - 2;
                        int var420;
                        if (this.lowerCase.getValue()) {
                           var420 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                           boolean var492 = false;
                        } else {
                           var420 = Managers.TEXT.getStringWidth(var50);
                        }

                        var326 = var326 - var420 - 1;
                        var420 = 2 + var9 + 11;
                        int var493;
                        if (this.jamieArray.getValue()) {
                           var493 = this.getJamieColor(var32 - 2);
                           boolean var575 = false;
                        } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                           if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                              var493 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                              boolean var576 = false;
                           } else {
                              var493 = Managers.COLORS.getRainbow().getRGB();
                              boolean var577 = false;
                           }
                        } else {
                           var493 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                        }

                        Gui.drawRect(var94, var239, var326, var420, var493);
                        int var64 = var36 + 1;
                        if (var64 >= Managers.MODULES.sortedLength.size()) {
                           var64 = var36;
                        }

                        Module var16 = Managers.MODULES.sortedLength.get(var64);
                        String var17 = var16.getArrayListInfo();
                        if (this.forgeHax.getValue()) {
                           var17 = String.valueOf(new StringBuilder().append(var16.getArrayListInfo()).append(ChatFormatting.RESET).append("<"));
                        }

                        var94 = var2 - 2;
                        if (this.lowerCase.getValue()) {
                           var239 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                           boolean var328 = false;
                        } else {
                           var239 = Managers.TEXT.getStringWidth(var50);
                        }

                        var94 = var94 - var239 - 2;
                        var239 = 2 + var9 + 1 + 9;
                        if (var64 == var36) {
                           var326 = var2;
                           boolean var422 = false;
                        } else {
                           var326 = var2 - 2;
                           if (this.lowerCase.getValue()) {
                              var420 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                              boolean var494 = false;
                           } else {
                              var420 = Managers.TEXT.getStringWidth(var50);
                           }

                           var326 -= var420;
                           if (this.lowerCase.getValue()) {
                              var420 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                              boolean var495 = false;
                           } else {
                              var420 = Managers.TEXT.getStringWidth(var50);
                           }

                           if (this.lowerCase.getValue()) {
                              var493 = Managers.TEXT.getStringWidth(var17.toLowerCase());
                              boolean var578 = false;
                           } else {
                              var493 = Managers.TEXT.getStringWidth(var17);
                           }

                           var326 = var326 + (var420 - var493) - 1;
                        }

                        var420 = 2 + var9 + 1 + 10;
                        if (this.jamieArray.getValue()) {
                           var493 = this.getJamieColor(var32 - 2);
                           boolean var579 = false;
                        } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                           if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                              var493 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                              boolean var580 = false;
                           } else {
                              var493 = Managers.COLORS.getRainbow().getRGB();
                              boolean var581 = false;
                           }
                        } else {
                           var493 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                        }

                        Gui.drawRect(var94, var239, var326, var420, var493);
                     }

                     TextManager var117 = Managers.TEXT;
                     String var243;
                     if (this.lowerCase.getValue()) {
                        var243 = var50.toLowerCase();
                        boolean var332 = false;
                     } else {
                        var243 = var50;
                     }

                     int var333 = var2 - 2;
                     int var426;
                     if (this.lowerCase.getValue()) {
                        var426 = Managers.TEXT.getStringWidth(var50.toLowerCase());
                        boolean var498 = false;
                     } else {
                        var426 = Managers.TEXT.getStringWidth(var50);
                     }

                     float var334 = (float)(var333 - var426);
                     float var427 = (float)(3 + var9);
                     int var499;
                     if (this.jamieArray.getValue()) {
                        var499 = this.getJamieColor(var32 - 2);
                        boolean var582 = false;
                     } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                        if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                           var499 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                           boolean var583 = false;
                        } else {
                           var499 = Managers.COLORS.getRainbow().getRGB();
                           boolean var584 = false;
                        }
                     } else {
                        var499 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                     }

                     var117.drawString(var243, var334, var427, var499, true);
                     boolean var118 = false;
                     var9 += 10;
                     ++var32;
                     var118 = false;
                  }

                  boolean var120 = false;
               }
            } else if (var34 && this.hideInChat.getValue()) {
               TextManager var147 = Managers.TEXT;
               String var263 = String.valueOf(new StringBuilder().append(var35).append(" mods enabled"));
               float var362 = (float)(var2 - 2 - Managers.TEXT.getStringWidth(String.valueOf(new StringBuilder().append(var35).append(" mods enabled"))));
               float var449 = (float)(var3 - var9 - 11);
               int var524;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var524 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var607 = false;
                  } else {
                     var524 = Managers.COLORS.getRainbow().getRGB();
                     boolean var608 = false;
                  }
               } else {
                  var524 = this.color;
               }

               var147.drawString(var263, var362, var449, var524, true);
               boolean var148 = false;
               var148 = false;
            } else if (this.ordering.getValue() == ModuleManager.Ordering.ABC) {
               for(int var37 = 0; var37 < Managers.MODULES.sortedAbc.size(); ++var37) {
                  String var41 = Managers.MODULES.sortedAbc.get(var37);
                  if (this.forgeHax.getValue()) {
                     var41 = String.valueOf(new StringBuilder().append(Managers.MODULES.sortedAbc.get(var37)).append(ChatFormatting.RESET).append("<"));
                  }

                  var9 += 10;
                  if (this.arrayListRect.getValue()) {
                     var94 = var2 - 2;
                     int var245;
                     if (this.lowerCase.getValue()) {
                        var245 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                        boolean var336 = false;
                     } else {
                        var245 = Managers.TEXT.getStringWidth(var41);
                     }

                     var94 = var94 - var245 - 1;
                     var245 = var3 - var9;
                     int var429;
                     if (var9 == 1) {
                        var429 = var3;
                        boolean var501 = false;
                     } else {
                        var429 = var3 - var9 + 10;
                     }

                     Gui.drawRect(var94, var245, var2, var429, var10);
                  }

                  if (this.arrayListGlow.getValue()) {
                     var94 = var2 - 2;
                     int var247;
                     if (this.lowerCase.getValue()) {
                        var247 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                        boolean var337 = false;
                     } else {
                        var247 = Managers.TEXT.getStringWidth(var41);
                     }

                     double var127 = (double)(var94 - var247 - 1);
                     double var248 = (double)(var3 - var9 - 4);
                     double var338 = (double)var2;
                     double var430;
                     if (var9 == 1) {
                        var430 = (double)var3;
                        boolean var502 = false;
                     } else {
                        var430 = (double)(var3 - var9 + 15);
                     }

                     RenderUtil.drawGlow(var127, var248, var338, var430, var11);
                  }

                  if (this.arrayListLine.getValue()) {
                     var94 = var2 - 2;
                     int var249;
                     if (this.lowerCase.getValue()) {
                        var249 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                        boolean var339 = false;
                     } else {
                        var249 = Managers.TEXT.getStringWidth(var41);
                     }

                     var94 = var94 - var249 - 2;
                     var249 = var3 - var9;
                     int var340 = var2 - 2;
                     int var431;
                     if (this.lowerCase.getValue()) {
                        var431 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                        boolean var503 = false;
                     } else {
                        var431 = Managers.TEXT.getStringWidth(var41);
                     }

                     var340 = var340 - var431 - 1;
                     if (var9 == 1) {
                        var431 = var3;
                        boolean var504 = false;
                     } else {
                        var431 = var3 - var9 + 10;
                     }

                     int var505;
                     if (this.jamieArray.getValue()) {
                        var505 = this.getJamieColor(var32 - 2);
                        boolean var587 = false;
                     } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                        if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                           var505 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                           boolean var588 = false;
                        } else {
                           var505 = Managers.COLORS.getRainbow().getRGB();
                           boolean var589 = false;
                        }
                     } else {
                        var505 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                     }

                     Gui.drawRect(var94, var249, var340, var431, var505);
                     int var51 = var37 + 1;
                     if (var51 >= Managers.MODULES.sortedAbc.size()) {
                        var51 = var37;
                     }

                     String var65 = Managers.MODULES.sortedAbc.get(var51);
                     if (this.forgeHax.getValue()) {
                        var65 = String.valueOf(new StringBuilder().append(Managers.MODULES.sortedAbc.get(var51)).append(ChatFormatting.RESET).append("<"));
                     }

                     var94 = var2 - 2;
                     if (this.lowerCase.getValue()) {
                        var249 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                        boolean var342 = false;
                     } else {
                        var249 = Managers.TEXT.getStringWidth(var41);
                     }

                     var94 = var94 - var249 - 2;
                     var249 = var3 - var9 - 1;
                     if (var51 == var37) {
                        var340 = var2;
                        boolean var433 = false;
                     } else {
                        var340 = var2 - 2;
                        if (this.lowerCase.getValue()) {
                           var431 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                           boolean var506 = false;
                        } else {
                           var431 = Managers.TEXT.getStringWidth(var41);
                        }

                        var340 -= var431;
                        if (this.lowerCase.getValue()) {
                           var431 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                           boolean var507 = false;
                        } else {
                           var431 = Managers.TEXT.getStringWidth(var41);
                        }

                        if (this.lowerCase.getValue()) {
                           var505 = Managers.TEXT.getStringWidth(var65.toLowerCase());
                           boolean var590 = false;
                        } else {
                           var505 = Managers.TEXT.getStringWidth(var65);
                        }

                        var340 = var340 + (var431 - var505) - 1;
                     }

                     if (var9 == 1) {
                        var431 = var3;
                        boolean var509 = false;
                     } else {
                        var431 = var3 - var9;
                     }

                     if (this.jamieArray.getValue()) {
                        var505 = this.getJamieColor(var32 - 2);
                        boolean var591 = false;
                     } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                        if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                           var505 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                           boolean var592 = false;
                        } else {
                           var505 = Managers.COLORS.getRainbow().getRGB();
                           boolean var593 = false;
                        }
                     } else {
                        var505 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                     }

                     Gui.drawRect(var94, var249, var340, var431, var505);
                  }

                  TextManager var132 = Managers.TEXT;
                  String var253;
                  if (this.lowerCase.getValue()) {
                     var253 = var41.toLowerCase();
                     boolean var346 = false;
                  } else {
                     var253 = var41;
                  }

                  int var347 = var2 - 2;
                  int var437;
                  if (this.lowerCase.getValue()) {
                     var437 = Managers.TEXT.getStringWidth(var41.toLowerCase());
                     boolean var511 = false;
                  } else {
                     var437 = Managers.TEXT.getStringWidth(var41);
                  }

                  float var348 = (float)(var347 - var437);
                  float var438 = (float)(var3 - var9 + 1);
                  int var512;
                  if (this.jamieArray.getValue()) {
                     var512 = this.getJamieColor(var32 - 2);
                     boolean var594 = false;
                  } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var512 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var595 = false;
                     } else {
                        var512 = Managers.COLORS.getRainbow().getRGB();
                        boolean var596 = false;
                     }
                  } else {
                     var512 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var132.drawString(var253, var348, var438, var512, true);
                  boolean var133 = false;
                  ++var32;
                  var133 = false;
               }

               boolean var135 = false;
            } else {
               for(int var38 = 0; var38 < Managers.MODULES.sortedLength.size(); ++var38) {
                  Module var42 = Managers.MODULES.sortedLength.get(var38);
                  String var52 = var42.getArrayListInfo();
                  if (this.forgeHax.getValue()) {
                     var52 = String.valueOf(new StringBuilder().append(var52).append(ChatFormatting.RESET).append("<"));
                  }

                  var9 += 10;
                  if (this.arrayListRect.getValue()) {
                     var94 = var2 - 2;
                     int var254;
                     if (this.lowerCase.getValue()) {
                        var254 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                        boolean var349 = false;
                     } else {
                        var254 = Managers.TEXT.getStringWidth(var52);
                     }

                     var94 = var94 - var254 - 1;
                     var254 = var3 - var9;
                     int var439;
                     if (var9 == 1) {
                        var439 = var3;
                        boolean var513 = false;
                     } else {
                        var439 = var3 - var9 + 10;
                     }

                     Gui.drawRect(var94, var254, var2, var439, var10);
                  }

                  if (this.arrayListGlow.getValue()) {
                     var94 = var2 - 2;
                     int var256;
                     if (this.lowerCase.getValue()) {
                        var256 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                        boolean var350 = false;
                     } else {
                        var256 = Managers.TEXT.getStringWidth(var52);
                     }

                     double var139 = (double)(var94 - var256 - 1);
                     double var257 = (double)(var3 - var9 - 4);
                     double var351 = (double)var2;
                     double var440;
                     if (var9 == 1) {
                        var440 = (double)var3;
                        boolean var514 = false;
                     } else {
                        var440 = (double)(var3 - var9 + 15);
                     }

                     RenderUtil.drawGlow(var139, var257, var351, var440, var11);
                  }

                  if (this.arrayListLine.getValue()) {
                     var94 = var2 - 2;
                     int var258;
                     if (this.lowerCase.getValue()) {
                        var258 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                        boolean var352 = false;
                     } else {
                        var258 = Managers.TEXT.getStringWidth(var52);
                     }

                     var94 = var94 - var258 - 2;
                     var258 = var3 - var9;
                     int var353 = var2 - 2;
                     int var441;
                     if (this.lowerCase.getValue()) {
                        var441 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                        boolean var515 = false;
                     } else {
                        var441 = Managers.TEXT.getStringWidth(var52);
                     }

                     var353 = var353 - var441 - 1;
                     if (var9 == 1) {
                        var441 = var3;
                        boolean var516 = false;
                     } else {
                        var441 = var3 - var9 + 10;
                     }

                     int var517;
                     if (this.jamieArray.getValue()) {
                        var517 = this.getJamieColor(var32 - 2);
                        boolean var597 = false;
                     } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                        if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                           var517 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                           boolean var598 = false;
                        } else {
                           var517 = Managers.COLORS.getRainbow().getRGB();
                           boolean var599 = false;
                        }
                     } else {
                        var517 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                     }

                     Gui.drawRect(var94, var258, var353, var441, var517);
                     int var66 = var38 + 1;
                     if (var66 >= Managers.MODULES.sortedLength.size()) {
                        var66 = var38;
                     }

                     Module var72 = Managers.MODULES.sortedLength.get(var66);
                     String var76 = var72.getArrayListInfo();
                     if (this.forgeHax.getValue()) {
                        var76 = String.valueOf(new StringBuilder().append(var72.getArrayListInfo()).append(ChatFormatting.RESET).append("<"));
                     }

                     var94 = var2 - 2;
                     if (this.lowerCase.getValue()) {
                        var258 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                        boolean var355 = false;
                     } else {
                        var258 = Managers.TEXT.getStringWidth(var52);
                     }

                     var94 = var94 - var258 - 2;
                     var258 = var3 - var9 - 1;
                     if (var66 == var38) {
                        var353 = var2;
                        boolean var443 = false;
                     } else {
                        var353 = var2 - 2;
                        if (this.lowerCase.getValue()) {
                           var441 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                           boolean var518 = false;
                        } else {
                           var441 = Managers.TEXT.getStringWidth(var52);
                        }

                        var353 -= var441;
                        if (this.lowerCase.getValue()) {
                           var441 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                           boolean var519 = false;
                        } else {
                           var441 = Managers.TEXT.getStringWidth(var52);
                        }

                        if (this.lowerCase.getValue()) {
                           var517 = Managers.TEXT.getStringWidth(var76.toLowerCase());
                           boolean var600 = false;
                        } else {
                           var517 = Managers.TEXT.getStringWidth(var76);
                        }

                        var353 = var353 + (var441 - var517) - 1;
                     }

                     var441 = var3 - var9;
                     if (this.jamieArray.getValue()) {
                        var517 = this.getJamieColor(var32 - 2);
                        boolean var601 = false;
                     } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                        if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                           var517 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                           boolean var602 = false;
                        } else {
                           var517 = Managers.COLORS.getRainbow().getRGB();
                           boolean var603 = false;
                        }
                     } else {
                        var517 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                     }

                     Gui.drawRect(var94, var258, var353, var441, var517);
                  }

                  TextManager var144 = Managers.TEXT;
                  String var262;
                  if (this.lowerCase.getValue()) {
                     var262 = var52.toLowerCase();
                     boolean var359 = false;
                  } else {
                     var262 = var52;
                  }

                  int var360 = var2 - 2;
                  int var447;
                  if (this.lowerCase.getValue()) {
                     var447 = Managers.TEXT.getStringWidth(var52.toLowerCase());
                     boolean var522 = false;
                  } else {
                     var447 = Managers.TEXT.getStringWidth(var52);
                  }

                  float var361 = (float)(var360 - var447);
                  float var448 = (float)(var3 - var9 + 1);
                  int var523;
                  if (this.jamieArray.getValue()) {
                     var523 = this.getJamieColor(var32 - 2);
                     boolean var604 = false;
                  } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var523 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var605 = false;
                     } else {
                        var523 = Managers.COLORS.getRainbow().getRGB();
                        boolean var606 = false;
                     }
                  } else {
                     var523 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var144.drawString(var262, var361, var448, var523, true);
                  boolean var145 = false;
                  ++var32;
                  var145 = false;
               }
            }
         }

         String var150;
         if (this.grayColors.getValue()) {
            var150 = String.valueOf(ChatFormatting.GRAY);
            boolean var264 = false;
         } else {
            var150 = "";
         }

         String var39 = var150;
         byte var151;
         if (mc.currentScreen instanceof GuiChat && this.renderingUp.getValue()) {
            var151 = 13;
            boolean var266 = false;
         } else if (this.renderingUp.getValue()) {
            var151 = -2;
            boolean var265 = false;
         } else {
            var151 = 0;
         }

         int var43 = var151;
         if (this.renderingUp.getValue()) {
            if (this.potions.getValue()) {
               for(PotionEffect var73 : new java.util.ArrayList(mc.player.getActivePotionEffects())) {
                  String var77 = this.getColoredPotionString(var73);
                  var43 += 10;
                  TextManager var152 = Managers.TEXT;
                  String var267;
                  if (this.lowerCase.getValue()) {
                     var267 = var77.toLowerCase();
                     boolean var363 = false;
                  } else {
                     var267 = var77;
                  }

                  int var450;
                  if (this.lowerCase.getValue()) {
                     var450 = Managers.TEXT.getStringWidth(var77.toLowerCase());
                     boolean var525 = false;
                  } else {
                     var450 = Managers.TEXT.getStringWidth(var77);
                  }

                  float var364 = (float)(var2 - var450 - 2);
                  float var451 = (float)(var3 - 2 - var43);
                  int var526;
                  if (this.potionColor.getValue()) {
                     var526 = var73.getPotion().getLiquidColor();
                     boolean var609 = false;
                  } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var526 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var610 = false;
                     } else {
                        var526 = Managers.COLORS.getRainbow().getRGB();
                        boolean var611 = false;
                     }
                  } else {
                     var526 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var152.drawString(var267, var364, var451, var526, true);
                  boolean var153 = false;
                  ++var32;
                  var153 = false;
               }
            }

            if (this.speed.getValue()) {
               String var54 = String.valueOf(
                  new StringBuilder().append(var39).append("Speed ").append(ChatFormatting.WHITE).append(Managers.SPEED.getSpeedKpH()).append(" km/h")
               );
               var43 += 10;
               TextManager var155 = Managers.TEXT;
               String var268;
               if (this.lowerCase.getValue()) {
                  var268 = var54.toLowerCase();
                  boolean var365 = false;
               } else {
                  var268 = var54;
               }

               int var452;
               if (this.lowerCase.getValue()) {
                  var452 = Managers.TEXT.getStringWidth(var54.toLowerCase());
                  boolean var527 = false;
               } else {
                  var452 = Managers.TEXT.getStringWidth(var54);
               }

               float var366 = (float)(var2 - var452 - 2);
               float var453 = (float)(var3 - 2 - var43);
               int var528;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var528 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var612 = false;
                  } else {
                     var528 = Managers.COLORS.getRainbow().getRGB();
                     boolean var613 = false;
                  }
               } else {
                  var528 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
               }

               var155.drawString(var268, var366, var453, var528, true);
               boolean var156 = false;
               ++var32;
            }

            if (this.time.getValue()) {
               String var55 = String.valueOf(
                  new StringBuilder().append(var39).append("Time ").append(ChatFormatting.WHITE).append(new SimpleDateFormat("h:mm a").format(new Date()))
               );
               var43 += 10;
               TextManager var157 = Managers.TEXT;
               String var269;
               if (this.lowerCase.getValue()) {
                  var269 = var55.toLowerCase();
                  boolean var367 = false;
               } else {
                  var269 = var55;
               }

               int var454;
               if (this.lowerCase.getValue()) {
                  var454 = Managers.TEXT.getStringWidth(var55.toLowerCase());
                  boolean var529 = false;
               } else {
                  var454 = Managers.TEXT.getStringWidth(var55);
               }

               float var368 = (float)(var2 - var454 - 2);
               float var455 = (float)(var3 - 2 - var43);
               int var530;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var530 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var614 = false;
                  } else {
                     var530 = Managers.COLORS.getRainbow().getRGB();
                     boolean var615 = false;
                  }
               } else {
                  var530 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
               }

               var157.drawString(var269, var368, var455, var530, true);
               boolean var158 = false;
               ++var32;
            }

            if (this.tps.getValue()) {
               String var56 = String.valueOf(new StringBuilder().append(var39).append("TPS ").append(ChatFormatting.WHITE).append(Managers.SERVER.getTPS()));
               var43 += 10;
               TextManager var159 = Managers.TEXT;
               String var270;
               if (this.lowerCase.getValue()) {
                  var270 = var56.toLowerCase();
                  boolean var369 = false;
               } else {
                  var270 = var56;
               }

               int var456;
               if (this.lowerCase.getValue()) {
                  var456 = Managers.TEXT.getStringWidth(var56.toLowerCase());
                  boolean var531 = false;
               } else {
                  var456 = Managers.TEXT.getStringWidth(var56);
               }

               float var370 = (float)(var2 - var456 - 2);
               float var457 = (float)(var3 - 2 - var43);
               int var532;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var532 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var616 = false;
                  } else {
                     var532 = Managers.COLORS.getRainbow().getRGB();
                     boolean var617 = false;
                  }
               } else {
                  var532 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
               }

               var159.drawString(var270, var370, var457, var532, true);
               boolean var160 = false;
               ++var32;
            }

            String var57 = String.valueOf(new StringBuilder().append(var39).append("FPS ").append(ChatFormatting.WHITE).append(Minecraft.getDebugFPS()));
            String var68 = String.valueOf(new StringBuilder().append(var39).append("Ping ").append(ChatFormatting.WHITE).append(Managers.SERVER.getPing()));
            if (Managers.TEXT.getStringWidth(var68) > Managers.TEXT.getStringWidth(var57)) {
               if (this.ping.getValue()) {
                  var43 += 10;
                  TextManager var161 = Managers.TEXT;
                  String var271;
                  if (this.lowerCase.getValue()) {
                     var271 = var68.toLowerCase();
                     boolean var371 = false;
                  } else {
                     var271 = var68;
                  }

                  int var458;
                  if (this.lowerCase.getValue()) {
                     var458 = Managers.TEXT.getStringWidth(var68.toLowerCase());
                     boolean var533 = false;
                  } else {
                     var458 = Managers.TEXT.getStringWidth(var68);
                  }

                  float var372 = (float)(var2 - var458 - 2);
                  float var459 = (float)(var3 - 2 - var43);
                  int var534;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var534 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var618 = false;
                     } else {
                        var534 = Managers.COLORS.getRainbow().getRGB();
                        boolean var619 = false;
                     }
                  } else {
                     var534 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var161.drawString(var271, var372, var459, var534, true);
                  boolean var162 = false;
                  ++var32;
               }

               if (this.fps.getValue()) {
                  var43 += 10;
                  TextManager var163 = Managers.TEXT;
                  String var272;
                  if (this.lowerCase.getValue()) {
                     var272 = var57.toLowerCase();
                     boolean var373 = false;
                  } else {
                     var272 = var57;
                  }

                  int var460;
                  if (this.lowerCase.getValue()) {
                     var460 = Managers.TEXT.getStringWidth(var57.toLowerCase());
                     boolean var535 = false;
                  } else {
                     var460 = Managers.TEXT.getStringWidth(var57);
                  }

                  float var374 = (float)(var2 - var460 - 2);
                  float var461 = (float)(var3 - 2 - var43);
                  int var536;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var536 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var620 = false;
                     } else {
                        var536 = Managers.COLORS.getRainbow().getRGB();
                        boolean var621 = false;
                     }
                  } else {
                     var536 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var163.drawString(var272, var374, var461, var536, true);
                  boolean var164 = false;
                  var164 = false;
               }
            } else {
               if (this.fps.getValue()) {
                  var43 += 10;
                  TextManager var166 = Managers.TEXT;
                  String var273;
                  if (this.lowerCase.getValue()) {
                     var273 = var57.toLowerCase();
                     boolean var375 = false;
                  } else {
                     var273 = var57;
                  }

                  int var462;
                  if (this.lowerCase.getValue()) {
                     var462 = Managers.TEXT.getStringWidth(var57.toLowerCase());
                     boolean var537 = false;
                  } else {
                     var462 = Managers.TEXT.getStringWidth(var57);
                  }

                  float var376 = (float)(var2 - var462 - 2);
                  float var463 = (float)(var3 - 2 - var43);
                  int var538;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var538 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var622 = false;
                     } else {
                        var538 = Managers.COLORS.getRainbow().getRGB();
                        boolean var623 = false;
                     }
                  } else {
                     var538 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var166.drawString(var273, var376, var463, var538, true);
                  boolean var167 = false;
                  ++var32;
               }

               if (this.ping.getValue()) {
                  var43 += 10;
                  TextManager var168 = Managers.TEXT;
                  String var274;
                  if (this.lowerCase.getValue()) {
                     var274 = var68.toLowerCase();
                     boolean var377 = false;
                  } else {
                     var274 = var68;
                  }

                  int var464;
                  if (this.lowerCase.getValue()) {
                     var464 = Managers.TEXT.getStringWidth(var68.toLowerCase());
                     boolean var539 = false;
                  } else {
                     var464 = Managers.TEXT.getStringWidth(var68);
                  }

                  float var378 = (float)(var2 - var464 - 2);
                  float var465 = (float)(var3 - 2 - var43);
                  int var540;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var540 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var624 = false;
                     } else {
                        var540 = Managers.COLORS.getRainbow().getRGB();
                        boolean var625 = false;
                     }
                  } else {
                     var540 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var168.drawString(var274, var378, var465, var540, true);
                  boolean var169 = false;
               }
            }

            boolean var170 = false;
         } else {
            if (this.potions.getValue()) {
               for(PotionEffect var74 : new java.util.ArrayList(mc.player.getActivePotionEffects())) {
                  String var78 = this.getColoredPotionString(var74);
                  TextManager var171 = Managers.TEXT;
                  String var275;
                  if (this.lowerCase.getValue()) {
                     var275 = var78.toLowerCase();
                     boolean var379 = false;
                  } else {
                     var275 = var78;
                  }

                  int var466;
                  if (this.lowerCase.getValue()) {
                     var466 = Managers.TEXT.getStringWidth(var78.toLowerCase());
                     boolean var541 = false;
                  } else {
                     var466 = Managers.TEXT.getStringWidth(var78);
                  }

                  float var380 = (float)(var2 - var466 - 2);
                  float var467 = (float)(2 + var43++ * 10);
                  int var543;
                  if (this.potionColor.getValue()) {
                     var543 = var74.getPotion().getLiquidColor();
                     boolean var626 = false;
                  } else if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var543 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var627 = false;
                     } else {
                        var543 = Managers.COLORS.getRainbow().getRGB();
                        boolean var628 = false;
                     }
                  } else {
                     var543 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var171.drawString(var275, var380, var467, var543, true);
                  boolean var172 = false;
                  ++var32;
                  var172 = false;
               }
            }

            if (this.speed.getValue()) {
               String var59 = String.valueOf(
                  new StringBuilder().append(var39).append("Speed ").append(ChatFormatting.WHITE).append(Managers.SPEED.getSpeedKpH()).append(" km/h")
               );
               TextManager var174 = Managers.TEXT;
               String var276;
               if (this.lowerCase.getValue()) {
                  var276 = var59.toLowerCase();
                  boolean var381 = false;
               } else {
                  var276 = var59;
               }

               int var468;
               if (this.lowerCase.getValue()) {
                  var468 = Managers.TEXT.getStringWidth(var59.toLowerCase());
                  boolean var544 = false;
               } else {
                  var468 = Managers.TEXT.getStringWidth(var59);
               }

               float var382 = (float)(var2 - var468 - 2);
               float var469 = (float)(2 + var43++ * 10);
               int var546;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var546 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var629 = false;
                  } else {
                     var546 = Managers.COLORS.getRainbow().getRGB();
                     boolean var630 = false;
                  }
               } else {
                  var546 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
               }

               var174.drawString(var276, var382, var469, var546, true);
               boolean var175 = false;
               ++var32;
            }

            if (this.time.getValue()) {
               String var60 = String.valueOf(
                  new StringBuilder().append(var39).append("Time ").append(ChatFormatting.WHITE).append(new SimpleDateFormat("h:mm a").format(new Date()))
               );
               TextManager var176 = Managers.TEXT;
               String var277;
               if (this.lowerCase.getValue()) {
                  var277 = var60.toLowerCase();
                  boolean var383 = false;
               } else {
                  var277 = var60;
               }

               int var470;
               if (this.lowerCase.getValue()) {
                  var470 = Managers.TEXT.getStringWidth(var60.toLowerCase());
                  boolean var547 = false;
               } else {
                  var470 = Managers.TEXT.getStringWidth(var60);
               }

               float var384 = (float)(var2 - var470 - 2);
               float var471 = (float)(2 + var43++ * 10);
               int var549;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var549 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var631 = false;
                  } else {
                     var549 = Managers.COLORS.getRainbow().getRGB();
                     boolean var632 = false;
                  }
               } else {
                  var549 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
               }

               var176.drawString(var277, var384, var471, var549, true);
               boolean var177 = false;
               ++var32;
            }

            if (this.tps.getValue()) {
               String var61 = String.valueOf(new StringBuilder().append(var39).append("TPS ").append(ChatFormatting.WHITE).append(Managers.SERVER.getTPS()));
               TextManager var178 = Managers.TEXT;
               String var278;
               if (this.lowerCase.getValue()) {
                  var278 = var61.toLowerCase();
                  boolean var385 = false;
               } else {
                  var278 = var61;
               }

               int var472;
               if (this.lowerCase.getValue()) {
                  var472 = Managers.TEXT.getStringWidth(var61.toLowerCase());
                  boolean var550 = false;
               } else {
                  var472 = Managers.TEXT.getStringWidth(var61);
               }

               float var386 = (float)(var2 - var472 - 2);
               float var473 = (float)(2 + var43++ * 10);
               int var552;
               if (ClickGui.INSTANCE.rainbow.getValue()) {
                  if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                     var552 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                     boolean var633 = false;
                  } else {
                     var552 = Managers.COLORS.getRainbow().getRGB();
                     boolean var634 = false;
                  }
               } else {
                  var552 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
               }

               var178.drawString(var278, var386, var473, var552, true);
               boolean var179 = false;
               ++var32;
            }

            String var62 = String.valueOf(new StringBuilder().append(var39).append("FPS ").append(ChatFormatting.WHITE).append(Minecraft.getDebugFPS()));
            String var70 = String.valueOf(new StringBuilder().append(var39).append("Ping ").append(ChatFormatting.WHITE).append(Managers.SERVER.getPing()));
            if (Managers.TEXT.getStringWidth(var70) > Managers.TEXT.getStringWidth(var62)) {
               if (this.ping.getValue()) {
                  TextManager var180 = Managers.TEXT;
                  String var279;
                  if (this.lowerCase.getValue()) {
                     var279 = var70.toLowerCase();
                     boolean var387 = false;
                  } else {
                     var279 = var70;
                  }

                  int var474;
                  if (this.lowerCase.getValue()) {
                     var474 = Managers.TEXT.getStringWidth(var70.toLowerCase());
                     boolean var553 = false;
                  } else {
                     var474 = Managers.TEXT.getStringWidth(var70);
                  }

                  float var388 = (float)(var2 - var474 - 2);
                  float var475 = (float)(2 + var43++ * 10);
                  int var555;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var555 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var635 = false;
                     } else {
                        var555 = Managers.COLORS.getRainbow().getRGB();
                        boolean var636 = false;
                     }
                  } else {
                     var555 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var180.drawString(var279, var388, var475, var555, true);
                  boolean var181 = false;
                  ++var32;
               }

               if (this.fps.getValue()) {
                  TextManager var182 = Managers.TEXT;
                  String var280;
                  if (this.lowerCase.getValue()) {
                     var280 = var62.toLowerCase();
                     boolean var389 = false;
                  } else {
                     var280 = var62;
                  }

                  int var476;
                  if (this.lowerCase.getValue()) {
                     var476 = Managers.TEXT.getStringWidth(var62.toLowerCase());
                     boolean var556 = false;
                  } else {
                     var476 = Managers.TEXT.getStringWidth(var62);
                  }

                  float var390 = (float)(var2 - var476 - 2);
                  float var477 = (float)(2 + var43++ * 10);
                  int var558;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var558 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var637 = false;
                     } else {
                        var558 = Managers.COLORS.getRainbow().getRGB();
                        boolean var638 = false;
                     }
                  } else {
                     var558 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var182.drawString(var280, var390, var477, var558, true);
                  boolean var183 = false;
                  var183 = false;
               }
            } else {
               if (this.fps.getValue()) {
                  TextManager var185 = Managers.TEXT;
                  String var281;
                  if (this.lowerCase.getValue()) {
                     var281 = var62.toLowerCase();
                     boolean var391 = false;
                  } else {
                     var281 = var62;
                  }

                  int var478;
                  if (this.lowerCase.getValue()) {
                     var478 = Managers.TEXT.getStringWidth(var62.toLowerCase());
                     boolean var559 = false;
                  } else {
                     var478 = Managers.TEXT.getStringWidth(var62);
                  }

                  float var392 = (float)(var2 - var478 - 2);
                  float var479 = (float)(2 + var43++ * 10);
                  int var561;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var561 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var639 = false;
                     } else {
                        var561 = Managers.COLORS.getRainbow().getRGB();
                        boolean var640 = false;
                     }
                  } else {
                     var561 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var185.drawString(var281, var392, var479, var561, true);
                  boolean var186 = false;
                  ++var32;
               }

               if (this.ping.getValue()) {
                  TextManager var187 = Managers.TEXT;
                  String var282;
                  if (this.lowerCase.getValue()) {
                     var282 = var70.toLowerCase();
                     boolean var393 = false;
                  } else {
                     var282 = var70;
                  }

                  int var480;
                  if (this.lowerCase.getValue()) {
                     var480 = Managers.TEXT.getStringWidth(var70.toLowerCase());
                     boolean var562 = false;
                  } else {
                     var480 = Managers.TEXT.getStringWidth(var70);
                  }

                  float var394 = (float)(var2 - var480 - 2);
                  float var481 = (float)(2 + var43++ * 10);
                  int var564;
                  if (ClickGui.INSTANCE.rainbow.getValue()) {
                     if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.ROLLING) {
                        var564 = ColorUtil.rainbow(var32 * ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB();
                        boolean var641 = false;
                     } else {
                        var564 = Managers.COLORS.getRainbow().getRGB();
                        boolean var642 = false;
                     }
                  } else {
                     var564 = ColorUtil.pulseColor(var29, var32, 14).getRGB();
                  }

                  var187.drawString(var282, var394, var481, var564, true);
                  boolean var188 = false;
               }
            }
         }

         boolean var63 = Integer.valueOf("Hell".hashCode()).equals(mc.world.getBiome(mc.player.getPosition()).getBiomeName().hashCode());
         int var71 = (int)mc.player.posX;
         int var75 = (int)mc.player.posY;
         int var79 = (int)mc.player.posZ;
         float var189;
         if (!var63) {
            var189 = 0.125F;
            boolean var283 = false;
         } else {
            var189 = 8.0F;
         }

         float var18 = var189;
         int var19 = (int)(mc.player.posX * (double)var18);
         int var20 = (int)(mc.player.posZ * (double)var18);
         int var21 = (int)MathHelper.wrapDegrees(mc.player.rotationYaw);
         if (this.coords.getValue()) {
            var151 = 0;
            boolean var284 = false;
         } else {
            var151 = 11;
         }

         byte var22 = var151;
         if (mc.currentScreen instanceof GuiChat) {
            var151 = 14;
            boolean var285 = false;
         } else {
            var151 = 0;
         }

         int var48 = var151;
         StringBuilder var192 = new StringBuilder();
         String var286;
         if (this.lowerCase.getValue()) {
            var286 = "XYZ: ".toLowerCase();
            boolean var395 = false;
         } else {
            var286 = "XYZ: ";
         }

         StringBuilder var193 = var192.append(var286).append(ChatFormatting.WHITE);
         if (var63) {
            var286 = String.valueOf(
               new StringBuilder()
                  .append(var71)
                  .append(", ")
                  .append(var75)
                  .append(", ")
                  .append(var79)
                  .append(ChatFormatting.GRAY)
                  .append(" [")
                  .append(ChatFormatting.WHITE)
                  .append(var19)
                  .append(", ")
                  .append(var20)
                  .append(ChatFormatting.GRAY)
                  .append("]")
                  .append(ChatFormatting.WHITE)
            );
            boolean var396 = false;
         } else {
            var286 = String.valueOf(
               new StringBuilder()
                  .append(var71)
                  .append(", ")
                  .append(var75)
                  .append(", ")
                  .append(var79)
                  .append(ChatFormatting.GRAY)
                  .append(" [")
                  .append(ChatFormatting.WHITE)
                  .append(var19)
                  .append(", ")
                  .append(var20)
                  .append(ChatFormatting.GRAY)
                  .append("]")
            );
         }

         String var23 = String.valueOf(var193.append(var286));
         String var194;
         if (this.direction.getValue()) {
            var194 = Managers.ROTATIONS.getDirection4D(false);
            boolean var288 = false;
         } else {
            var194 = "";
         }

         String var24 = var194;
         String var196;
         if (this.direction.getValue()) {
            StringBuilder var195 = new StringBuilder();
            if (this.lowerCase.getValue()) {
               var286 = "Yaw: ".toLowerCase();
               boolean var397 = false;
            } else {
               var286 = "Yaw: ";
            }

            var196 = String.valueOf(var195.append(var286).append(ChatFormatting.WHITE).append(var21));
            boolean var290 = false;
         } else {
            var196 = "";
         }

         String var25 = var196;
         String var197;
         if (this.coords.getValue()) {
            var197 = var23;
            boolean var291 = false;
         } else {
            var197 = "";
         }

         String var26 = var197;
         var48 += 10;
         if (mc.currentScreen instanceof GuiChat && this.direction.getValue()) {
            var25 = "";
            StringBuilder var198 = new StringBuilder();
            if (this.lowerCase.getValue()) {
               var286 = "Yaw: ".toLowerCase();
               boolean var398 = false;
            } else {
               var286 = "Yaw: ";
            }

            var24 = String.valueOf(
               var198.append(var286)
                  .append(ChatFormatting.WHITE)
                  .append(var21)
                  .append(ChatFormatting.RESET)
                  .append(" ")
                  .append(this.getFacingDirectionShort())
            );
         }

         if (ClickGui.INSTANCE.rainbow.getValue()) {
            String var201;
            if (this.coords.getValue()) {
               StringBuilder var199 = new StringBuilder();
               if (this.lowerCase.getValue()) {
                  var286 = "XYZ: ".toLowerCase();
                  boolean var399 = false;
               } else {
                  var286 = "XYZ: ";
               }

               StringBuilder var200 = var199.append(var286).append(ChatFormatting.WHITE);
               if (var63) {
                  var286 = String.valueOf(
                     new StringBuilder()
                        .append(var71)
                        .append(", ")
                        .append(var75)
                        .append(", ")
                        .append(var79)
                        .append(ChatFormatting.GRAY)
                        .append(" [")
                        .append(ChatFormatting.WHITE)
                        .append(var19)
                        .append(", ")
                        .append(var20)
                        .append(ChatFormatting.GRAY)
                        .append("]")
                        .append(ChatFormatting.WHITE)
                  );
                  boolean var400 = false;
               } else {
                  var286 = String.valueOf(
                     new StringBuilder()
                        .append(var71)
                        .append(", ")
                        .append(var75)
                        .append(", ")
                        .append(var79)
                        .append(ChatFormatting.GRAY)
                        .append(" [")
                        .append(ChatFormatting.WHITE)
                        .append(var19)
                        .append(", ")
                        .append(var20)
                        .append(ChatFormatting.GRAY)
                        .append("]")
                  );
               }

               var201 = String.valueOf(var200.append(var286));
               boolean var295 = false;
            } else {
               var201 = "";
            }

            String var27 = var201;
            if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.STATIC) {
               Managers.TEXT.drawString(var24, 2.0F, (float)(var3 - var48 - 11 + var22), Managers.COLORS.getRainbow().getRGB(), true);
               boolean var204 = false;
               Managers.TEXT.drawString(var25, 2.0F, (float)(var3 - var48 - 22 + var22), Managers.COLORS.getRainbow().getRGB(), true);
               var204 = false;
               Managers.TEXT.drawString(var27, 2.0F, (float)(var3 - var48), Managers.COLORS.getRainbow().getRGB(), true);
               var204 = false;
               var204 = false;
            } else {
               if (mc.currentScreen instanceof GuiChat && this.direction.getValue()) {
                  if (this.lowerCase.getValue()) {
                     var286 = "Yaw: ".toLowerCase();
                     boolean var405 = false;
                  } else {
                     var286 = "Yaw: ";
                  }

                  this.drawDoubleRainbowRollingString(
                     var286,
                     String.valueOf(new StringBuilder().append(String.valueOf(ChatFormatting.WHITE)).append(var21)),
                     2.0F,
                     (float)(var3 - var48 - 11 + var22)
                  );
                  String var28 = String.valueOf(new StringBuilder().append("Yaw: ").append(ChatFormatting.WHITE).append(var21));
                  Managers.TEXT
                     .drawRollingRainbowString(
                        String.valueOf(new StringBuilder().append(" ").append(this.getFacingDirectionShort())),
                        2.0F + (float)Managers.TEXT.getStringWidth(var28),
                        (float)(var3 - var48 - 11 + var22),
                        true
                     );
                  boolean var203 = false;
               } else {
                  TextManager var202 = Managers.TEXT;
                  if (this.direction.getValue()) {
                     var286 = var24;
                     boolean var401 = false;
                  } else {
                     var286 = "";
                  }

                  var202.drawRollingRainbowString(var286, 2.0F, (float)(var3 - var48 - 11 + var22), true);
                  if (this.direction.getValue()) {
                     if (this.lowerCase.getValue()) {
                        var286 = "Yaw: ".toLowerCase();
                        boolean var402 = false;
                     } else {
                        var286 = "Yaw: ";
                        boolean var403 = false;
                     }
                  } else {
                     var286 = "";
                  }

                  String var404;
                  if (this.direction.getValue()) {
                     var404 = String.valueOf(new StringBuilder().append(String.valueOf(ChatFormatting.WHITE)).append(var21));
                     boolean var482 = false;
                  } else {
                     var404 = "";
                  }

                  this.drawDoubleRainbowRollingString(var286, var404, 2.0F, (float)(var3 - var48 - 22 + var22));
               }

               if (this.coords.getValue()) {
                  if (this.lowerCase.getValue()) {
                     var286 = "XYZ: ".toLowerCase();
                     boolean var406 = false;
                  } else {
                     var286 = "XYZ: ";
                     boolean var407 = false;
                  }
               } else {
                  var286 = "";
               }

               String var409;
               if (this.coords.getValue()) {
                  StringBuilder var408 = new StringBuilder().append(ChatFormatting.WHITE);
                  String var483;
                  if (var63) {
                     var483 = String.valueOf(
                        new StringBuilder()
                           .append(var71)
                           .append(", ")
                           .append(var75)
                           .append(", ")
                           .append(var79)
                           .append(ChatFormatting.GRAY)
                           .append(" [")
                           .append(ChatFormatting.WHITE)
                           .append(var19)
                           .append(", ")
                           .append(var20)
                           .append(ChatFormatting.GRAY)
                           .append("]")
                           .append(ChatFormatting.WHITE)
                     );
                     boolean var565 = false;
                  } else {
                     var483 = String.valueOf(
                        new StringBuilder()
                           .append(var71)
                           .append(", ")
                           .append(var75)
                           .append(", ")
                           .append(var79)
                           .append(ChatFormatting.GRAY)
                           .append(" [")
                           .append(ChatFormatting.WHITE)
                           .append(var19)
                           .append(", ")
                           .append(var20)
                           .append(ChatFormatting.GRAY)
                           .append("]")
                     );
                  }

                  var409 = String.valueOf(var408.append(var483));
                  boolean var484 = false;
               } else {
                  var409 = "";
               }

               this.drawDoubleRainbowRollingString(var286, var409, 2.0F, (float)(var3 - var48));
            }

            boolean var208 = false;
         } else {
            Managers.TEXT.drawString(var24, 2.0F, (float)(var3 - var48 - 11 + var22), this.color, true);
            boolean var209 = false;
            Managers.TEXT.drawString(var25, 2.0F, (float)(var3 - var48 - 22 + var22), this.color, true);
            var209 = false;
            Managers.TEXT.drawString(var26, 2.0F, (float)(var3 - var48), this.color, true);
            var209 = false;
         }

         if (this.armor.getValue()) {
            this.drawArmorHUD();
         }

         if (this.greeter.getValue()) {
            this.drawWelcomer();
         }

         if (this.lag.getValue()) {
            this.drawLagOMeter();
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$14(Boolean var1) {
      boolean var10000;
      if (this.watermark.isOpen() && this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawTextRadar(int var1) {
      if (!this.players.isEmpty()) {
         int var2 = Managers.TEXT.getFontHeight() + 7 + var1;

         for(Entry var4 : this.players.entrySet()) {
            String var5 = String.valueOf(new StringBuilder().append((String)var4.getKey()).append(" "));
            int var6 = Managers.TEXT.getFontHeight() + 1;
            if (ClickGui.INSTANCE.rainbow.getValue()) {
               if (ClickGui.INSTANCE.hudRainbow.getValue() == ClickGui.HudRainbow.STATIC) {
                  Managers.TEXT.drawString(var5, 2.0F, (float)var2, ColorUtil.rainbow(ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB(), true);
                  boolean var10000 = false;
                  var2 += var6;
                  var10000 = false;
               } else {
                  Managers.TEXT.drawString(var5, 2.0F, (float)var2, ColorUtil.rainbow(ClickGui.INSTANCE.rainbowDelay.getValue()).getRGB(), true);
                  boolean var8 = false;
                  var2 += var6;
                  var8 = false;
               }
            } else {
               Managers.TEXT.drawString(var5, 2.0F, (float)var2, this.color, true);
               boolean var10 = false;
               var2 += var6;
            }

            boolean var11 = false;
         }
      }
   }

   private boolean lambda$new$35(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen() && this.arrayListRect.getValue()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$28(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$13(Boolean var1) {
      boolean var10000;
      if (this.watermark.isOpen() && this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private String getFacingDirectionShort() {
      int var1 = Managers.ROTATIONS.getYaw4D();
      if (var1 == 0) {
         return "(+Z)";
      } else if (var1 == 1) {
         return "(-X)";
      } else if (var1 == 2) {
         return "(-Z)";
      } else {
         return var1 == 3 ? "(+X)" : "Loading...";
      }
   }

   private void drawCombatCount() {
      int var1 = Managers.TEXT.scaledWidth;
      int var2 = Managers.TEXT.scaledHeight;
      int var3 = var1 / 2;
      int var4 = var2 - this.combatCountY.getValue();
      int var5 = var3 + this.combatCountX.getValue();
      GlStateManager.enableTexture2D();
      int var6 = InventoryUtil.getItemCount(Items.TOTEM_OF_UNDYING);
      GlStateManager.enableDepth();
      mc.getRenderItem().zLevel = 200.0F;
      mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.TOTEM_OF_UNDYING), var5, var4);
      mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, new ItemStack(Items.TOTEM_OF_UNDYING), var5, var4, "");
      mc.getRenderItem().zLevel = 0.0F;
      GlStateManager.enableTexture2D();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      Managers.TEXT
         .drawStringWithShadow(String.valueOf(var6), (float)(var5 + 19 - 2 - Managers.TEXT.getStringWidth(String.valueOf(var6))), (float)(var4 + 9), 16777215);
      GlStateManager.enableDepth();
      GlStateManager.disableLighting();
      int var7 = InventoryUtil.getItemCount(Items.END_CRYSTAL);
      var5 += 20;
      GlStateManager.enableDepth();
      mc.getRenderItem().zLevel = 200.0F;
      mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.END_CRYSTAL), var5, var4);
      mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, new ItemStack(Items.END_CRYSTAL), var5, var4, "");
      mc.getRenderItem().zLevel = 0.0F;
      GlStateManager.enableTexture2D();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      Managers.TEXT
         .drawStringWithShadow(String.valueOf(var7), (float)(var5 + 19 - 2 - Managers.TEXT.getStringWidth(String.valueOf(var7))), (float)(var4 + 9), 16777215);
      GlStateManager.enableDepth();
      GlStateManager.disableLighting();
      int var8 = InventoryUtil.getItemCount(Items.EXPERIENCE_BOTTLE);
      var5 += 20;
      GlStateManager.enableDepth();
      mc.getRenderItem().zLevel = 200.0F;
      mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.EXPERIENCE_BOTTLE), var5, var4);
      mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, new ItemStack(Items.EXPERIENCE_BOTTLE), var5, var4, "");
      mc.getRenderItem().zLevel = 0.0F;
      GlStateManager.enableTexture2D();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      Managers.TEXT
         .drawStringWithShadow(String.valueOf(var8), (float)(var5 + 19 - 2 - Managers.TEXT.getStringWidth(String.valueOf(var8))), (float)(var4 + 9), 16777215);
      GlStateManager.enableDepth();
      GlStateManager.disableLighting();
      int var9 = InventoryUtil.getItemCount(Items.GOLDEN_APPLE);
      var5 += 20;
      GlStateManager.enableDepth();
      mc.getRenderItem().zLevel = 200.0F;
      mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.GOLDEN_APPLE), var5, var4);
      mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, new ItemStack(Items.GOLDEN_APPLE), var5, var4, "");
      mc.getRenderItem().zLevel = 0.0F;
      GlStateManager.enableTexture2D();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      Managers.TEXT
         .drawStringWithShadow(String.valueOf(var9), (float)(var5 + 19 - 2 - Managers.TEXT.getStringWidth(String.valueOf(var9))), (float)(var4 + 9), 16777215);
      GlStateManager.enableDepth();
      GlStateManager.disableLighting();
      int var10 = InventoryUtil.getItemCount(Item.getItemFromBlock(Blocks.OBSIDIAN));
      var5 += 20;
      GlStateManager.enableDepth();
      mc.getRenderItem().zLevel = 200.0F;
      mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Blocks.OBSIDIAN), var5, var4);
      mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, new ItemStack(Blocks.OBSIDIAN), var5, var4, "");
      mc.getRenderItem().zLevel = 0.0F;
      GlStateManager.enableTexture2D();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      Managers.TEXT
         .drawStringWithShadow(
            String.valueOf(var10), (float)(var5 + 19 - 2 - Managers.TEXT.getStringWidth(String.valueOf(var10))), (float)(var4 + 9), 16777215
         );
      GlStateManager.enableDepth();
      GlStateManager.disableLighting();
   }

   private boolean lambda$new$40(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(ModuleManager.Ordering var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.GLOBAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$15(Integer var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.watermark.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$44(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawArmorHUD() {
      int var1 = Managers.TEXT.scaledWidth;
      int var2 = Managers.TEXT.scaledHeight;
      GlStateManager.enableTexture2D();
      int var3 = var1 / 2;
      int var4 = 0;
      int var10000 = var2 - 55;
      byte var10001;
      if (mc.player.isInWater() && mc.playerController.gameIsSurvivalOrAdventure()) {
         var10001 = 10;
         boolean var10002 = false;
      } else {
         var10001 = 0;
      }

      int var5 = var10000 - var10001;

      for(ItemStack var7 : mc.player.inventory.armorInventory) {
         ++var4;
         if (var7.isEmpty()) {
            boolean var13 = false;
         } else {
            int var8 = var3 - 90 + (9 - var4) * 20 + 2;
            GlStateManager.enableDepth();
            mc.getRenderItem().zLevel = 200.0F;
            mc.getRenderItem().renderItemAndEffectIntoGUI(var7, var8, var5);
            mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, var7, var8, var5, "");
            mc.getRenderItem().zLevel = 0.0F;
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            String var14;
            if (var7.getCount() > 1) {
               var14 = String.valueOf(var7.getCount());
               boolean var16 = false;
            } else {
               var14 = "";
            }

            String var9 = var14;
            Managers.TEXT.drawStringWithShadow(var9, (float)(var8 + 19 - 2 - Managers.TEXT.getStringWidth(var9)), (float)(var5 + 9), 16777215);
            float var11 = ((float)var7.getMaxDamage() - (float)var7.getItemDamage()) / (float)var7.getMaxDamage();
            float var12 = 1.0F - var11;
            int var10 = 100 - (int)(var12 * 100.0F);
            Managers.TEXT
               .drawStringWithShadow(
                  String.valueOf(var10),
                  (float)(var8 + 8) - (float)Managers.TEXT.getStringWidth(String.valueOf(var10)) / 2.0F,
                  (float)(var5 - 11),
                  ColorUtil.toRGBA((int)(var12 * 255.0F), (int)(var11 * 255.0F), 0)
               );
            boolean var15 = false;
         }
      }

      GlStateManager.enableDepth();
      GlStateManager.disableLighting();
   }

   private boolean lambda$new$20(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$12(String var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.watermark.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$29(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private void drawDoubleRainbowRollingString(String var1, String var2, float var3, float var4) {
      Managers.TEXT.drawRollingRainbowString(var1, var3, var4, true);
      Managers.TEXT.drawString(var2, var3 + (float)Managers.TEXT.getStringWidth(var1), var4, -1, true);
      boolean var10000 = false;
   }

   private boolean lambda$new$32(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS && this.arrayList.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$16(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == HUD.Page.ELEMENTS) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static enum GreeterMode {
      CUSTOM,
      PLAYER;
      private static final HUD.GreeterMode[] $VALUES = new HUD.GreeterMode[]{HUD.GreeterMode.PLAYER, CUSTOM};
   }

   private static enum Page {
      ELEMENTS,
      GLOBAL;

      private static final HUD.Page[] $VALUES = new HUD.Page[]{ELEMENTS, GLOBAL};
   }
}
