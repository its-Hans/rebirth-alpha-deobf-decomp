package me.rebirthclient.mod.modules.impl.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import me.rebirthclient.api.events.impl.ClientEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.mod.commands.Command;
import me.rebirthclient.mod.gui.screen.Gui;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClickGui extends Module {
   public final Setting<Boolean> rollingLine;
   public final Setting<Float> rainbowSaturation;
   public final Setting<ClickGui.Style> style;
   public final Setting<Boolean> snow;
   public final Setting<Color> color;
   public final Setting<Boolean> colorParticles;
   public final Setting<Integer> height;
   public final Setting<Boolean> rainbow;
   public final Setting<Boolean> icon;
   public final Setting<ClickGui.Rainbow> rainbowMode;
   public static ClickGui INSTANCE;
   public final Setting<Color> secondColor;
   public final Setting<Boolean> blur;
   public final Setting<Boolean> gear;
   public final Setting<Integer> rainbowDelay;
   public final Setting<Boolean> colorRect;
   public final Setting<Boolean> disableSave;
   public final Setting<Boolean> cleanGui;
   public final Setting<Integer> rainbowSpeed;
   public final Setting<Boolean> background;
   public final Setting<Boolean> rect;
   public final Setting<String> prefix = this.add(new Setting<>("Prefix", ";"));
   public final Setting<Boolean> line;
   private final Setting<Integer> animationTime;
   public final Setting<ClickGui.HudRainbow> hudRainbow;
   public final Setting<Boolean> particles;
   public static FadeUtils animation = new FadeUtils(500L);

   private boolean lambda$new$0(Boolean var1) {
      return this.line.isOpen();
   }

   private boolean lambda$new$1(Boolean var1) {
      return this.rect.isOpen();
   }

   private boolean lambda$new$7(Integer var1) {
      return this.rainbow.isOpen();
   }

   private boolean lambda$new$4(Float var1) {
      boolean var10000;
      if (this.rainbow.isOpen() && this.rainbowMode.getValue() == ClickGui.Rainbow.NORMAL) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onTick() {
      if (!(mc.currentScreen instanceof Gui) && !(mc.currentScreen instanceof GuiMainMenu)) {
         this.disable();
      }
   }

   @SubscribeEvent
   public void onSettingChange(ClientEvent var1) {
      if (!fullNullCheck()) {
         if (var1.getStage() == 2 && var1.getSetting().getMod().equals(this)) {
            if (var1.getSetting().equals(this.prefix)) {
               Managers.COMMANDS.setPrefix(this.prefix.getPlannedValue());
               Command.sendMessage(
                  String.valueOf(new StringBuilder().append("Prefix set to ").append(ChatFormatting.DARK_GRAY).append(Managers.COMMANDS.getCommandPrefix()))
               );
            }

            Managers.COLORS.setCurrent(this.color.getValue());
         }
      }
   }

   private boolean lambda$new$5(Color var1) {
      boolean var10000;
      if (this.rainbow.isOpen() && this.rainbowMode.getValue() == ClickGui.Rainbow.DOUBLE) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      return this.particles.isOpen();
   }

   private boolean lambda$new$6(ClickGui.HudRainbow var1) {
      return this.rainbow.isOpen();
   }

   private boolean lambda$new$3(ClickGui.Rainbow var1) {
      return this.rainbow.isOpen();
   }

   @Override
   public void onLoad() {
      Managers.COLORS.setCurrent(this.color.getValue());
      Managers.COMMANDS.setPrefix(this.prefix.getValue());
   }

   private boolean lambda$new$8(Integer var1) {
      return this.rainbow.isOpen();
   }

   @Override
   public void onDisable() {
      if (this.disableSave.getValue()) {
         Managers.CONFIGS.saveConfig(Managers.CONFIGS.config.replaceFirst("Rebirth/", ""));
      }
   }

   @Override
   public void onEnable() {
      animation.setLength((long)this.animationTime.getValue().intValue());
      animation.reset();
      if (mc.world != null) {
         mc.displayGuiScreen(Gui.INSTANCE);
      }

      if (this.blur.getValue()) {
         mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
      }
   }

   public ClickGui() {
      super("ClickGui", "Opens the ClickGui", Category.CLIENT);
      this.disableSave = this.add(new Setting<>("DisableSave", true));
      this.style = this.add(new Setting<>("Style", ClickGui.Style.NEW));
      this.height = this.add(new Setting<>("ButtonHeight", 4, 1, 5));
      this.blur = this.add(new Setting<>("Blur", false));
      this.line = this.add(new Setting<>("Line", true).setParent());
      this.rollingLine = this.add(new Setting<>("RollingLine", true, this::lambda$new$0));
      this.rect = this.add(new Setting<>("Rect", true).setParent());
      this.colorRect = this.add(new Setting<>("ColorRect", false, this::lambda$new$1));
      this.gear = this.add(new Setting<>("Gear", true));
      this.icon = this.add(new Setting<>("Icon", true));
      this.animationTime = this.add(new Setting<>("AnimationTime", 500, 0, 2000));
      this.snow = this.add(new Setting<>("Snow", true));
      this.particles = this.add(new Setting<>("Particles", false).setParent());
      this.colorParticles = this.add(new Setting<>("ColorParticles", true, this::lambda$new$2));
      this.background = this.add(new Setting<>("Background", true));
      this.cleanGui = this.add(new Setting<>("CleanGui", false));
      this.color = this.add(new Setting<>("Color", new Color(125, 125, 213)).hideAlpha().noRainbow());
      this.rainbow = this.add(new Setting<>("Rainbow", false).setParent());
      this.rainbowMode = this.add(new Setting<>("Mode", ClickGui.Rainbow.NORMAL, this::lambda$new$3));
      this.rainbowSaturation = this.add(new Setting<>("Saturation", 130.0F, 1.0F, 255.0F, this::lambda$new$4));
      this.secondColor = this.add(new Setting<>("SecondColor", new Color(255, 255, 255), this::lambda$new$5).hideAlpha());
      this.hudRainbow = this.add(new Setting<>("HUD", ClickGui.HudRainbow.STATIC, this::lambda$new$6));
      this.rainbowDelay = this.add(new Setting<>("Delay", 350, 0, 600, this::lambda$new$7));
      this.rainbowSpeed = this.add(new Setting<>("Speed", 350, 0, 600, this::lambda$new$8));
      INSTANCE = this;
   }

   public int getButtonHeight() {
      return 11 + this.height.getValue();
   }

   public static enum HudRainbow {
      STATIC,
      ROLLING;

      private static final ClickGui.HudRainbow[] $VALUES = new ClickGui.HudRainbow[]{STATIC, ROLLING};
   }

   public static enum Rainbow {
      NORMAL,
      DOUBLE,
      PLAIN;
      private static final ClickGui.Rainbow[] $VALUES = new ClickGui.Rainbow[]{ClickGui.Rainbow.NORMAL, ClickGui.Rainbow.PLAIN, ClickGui.Rainbow.DOUBLE};
   }

   public static enum Style {
      DOTGOD,
      NEW,
      FUTURE,
      OLD;
      private static final ClickGui.Style[] $VALUES = new ClickGui.Style[]{
         ClickGui.Style.OLD, ClickGui.Style.NEW, ClickGui.Style.FUTURE, ClickGui.Style.DOTGOD
      };
   }
}
