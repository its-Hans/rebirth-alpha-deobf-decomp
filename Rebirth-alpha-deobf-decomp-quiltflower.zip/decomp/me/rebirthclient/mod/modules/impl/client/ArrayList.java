package me.rebirthclient.mod.modules.impl.client;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.rebirthclient.api.events.impl.ClientEvent;
import me.rebirthclient.api.events.impl.Render2DEvent;
import me.rebirthclient.api.managers.Managers;
import me.rebirthclient.api.managers.impl.TextManager;
import me.rebirthclient.api.util.FadeUtils;
import me.rebirthclient.api.util.Timer;
import me.rebirthclient.api.util.render.ColorUtil;
import me.rebirthclient.api.util.render.RenderUtil;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;

public class ArrayList extends Module {
   private List<ArrayList.Modules> Map;
   private final Setting<Boolean> animationY;
   private final Setting<Integer> animationTime;
   private final Setting<Boolean> onlyDrawn;
   private final Setting<Integer> listY;
   private boolean needUpdate;
   public final Setting<Integer> rainbowDelay;
   private final Setting<Float> saturation;
   private final Setting<Boolean> bgSync;
   private final Setting<Integer> listX = this.add(new Setting<>("X", 0, 0, 2000));
   private final Setting<Boolean> reverse;
   private final Setting<Boolean> forgeHax;
   int pulseProgress;
   int progress;
   private final Setting<Boolean> rect;
   private final Timer updateTimer;
   private final Setting<Boolean> fps;
   private final Setting<Integer> pulseSpeed;
   private final Setting<Color> color;
   private final Setting<Boolean> onlyBind;
   public final Setting<ArrayList.ColorMode> colorMode;
   private final Setting<Color> bgColor;
   private final Setting<Integer> rainbowSpeed;
   private final Setting<Boolean> backGround;

   private boolean lambda$new$2(Integer var1) {
      boolean var10000;
      if (this.colorMode.getValue() != ArrayList.ColorMode.Pulse && this.colorMode.getValue() != ArrayList.ColorMode.PulseRainbow) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Float var1) {
      boolean var10000;
      if (this.colorMode.getValue() != ArrayList.ColorMode.Rainbow && this.colorMode.getValue() != ArrayList.ColorMode.PulseRainbow) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   private boolean lambda$new$6(Color var1) {
      return this.backGround.isOpen();
   }

   @SubscribeEvent
   public void clientEvent(ClientEvent var1) {
      if (this.updateTimer.passedMs(5000L)) {
         this.updateTimer.reset();
         boolean var10000 = false;
         this.needUpdate = true;
      }
   }

   private Color rainbow(int var1) {
      double var2 = Math.ceil((double)(this.progress + var1 * this.rainbowDelay.getValue()) / 20.0);
      if (this.colorMode.getValue() == ArrayList.ColorMode.Pulse) {
         return this.pulseColor(this.color.getValue(), var1);
      } else {
         return this.colorMode.getValue() == ArrayList.ColorMode.Rainbow
            ? Color.getHSBColor((float)(var2 % 360.0 / 360.0), this.saturation.getValue() / 255.0F, 1.0F)
            : this.pulseColor(Color.getHSBColor((float)(var2 % 360.0 / 360.0), this.saturation.getValue() / 255.0F, 1.0F), var1);
      }
   }

   private boolean lambda$new$5(Boolean var1) {
      return this.backGround.isOpen();
   }

   private void doRender() {
      if (!fullNullCheck()) {
         if (this.needUpdate) {
            this.Map = this.Map.stream().sorted(Comparator.comparing(ArrayList::lambda$doRender$7)).collect(Collectors.toList());
         }

         int var1 = this.listY.getValue();
         int var2 = 20;

         for(ArrayList.Modules var4 : this.Map) {
            if (!var4.module.isDrawn() && this.onlyDrawn.getValue()) {
               boolean var32 = false;
            } else if (this.onlyBind.getValue() && var4.module.getBind().getKey() == -1) {
               boolean var31 = false;
            } else {
               var4.fade.setLength((long)this.animationTime.getValue().intValue());
               if (var4.module.isOn()) {
                  var4.enable();
                  boolean var10000 = false;
               } else {
                  var4.disable();
               }

               var4.updateName();
               int var5;
               int var6;
               if (!this.reverse.getValue()) {
                  if (var4.isEnabled) {
                     double var7 = var4.fade.easeOutQuad();
                     var5 = (int)(
                        (double)Managers.TEXT
                              .getStringWidth(String.valueOf(new StringBuilder().append(var4.module.getArrayListInfo()).append(this.getSuffix())))
                           * var7
                     );
                     var6 = (int)((double)Managers.TEXT.getFontHeight2() * var7);
                     var4.lastY = var6;
                     var4.lastX = var5;
                     boolean var16 = false;
                  } else {
                     double var11 = Math.abs(var4.fade.easeOutQuad() - 1.0);
                     var5 = (int)((double)var4.lastX * var11);
                     var6 = (int)((double)var4.lastY * var11);
                     if (var11 <= 0.0) {
                        boolean var17 = false;
                        continue;
                     }
                  }
               } else if (var4.isEnabled) {
                  double var12 = Math.abs(var4.fade.easeOutQuad() - 1.0);
                  var5 = (int)(
                     (double)Managers.TEXT.getStringWidth(String.valueOf(new StringBuilder().append(var4.module.getArrayListInfo()).append(this.getSuffix())))
                        * var12
                  );
                  var12 = var4.fade.easeOutQuad();
                  var6 = (int)((double)Managers.TEXT.getFontHeight2() * var12);
                  var4.lastY = var6;
                  var4.lastX = var5;
                  boolean var18 = false;
               } else {
                  double var14 = var4.fade.easeOutQuad();
                  var5 = (int)(
                        (double)Managers.TEXT
                              .getStringWidth(String.valueOf(new StringBuilder().append(var4.module.getArrayListInfo()).append(this.getSuffix())))
                           * var14
                     )
                     + var4.lastX;
                  var14 = Math.abs(var4.fade.easeOutQuad() - 1.0);
                  var6 = (int)((double)var4.lastY * var14);
                  if (var14 <= 0.0) {
                     boolean var30 = false;
                     continue;
                  }

                  if (var5
                     >= Managers.TEXT.getStringWidth(String.valueOf(new StringBuilder().append(var4.module.getArrayListInfo()).append(this.getSuffix())))) {
                     boolean var29 = false;
                     continue;
                  }
               }

               var5 = (int)((double)var5 + 20.0 * Math.abs(var4.change.easeOutQuad() - 1.0));
               ++var2;
               int var9;
               if (!this.reverse.getValue()) {
                  int var19 = Managers.TEXT.scaledWidth - var5 - this.listX.getValue();
                  byte var10001;
                  if (this.rect.getValue()) {
                     var10001 = 2;
                     boolean var10002 = false;
                  } else {
                     var10001 = 0;
                  }

                  var9 = var19 - var10001;
                  if (this.backGround.getValue()) {
                     float var20 = (float)var9;
                     int var39;
                     if (this.animationY.getValue()) {
                        var39 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var10003 = false;
                     } else {
                        var39 = 0;
                     }

                     float var33 = (float)(var1 - var39 - 1);
                     float var40 = (float)(Managers.TEXT.scaledWidth - this.listX.getValue());
                     int var10004;
                     if (this.animationY.getValue()) {
                        var10004 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var10005 = false;
                     } else {
                        var10004 = 0;
                     }

                     float var50 = (float)(var1 - var10004 + Managers.TEXT.getFontHeight2() - 1);
                     if (this.bgSync.getValue()) {
                        var10004 = ColorUtil.injectAlpha(this.getColor(var2), this.bgColor.getValue().getAlpha());
                        boolean var63 = false;
                     } else {
                        var10004 = this.bgColor.getValue().getRGB();
                     }

                     RenderUtil.drawRect(var20, var33, var40, var50, var10004);
                  }

                  if (this.rect.getValue()) {
                     float var21 = (float)(Managers.TEXT.scaledWidth - this.listX.getValue() - 1);
                     int var41;
                     if (this.animationY.getValue()) {
                        var41 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var51 = false;
                     } else {
                        var41 = 0;
                     }

                     float var34 = (float)(var1 - var41 - 1);
                     float var42 = (float)(Managers.TEXT.scaledWidth - this.listX.getValue());
                     int var57;
                     if (this.animationY.getValue()) {
                        var57 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var64 = false;
                     } else {
                        var57 = 0;
                     }

                     RenderUtil.drawRect(var21, var34, var42, (float)(var1 - var57 + Managers.TEXT.getFontHeight2()), this.getColor(var2));
                     boolean var22 = false;
                  }
               } else {
                  int var23 = -var5 + this.listX.getValue();
                  byte var35;
                  if (this.rect.getValue()) {
                     var35 = 2;
                     boolean var43 = false;
                  } else {
                     var35 = 0;
                  }

                  var9 = var23 + var35;
                  if (this.rect.getValue()) {
                     float var24 = (float)this.listX.getValue().intValue();
                     int var44;
                     if (this.animationY.getValue()) {
                        var44 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var52 = false;
                     } else {
                        var44 = 0;
                     }

                     float var36 = (float)(var1 - var44 - 1);
                     float var45 = (float)(this.listX.getValue() + 1);
                     int var58;
                     if (this.animationY.getValue()) {
                        var58 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var65 = false;
                     } else {
                        var58 = 0;
                     }

                     RenderUtil.drawRect(var24, var36, var45, (float)(var1 - var58 + Managers.TEXT.getFontHeight2() - 1), this.getColor(var2));
                  }

                  if (this.backGround.getValue()) {
                     float var25 = (float)this.listX.getValue().intValue();
                     int var46;
                     if (this.animationY.getValue()) {
                        var46 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var53 = false;
                     } else {
                        var46 = 0;
                     }

                     float var37 = (float)(var1 - var46 - 1);
                     var46 = Math.abs(
                        var5
                           - Managers.TEXT.getStringWidth(String.valueOf(new StringBuilder().append(var4.module.getArrayListInfo()).append(this.getSuffix())))
                     );
                     byte var54;
                     if (this.rect.getValue()) {
                        var54 = 2;
                        boolean var59 = false;
                     } else {
                        var54 = 0;
                     }

                     float var48 = (float)(var46 + var54);
                     int var60;
                     if (this.animationY.getValue()) {
                        var60 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                        boolean var66 = false;
                     } else {
                        var60 = 0;
                     }

                     float var55 = (float)(var1 - var60 + Managers.TEXT.getFontHeight2() - 1);
                     if (this.bgSync.getValue()) {
                        var60 = ColorUtil.injectAlpha(this.getColor(var2), this.bgColor.getValue().getAlpha());
                        boolean var67 = false;
                     } else {
                        var60 = this.bgColor.getValue().getRGB();
                     }

                     RenderUtil.drawRect(var25, var37, var48, var55, var60);
                  }
               }

               TextManager var26 = Managers.TEXT;
               String var38 = String.valueOf(new StringBuilder().append(var4.module.getArrayListInfo()).append(this.getSuffix()));
               float var49 = (float)var9;
               int var62;
               if (this.animationY.getValue()) {
                  var62 = Math.abs(var6 - Managers.TEXT.getFontHeight2());
                  boolean var68 = false;
               } else {
                  var62 = 0;
               }

               var26.drawString(var38, var49, (float)(var1 - var62), this.getColor(var2), true);
               boolean var27 = false;
               var1 += var6;
               boolean var28 = false;
            }
         }
      }
   }

   private Color pulseColor(Color var1, int var2) {
      float[] var3 = new float[3];
      Color.RGBtoHSB(var1.getRed(), var1.getGreen(), var1.getBlue(), var3);
      boolean var10000 = false;
      float var4 = Math.abs(
         (
                  (float)((long)this.pulseProgress % 2000L) / Float.intBitsToFloat(Float.floatToIntBits(0.0013786979F) ^ 2127476077)
                     + (float)var2 / 14.0F * Float.intBitsToFloat(Float.floatToIntBits(0.09192204F) ^ 2109489567)
               )
               % Float.intBitsToFloat(Float.floatToIntBits(0.7858098F) ^ 2135501525)
            - Float.intBitsToFloat(Float.floatToIntBits(6.46708F) ^ 2135880274)
      );
      var4 = Float.intBitsToFloat(Float.floatToIntBits(18.996923F) ^ 2123889075) + Float.intBitsToFloat(Float.floatToIntBits(2.7958195F) ^ 2134044341) * var4;
      var3[2] = var4 % Float.intBitsToFloat(Float.floatToIntBits(0.8992331F) ^ 2137404452);
      return new Color(Color.HSBtoRGB(var3[0], var3[1], var3[2]));
   }

   @Override
   public void onTick() {
      this.progress += this.rainbowSpeed.getValue();
      this.pulseProgress += this.pulseSpeed.getValue();
   }

   private String getSuffix() {
      return this.forgeHax.getValue() ? "§r<" : "";
   }

   @Override
   public void onLoad() {
      for(Module var2 : Managers.MODULES.getModules()) {
         this.Map.add(new ArrayList.Modules(var2));
         boolean var10000 = false;
         var10000 = false;
      }
   }

   private int getColor(int var1) {
      return this.colorMode.getValue() != ArrayList.ColorMode.Custom ? this.rainbow(var1).getRGB() : this.color.getValue().getRGB();
   }

   @Override
   public void onLogin() {
      this.needUpdate = true;
   }

   public ArrayList() {
      super("ArrayList", "", Category.CLIENT);
      this.listY = this.add(new Setting<>("Y", 10, 1, 2000));
      this.animationTime = this.add(new Setting<>("AnimationTime", 300, 0, 1000));
      this.forgeHax = this.add(new Setting<>("ForgeHax", true));
      this.reverse = this.add(new Setting<>("Reverse", false));
      this.fps = this.add(new Setting<>("Fps", true));
      this.onlyDrawn = this.add(new Setting<>("OnlyDrawn", true));
      this.onlyBind = this.add(new Setting<>("OnlyBind", false));
      this.animationY = this.add(new Setting<>("AnimationY", true));
      this.colorMode = this.add(new Setting<>("ColorMode", ArrayList.ColorMode.Pulse));
      this.rainbowSpeed = this.register(new Setting<>("RainbowSpeed", 200, 1, 400, this::lambda$new$0));
      this.saturation = this.register(new Setting<>("Saturation", 130.0F, 1.0F, 255.0F, this::lambda$new$1));
      this.pulseSpeed = this.register(new Setting<>("PulseSpeed", 100, 1, 400, this::lambda$new$2));
      this.rainbowDelay = this.add(new Setting<>("Delay", 350, 0, 600, this::lambda$new$3));
      this.color = this.add(new Setting<>("Color", new Color(255, 255, 255, 255), this::lambda$new$4).hideAlpha());
      this.rect = this.add(new Setting<>("Rect", true));
      this.backGround = this.add(new Setting<>("BackGround", true).setParent());
      this.bgSync = this.add(new Setting<>("Sync", false, this::lambda$new$5));
      this.bgColor = this.add(new Setting<>("BGColor", new Color(0, 0, 0, 100), this::lambda$new$6));
      this.Map = new java.util.ArrayList<>();
      this.updateTimer = new Timer();
      this.needUpdate = false;
      this.progress = 0;
      this.pulseProgress = 0;
   }

   @Override
   public void onRender2D(Render2DEvent var1) {
      if (this.fps.getValue()) {
         this.doRender();
      }
   }

   private static Integer lambda$doRender$7(ArrayList.Modules var0) {
      return Managers.TEXT.getStringWidth(var0.module.getArrayListInfo()) * -1;
   }

   private boolean lambda$new$4(Color var1) {
      boolean var10000;
      if (this.colorMode.getValue() != ArrayList.ColorMode.Rainbow) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Integer var1) {
      boolean var10000;
      if (this.colorMode.getValue() != ArrayList.ColorMode.Rainbow && this.colorMode.getValue() != ArrayList.ColorMode.PulseRainbow) {
         var10000 = false;
      } else {
         var10000 = true;
         boolean var10001 = false;
      }

      return var10000;
   }

   @SubscribeEvent
   public void onRender(RenderTickEvent var1) {
      if (!this.fps.getValue()) {
         this.doRender();
      }
   }

   private boolean lambda$new$3(Integer var1) {
      boolean var10000;
      if (this.colorMode.getValue() == ArrayList.ColorMode.Rainbow) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private static enum ColorMode {
      Custom,
      PulseRainbow,
      Pulse,
      Rainbow;
      private static final ArrayList.ColorMode[] $VALUES = new ArrayList.ColorMode[]{Custom, Pulse, ArrayList.ColorMode.Rainbow, PulseRainbow};
   }

   public static class Modules {
      public String lastName;
      public final FadeUtils fade;
      public int lastX;
      public boolean isEnabled = false;
      public final FadeUtils change;
      public int lastY;
      public Module module;

      public void disable() {
         if (this.isEnabled) {
            this.isEnabled = false;
            this.fade.reset();
         }
      }

      public void updateName() {
         String var10000 = this.lastName;
         if (!Integer.valueOf(this.module.getArrayListInfo().hashCode()).equals(var10000.hashCode())) {
            this.lastName = this.module.getArrayListInfo();
            this.change.reset();
         }
      }

      public void enable() {
         if (!this.isEnabled) {
            this.isEnabled = true;
            this.fade.reset();
         }
      }

      public Modules(Module var1) {
         this.lastX = 0;
         this.lastY = 0;
         this.module = var1;
         this.fade = new FadeUtils(500L);
         this.change = new FadeUtils(200L);
         this.lastName = var1.getArrayListInfo();
      }
   }
}
