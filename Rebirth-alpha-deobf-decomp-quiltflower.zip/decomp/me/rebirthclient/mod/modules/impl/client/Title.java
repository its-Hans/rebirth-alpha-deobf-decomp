package me.rebirthclient.mod.modules.impl.client;

import me.rebirthclient.api.util.Timer;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import org.lwjgl.opengl.Display;

public class Title extends Module {
   public final Setting<String> title = this.add(new Setting<>("Title", "Rebirth alpha"));
   private static int titleLength = 0;
   public final Setting<Integer> updateTime;
   public final Setting<Boolean> animation = this.add(new Setting<>("Animation", true).setParent());
   private static String lastTitle;
   public static Title INSTANCE = new Title();
   private static boolean original = false;
   private static boolean back = false;
   private static int breakTimer = 0;
   private static final Timer updateTimer = new Timer();

   public Title() {
      super("Title", "Change client title", Category.CLIENT);
      this.updateTime = this.add(new Setting<>("updateTime", 300, 0, 1000, this::lambda$new$0));
      INSTANCE = this;
   }

   public static void updateTitle() {
      if (!original) {
         Display.setTitle("Minecraft 1.12.2");
         original = true;
      }

      if (!INSTANCE.isOff()) {
         if (lastTitle != null) {
            String var10000 = lastTitle;
            if (!Integer.valueOf(INSTANCE.title.getValue().hashCode()).equals(var10000.hashCode())) {
               updateTimer.reset();
               titleLength = 0;
               breakTimer = 0;
               back = false;
            }
         }

         lastTitle = INSTANCE.title.getValue();
         if (INSTANCE.animation.getValue()) {
            if (lastTitle != null && updateTimer.passedMs((long)INSTANCE.updateTime.getValue().intValue())) {
               updateTimer.reset();
               boolean var0 = false;
               Display.setTitle(lastTitle.substring(0, lastTitle.length() - titleLength));
               if (titleLength == lastTitle.length() && breakTimer != 2 || titleLength == 0 && breakTimer != 4) {
                  ++breakTimer;
                  return;
               }

               breakTimer = 0;
               if (titleLength == lastTitle.length()) {
                  back = true;
               }

               if (back) {
                  --titleLength;
                  var0 = false;
               } else {
                  ++titleLength;
               }

               if (titleLength == 0) {
                  back = false;
                  var0 = false;
               }
            }
         } else {
            Display.setTitle(lastTitle);
         }
      }
   }

   private boolean lambda$new$0(Integer var1) {
      return this.animation.isOpen();
   }

   @Override
   public void onDisable() {
      Display.setTitle("Minecraft 1.12.2");
   }
}
