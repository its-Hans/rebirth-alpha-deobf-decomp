package me.rebirthclient.mod.modules.impl.client;

import me.rebirthclient.api.events.impl.Render3DEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.client.settings.GameSettings.Options;

public class FakeFPS extends Module {
   int lastFps;
   public final Setting<Integer> times = this.add(new Setting<>("times", 5, 1, 100));
   public static FakeFPS INSTANCE;

   @Override
   public void onRender3D(Render3DEvent var1) {
      Minecraft var10000 = Minecraft.getMinecraft();
      Object[] var10002 = new Object[]{Minecraft.getDebugFPS(), RenderChunk.renderChunksUpdated, null, null, null, null, null, null};
      String var10005;
      if (RenderChunk.renderChunksUpdated == 1) {
         var10005 = "";
         boolean var10006 = false;
      } else {
         var10005 = "s";
      }

      var10002[2] = var10005;
      if ((float)Minecraft.getMinecraft().gameSettings.limitFramerate == Options.FRAMERATE_LIMIT.getValueMax()) {
         var10005 = "inf";
         boolean var7 = false;
      } else {
         var10005 = Minecraft.getMinecraft().gameSettings.limitFramerate;
      }

      var10002[3] = var10005;
      if (Minecraft.getMinecraft().gameSettings.enableVsync) {
         var10005 = " vsync";
         boolean var8 = false;
      } else {
         var10005 = "";
      }

      var10002[4] = var10005;
      if (Minecraft.getMinecraft().gameSettings.fancyGraphics) {
         var10005 = "";
         boolean var9 = false;
      } else {
         var10005 = " fast";
      }

      var10002[5] = var10005;
      if (Minecraft.getMinecraft().gameSettings.clouds == 0) {
         var10005 = "";
         boolean var10 = false;
      } else if (Minecraft.getMinecraft().gameSettings.clouds == 1) {
         var10005 = " fast-clouds";
         boolean var11 = false;
      } else {
         var10005 = " fancy-clouds";
      }

      var10002[6] = var10005;
      if (OpenGlHelper.useVbo()) {
         var10005 = " vbo";
         boolean var12 = false;
      } else {
         var10005 = "";
      }

      var10002[7] = var10005;
      var10000.debug = String.format("%d fps (%d chunk update%s) T: %s%s%s%s%s", var10002);
      if (Minecraft.getDebugFPS() != this.lastFps) {
         Minecraft.debugFPS *= this.times.getValue();
         this.lastFps = Minecraft.getDebugFPS();
      }
   }

   public FakeFPS() {
      super("FakeFPS", "FakeFPS", Category.CLIENT);
      this.lastFps = 0;
      INSTANCE = this;
   }
}
