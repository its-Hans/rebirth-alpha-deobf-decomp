package me.rebirthclient.mod.modules.impl.client;

import me.rebirthclient.api.events.impl.PerspectiveEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.init.MobEffects;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FovMod extends Module {
   private final Setting<Float> aspectFactor;
   private final Setting<Float> sprint;
   private final Setting<Boolean> defaults;
   private final Setting<Boolean> aspectRatio;
   private final Setting<Boolean> customFov;
   private final Setting<Float> fov;
   private final Setting<Float> speed;
   private final Setting<FovMod.Page> page = this.add(new Setting<>("Settings", FovMod.Page.FOV));
   public static FovMod INSTANCE = new FovMod();

   @SubscribeEvent
   public void onPerspectiveUpdate(PerspectiveEvent var1) {
      if (!fullNullCheck()) {
         if (this.aspectRatio.getValue()) {
            var1.setAngle(this.aspectFactor.getValue());
         }
      }
   }

   private boolean lambda$new$3(Float var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.FOV && this.aspectRatio.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$4(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$1(Float var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.FOV && this.customFov.isOpen()) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$0(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.FOV) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$5(Float var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   @Override
   public void onUpdate() {
      if (this.customFov.getValue()) {
         mc.gameSettings.setOptionFloatValue(Options.FOV, this.fov.getValue());
      }

      if (this.defaults.getValue()) {
         this.sprint.setValue(1.15F);
         this.speed.setValue(1.15F);
         this.defaults.setValue(false);
      }
   }

   public FovMod() {
      super("FovMod", "FOV modifier", Category.CLIENT);
      this.customFov = this.add(new Setting<>("CustomFov", false, this::lambda$new$0).setParent());
      this.fov = this.add(new Setting<>("FOV", 120.0F, 10.0F, 180.0F, this::lambda$new$1));
      this.aspectRatio = this.add(new Setting<>("AspectRatio", false, this::lambda$new$2).setParent());
      this.aspectFactor = this.add(new Setting<>("AspectFactor", 1.8F, 0.1F, 3.0F, this::lambda$new$3));
      this.defaults = this.add(new Setting<>("Defaults", false, this::lambda$new$4));
      this.sprint = this.add(new Setting<>("SprintAdd", 1.15F, 1.0F, 2.0F, this::lambda$new$5));
      this.speed = this.add(new Setting<>("SwiftnessAdd", 1.15F, 1.0F, 2.0F, this::lambda$new$6));
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onFOVUpdate(FOVUpdateEvent var1) {
      if (!fullNullCheck()) {
         float var2 = 1.0F;
         if (var1.getEntity().isSprinting()) {
            var2 = this.sprint.getValue();
            if (var1.getEntity().isPotionActive(MobEffects.SPEED)) {
               var2 = this.speed.getValue();
            }
         }

         var1.setNewfov(var2);
      }
   }

   private boolean lambda$new$6(Float var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.ADVANCED) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   private boolean lambda$new$2(Boolean var1) {
      boolean var10000;
      if (this.page.getValue() == FovMod.Page.FOV) {
         var10000 = true;
         boolean var10001 = false;
      } else {
         var10000 = false;
      }

      return var10000;
   }

   public static enum Page {
      ADVANCED,
      FOV;
      private static final FovMod.Page[] $VALUES = new FovMod.Page[]{FovMod.Page.FOV, ADVANCED};
   }
}
