package me.rebirthclient.mod.modules.impl.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;
import me.rebirthclient.api.events.impl.PacketEvent;
import me.rebirthclient.mod.modules.Category;
import me.rebirthclient.mod.modules.Module;
import me.rebirthclient.mod.modules.settings.Setting;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Chat extends Module {
   public final Setting<Chat.Bracket> bracket;
   public static Chat INSTANCE;
   public final Setting<Boolean> colorRect;
   public final Setting<Boolean> infinite;
   public final Setting<Boolean> time;
   private final Setting<String> suffixString;
   public final Setting<Color> color;
   public final Setting<Boolean> animation = this.add(new Setting<>("Animation", true));
   public final Setting<Boolean> suffix;
   public final Setting<Boolean> rect = this.add(new Setting<>("Rect", true).setParent());

   private boolean lambda$new$2(Chat.Bracket var1) {
      return this.time.isOpen();
   }

   public Chat() {
      super("Chat", "Modifies your chat", Category.CLIENT);
      this.colorRect = this.add(new Setting<>("ColorRect", false, this::lambda$new$0));
      this.infinite = this.add(new Setting<>("InfiniteChat", true));
      this.suffix = this.add(new Setting<>("Suffix", false).setParent());
      this.suffixString = this.add(new Setting<>("suffixString", "| NewRebirth", this::lambda$new$1));
      this.time = this.add(new Setting<>("TimeStamps", false).setParent());
      this.bracket = this.add(new Setting<>("Bracket", Chat.Bracket.TRIANGLE, this::lambda$new$2));
      this.color = this.add(new Setting<>("Color", new Color(134, 173, 255, 255)).hideAlpha());
      INSTANCE = this;
   }

   private boolean lambda$new$0(Boolean var1) {
      return this.rect.isOpen();
   }

   private boolean lambda$new$1(String var1) {
      return this.suffix.isOpen();
   }

   @SubscribeEvent
   public void onPacketSend(PacketEvent.Send var1) {
      if (!fullNullCheck()) {
         if (this.suffix.getValue() && var1.getPacket() instanceof CPacketChatMessage) {
            CPacketChatMessage var2 = var1.getPacket();
            String var3 = var2.getMessage();
            if (var3.startsWith("/") || var3.startsWith("!") || var3.endsWith(this.suffixString.getValue())) {
               return;
            }

            var3 = String.valueOf(new StringBuilder().append(var3).append(" ").append(this.suffixString.getValue()));
            if (var3.length() >= 256) {
               var3 = var3.substring(0, 256);
            }

            var2.message = var3;
         }
      }
   }

   @SubscribeEvent
   public void onClientChatReceived(ClientChatReceivedEvent var1) {
      if (!fullNullCheck()) {
         if (this.time.getValue()) {
            Date var2 = new Date();
            SimpleDateFormat var3 = new SimpleDateFormat("HH:mm");
            String var4 = var3.format(var2);
            String var10000;
            if (this.bracket.getValue() == Chat.Bracket.TRIANGLE) {
               var10000 = "<";
               boolean var10001 = false;
            } else {
               var10000 = "[";
            }

            String var5 = var10000;
            if (this.bracket.getValue() == Chat.Bracket.TRIANGLE) {
               var10000 = ">";
               boolean var9 = false;
            } else {
               var10000 = "]";
            }

            String var6 = var10000;
            TextComponentString var7 = new TextComponentString(
               String.valueOf(
                  new StringBuilder()
                     .append(ChatFormatting.GRAY)
                     .append(var5)
                     .append(ChatFormatting.WHITE)
                     .append(var4)
                     .append(ChatFormatting.GRAY)
                     .append(var6)
                     .append(ChatFormatting.RESET)
                     .append(" ")
               )
            );
            var1.setMessage(var7.appendSibling(var1.getMessage()));
         }
      }
   }

   private static enum Bracket {
      SQUARE,
      TRIANGLE;

      private static final Chat.Bracket[] $VALUES = new Chat.Bracket[]{SQUARE, TRIANGLE};
   }
}
