package junit.framework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class TestResult {
   protected List<TestFailure> fFailures = new ArrayList<>();
   protected List<TestFailure> fErrors = new ArrayList<>();
   protected List<TestListener> fListeners = new ArrayList<>();
   protected int fRunTests = 0;
   private boolean fStop = false;

   public synchronized void addError(Test var1, Throwable var2) {
      this.fErrors.add(new TestFailure(var1, var2));

      for(TestListener var4 : this.cloneListeners()) {
         var4.addError(var1, var2);
      }
   }

   public synchronized void addFailure(Test var1, AssertionFailedError var2) {
      this.fFailures.add(new TestFailure(var1, var2));

      for(TestListener var4 : this.cloneListeners()) {
         var4.addFailure(var1, var2);
      }
   }

   public synchronized void addListener(TestListener var1) {
      this.fListeners.add(var1);
   }

   public synchronized void removeListener(TestListener var1) {
      this.fListeners.remove(var1);
   }

   private synchronized List<TestListener> cloneListeners() {
      ArrayList var1 = new ArrayList();
      var1.addAll(this.fListeners);
      return var1;
   }

   public void endTest(Test var1) {
      for(TestListener var3 : this.cloneListeners()) {
         var3.endTest(var1);
      }
   }

   public synchronized int errorCount() {
      return this.fErrors.size();
   }

   public synchronized Enumeration<TestFailure> errors() {
      return Collections.enumeration(this.fErrors);
   }

   public synchronized int failureCount() {
      return this.fFailures.size();
   }

   public synchronized Enumeration<TestFailure> failures() {
      return Collections.enumeration(this.fFailures);
   }

   protected void run(TestCase var1) {
      this.startTest(var1);
      Protectable var2 = new Protectable(this, var1) {
         final TestCase val$test;
         final TestResult this$0;

         {
            this.this$0 = var1;
            this.val$test = var2;
         }

         @Override
         public void protect() throws Throwable {
            this.val$test.runBare();
         }
      };
      this.runProtected(var1, var2);
      this.endTest(var1);
   }

   public synchronized int runCount() {
      return this.fRunTests;
   }

   public void runProtected(Test var1, Protectable var2) {
      Protectable var10000 = var2;

      try {
         var10000.protect();
      } catch (AssertionFailedError var4) {
         this.addFailure(var1, var4);
      } catch (Throwable | ThreadDeath var5) {
         throw var5;
      }
   }

   public synchronized boolean shouldStop() {
      return this.fStop;
   }

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   // $QF: Could not inline inconsistent finally blocks
   // $QF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public void startTest(Test var1) {
      int var2 = var1.countTestCases();
      TestResult var3 = this;
      synchronized(this){} // $QF: monitorenter 
      TestResult var10000 = this;
      TestResult var10001 = this;

      try {
         var10000.fRunTests = var10001.fRunTests + var2;
         // $QF: monitorexit
      } catch (Throwable var10) {
         Throwable var13 = var10;
         boolean var15 = false;

         while(true) {
            Throwable var4 = var13;
            var10000 = var3;

            try {
               // $QF: monitorexit
               throw var4;
            } catch (Throwable var9) {
               var13 = var9;
               boolean var16 = false;
               continue;
            }
         }
      }

      for(TestListener var12 : this.cloneListeners()) {
         var12.startTest(var1);
      }
   }

   public synchronized void stop() {
      this.fStop = true;
   }

   public synchronized boolean wasSuccessful() {
      return this.failureCount() == 0 && this.errorCount() == 0;
   }
}
