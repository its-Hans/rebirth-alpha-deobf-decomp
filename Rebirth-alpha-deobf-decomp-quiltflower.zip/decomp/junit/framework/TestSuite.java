package junit.framework;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class TestSuite implements Test {
   private String fName;
   private Vector<Test> fTests = new Vector<>(10);

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public static Test createTest(Class<?> var0, String var1) {
      Class var10000 = var0;

      Constructor var2;
      try {
         var2 = getTestConstructor(var10000);
      } catch (NoSuchMethodException var6) {
         boolean var10001 = false;
         return warning("Class " + var0.getName() + " has no public constructor TestCase(String name) or TestCase()");
      }

      Constructor var7 = var2;

      try {
         Object var3;
         if (var7.getParameterTypes().length == 0) {
            var3 = var2.newInstance();
            if (var3 instanceof TestCase) {
               ((TestCase)var3).setName(var1);
               return (Test)var3;
            }
         } else {
            var3 = var2.newInstance(var1);
         }

         return (Test)var3;
      } catch (InvocationTargetException | IllegalAccessException | InstantiationException var5) {
         boolean var8 = false;
         return warning("Class " + var0.getName() + " has no public constructor TestCase(String name) or TestCase()");
      }
   }

   public static Constructor<?> getTestConstructor(Class<?> var0) throws NoSuchMethodException {
      Class var10000 = var0;
      Class[] var10001 = new Class[]{String.class};

      try {
         return var10000.getConstructor(var10001);
      } catch (NoSuchMethodException var2) {
         return var0.getConstructor();
      }
   }

   public static Test warning(String var0) {
      return new TestCase("warning", var0) {
         final String val$message;

         {
            this.val$message = var2;
         }

         @Override
         protected void runTest() {
            fail(this.val$message);
         }
      };
   }

   private static String exceptionToString(Throwable var0) {
      StringWriter var1 = new StringWriter();
      PrintWriter var2 = new PrintWriter(var1);
      var0.printStackTrace(var2);
      return var1.toString();
   }

   public TestSuite() {
   }

   public TestSuite(Class<?> var1) {
      this.addTestsFromTestCase(var1);
   }

   private void addTestsFromTestCase(Class<?> var1) {
      this.fName = var1.getName();
      Class var10000 = var1;

      try {
         getTestConstructor(var10000);
      } catch (NoSuchMethodException var8) {
         this.addTest(warning("Class " + var1.getName() + " has no public constructor TestCase(String name) or TestCase()"));
         return;
      }

      if (!Modifier.isPublic(var1.getModifiers())) {
         this.addTest(warning("Class " + var1.getName() + " is not public"));
      } else {
         Class var2 = var1;

         for(ArrayList var3 = new ArrayList(); Test.class.isAssignableFrom(var2); var2 = var2.getSuperclass()) {
            for(Method var7 : var2.getDeclaredMethods()) {
               this.addTestMethod(var7, var3, var1);
            }
         }

         if (this.fTests.size() == 0) {
            this.addTest(warning("No tests found in " + var1.getName()));
         }
      }
   }

   public TestSuite(Class<? extends TestCase> var1, String var2) {
      this(var1);
      this.setName(var2);
   }

   public TestSuite(String var1) {
      this.setName(var1);
   }

   public TestSuite(Class<?>... var1) {
      for(Class var5 : var1) {
         this.addTest(this.testCaseForClass(var5));
      }
   }

   private Test testCaseForClass(Class<?> var1) {
      return (Test)(TestCase.class.isAssignableFrom(var1)
         ? new TestSuite(var1.asSubclass(TestCase.class))
         : warning(var1.getCanonicalName() + " does not extend TestCase"));
   }

   public TestSuite(Class<? extends TestCase>[] var1, String var2) {
      this(var1);
      this.setName(var2);
   }

   public void addTest(Test var1) {
      this.fTests.add(var1);
   }

   public void addTestSuite(Class<? extends TestCase> var1) {
      this.addTest(new TestSuite(var1));
   }

   @Override
   public int countTestCases() {
      int var1 = 0;

      for(Test var3 : this.fTests) {
         var1 += var3.countTestCases();
      }

      return var1;
   }

   public String getName() {
      return this.fName;
   }

   @Override
   public void run(TestResult var1) {
      for(Test var3 : this.fTests) {
         if (var1.shouldStop()) {
            break;
         }

         this.runTest(var3, var1);
      }
   }

   public void runTest(Test var1, TestResult var2) {
      var1.run(var2);
   }

   public void setName(String var1) {
      this.fName = var1;
   }

   public Test testAt(int var1) {
      return this.fTests.get(var1);
   }

   public int testCount() {
      return this.fTests.size();
   }

   public Enumeration<Test> tests() {
      return this.fTests.elements();
   }

   @Override
   public String toString() {
      return this.getName() != null ? this.getName() : super.toString();
   }

   private void addTestMethod(Method var1, List<String> var2, Class<?> var3) {
      String var4 = var1.getName();
      if (!var2.contains(var4)) {
         if (!this.isPublicTestMethod(var1)) {
            if (this.isTestMethod(var1)) {
               this.addTest(warning("Test method isn't public: " + var1.getName() + "(" + var3.getCanonicalName() + ")"));
            }
         } else {
            var2.add(var4);
            this.addTest(createTest(var3, var4));
         }
      }
   }

   private boolean isPublicTestMethod(Method var1) {
      return this.isTestMethod(var1) && Modifier.isPublic(var1.getModifiers());
   }

   private boolean isTestMethod(Method var1) {
      return var1.getParameterTypes().length == 0 && var1.getName().startsWith("test") && var1.getReturnType().equals(Void.TYPE);
   }
}
