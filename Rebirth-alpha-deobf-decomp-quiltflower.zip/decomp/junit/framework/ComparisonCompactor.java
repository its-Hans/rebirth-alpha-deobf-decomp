package junit.framework;

public class ComparisonCompactor {
   private static final String ELLIPSIS = "...";
   private static final String DELTA_END = "]";
   private static final String DELTA_START = "[";
   private int fContextLength;
   private String fExpected;
   private String fActual;
   private int fPrefix;
   private int fSuffix;

   public ComparisonCompactor(int var1, String var2, String var3) {
      this.fContextLength = var1;
      this.fExpected = var2;
      this.fActual = var3;
   }

   public String compact(String var1) {
      if (this.fExpected != null && this.fActual != null && !this.areStringsEqual()) {
         this.findCommonPrefix();
         this.findCommonSuffix();
         String var2 = this.compactString(this.fExpected);
         String var3 = this.compactString(this.fActual);
         return Assert.format(var1, var2, var3);
      } else {
         return Assert.format(var1, this.fExpected, this.fActual);
      }
   }

   private String compactString(String var1) {
      String var2 = "[" + var1.substring(this.fPrefix, var1.length() - this.fSuffix + 1) + "]";
      if (this.fPrefix > 0) {
         var2 = this.computeCommonPrefix() + var2;
      }

      if (this.fSuffix > 0) {
         var2 = var2 + this.computeCommonSuffix();
      }

      return var2;
   }

   private void findCommonPrefix() {
      this.fPrefix = 0;
      int var1 = Math.min(this.fExpected.length(), this.fActual.length());

      while(this.fPrefix < var1 && this.fExpected.charAt(this.fPrefix) == this.fActual.charAt(this.fPrefix)) {
         ++this.fPrefix;
      }
   }

   private void findCommonSuffix() {
      int var1 = this.fExpected.length() - 1;

      for(int var2 = this.fActual.length() - 1;
         var2 >= this.fPrefix && var1 >= this.fPrefix && this.fExpected.charAt(var1) == this.fActual.charAt(var2);
         --var1
      ) {
         --var2;
      }

      this.fSuffix = this.fExpected.length() - var1;
   }

   private String computeCommonPrefix() {
      return (this.fPrefix > this.fContextLength ? "..." : "") + this.fExpected.substring(Math.max(0, this.fPrefix - this.fContextLength), this.fPrefix);
   }

   private String computeCommonSuffix() {
      int var1 = Math.min(this.fExpected.length() - this.fSuffix + 1 + this.fContextLength, this.fExpected.length());
      return this.fExpected.substring(this.fExpected.length() - this.fSuffix + 1, var1)
         + (this.fExpected.length() - this.fSuffix + 1 < this.fExpected.length() - this.fContextLength ? "..." : "");
   }

   private boolean areStringsEqual() {
      return this.fExpected.equals(this.fActual);
   }
}
