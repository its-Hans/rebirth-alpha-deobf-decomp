package junit.framework;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public abstract class TestCase extends Assert implements Test {
   private String fName;

   public TestCase() {
      this.fName = null;
   }

   public TestCase(String var1) {
      this.fName = var1;
   }

   @Override
   public int countTestCases() {
      return 1;
   }

   protected TestResult createResult() {
      return new TestResult();
   }

   public TestResult run() {
      TestResult var1 = this.createResult();
      this.run(var1);
      return var1;
   }

   @Override
   public void run(TestResult var1) {
      var1.run(this);
   }

   // $QF: Could not verify finally blocks. A semaphore variable has been added to preserve control flow.
   // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public void runBare() throws Throwable {
      Throwable var1 = null;
      this.setUp();
      TestCase var10000 = this;
      boolean var10 = false /* QF: Semaphore variable */;

      label96: {
         label97: {
            Throwable var2;
            try {
               var10 = true;
               var10000.runTest();
               var10 = false;
               break label97;
            } catch (Throwable var14) {
               var2 = var14;
               var10 = false;
            } finally {
               if (var10) {
                  TestCase var10001 = this;

                  try {
                     var10001.tearDown();
                  } catch (Throwable var11) {
                     if (var1 == null) {
                        var1 = var11;
                     }
                  }
               }
            }

            var1 = var2;
            var10000 = this;

            try {
               var10000.tearDown();
            } catch (Throwable var12) {
               if (var2 == null) {
                  var1 = var12;
               }
            }
            break label96;
         }

         var10000 = this;

         try {
            var10000.tearDown();
         } catch (Throwable var13) {
            if (var1 == null) {
               var1 = var13;
            }
         }
      }

      if (var1 != null) {
         throw var1;
      }
   }

   protected void runTest() throws Throwable {
      assertNotNull("TestCase.fName cannot be null", this.fName);
      Method var1 = null;
      TestCase var10000 = this;

      try {
         var1 = var10000.getClass().getMethod(this.fName, null);
      } catch (NoSuchMethodException var4) {
         fail("Method \"" + this.fName + "\" not found");
      }

      if (!Modifier.isPublic(var1.getModifiers())) {
         fail("Method \"" + this.fName + "\" should be public");
      }

      Method var5 = var1;
      TestCase var10001 = this;
      Object[] var10002 = new Object[0];

      try {
         var5.invoke(var10001, var10002);
      } catch (IllegalAccessException | InvocationTargetException var3) {
         var3.fillInStackTrace();
         throw var3.getTargetException();
      }
   }

   protected void setUp() throws Exception {
   }

   protected void tearDown() throws Exception {
   }

   @Override
   public String toString() {
      return this.getName() + "(" + this.getClass().getName() + ")";
   }

   public String getName() {
      return this.fName;
   }

   public void setName(String var1) {
      this.fName = var1;
   }
}
