package junit.extensions;

interface package-info {
}
