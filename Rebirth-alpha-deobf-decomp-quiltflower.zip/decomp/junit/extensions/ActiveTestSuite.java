package junit.extensions;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestResult;
import junit.framework.TestSuite;

public class ActiveTestSuite extends TestSuite {
   private int fActiveTestDeathCount;

   public ActiveTestSuite() {
   }

   public ActiveTestSuite(Class<? extends TestCase> var1) {
      super(var1);
   }

   public ActiveTestSuite(String var1) {
      super(var1);
   }

   public ActiveTestSuite(Class<? extends TestCase> var1, String var2) {
      super(var1, var2);
   }

   @Override
   public void run(TestResult var1) {
      this.fActiveTestDeathCount = 0;
      super.run(var1);
      this.waitUntilFinished();
   }

   @Override
   public void runTest(Test var1, TestResult var2) {
      Thread var3 = new Thread(this, var1, var2) {
         final Test val$test;
         final TestResult val$result;
         final ActiveTestSuite this$0;

         {
            this.this$0 = var1;
            this.val$test = var2;
            this.val$result = var3;
         }

         // $QF: Could not properly define all variable types!
         // Please report this to the Quiltflower issue tracker, at https://github.com/QuiltMC/quiltflower/issues with a copy of the class file (if you have the rights to distribute it!)
         @Override
         public void run() {
            <undefinedtype> var10000 = this;

            try {
               var10000.val$test.run(this.val$result);
            } finally {
               this.this$0.runFinished();
            }
         }
      };
      var3.start();
   }

   synchronized void waitUntilFinished() {
      while(this.fActiveTestDeathCount < this.testCount()) {
         ActiveTestSuite var10000 = this;

         try {
            var10000.wait();
         } catch (InterruptedException var2) {
            return;
         }
      }
   }

   public synchronized void runFinished() {
      ++this.fActiveTestDeathCount;
      this.notifyAll();
   }
}
