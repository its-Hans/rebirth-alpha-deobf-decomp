package junit.runner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.NumberFormat;
import java.util.Properties;
import junit.framework.AssertionFailedError;
import junit.framework.Test;
import junit.framework.TestListener;

public abstract class BaseTestRunner implements TestListener {
   public static final String SUITE_METHODNAME = "suite";
   private static Properties fPreferences;
   static int fgMaxMessageLength = 500;
   static boolean fgFilterStack = true;
   boolean fLoading = true;

   @Override
   public synchronized void startTest(Test var1) {
      this.testStarted(var1.toString());
   }

   protected static void setPreferences(Properties var0) {
      fPreferences = var0;
   }

   protected static Properties getPreferences() {
      if (fPreferences == null) {
         fPreferences = new Properties();
         fPreferences.put("loading", "true");
         fPreferences.put("filterstack", "true");
         readPreferences();
      }

      return fPreferences;
   }

   public static void savePreferences() throws IOException {
      FileOutputStream var0 = new FileOutputStream(getPreferencesFile());

      try {
         getPreferences().store(var0, "");
      } finally {
         var0.close();
      }
   }

   public static void setPreference(String var0, String var1) {
      getPreferences().put(var0, var1);
   }

   @Override
   public synchronized void endTest(Test var1) {
      this.testEnded(var1.toString());
   }

   @Override
   public synchronized void addError(Test var1, Throwable var2) {
      this.testFailed(1, var1, var2);
   }

   @Override
   public synchronized void addFailure(Test var1, AssertionFailedError var2) {
      this.testFailed(2, var1, var2);
   }

   public abstract void testStarted(String var1);

   public abstract void testEnded(String var1);

   public abstract void testFailed(int var1, Test var2, Throwable var3);

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public Test getTest(String var1) {
      if (var1.length() <= 0) {
         this.clearStatus();
         return null;
      } else {
         Object var2 = null;
         BaseTestRunner var10000 = this;
         String var10001 = var1;

         label68: {
            label69: {
               ClassNotFoundException var3;
               try {
                  try {
                     var10 = var10000.loadSuiteClass(var10001);
                     break label69;
                  } catch (ClassNotFoundException var8) {
                     var3 = var8;
                  }
               } catch (Exception var9) {
                  var16 = var9;
                  boolean var19 = false;
                  break label68;
               }

               String var4 = var3.getMessage();
               if (var4 == null) {
                  var4 = var1;
               }

               this.runFailed("Class not found \"" + var4 + "\"");
               return null;
            }

            Object var11 = null;
            Class var17 = var10;
            var10001 = "suite";
            byte var10002 = 0;

            try {
               var12 = var17.getMethod(var10001);
            } catch (Exception var7) {
               var16 = var7;
               boolean var21 = false;
               break label68;
            }

            if (!Modifier.isStatic(var12.getModifiers())) {
               this.runFailed("Suite() method must be static");
               return null;
            }

            Test var14 = null;
            Method var18 = var12;
            var10001 = null;
            Class[] var24 = new Class[0];

            try {
               var14 = (Test)var18.invoke(var10001, var24);
               if (var14 == null) {
                  return var14;
               }
            } catch (IllegalAccessException | InvocationTargetException var6) {
               var16 = var6;
               boolean var23 = false;
               break label68;
            }

            this.clearStatus();
            return var14;
         }

         Object var13 = var16;
         this.runFailed("Error: " + var13.toString());
         return null;
      }
   }

   public String elapsedTimeAsString(long var1) {
      return NumberFormat.getInstance().format((double)var1 / 1000.0);
   }

   protected String processArguments(String[] var1) {
      String var2 = null;

      for(int var3 = 0; var3 < var1.length; ++var3) {
         if (var1[var3].equals("-noloading")) {
            this.setLoading(false);
         } else if (var1[var3].equals("-nofilterstack")) {
            fgFilterStack = false;
         } else if (var1[var3].equals("-c")) {
            if (var1.length > var3 + 1) {
               var2 = this.extractClassName(var1[var3 + 1]);
            } else {
               System.out.println("Missing Test class name");
            }

            ++var3;
         } else {
            var2 = var1[var3];
         }
      }

      return var2;
   }

   public void setLoading(boolean var1) {
      this.fLoading = var1;
   }

   public String extractClassName(String var1) {
      return var1.startsWith("Default package for") ? var1.substring(var1.lastIndexOf(".") + 1) : var1;
   }

   public static String truncate(String var0) {
      if (fgMaxMessageLength != -1 && var0.length() > fgMaxMessageLength) {
         var0 = var0.substring(0, fgMaxMessageLength) + "...";
      }

      return var0;
   }

   protected abstract void runFailed(String var1);

   protected Class<?> loadSuiteClass(String var1) throws ClassNotFoundException {
      return Class.forName(var1);
   }

   protected void clearStatus() {
   }

   protected boolean useReloadingTestSuiteLoader() {
      return getPreference("loading").equals("true") && this.fLoading;
   }

   private static File getPreferencesFile() {
      String var0 = System.getProperty("user.home");
      return new File(var0, "junit.properties");
   }

   private static void readPreferences() {
      FileInputStream var0 = null;
      FileInputStream var10000 = new FileInputStream;
      FileInputStream var10001 = var10000;

      try {
         var10001./* $QF: Unable to resugar constructor */<init>(getPreferencesFile());
         var0 = var10000;
         setPreferences(new Properties(getPreferences()));
         getPreferences().load(var0);
      } catch (IOException var4) {
         if (var0 != null) {
            var10000 = var0;

            try {
               var10000.close();
            } catch (IOException var3) {
            }
         }
      }
   }

   public static String getPreference(String var0) {
      return getPreferences().getProperty(var0);
   }

   public static int getPreference(String var0, int var1) {
      String var2 = getPreference(var0);
      int var3 = var1;
      if (var2 == null) {
         return var1;
      } else {
         String var10000 = var2;

         try {
            var3 = Integer.parseInt(var10000);
         } catch (NumberFormatException var5) {
         }

         return var3;
      }
   }

   public static String getFilteredTrace(Throwable var0) {
      StringWriter var1 = new StringWriter();
      PrintWriter var2 = new PrintWriter(var1);
      var0.printStackTrace(var2);
      StringBuffer var3 = var1.getBuffer();
      String var4 = var3.toString();
      return getFilteredTrace(var4);
   }

   public static String getFilteredTrace(String var0) {
      if (showStackRaw()) {
         return var0;
      } else {
         StringWriter var1 = new StringWriter();
         PrintWriter var2 = new PrintWriter(var1);
         StringReader var3 = new StringReader(var0);
         BufferedReader var4 = new BufferedReader(var3);

         while(true) {
            BufferedReader var10000 = var4;

            try {
               String var5 = var10000.readLine();
               if (var5 == null) {
                  return var1.toString();
               }

               if (!filterLine(var5)) {
                  var2.println(var5);
               }
            } catch (Exception var7) {
               return var0;
            }
         }
      }
   }

   protected static boolean showStackRaw() {
      return !getPreference("filterstack").equals("true") || !fgFilterStack;
   }

   static boolean filterLine(String var0) {
      String[] var1 = new String[]{
         "junit.framework.TestCase",
         "junit.framework.TestResult",
         "junit.framework.TestSuite",
         "junit.framework.Assert.",
         "junit.swingui.TestRunner",
         "junit.awtui.TestRunner",
         "junit.textui.TestRunner",
         "java.lang.reflect.Method.invoke("
      };

      for(int var2 = 0; var2 < var1.length; ++var2) {
         if (var0.indexOf(var1[var2]) > 0) {
            return true;
         }
      }

      return false;
   }

   static {
      fgMaxMessageLength = getPreference("maxmessage", fgMaxMessageLength);
   }
}
