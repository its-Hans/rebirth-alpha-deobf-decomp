package junit.textui;

import java.io.InputStream;
import java.io.PrintStream;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestResult;
import junit.framework.TestSuite;
import junit.runner.BaseTestRunner;
import junit.runner.Version;

public class TestRunner extends BaseTestRunner {
   private ResultPrinter fPrinter;
   public static final int SUCCESS_EXIT = 0;
   public static final int FAILURE_EXIT = 1;
   public static final int EXCEPTION_EXIT = 2;

   public TestRunner() {
      this(System.out);
   }

   public TestRunner(PrintStream var1) {
      this(new ResultPrinter(var1));
   }

   public TestRunner(ResultPrinter var1) {
      this.fPrinter = var1;
   }

   public static void run(Class<? extends TestCase> var0) {
      run(new TestSuite(var0));
   }

   public static TestResult run(Test var0) {
      TestRunner var1 = new TestRunner();
      return var1.doRun(var0);
   }

   public static void runAndWait(Test var0) {
      TestRunner var1 = new TestRunner();
      var1.doRun(var0, true);
   }

   @Override
   public void testFailed(int var1, Test var2, Throwable var3) {
   }

   @Override
   public void testStarted(String var1) {
   }

   @Override
   public void testEnded(String var1) {
   }

   protected TestResult createTestResult() {
      return new TestResult();
   }

   public TestResult doRun(Test var1) {
      return this.doRun(var1, false);
   }

   public TestResult doRun(Test var1, boolean var2) {
      TestResult var3 = this.createTestResult();
      var3.addListener(this.fPrinter);
      long var4 = System.currentTimeMillis();
      var1.run(var3);
      long var6 = System.currentTimeMillis();
      long var8 = var6 - var4;
      this.fPrinter.print(var3, var8);
      this.pause(var2);
      return var3;
   }

   protected void pause(boolean var1) {
      if (var1) {
         this.fPrinter.printWaitPrompt();
         InputStream var10000 = System.in;

         try {
            var10000.read();
         } catch (Exception var3) {
         }
      }
   }

   public static void main(String[] var0) {
      TestRunner var1 = new TestRunner();
      TestRunner var10000 = var1;
      String[] var10001 = var0;

      try {
         TestResult var2 = var10000.start(var10001);
         if (!var2.wasSuccessful()) {
            System.exit(1);
         }

         System.exit(0);
      } catch (Exception var3) {
         System.err.println(var3.getMessage());
         System.exit(2);
      }
   }

   // $QF: Inserted dummy exception handlers to handle obfuscated exceptions
   public TestResult start(String[] var1) throws Exception {
      String var2 = "";
      String var3 = "";
      boolean var4 = false;

      for(int var5 = 0; var5 < var1.length; ++var5) {
         if (var1[var5].equals("-wait")) {
            var4 = true;
         } else if (var1[var5].equals("-c")) {
            var2 = this.extractClassName(var1[++var5]);
         } else if (var1[var5].equals("-m")) {
            String var6 = var1[++var5];
            int var7 = var6.lastIndexOf(46);
            var2 = var6.substring(0, var7);
            var3 = var6.substring(var7 + 1);
         } else if (var1[var5].equals("-v")) {
            System.err.println("JUnit " + Version.id() + " by Kent Beck and Erich Gamma");
         } else {
            var2 = var1[var5];
         }
      }

      if (var2.equals("")) {
         throw new Exception("Usage: TestRunner [-wait] testCaseName, where name is the name of the TestCase class");
      } else {
         String var10000 = var3;
         String var10001 = "";

         label58: {
            try {
               if (!var10000.equals(var10001)) {
                  return this.runSingleMethod(var2, var3, var4);
               }
            } catch (Exception var9) {
               var12 = var9;
               boolean var14 = false;
               break label58;
            }

            TestRunner var13 = this;
            var10001 = var2;

            try {
               Test var11 = var13.getTest(var10001);
               return this.doRun(var11, var4);
            } catch (Exception var8) {
               var12 = var8;
               boolean var16 = false;
            }
         }

         Exception var10 = var12;
         throw new Exception("Could not create and run test suite: " + var10);
      }
   }

   protected TestResult runSingleMethod(String var1, String var2, boolean var3) throws Exception {
      Class var4 = this.loadSuiteClass(var1).asSubclass(TestCase.class);
      Test var5 = TestSuite.createTest(var4, var2);
      return this.doRun(var5, var3);
   }

   @Override
   protected void runFailed(String var1) {
      System.err.println(var1);
      System.exit(1);
   }

   public void setPrinter(ResultPrinter var1) {
      this.fPrinter = var1;
   }
}
