package junit.textui;

interface package-info {
}
